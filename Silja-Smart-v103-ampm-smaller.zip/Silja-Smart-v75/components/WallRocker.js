// مفتاح حائط ذكي (Rocker): لوحة بإطار ومفتاح بيتقلب فوق/تحت بحركة ثلاثية الأبعاد.
// فوق (I) = شغال: النص العلوي بيتنوّر بلون الجهاز ومعاه نقطة LED مضيئة وهالة ناعمة.
// تحت (O) = مطفي: النص السفلي هو اللي بيبقى بارز. الحركة بتقف مع "حركة أقل".
import React, { useEffect, useRef } from 'react';
import { View, Animated, Easing, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { withAlpha } from '../colorUtils';
import { useMotionActive } from '../ThemeContext';

export default function WallRocker({ isOn, onColor, theme, width = 58, pending = false }) {
  const height = Math.round(width * 1.6);
  const tilt = useRef(new Animated.Value(isOn ? 1 : 0)).current;
  const breath = useRef(new Animated.Value(0)).current;
  const motion = useMotionActive();

  useEffect(() => {
    Animated.spring(tilt, { toValue: isOn ? 1 : 0, friction: 6, tension: 140, useNativeDriver: true }).start();
  }, [isOn, tilt]);

  useEffect(() => {
    if (!isOn || !motion) { breath.stopAnimation(); breath.setValue(isOn ? 0.5 : 0); return undefined; }
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(breath, { toValue: 1, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(breath, { toValue: 0, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [isOn, motion, breath]);

  const dark = !theme.isLight;
  const plate = dark ? ['#2B333F', '#151A21'] : ['#FFFFFF', '#E3E7EE'];
  const muted = dark ? 'rgba(255,255,255,0.38)' : 'rgba(20,30,45,0.38)';
  const pad = Math.max(5, Math.round(width * 0.1));
  const paddleW = width - pad * 2;
  const paddleH = height - pad * 2;
  const rot = tilt.interpolate({ inputRange: [0, 1], outputRange: ['9deg', '-9deg'] });

  const topLit = isOn;
  const topColors = topLit
    ? [withAlpha(onColor, 0.62), withAlpha(onColor, 0.22)]
    : (dark ? ['rgba(0,0,0,0.38)', 'rgba(0,0,0,0.22)'] : ['rgba(0,0,0,0.10)', 'rgba(0,0,0,0.05)']);
  const botColors = !topLit
    ? (dark ? ['rgba(255,255,255,0.16)', 'rgba(255,255,255,0.05)'] : ['rgba(255,255,255,0.95)', 'rgba(255,255,255,0.55)'])
    : (dark ? ['rgba(0,0,0,0.38)', 'rgba(0,0,0,0.22)'] : ['rgba(0,0,0,0.10)', 'rgba(0,0,0,0.05)']);

  return (
    <View style={{ width: width + 24, height: height + 24, alignItems: 'center', justifyContent: 'center' }}>
      {isOn && (
        <Animated.View
          pointerEvents="none"
          style={{
            position: 'absolute', width: width + 22, height: height + 22, borderRadius: 24, backgroundColor: onColor,
            opacity: breath.interpolate({ inputRange: [0, 1], outputRange: [0.1, 0.24] }),
          }}
        />
      )}
      <LinearGradient
        colors={plate}
        start={{ x: 0.2, y: 0 }}
        end={{ x: 0.8, y: 1 }}
        style={{
          width, height, borderRadius: 14, padding: pad, borderWidth: 1,
          borderColor: dark ? 'rgba(255,255,255,0.10)' : 'rgba(0,0,0,0.10)', opacity: pending ? 0.65 : 1,
        }}
      >
        <Animated.View
          style={{
            width: paddleW, height: paddleH, borderRadius: 9, overflow: 'hidden',
            borderWidth: 1, borderColor: dark ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.12)',
            transform: [{ perspective: 380 }, { rotateX: rot }],
          }}
        >
          <LinearGradient colors={topColors} style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <View style={{ width: 3, height: Math.round(paddleH * 0.2), borderRadius: 2, backgroundColor: topLit ? '#FFFFFF' : muted }} />
          </LinearGradient>
          <View style={{ height: StyleSheet.hairlineWidth * 2, backgroundColor: dark ? 'rgba(255,255,255,0.22)' : 'rgba(0,0,0,0.2)' }} />
          <LinearGradient colors={botColors} style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
            <View style={{ width: Math.round(paddleH * 0.17), height: Math.round(paddleH * 0.17), borderRadius: 20, borderWidth: 2, borderColor: topLit ? muted : (theme.off || muted) }} />
          </LinearGradient>
        </Animated.View>
      </LinearGradient>
      {/* نقطة LED فوق اللوحة */}
      <View
        style={{
          position: 'absolute', top: 6, width: 6, height: 6, borderRadius: 3,
          backgroundColor: isOn ? onColor : (dark ? 'rgba(255,255,255,0.18)' : 'rgba(0,0,0,0.18)'),
        }}
      />
    </View>
  );
}
