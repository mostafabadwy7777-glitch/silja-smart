// تعريف كل الثيمات (الأشكال اللونية) المتاحة في التطبيق.
// كل ثيم بيحدد ألوان الخلفية، الكروت، النصوص، ولون حالتي التشغيل/الإيقاف الافتراضيين.
// أي مفتاح ينفع يستخدم لون مختلف عن الافتراضي (onColor / offColor) لو المستخدم اختار كده بنفسه.

export const THEMES = [
  {
    id: 'forest',
    name: 'أخضر ليلي',
    bg: '#0f1712',
    card: '#151f1a',
    cardAlt: '#182420',
    border: '#22302a',
    textPrimary: '#ffffff',
    textSecondary: '#8fa398',
    textMuted: '#5f7268',
    accent: '#2e7d4f',
    accentSoft: '#7fd88f',
    on: '#3ddc84',
    off: '#e05656',
    danger: '#c0392b',
  },
  {
    id: 'neon-blue',
    name: 'أزرق نيون',
    bg: '#0a1420',
    card: '#0f1e2e',
    cardAlt: '#122436',
    border: '#1c3a52',
    textPrimary: '#ffffff',
    textSecondary: '#7fa8c9',
    textMuted: '#4d7291',
    accent: '#2f7fd6',
    accentSoft: '#7fc4ff',
    on: '#38d1ff',
    off: '#ff5a6e',
    danger: '#c0392b',
  },
  {
    id: 'violet',
    name: 'بنفسجي ملكي',
    bg: '#150f20',
    card: '#1e1730',
    cardAlt: '#241c3a',
    border: '#352a4e',
    textPrimary: '#ffffff',
    textSecondary: '#b39ddb',
    textMuted: '#7e6a99',
    accent: '#7b4fd6',
    accentSoft: '#c9a6ff',
    on: '#b388ff',
    off: '#ff6e8f',
    danger: '#c0392b',
  },
  {
    id: 'sunset',
    name: 'برتقالي دافئ',
    bg: '#1c1209',
    card: '#26190d',
    cardAlt: '#2e1f11',
    border: '#4a3319',
    textPrimary: '#fff8f0',
    textSecondary: '#e0a978',
    textMuted: '#9c7350',
    accent: '#e07b28',
    accentSoft: '#ffb066',
    on: '#ffb347',
    off: '#e05656',
    danger: '#c0392b',
  },
  {
    id: 'ruby',
    name: 'أحمر ناري',
    bg: '#1a0c0c',
    card: '#241111',
    cardAlt: '#2c1414',
    border: '#4a1f1f',
    textPrimary: '#fff0f0',
    textSecondary: '#e08a8a',
    textMuted: '#9c5c5c',
    accent: '#c0392b',
    accentSoft: '#ff8a8a',
    on: '#ff6b5b',
    off: '#5f6b73',
    danger: '#c0392b',
  },
  {
    id: 'daylight',
    name: 'فاتح نهاري',
    bg: '#f2f5f3',
    card: '#ffffff',
    cardAlt: '#eef2ef',
    border: '#dde5e0',
    textPrimary: '#0f1712',
    textSecondary: '#516358',
    textMuted: '#8a988f',
    accent: '#2e7d4f',
    accentSoft: '#1fa35c',
    on: '#1fa35c',
    off: '#d9463f',
    danger: '#c0392b',
  },
];

// باليتة ألوان جاهزة يقدر المستخدم يختار منها لكل مفتاح (لون التشغيل ولون الإيقاف بشكل منفصل)
export const COLOR_SWATCHES = [
  '#3ddc84', // أخضر
  '#38d1ff', // سماوي
  '#4f8cff', // أزرق
  '#b388ff', // بنفسجي
  '#ff6fb5', // وردي
  '#ffb347', // برتقالي
  '#ffdd57', // أصفر
  '#ff6b5b', // أحمر فاتح
  '#e05656', // أحمر
  '#ffffff', // أبيض
];

export const DEFAULT_THEME_ID = 'forest';

export function getTheme(id) {
  return THEMES.find((t) => t.id === id) || THEMES[0];
}
