/**
 * Runs AFTER `expo prebuild --platform android`.
 * Injects a release signingConfig into android/app/build.gradle that reads
 * the keystore path/password from environment variables, and wires
 * buildTypes.release to use it. This makes local `gradlew` builds in CI
 * produce an app signed with the SAME key every time (required so Android
 * treats a new build as an update instead of a conflicting app).
 */
const fs = require("fs");
const path = require("path");

const gradlePath = path.join(__dirname, "..", "android", "app", "build.gradle");
let content = fs.readFileSync(gradlePath, "utf8");

if (content.includes("SILJA_RELEASE_SIGNING")) {
  console.log("Signing config already present, skipping.");
  process.exit(0);
}

const signingConfigBlock = `
    // SILJA_RELEASE_SIGNING - injected by scripts/apply-android-signing.js
    signingConfigs {
        release {
            if (System.getenv("SILJA_KEYSTORE_PATH")) {
                storeFile file(System.getenv("SILJA_KEYSTORE_PATH"))
                storePassword System.getenv("SILJA_KEYSTORE_PASSWORD")
                keyAlias System.getenv("SILJA_KEY_ALIAS")
                keyPassword System.getenv("SILJA_KEYSTORE_PASSWORD")
            }
        }
    }
`;

// Insert signingConfigs block right after "android {"
content = content.replace(
  /android\s*\{/,
  (match) => `${match}\n${signingConfigBlock}`
);

// Point release buildType at the new signingConfig
content = content.replace(
  /buildTypes\s*\{\s*release\s*\{([^}]*)\}/,
  (match, inner) => {
    if (inner.includes("signingConfig")) {
      return match.replace(/signingConfig\s+signingConfigs\.\w+/, "signingConfig signingConfigs.release");
    }
    return match.replace(inner, `${inner}\n            signingConfig signingConfigs.release`);
  }
);

fs.writeFileSync(gradlePath, content);
console.log("Injected release signingConfig into build.gradle");
