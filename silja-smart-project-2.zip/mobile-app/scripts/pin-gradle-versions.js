/**
 * Runs AFTER `expo prebuild`. Pins the Gradle wrapper / Android Gradle
 * Plugin / Kotlin versions to the minimums Expo SDK 51 (expo ~51, RN 0.74.5)
 * actually requires:
 *   Gradle 8.10.2, AGP 8.2.1, Kotlin 1.9.24
 *
 * Without this, a fresh `npm install` can resolve a newer/older AGP or
 * Gradle than expo-modules-core's build script expects, which surfaces as
 * the confusing "Plugin [id: 'expo-module-gradle-plugin'] was not found" /
 * "unknown property 'release'" failure instead of a clear version error.
 */
const fs = require("fs");
const path = require("path");

const androidRoot = path.join(__dirname, "..", "android");

// 1. Gradle wrapper version
const wrapperPropsPath = path.join(
  androidRoot,
  "gradle",
  "wrapper",
  "gradle-wrapper.properties"
);
if (fs.existsSync(wrapperPropsPath)) {
  let content = fs.readFileSync(wrapperPropsPath, "utf8");
  content = content.replace(
    /distributionUrl=.*/,
    "distributionUrl=https\\://services.gradle.org/distributions/gradle-8.10.2-all.zip"
  );
  fs.writeFileSync(wrapperPropsPath, content);
  console.log("Pinned Gradle wrapper to 8.10.2");
} else {
  console.warn(`${wrapperPropsPath} not found, skipping Gradle wrapper pin.`);
}

// 2. Android Gradle Plugin (AGP) + Kotlin versions in android/build.gradle
const buildGradlePath = path.join(androidRoot, "build.gradle");
if (fs.existsSync(buildGradlePath)) {
  let content = fs.readFileSync(buildGradlePath, "utf8");

  // com.android.tools.build:gradle:X.Y.Z  ->  8.2.1
  content = content.replace(
    /(com\.android\.tools\.build:gradle:)[^"'\s)]+/,
    "$18.2.1"
  );

  // org.jetbrains.kotlin:kotlin-gradle-plugin:X.Y.Z -> 1.9.24
  content = content.replace(
    /(org\.jetbrains\.kotlin:kotlin-gradle-plugin:)[^"'\s)]+/,
    "$11.9.24"
  );

  // kotlinVersion = "X.Y.Z" (ext block) -> 1.9.24
  content = content.replace(
    /(kotlinVersion\s*=\s*["'])[^"']+(["'])/,
    "$11.9.24$2"
  );

  fs.writeFileSync(buildGradlePath, content);
  console.log("Pinned AGP to 8.2.1 and Kotlin to 1.9.24 in android/build.gradle");
} else {
  console.warn(`${buildGradlePath} not found, skipping AGP/Kotlin pin.`);
}
