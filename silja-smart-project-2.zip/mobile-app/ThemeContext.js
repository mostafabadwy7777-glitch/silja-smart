import React, { createContext, useContext, useEffect, useState } from 'react';
import { DEFAULT_THEME_ID, getTheme } from './theme';
import { loadThemeId, saveThemeId } from './storage';

const ThemeContext = createContext({
  theme: getTheme(DEFAULT_THEME_ID),
  themeId: DEFAULT_THEME_ID,
  setThemeId: () => {},
});

export function ThemeProvider({ children }) {
  const [themeId, setThemeIdState] = useState(DEFAULT_THEME_ID);

  useEffect(() => {
    (async () => {
      const saved = await loadThemeId();
      if (saved) setThemeIdState(saved);
    })();
  }, []);

  const setThemeId = async (id) => {
    setThemeIdState(id);
    await saveThemeId(id);
  };

  const theme = getTheme(themeId);

  return (
    <ThemeContext.Provider value={{ theme, themeId, setThemeId }}>
      {children}
    </ThemeContext.Provider>
  );
}

// Hook بسيط عشان أي شاشة تاخد الثيم الحالي وتقدر تغيّره
export function useTheme() {
  return useContext(ThemeContext);
}
