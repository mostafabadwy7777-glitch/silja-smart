import React, { useEffect, useRef, useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, TextInput, TouchableOpacity, StyleSheet, StatusBar, Alert } from 'react-native';
import mqtt from 'mqtt';
import {
  DEFAULT_SETTINGS,
  loadSettings,
  saveSettings,
  loadBoards,
  saveBoards,
  loadPairingKey,
  savePairingKey,
  loadScenes,
  saveScenes,
  loadPushEnabled,
  savePushEnabled,
  newId,
} from './storage';
import { ThemeProvider, useTheme } from './ThemeContext';
import { registerForPushNotificationsAsync, unregisterPushNotifications } from './notifications';
import BoardsListScreen from './screens/BoardsListScreen';
import SwitchesScreen from './screens/SwitchesScreen';
import IrrigationScreen from './screens/IrrigationScreen';
import ThemeScreen from './screens/ThemeScreen';
import ScenesScreen from './screens/ScenesScreen';
import HistoryScreen from './screens/HistoryScreen';
import BackupScreen from './screens/BackupScreen';

export default function App() {
  return (
    <ThemeProvider>
      <AppInner />
    </ThemeProvider>
  );
}

function AppInner() {
  const { theme } = useTheme();
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [pairingKey, setPairingKey] = useState('');
  const [boards, setBoards] = useState([]);
  const [scenes, setScenes] = useState([]);
  const [pushEnabled, setPushEnabled] = useState(false);
  const [ready, setReady] = useState(false);
  const [screen, setScreen] = useState('settings'); // settings | boards | board | theme | scenes | history | backup
  const [activeBoard, setActiveBoard] = useState(null);
  const [connected, setConnected] = useState(false);

  const clientRef = useRef(null);

  // ---------- تحميل البيانات المحفوظة ----------
  // بيرجع true لو فيه إعدادات سيرفر + مفتاح ربط محفوظين (يعني التطبيق "مظبوط").
  const loadAllFromStorage = async () => {
    const savedSettings = await loadSettings();
    const savedBoards = await loadBoards();
    const savedPairingKey = await loadPairingKey();
    const savedScenes = await loadScenes();
    const savedPushEnabled = await loadPushEnabled();
    const configured = !!(savedSettings && savedPairingKey);
    if (savedSettings) setSettings(savedSettings);
    setPairingKey(savedPairingKey);
    setBoards(savedBoards);
    setScenes(savedScenes);
    setPushEnabled(savedPushEnabled);
    return configured;
  };

  useEffect(() => {
    (async () => {
      const configured = await loadAllFromStorage();
      if (configured) setScreen('boards');
      setReady(true);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // بعد استيراد نسخة احتياطية، نعيد تحميل كل حاجة من التخزين المحلي على طول
  // (بدل ما نستنى إعادة تشغيل التطبيق) ونرجع لشاشة البوردات أو الإعدادات
  // حسب لو فيه سيرفر ومفتاح ربط اتحفظوا في النسخة اللي اتستوردت.
  const handleBackupImported = async () => {
    const configured = await loadAllFromStorage();
    setActiveBoard(null);
    setScreen(configured ? 'boards' : 'settings');
  };

  // ---------- اتصال MQTT واحد مشترك لكل البوردات ----------
  useEffect(() => {
    if (!ready || screen === 'settings' || !settings.host) return undefined;

    const url = `${settings.protocol}://${settings.host}:${settings.port}${settings.path}`;
    const client = mqtt.connect(url, {
      clientId: 'iot-app-' + Math.random().toString(16).slice(2, 10),
      username: settings.username || undefined,
      password: settings.password || undefined,
      reconnectPeriod: 3000,
      connectTimeout: 8000,
    });
    clientRef.current = client;

    client.on('connect', () => {
      setConnected(true);
      // كل ما نتصل (أو نعيد الاتصال)، لو الإشعارات مفعّلة نعيد نشر التوكن Retained
      // عشان سيرفر الإشعارات يفضل عارفه حتى لو البروكر أعاد تشغيل أو مسح الحالة.
      if (pushEnabled) registerForPushNotificationsAsync(client);
    });
    client.on('reconnect', () => setConnected(false));
    client.on('close', () => setConnected(false));
    client.on('error', (err) => console.log('MQTT error:', err.message));

    return () => client.end(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, screen, settings]);

  const persistSettings = async (s) => {
    setSettings(s);
    await saveSettings(s);
  };

  const persistPairingKey = async (k) => {
    setPairingKey(k);
    await savePairingKey(k);
  };

  const persistBoards = async (list) => {
    setBoards(list);
    await saveBoards(list);
  };

  const persistScenes = async (list) => {
    setScenes(list);
    await saveScenes(list);
  };

  const togglePush = async () => {
    if (pushEnabled) {
      await unregisterPushNotifications(clientRef.current);
      setPushEnabled(false);
      await savePushEnabled(false);
      return;
    }
    const res = await registerForPushNotificationsAsync(clientRef.current);
    if (!res.ok) {
      Alert.alert('الإشعارات', res.error || 'حصل خطأ');
      return;
    }
    setPushEnabled(true);
    await savePushEnabled(true);
    Alert.alert(
      'اتفعّلت',
      'التوكن اتنشر على البروكر. لازم سيرفر الإشعارات (server/) يكون شغال عشان الإشعارات توصلك فعليًا وقت التطبيق مقفول.'
    );
  };

  const addBoard = (board) => persistBoards([...boards, { ...board, id: newId() }]);
  const deleteBoard = (id) => persistBoards(boards.filter((b) => b.id !== id));
  const updateBoard = (updated) => {
    setActiveBoard(updated);
    persistBoards(boards.map((b) => (b.id === updated.id ? updated : b)));
  };

  // ---------- شاشة إعدادات الاتصال ----------
  if (screen === 'settings') {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
        <StatusBar barStyle={theme.id === 'daylight' ? 'dark-content' : 'light-content'} />
        <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
          <Text style={[styles.title, { color: theme.textPrimary }]}>إعدادات الاتصال بالسيرفر</Text>
          <Text style={[styles.hint, { color: theme.textSecondary }]}>
            بيانات البروكر (WebSocket) دي بتتشارك بين كل البوردات. كل بورد بعد كده بيتضاف تلقائي عن طريق الاكتشاف من الفيرموير.
          </Text>

          <Field label="Protocol" value={settings.protocol} onChange={(v) => setSettings({ ...settings, protocol: v })} placeholder="ws أو wss" />
          <Field label="Host" value={settings.host} onChange={(v) => setSettings({ ...settings, host: v })} placeholder="broker.example.com" />
          <Field label="WebSocket Port" value={settings.port} onChange={(v) => setSettings({ ...settings, port: v })} placeholder="8884" keyboardType="numeric" />
          <Field label="Path" value={settings.path} onChange={(v) => setSettings({ ...settings, path: v })} placeholder="/mqtt" />
          <Field label="Username" value={settings.username} onChange={(v) => setSettings({ ...settings, username: v })} />
          <Field label="Password" value={settings.password} onChange={(v) => setSettings({ ...settings, password: v })} secure />

          <View style={{ height: 8 }} />
          <Text style={[styles.title, { color: theme.textPrimary, fontSize: 16 }]}>مفتاح الربط (Pairing Key)</Text>
          <Text style={[styles.hint, { color: theme.textSecondary }]}>
            سر خاص بيك بس — حطّه هنا وحط نفس القيمة بالظبط في كود الفيرموير بتاعك. أي بورد بيبعت رسالة اكتشاف بدون
            توقيع متطابق مع المفتاح ده هيترفض تلقائيًا، فالتطبيق مش هيشتغل غير مع فيرموير انت اللي عملته. اختار قيمة
            طويلة وعشوائية (مش سهلة التخمين) واحتفظ بيها في مكان آمن.
          </Text>
          <Field
            label="Pairing Key"
            value={pairingKey}
            onChange={setPairingKey}
            placeholder="مثال: a94f7c1e9d2b4a6f-my-secret"
            secure
          />

          <TouchableOpacity
            style={[styles.primaryBtn, { backgroundColor: theme.accent }]}
            onPress={async () => {
              if (!settings.host) {
                Alert.alert('خطأ', 'لازم تدخل عنوان السيرفر (Host)');
                return;
              }
              if (!pairingKey.trim()) {
                Alert.alert('خطأ', 'لازم تحط مفتاح ربط (Pairing Key) عشان الاكتشاف يشتغل بأمان');
                return;
              }
              await persistSettings(settings);
              await persistPairingKey(pairingKey.trim());
              setScreen('boards');
            }}
          >
            <Text style={styles.btnText}>حفظ ومتابعة</Text>
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView>
    );
  }

  // ---------- شاشة الثيمات / المظهر ----------
  if (screen === 'theme') {
    return <ThemeScreen onBack={() => setScreen('boards')} />;
  }

  // ---------- شاشة المشاهد (Scenes/Groups) ----------
  if (screen === 'scenes') {
    return (
      <ScenesScreen
        boards={boards}
        scenes={scenes}
        onSaveScenes={persistScenes}
        client={clientRef.current}
        connected={connected}
        onBack={() => setScreen('boards')}
      />
    );
  }

  // ---------- شاشة سجل الأحداث (History) ----------
  if (screen === 'history') {
    return <HistoryScreen client={clientRef.current} connected={connected} onBack={() => setScreen('boards')} />;
  }

  // ---------- شاشة النسخة الاحتياطية (تصدير/استيراد) ----------
  if (screen === 'backup') {
    return <BackupScreen onBack={() => setScreen('boards')} onImported={handleBackupImported} />;
  }

  // ---------- شاشة التحكم في بورد واحد ----------
  if (screen === 'board' && activeBoard) {
    const Screen = activeBoard.type === 'irrigation' ? IrrigationScreen : SwitchesScreen;
    return (
      <Screen
        board={activeBoard}
        client={clientRef.current}
        connected={connected}
        pairingKey={pairingKey}
        onUpdateBoard={updateBoard}
        onBack={() => {
          setActiveBoard(null);
          setScreen('boards');
        }}
      />
    );
  }

  // ---------- شاشة قائمة البوردات ----------
  return (
    <BoardsListScreen
      boards={boards}
      connected={connected}
      client={clientRef.current}
      pairingKey={pairingKey}
      onAdd={addBoard}
      onDelete={deleteBoard}
      onOpen={(b) => {
        setActiveBoard(b);
        setScreen('board');
      }}
      onOpenSettings={() => setScreen('settings')}
      onOpenTheme={() => setScreen('theme')}
      onOpenScenes={() => setScreen('scenes')}
      onOpenHistory={() => setScreen('history')}
      onOpenBackup={() => setScreen('backup')}
      pushEnabled={pushEnabled}
      onTogglePush={togglePush}
    />
  );
}

function Field({ label, value, onChange, placeholder, secure, keyboardType }) {
  const { theme } = useTheme();
  return (
    <View style={{ marginBottom: 12 }}>
      <Text style={[styles.label, { color: theme.textSecondary }]}>{label}</Text>
      <TextInput
        style={[styles.input, { backgroundColor: theme.cardAlt, color: theme.textPrimary }]}
        value={value}
        onChangeText={onChange}
        placeholder={placeholder}
        placeholderTextColor={theme.textMuted}
        secureTextEntry={secure}
        keyboardType={keyboardType}
        autoCapitalize="none"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 18, paddingTop: 55 },
  title: { fontSize: 22, fontWeight: '700', marginBottom: 6 },
  hint: { fontSize: 12, marginBottom: 16 },
  label: { fontSize: 12, marginBottom: 6 },
  input: { borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10 },
  primaryBtn: { borderRadius: 12, paddingVertical: 14, alignItems: 'center', marginTop: 10 },
  btnText: { color: '#fff', fontWeight: '600', fontSize: 13 },
});
