package com.mostafabadawy.siljasmart.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.widget.RemoteViews
import com.mostafabadawy.siljasmart.R
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * ============================================================================
 * Silja Smart — Widget مفتاح واحد على الشاشة الرئيسية
 * ============================================================================
 * كل نسخة من الـ widget بتتحكم في مفتاح واحد بس (تختاره وقت الإضافة عن طريق
 * SiljaWidgetConfigActivity). الضغط على الزرار بيبعت طلب HTTP مباشر لسيرفر
 * الـ companion (server/index.js — API الـ /widget/*) اللي هو بدوره بينشر
 * أمر التشغيل/الإيقاف على MQTT. الـ widget نفسه مبيعملش اتصال MQTT خالص —
 * ده اللي بيخليه بسيط وسريع الاستجابة.
 *
 * الإعدادات (serverUrl / token / controlTopic / أسماء العرض) بتتخزن محليًا في
 * SharedPreferences خاصة بالـ widget (مش نفس تخزين تطبيق React Native؛ الاتنين
 * منفصلين عمدًا عشان الـ widget يقدر يشتغل من غير ما يحتاج يشغّل الـ JS bridge).
 * ============================================================================
 */
class SiljaWidgetProvider : AppWidgetProvider() {

    companion object {
        const val PREFS_NAME = "silja_widget_prefs"
        const val ACTION_TOGGLE = "com.mostafabadawy.siljasmart.widget.ACTION_TOGGLE"
        const val ACTION_REFRESH = "com.mostafabadawy.siljasmart.widget.ACTION_REFRESH"
        private val executor = Executors.newCachedThreadPool()

        fun prefs(context: Context): SharedPreferences =
            context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        fun keyFor(widgetId: Int, field: String) = "widget_${widgetId}_$field"

        fun isConfigured(context: Context, widgetId: Int): Boolean {
            val p = prefs(context)
            return !p.getString(keyFor(widgetId, "serverUrl"), null).isNullOrBlank() &&
                !p.getString(keyFor(widgetId, "controlTopic"), null).isNullOrBlank()
        }

        fun saveConfig(
            context: Context,
            widgetId: Int,
            serverUrl: String,
            token: String,
            controlTopic: String,
            boardName: String,
            switchName: String
        ) {
            prefs(context).edit()
                .putString(keyFor(widgetId, "serverUrl"), serverUrl.trimEnd('/'))
                .putString(keyFor(widgetId, "token"), token)
                .putString(keyFor(widgetId, "controlTopic"), controlTopic)
                .putString(keyFor(widgetId, "boardName"), boardName)
                .putString(keyFor(widgetId, "switchName"), switchName)
                .putString(keyFor(widgetId, "state"), "unknown")
                .apply()
        }

        fun clearConfig(context: Context, widgetId: Int) {
            val editor = prefs(context).edit()
            listOf("serverUrl", "token", "controlTopic", "boardName", "switchName", "state").forEach {
                editor.remove(keyFor(widgetId, it))
            }
            editor.apply()
        }

        // بيبني الـ RemoteViews الحالية للـ widget بناءً على آخر حالة معروفة محليًا
        // (من غير ما يستنى رد السيرفر) — عشان التحديث يبان فوري وقت الضغط.
        fun buildViews(context: Context, widgetId: Int): RemoteViews {
            val views = RemoteViews(context.packageName, R.layout.silja_widget)
            val p = prefs(context)

            if (!isConfigured(context, widgetId)) {
                views.setTextViewText(R.id.widget_board_name, "لسه مش مظبوط")
                views.setTextViewText(R.id.widget_switch_name, "دوس هنا عشان تختار مفتاح")
                views.setViewVisibility(R.id.widget_toggle_btn, android.view.View.GONE)

                val configIntent = Intent(context, SiljaWidgetConfigActivity::class.java).apply {
                    putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                }
                val pi = PendingIntent.getActivity(
                    context, widgetId, configIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_root, pi)
                return views
            }

            val boardName = p.getString(keyFor(widgetId, "boardName"), "") ?: ""
            val switchName = p.getString(keyFor(widgetId, "switchName"), "") ?: ""
            val state = p.getString(keyFor(widgetId, "state"), "unknown") ?: "unknown"

            views.setTextViewText(R.id.widget_switch_name, switchName)
            views.setTextViewText(R.id.widget_board_name, boardName)
            views.setViewVisibility(R.id.widget_toggle_btn, android.view.View.VISIBLE)

            val label = when (state) {
                "ON" -> "شغال — دوس تقفيله"
                "OFF" -> "مقفول — دوس تشغيله"
                else -> "دوس تبدّل الحالة"
            }
            views.setTextViewText(R.id.widget_toggle_btn, label)
            views.setInt(
                R.id.widget_dot,
                "setBackgroundResource",
                when (state) {
                    "ON" -> R.drawable.silja_dot_on
                    "OFF" -> R.drawable.silja_dot_off
                    else -> R.drawable.silja_dot_unknown
                }
            )

            val toggleIntent = Intent(context, SiljaWidgetProvider::class.java).apply {
                action = ACTION_TOGGLE
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
            }
            val togglePi = PendingIntent.getBroadcast(
                context, widgetId, toggleIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_toggle_btn, togglePi)
            views.setOnClickPendingIntent(R.id.widget_root, togglePi)

            return views
        }

        fun refreshWidget(context: Context, appWidgetManager: AppWidgetManager, widgetId: Int) {
            appWidgetManager.updateAppWidget(widgetId, buildViews(context, widgetId))
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { refreshWidget(context, appWidgetManager, it) }
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        appWidgetIds.forEach { clearConfig(context, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action != ACTION_TOGGLE) return

        val widgetId = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, -1)
        if (widgetId == -1) return

        val appWidgetManager = AppWidgetManager.getInstance(context)
        val p = prefs(context)
        val serverUrl = p.getString(keyFor(widgetId, "serverUrl"), null)
        val token = p.getString(keyFor(widgetId, "token"), "") ?: ""
        val controlTopic = p.getString(keyFor(widgetId, "controlTopic"), null)
        if (serverUrl.isNullOrBlank() || controlTopic.isNullOrBlank()) return

        // تفاؤلي: نوري حالة "جاري..." فورًا، وبعدين نصحح لما الرد يوصل
        appWidgetManager.partiallyUpdateAppWidget(widgetId, RemoteViews(context.packageName, R.layout.silja_widget).apply {
            setTextViewText(R.id.widget_toggle_btn, "جاري…")
        })

        executor.execute {
            var newState = "unknown"
            var ok = false
            try {
                val url = URL("$serverUrl/widget/toggle")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
                conn.setRequestProperty("Authorization", "Bearer $token")
                conn.connectTimeout = 8000
                conn.readTimeout = 8000

                val body = JSONObject().apply {
                    put("controlTopic", controlTopic)
                    put("state", "TOGGLE")
                }
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

                if (conn.responseCode in 200..299) {
                    val resp = conn.inputStream.bufferedReader().use { it.readText() }
                    newState = JSONObject(resp).optString("state", "unknown")
                    ok = true
                }
                conn.disconnect()
            } catch (e: Exception) {
                ok = false
            }

            if (ok) {
                p.edit().putString(keyFor(widgetId, "state"), newState).apply()
            }
            refreshWidget(context, appWidgetManager, widgetId)
        }
    }
}
