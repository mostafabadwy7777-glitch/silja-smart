package com.mostafabadawy.siljasmart.widget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import com.mostafabadawy.siljasmart.R
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * شاشة إعداد الـ widget — بتظهر تلقائي وقت ما المستخدم يسحب الـ widget على
 * الشاشة الرئيسية. بتاخد عنوان سيرفر الـ companion والتوكن، تجيب قايمة
 * المفاتيح الحالية من `GET /widget/switches`، وتخلي المستخدم يختار واحد منها
 * ليربطه بالـ widget ده. القيم دي بتتخزن محليًا في SharedPreferences خاصة
 * بالـ widget (مش مرتبطة بتخزين تطبيق React Native).
 */
class SiljaWidgetConfigActivity : Activity() {

    private var widgetId: Int = AppWidgetManager.INVALID_APPWIDGET_ID
    private val executor = Executors.newSingleThreadExecutor()
    private val mainHandler = Handler(Looper.getMainLooper())
    private var fetchedSwitches: List<SwitchOption> = emptyList()

    data class SwitchOption(
        val boardName: String,
        val switchName: String,
        val controlTopic: String
    ) {
        override fun toString() = "$boardName — $switchName"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(Activity.RESULT_CANCELED)
        setContentView(R.layout.silja_widget_config)

        widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID,
            AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        val serverInput = findViewById<android.widget.EditText>(R.id.config_server_url)
        val tokenInput = findViewById<android.widget.EditText>(R.id.config_token)
        val listView = findViewById<android.widget.ListView>(R.id.config_switches_list)
        val fetchBtn = findViewById<android.widget.Button>(R.id.config_fetch_btn)
        val statusText = findViewById<android.widget.TextView>(R.id.config_status_text)

        // لو المستخدم بيعدّل widget موجود بالفعل، نعبّي القيم المحفوظة
        val prefs = SiljaWidgetProvider.prefs(this)
        prefs.getString(SiljaWidgetProvider.keyFor(widgetId, "serverUrl"), null)?.let { serverInput.setText(it) }
        prefs.getString(SiljaWidgetProvider.keyFor(widgetId, "token"), null)?.let { tokenInput.setText(it) }

        fetchBtn.setOnClickListener {
            val base = serverInput.text.toString().trim().trimEnd('/')
            val token = tokenInput.text.toString().trim()
            if (base.isEmpty()) {
                Toast.makeText(this, "لازم تكتب عنوان سيرفر الـ companion", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            statusText.text = "جاري الجلب…"
            listView.visibility = View.GONE

            executor.execute {
                var error: String? = null
                var options: List<SwitchOption> = emptyList()
                try {
                    val url = URL("$base/widget/switches")
                    val conn = url.openConnection() as HttpURLConnection
                    conn.requestMethod = "GET"
                    conn.setRequestProperty("Authorization", "Bearer $token")
                    conn.connectTimeout = 8000
                    conn.readTimeout = 8000

                    if (conn.responseCode in 200..299) {
                        val resp = conn.inputStream.bufferedReader().use { it.readText() }
                        val arr = org.json.JSONObject(resp).optJSONArray("switches") ?: JSONArray()
                        val list = mutableListOf<SwitchOption>()
                        for (i in 0 until arr.length()) {
                            val o = arr.getJSONObject(i)
                            list.add(
                                SwitchOption(
                                    boardName = o.optString("boardName", ""),
                                    switchName = o.optString("switchName", ""),
                                    controlTopic = o.optString("controlTopic", "")
                                )
                            )
                        }
                        options = list
                        if (list.isEmpty()) error = "السيرفر رد بس مفيش مفاتيح مكتشفة لسه"
                    } else if (conn.responseCode == 401) {
                        error = "التوكن غلط (401) — تأكد من WIDGET_TOKEN في إعدادات السيرفر"
                    } else {
                        error = "السيرفر رد بخطأ (${conn.responseCode})"
                    }
                    conn.disconnect()
                } catch (e: Exception) {
                    error = "مقدرش أوصل للسيرفر: ${e.message}"
                }

                val finalError = error
                mainHandler.post {
                    if (finalError != null) {
                        statusText.text = "⚠ $finalError"
                        return@post
                    }
                    fetchedSwitches = options
                    statusText.text = "اختار مفتاح من القايمة تحت:"
                    listView.visibility = View.VISIBLE
                    listView.adapter = ArrayAdapter(
                        this@SiljaWidgetConfigActivity,
                        android.R.layout.simple_list_item_1,
                        options
                    )
                }
            }
        }

        listView.setOnItemClickListener { _, _, position, _ ->
            val chosen = fetchedSwitches.getOrNull(position) ?: return@setOnItemClickListener
            val base = serverInput.text.toString().trim().trimEnd('/')
            val token = tokenInput.text.toString().trim()

            SiljaWidgetProvider.saveConfig(
                this,
                widgetId,
                serverUrl = base,
                token = token,
                controlTopic = chosen.controlTopic,
                boardName = chosen.boardName,
                switchName = chosen.switchName
            )

            val appWidgetManager = AppWidgetManager.getInstance(this)
            SiljaWidgetProvider.refreshWidget(this, appWidgetManager, widgetId)

            val resultValue = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
            setResult(Activity.RESULT_OK, resultValue)
            finish()
        }
    }
}
