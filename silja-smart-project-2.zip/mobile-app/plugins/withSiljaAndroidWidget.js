const { withDangerousMod, withAndroidManifest } = require("@expo/config-plugins");
const fs = require("fs");
const path = require("path");

/**
 * Copies mobile-app/widget/android/* (Kotlin sources + res/) into the
 * generated android/ project on every `expo prebuild`, and registers the
 * widget's receiver + config activity in AndroidManifest.xml.
 *
 * Source is never generated automatically by Expo, so without this plugin
 * `app.json`'s reference to it makes prebuild fail immediately.
 */

function copyDir(src, dest) {
  fs.mkdirSync(dest, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, entry.name);
    const d = path.join(dest, entry.name);
    if (entry.isDirectory()) {
      copyDir(s, d);
    } else {
      fs.copyFileSync(s, d);
    }
  }
}

const withSiljaWidgetFiles = (config) => {
  return withDangerousMod(config, [
    "android",
    async (config) => {
      const projectRoot = config.modRequest.projectRoot;
      const platformRoot = config.modRequest.platformProjectRoot; // .../android
      const widgetRoot = path.join(projectRoot, "widget", "android");

      if (!fs.existsSync(widgetRoot)) {
        console.warn(
          `[withSiljaAndroidWidget] ${widgetRoot} not found, skipping widget files.`
        );
        return config;
      }

      // Kotlin sources
      const javaSrc = path.join(widgetRoot, "src", "main", "java");
      if (fs.existsSync(javaSrc)) {
        copyDir(javaSrc, path.join(platformRoot, "app", "src", "main", "java"));
      }

      // res/xml, res/layout, res/drawable copy as-is
      for (const sub of ["xml", "layout", "drawable"]) {
        const src = path.join(widgetRoot, "res", sub);
        if (fs.existsSync(src)) {
          copyDir(src, path.join(platformRoot, "app", "src", "main", "res", sub));
        }
      }

      // res/values/strings.xml -> renamed so it merges instead of
      // clobbering the app's generated strings.xml
      const valuesSrc = path.join(widgetRoot, "res", "values", "strings.xml");
      if (fs.existsSync(valuesSrc)) {
        const destDir = path.join(platformRoot, "app", "src", "main", "res", "values");
        fs.mkdirSync(destDir, { recursive: true });
        fs.copyFileSync(valuesSrc, path.join(destDir, "silja_widget_strings.xml"));
      }

      return config;
    },
  ]);
};

const withSiljaWidgetManifest = (config) => {
  return withAndroidManifest(config, (config) => {
    const manifest = config.modResults;
    const app = manifest.manifest.application[0];

    if (!app.receiver) app.receiver = [];
    const receiverName = ".widget.SiljaWidgetProvider";
    if (!app.receiver.some((r) => r.$["android:name"] === receiverName)) {
      app.receiver.push({
        $: {
          "android:name": receiverName,
          "android:exported": "true",
        },
        "intent-filter": [
          {
            action: [
              { $: { "android:name": "android.appwidget.action.APPWIDGET_UPDATE" } },
            ],
          },
        ],
        "meta-data": [
          {
            $: {
              "android:name": "android.appwidget.provider",
              "android:resource": "@xml/silja_widget_info",
            },
          },
        ],
      });
    }

    if (!app.activity) app.activity = [];
    const activityName = ".widget.SiljaWidgetConfigActivity";
    if (!app.activity.some((a) => a.$["android:name"] === activityName)) {
      app.activity.push({
        $: {
          "android:name": activityName,
          "android:exported": "true",
          "android:theme": "@android:style/Theme.DeviceDefault.Light.Dialog",
        },
        "intent-filter": [
          {
            action: [
              { $: { "android:name": "android.appwidget.action.APPWIDGET_CONFIGURE" } },
            ],
          },
        ],
      });
    }

    return config;
  });
};

module.exports = function withSiljaAndroidWidget(config) {
  config = withSiljaWidgetFiles(config);
  config = withSiljaWidgetManifest(config);
  return config;
};
