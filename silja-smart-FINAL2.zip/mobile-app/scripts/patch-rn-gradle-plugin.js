/**
 * Runs AFTER `npm install`. Patches @react-native/gradle-plugin (the whole
 * multi-module Gradle project under node_modules/@react-native/gradle-plugin)
 * for two known incompatibilities with newer Gradle/Kotlin toolchains:
 *
 * 1. `serviceOf<ModuleRegistry>()` was removed from Gradle in 8.10+.
 *    RN 0.74.5's bundled gradle-plugin still references it in a test-only
 *    dependency block, which is safe to drop for a release build.
 *    See: facebook/react-native#54020
 *
 * 2. The plugin's own build scripts set allWarningsAsErrors = true. A
 *    newer Kotlin compiler than this code was written against emits a
 *    warning (e.g. "unnecessary safe call" on Jvm.current()) that didn't
 *    exist before, which then fails the build even though nothing is
 *    actually broken. Turn that off everywhere in this project.
 */
const fs = require("fs");
const path = require("path");

const gradlePluginRoot = path.join(
  __dirname,
  "..",
  "node_modules",
  "@react-native",
  "gradle-plugin"
);

function findKtsFiles(dir) {
  let results = [];
  if (!fs.existsSync(dir)) return results;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name === "node_modules" || entry.name === "build") continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      results = results.concat(findKtsFiles(full));
    } else if (entry.name.endsWith(".gradle.kts")) {
      results.push(full);
    }
  }
  return results;
}

const files = findKtsFiles(gradlePluginRoot);

if (files.length === 0) {
  console.warn(`No .gradle.kts files found under ${gradlePluginRoot}`);
}

for (const filePath of files) {
  let content = fs.readFileSync(filePath, "utf8");
  const original = content;

  if (content.includes("serviceOf")) {
    content = content.replace(
      /import org\.gradle\.configurationcache\.extensions\.serviceOf\n/,
      ""
    );
    content = content.replace(
      /\n\s*testRuntimeOnly\(\s*\n\s*files\(\s*\n\s*serviceOf<ModuleRegistry>\(\)[\s\S]*?\)\s*\)\s*\n/,
      "\n"
    );
  }

  content = content
    .replace(/allWarningsAsErrors\s*=\s*true/g, "allWarningsAsErrors = false")
    .replace(/allWarningsAsErrors\.set\(true\)/g, "allWarningsAsErrors.set(false)");

  if (content !== original) {
    fs.writeFileSync(filePath, content);
    console.log(`Patched ${filePath}`);
  }
}
