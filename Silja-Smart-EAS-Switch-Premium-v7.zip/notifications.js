import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { loadOrCreateInstallId } from './storage';

// ============================================================================
// إشعارات Push — إعلام المستخدم لو مفتاح اتقفل/اتفتح من غير ما يكون فاتح التطبيق.
// ============================================================================
// الفكرة: MQTT وحده مش كفاية لإشعارات وقت التطبيق مقفول، لازم حاجة شغالة طول
// الوقت (سيرفر) تستقبل التوكن وتراقب حالة المفاتيح وتبعت الإشعار الفعلي عن طريق
// Expo Push Service. التطبيق هنا بس بيسجّل توكن الجهاز، وبينشره على MQTT (Retained)
// على توبيك ثابت خاص بالتركيب ده، وسيرفر مستقل (شوف مجلد server/) بيقرأ التوكنات
// دي ويستخدمها للإرسال. لو مفيش سيرفر شغال، التسجيل بيحصل عادي بس مفيش حد هيبعت
// إشعارات فعليًا لحد ما تشغّل السيرفر (شوف server/README.md).
// ============================================================================

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export function pushTokenTopic(installId) {
  return `silja/app/push_tokens/${installId}`;
}

// بيطلب إذن الإشعارات، ياخد Expo Push Token، وينشره Retained على MQTT عشان
// سيرفر الإشعارات يلاقيه. بيرجع التوكن (أو null لو اترفض/فشل).
export async function registerForPushNotificationsAsync(client) {
  if (!Device.isDevice) {
    return { ok: false, error: 'الإشعارات محتاجة جهاز حقيقي، مش شغالة في المحاكي (Simulator/Emulator)' };
  }

  const { status: existing } = await Notifications.getPermissionsAsync();
  let finalStatus = existing;
  if (existing !== 'granted') {
    const { status } = await Notifications.requestPermissionsAsync();
    finalStatus = status;
  }
  if (finalStatus !== 'granted') {
    return { ok: false, error: 'رفضت إذن الإشعارات — ممكن تفعّله بعدين من إعدادات الموبايل' };
  }

  if (Platform.OS === 'android') {
    await Notifications.setNotificationChannelAsync('silja-default', {
      name: 'Silja Smart',
      importance: Notifications.AndroidImportance.HIGH,
      vibrationPattern: [0, 200, 150, 200],
    });
  }

  let tokenResponse;
  try {
    tokenResponse = await Notifications.getExpoPushTokenAsync();
  } catch (e) {
    return { ok: false, error: 'مقدرش أجيب توكن الإشعارات: ' + e.message };
  }
  const token = tokenResponse?.data;
  if (!token) return { ok: false, error: 'مفيش توكن رجع من Expo' };

  const installId = await loadOrCreateInstallId();
  if (client && client.connected) {
    client.publish(
      pushTokenTopic(installId),
      JSON.stringify({ token, platform: Platform.OS, updatedAt: Date.now() }),
      { retain: true, qos: 1 }
    );
  }

  return { ok: true, token, installId };
}

// بيمسح تسجيل التوكن (بينشر رسالة فاضية Retained عشان تشيل القيمة القديمة من البروكر).
export async function unregisterPushNotifications(client) {
  const installId = await loadOrCreateInstallId();
  if (client && client.connected) {
    client.publish(pushTokenTopic(installId), '', { retain: true, qos: 1 });
  }
}

// إشعار محلي فوري من نفس جهاز الموبايل (مش عن طريق سيرفر أو MQTT) — بيستخدم
// لحظة حدث مهم حصل جوه التطبيق نفسه وهو مفتوح، زي تفعيل زرار الطوارئ، عشان
// المستخدم ياخد تنبيه واضح حتى لو مش شايف الشاشة في اللحظة دي.
export async function notifyLocal(title, body) {
  try {
    await Notifications.scheduleNotificationAsync({
      content: { title, body, sound: true },
      trigger: null, // null = يظهر فورًا
    });
  } catch (e) {
    // فشل الإشعار المحلي (مثلاً الإذن مرفوض) — متعمدين متجاهلينه هنا عشان
    // ميوقفش تنفيذ الأمر نفسه (الطوارئ لازم تتبعت حتى لو الإشعار فشل).
  }
}
