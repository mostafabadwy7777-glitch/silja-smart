import CryptoJS from 'crypto-js';
import { DEVICE_ICONS } from './deviceIcons';

// ============================================================================
// اكتشاف البورد + التحقق من التوقيع (Pairing)
// ============================================================================
// الفكرة: التطبيق مش بيقبل أي بورد يظهر على أي توبيك. البورد لازم يبعت رسالة
// اكتشاف واحدة (JSON) على `<device_id>/discovery` وفيها توقيع HMAC-SHA256
// محسوب بـ "مفتاح الربط" (Pairing Key) اللي انت حاططه في إعدادات التطبيق —
// نفس المفتاح ده لازم يكون متحط في كود الفيرموير بتاعك. لو التوقيع مش متطابق
// (يعني الرسالة جاية من فيرموير تاني مش عارف المفتاح) التطبيق بيرفض الرسالة
// تمامًا ومش بيضيف أي بورد أو مفتاح منها.
//
// ده بيربط التطبيق بالفيرموير بتاعك انت بس، لأن مفتاح الربط مش متحط جوه كود
// التطبيق نفسه (فمش هيتقرا لو حد فك التطبيق) — انت اللي بتكتبه بنفسك في
// الإعدادات وفي الفيرموير، فحتى لو حد نسخ التطبيق أو عرف اسم الجهاز
// (device_id)، مش هيقدر يولّد توقيع صحيح من غير ما يعرف مفتاحك بالظبط.
// ============================================================================

// نفس ترتيب الحقول ده لازم يتطابق تمامًا مع اللي الفيرموير بيستخدمه وهو بيبني
// السترينج اللي بيوقّعه (شوف مثال الفيرموير في README / firmware-examples).
// مقصود عمدًا إنه تجميع نصوص بسيط (مش JSON منسّق) عشان يكون سهل تنفيذه بالظبط
// في كود C/C++ المتحكمات من غير مكتبات ترتيب أو JSON إضافية.
function buildCanonicalString(msg) {
  const type = msg.type === 'irrigation' ? 'irrigation' : 'switches';
  const switches = Array.isArray(msg.switches) ? msg.switches : [];
  const swPart = switches
    .map((s) =>
      [
        s.name || '',
        s.control_topic || s.control || s.topic || '',
        s.status_topic || s.state_topic || s.status || '',
        s.icon || '',
        s.control_type || s.type || '',
      ].join(',')
    )
    .join(';');

  return [msg.device_id || '', msg.name || '', type, msg.prefix || '', swPart].join('|');
}

export function signDiscoveryMessage(msg, pairingKey) {
  const canonical = buildCanonicalString(msg);
  return CryptoJS.HmacSHA256(canonical, pairingKey).toString(CryptoJS.enc.Hex);
}

// مقارنة بزمن شبه ثابت عشان نقلل فرص استنتاج المفتاح من فروق التوقيت
// (مش حماية كاملة زي الموجودة في السيرفرات، بس أفضل من مقارنة === مباشرة).
function safeEqual(a, b) {
  if (typeof a !== 'string' || typeof b !== 'string' || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

export function verifyDiscoveryMessage(msg, pairingKey) {
  if (!msg || typeof msg.sig !== 'string' || !msg.sig) return false;
  if (!pairingKey) return false;
  const expected = signDiscoveryMessage(msg, pairingKey);
  return safeEqual(expected, msg.sig);
}

function normalizeSwitch(item, idx) {
  const controlTopic = item.control_topic || item.control || item.topic;
  if (!controlTopic) return null;
  const iconId = DEVICE_ICONS.some((d) => d.id === item.icon) ? item.icon : 'switch';
  const controlType = item.control_type === 'updown' || item.type === 'updown' ? 'updown' : 'toggle';
  return {
    name: item.name || `مفتاح ${idx + 1}`,
    controlTopic,
    statusTopic: item.status_topic || item.state_topic || item.status || undefined,
    icon: iconId,
    controlType,
  };
}

export function normalizeSwitchList(list) {
  return (Array.isArray(list) ? list : []).map(normalizeSwitch).filter(Boolean);
}

// ============================================================================
// توبيك "توفر" (Availability) البورد — نفس الفكرة اللي بورد الري كان شغال
// بيها من زمان (`<prefix>/availability`)، بس دلوقتي شغالة لكل أنواع البوردات.
// ============================================================================
// الفيرموير المفروض ينشر على التوبيك ده رسالة Retained قيمتها "online" بمجرد
// ما يتصل بالبروكر، ويسجّل نفس التوبيك كـ Last Will (LWT) بقيمة "offline"
// عشان البروكر ينشرها تلقائيًا لو البورد اتقطع فجأة (اتفصلت الكهرباء/النت)
// من غير ما يقدر يبعت أي رسالة وداع بنفسه. شوف firmware-examples للتفاصيل.
//
// التوبيك مش جزء من التوقيع (sig) — بيتحسب في التطبيق من device_id (لوحة
// المفاتيح) أو prefix (الري) اللي أصلاً جايين موقّعين من رسالة الاكتشاف،
// فمفيش داعي لأي حقل إضافي في البروتوكول.
export function boardAvailabilityTopic(board) {
  if (!board) return null;
  if (board.type === 'irrigation') return board.prefix ? `${board.prefix}/availability` : null;
  return board.deviceId ? `${board.deviceId}/availability` : null;
}

// بيحوّل payload الأفيلابيليتي الخام لحالة واضحة، وبيتجاهل أي حاجة غريبة.
export function parseAvailability(raw) {
  const v = (raw || '').toString().trim().toLowerCase();
  if (v === 'online') return 'online';
  if (v === 'offline') return 'offline';
  return null;
}

// بيقرأ ويتحقق من رسالة اكتشاف بورد كاملة جاية من الفيرموير على `<device_id>/discovery`.
// الشكل المتوقع:
// {
//   "device_id": "kitchen-esp32-01",
//   "name": "المطبخ",
//   "type": "switches" | "irrigation",
//   "prefix": "irrigation",              // لازم لو type == irrigation
//   "switches": [ { "name", "control_topic", "status_topic", "icon", "control_type" }, ... ],
//   "sig": "<hex hmac-sha256 على الحقول اللي فوق>"
// }
export function parseBoardDiscovery(str, pairingKey) {
  let data;
  try {
    data = JSON.parse(str);
  } catch (e) {
    return { ok: false, error: 'الرسالة اللي وصلت مش JSON صحيح' };
  }

  if (!pairingKey) {
    return { ok: false, error: 'لازم تحط "مفتاح الربط" في إعدادات الاتصال الأول' };
  }

  if (!verifyDiscoveryMessage(data, pairingKey)) {
    return {
      ok: false,
      error:
        'التوقيع مش متطابق — الجهاز ده مش شغال بنفس "مفتاح الربط" بتاعك، فمرفوض إنه يتضاف. اتأكد إن الفيرموير مستخدم نفس المفتاح المكتوب في الإعدادات.',
    };
  }

  const type = data.type === 'irrigation' ? 'irrigation' : 'switches';
  const board = {
    name: (data.name || data.device_id || 'بورد جديد').toString(),
    type,
    deviceId: data.device_id,
  };

  if (type === 'irrigation') {
    if (!data.prefix) {
      return { ok: false, error: 'رسالة اكتشاف بورد الري لازم تحتوي على "prefix"' };
    }
    board.prefix = data.prefix;
  } else {
    const devices = normalizeSwitchList(data.switches);
    if (devices.length === 0) {
      return { ok: false, error: 'الرسالة لازم تحتوي "switches" فيها مفتاح واحد على الأقل وله control_topic' };
    }
    board.devices = devices;
  }

  return { ok: true, board };
}
