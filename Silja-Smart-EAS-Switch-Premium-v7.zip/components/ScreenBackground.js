import React, { useEffect, useMemo, useRef } from 'react';
import { View, StyleSheet, Animated, Easing } from 'react-native';

// ============================================================================
// خلفية زخرفية "حية" لكل شاشة — نفس فكرة النسخة اللي قبل كده (هالات ضوء +
// أرضية شبكية بمنظور 3D)، لكن دلوقتي كل حاجة بتتحرك ببطء وبشكل لا نهائي:
//
//   1) الهالات الضوئية بتـ"تنفّس" — تكبر وتصغر بنعومة (نبض بطيء)
//   2) خطوط الأرضية الشبكية بتزحف للأمام بشكل مستمر — إحساس إنك ماشي/طاير
//      فوق أرضية ممتدة، زي واجهات الألعاب المستقبلية
//   3) نقط ضوء صغيرة (غبار ضوئي) بتعوم لأعلى وتختفي بالتدريج، كل نقطة
//      بسرعة وتوقيت مختلف شوية عن التانية عشان الحركة تبقى طبيعية مش
//      متزامنة كلها مع بعض
//
// كل الحركات بتستخدم Animated + useNativeDriver (scale/translateY/opacity
// بس) عشان تفضل ناعمة وخفيفة على الأداء حتى مع أكتر من طبقة شغالة في نفس
// الوقت. الطبقة كلها لسه pointerEvents="none" فمش بتأثر على أي تفاعل.
// ============================================================================

const GRID_ROWS = 10;
const ROW_HEIGHT = 30;
const GRID_COLS = 9;
const PARTICLE_COUNT = 10;

export default function ScreenBackground({ theme, grid = true, glows = true, particles = true }) {
  const pulse = useRef(new Animated.Value(0)).current;
  const scroll = useRef(new Animated.Value(0)).current;
  const floatAnims = useRef(
    Array.from({ length: PARTICLE_COUNT }).map(() => new Animated.Value(0))
  ).current;

  useEffect(() => {
    if (!theme) return undefined;

    const pulseLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, {
          toValue: 1,
          duration: 2600,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
        Animated.timing(pulse, {
          toValue: 0,
          duration: 2600,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
      ])
    );
    if (glows) pulseLoop.start();

    const scrollLoop = Animated.loop(
      Animated.timing(scroll, {
        toValue: 1,
        duration: 3200,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    );
    if (grid) scrollLoop.start();

    const particleTimeouts = [];
    const particleLoops = floatAnims.map((v, i) => {
      v.setValue(0);
      const loop = Animated.loop(
        Animated.timing(v, {
          toValue: 1,
          duration: 4200 + (i % 5) * 700,
          easing: Easing.linear,
          useNativeDriver: true,
        })
      );
      if (particles) {
        const t = setTimeout(() => loop.start(), i * 260);
        particleTimeouts.push(t);
      }
      return loop;
    });

    return () => {
      pulseLoop.stop();
      scrollLoop.stop();
      particleLoops.forEach((l) => l.stop());
      particleTimeouts.forEach((t) => clearTimeout(t));
    };
  }, [theme, grid, glows, particles]);

  const particleSeeds = useMemo(
    () =>
      Array.from({ length: PARTICLE_COUNT }).map((_, i) => ({
        left: `${(i * 37 + 8) % 92}%`,
        size: 3 + (i % 3),
      })),
    []
  );

  if (!theme) return null;
  const lineColor = theme.accent;

  const glowScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.92, 1.14] });
  const gridTranslateY = scroll.interpolate({ inputRange: [0, 1], outputRange: [0, ROW_HEIGHT] });

  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFillObject}>
      {glows && (
        <>
          <Animated.View
            style={[
              styles.glow,
              styles.glowTopRight,
              { backgroundColor: theme.accent, shadowColor: theme.accent, transform: [{ scale: glowScale }] },
            ]}
          />
          <Animated.View
            style={[
              styles.glow,
              styles.glowBottomLeft,
              { backgroundColor: theme.accentSoft, shadowColor: theme.accentSoft, transform: [{ scale: glowScale }] },
            ]}
          />
          <Animated.View
            style={[
              styles.glow,
              styles.glowCenter,
              { backgroundColor: theme.on, shadowColor: theme.on, transform: [{ scale: glowScale }] },
            ]}
          />
        </>
      )}

      {particles && (
        <View style={StyleSheet.absoluteFillObject}>
          {particleSeeds.map((p, i) => {
            const v = floatAnims[i];
            const translateY = v.interpolate({ inputRange: [0, 1], outputRange: [0, -70] });
            const opacity = v.interpolate({
              inputRange: [0, 0.15, 0.8, 1],
              outputRange: [0, 0.55, 0.3, 0],
            });
            return (
              <Animated.View
                key={'particle-' + i}
                style={{
                  position: 'absolute',
                  bottom: 40,
                  left: p.left,
                  width: p.size,
                  height: p.size,
                  borderRadius: p.size,
                  backgroundColor: theme.accentSoft,
                  opacity,
                  transform: [{ translateY }],
                }}
              />
            );
          })}
        </View>
      )}

      {grid && (
        <View style={styles.gridWrap}>
          <View style={styles.gridPlane}>
            <Animated.View style={{ transform: [{ translateY: gridTranslateY }] }}>
              {Array.from({ length: GRID_ROWS + 1 }).map((_, i) => (
                <View key={'r' + i} style={[styles.gridRow, { borderBottomColor: lineColor }]} />
              ))}
            </Animated.View>
            <View style={styles.gridColsWrap}>
              {Array.from({ length: GRID_COLS }).map((_, i) => (
                <View key={'c' + i} style={[styles.gridCol, { backgroundColor: lineColor }]} />
              ))}
            </View>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  glow: {
    position: 'absolute',
    borderRadius: 999,
    opacity: 0.16,
    shadowOpacity: 0.55,
    shadowRadius: 70,
    shadowOffset: { width: 0, height: 0 },
  },
  glowTopRight: { top: -70, right: -70, width: 220, height: 220 },
  glowBottomLeft: { bottom: -50, left: -70, width: 260, height: 260, opacity: 0.14 },
  glowCenter: { top: '32%', left: '18%', width: 170, height: 170, opacity: 0.07 },

  gridWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: 230,
    overflow: 'hidden',
    opacity: 0.16,
  },
  gridPlane: {
    position: 'absolute',
    left: '-20%',
    width: '140%',
    height: GRID_ROWS * ROW_HEIGHT,
    bottom: 0,
    transform: [{ perspective: 700 }, { rotateX: '68deg' }],
  },
  gridRow: { height: ROW_HEIGHT, borderBottomWidth: 1 },
  gridColsWrap: {
    ...StyleSheet.absoluteFillObject,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  gridCol: { width: 1, height: '100%' },
});
