import React, { useEffect, useRef, useState } from 'react';
import { Modal, View, Text, StyleSheet, Animated, Easing } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { useTheme } from '../ThemeContext';

// ============================================================================
// نافذة تنبيه فاخرة بديلة لـ Alert.alert الافتراضية بتاعة نظام التشغيل —
// اللي كانت بتقطع فجأة من جو التطبيق الغامق/الذهبي لنافذة نظام بيضاء عادية.
// الشكل هنا: كارت بألوان الثيم الحالي، حواف مدوّرة، توهج خفيف حوالين الحافة،
// وحركة دخول/خروج ناعمة (تكبير + تلاشي) بدل الظهور المفاجئ.
//
// الاستخدام مطابق تمامًا لـ Alert.alert (نفس ترتيب البارامترات)، فالاستبدال
// في أي مكان هو مجرد تغيير اسم الاستدعاء:
//   Alert.alert('عنوان', 'رسالة', [{ text: 'إلغاء', style: 'cancel' }, ...])
//   showAlert('عنوان', 'رسالة', [{ text: 'إلغاء', style: 'cancel' }, ...])
//
// لازم <AlertHost /> يتركّب مرة واحدة بس في جذر التطبيق (جوه ThemeProvider)
// عشان يقدر يوصل لألوان الثيم الحالي، وبعد كده showAlert شغالة من أي مكان.
// ============================================================================

let _trigger = null;

export function showAlert(title, message, buttons) {
  const safeButtons = buttons && buttons.length ? buttons : [{ text: 'حسنًا' }];
  if (_trigger) {
    _trigger({ title, message, buttons: safeButtons });
  }
}

export default function AlertHost() {
  const { theme } = useTheme();
  const [config, setConfig] = useState(null);
  const anim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    _trigger = (cfg) => setConfig(cfg);
    return () => {
      _trigger = null;
    };
  }, []);

  useEffect(() => {
    if (config) {
      anim.setValue(0);
      Animated.timing(anim, {
        toValue: 1,
        duration: 220,
        easing: Easing.out(Easing.cubic),
        useNativeDriver: true,
      }).start();
    }
  }, [config, anim]);

  const close = (btn) => {
    Animated.timing(anim, {
      toValue: 0,
      duration: 150,
      easing: Easing.in(Easing.cubic),
      useNativeDriver: true,
    }).start(() => {
      setConfig(null);
      if (btn && typeof btn.onPress === 'function') btn.onPress();
    });
  };

  if (!config || !theme) return null;

  const scale = anim.interpolate({ inputRange: [0, 1], outputRange: [0.88, 1] });
  const backdropOpacity = anim.interpolate({ inputRange: [0, 1], outputRange: [0, 0.62] });
  const buttons = config.buttons;

  return (
    <Modal transparent visible animationType="none" onRequestClose={() => close(null)} statusBarTranslucent>
      <Animated.View style={[styles.backdrop, { opacity: backdropOpacity }]} pointerEvents="none" />
      <TouchableOpacity
        style={StyleSheet.absoluteFillObject}
        activeOpacity={1}
        onPress={() => close(null)}
      >
        <View style={styles.center} pointerEvents="box-none">
          <Animated.View
            onStartShouldSetResponder={() => true}
            style={[
              styles.card,
              {
                backgroundColor: theme.card,
                borderColor: theme.accent + '55',
                shadowColor: theme.accent,
                opacity: anim,
                transform: [{ scale }],
              },
            ]}
          >
            <View style={[styles.accentBar, { backgroundColor: theme.accent }]} />
            {!!config.title && <Text style={[styles.title, { color: theme.textPrimary }]}>{config.title}</Text>}
            {!!config.message && (
              <Text style={[styles.message, { color: theme.textSecondary }]}>{config.message}</Text>
            )}

            <View style={[styles.btnRow, buttons.length > 2 && styles.btnColumn]}>
              {buttons.map((b, i) => {
                const isDestructive = b.style === 'destructive';
                const isCancel = b.style === 'cancel';
                const btnColor = isDestructive ? theme.danger : isCancel ? theme.textSecondary : theme.accent;
                return (
                  <TouchableOpacity
                    key={i}
                    onPress={() => close(b)}
                    style={[
                      styles.btn,
                      buttons.length > 2 ? styles.btnFull : styles.btnFlex,
                      { borderColor: isDestructive ? theme.danger : theme.border },
                      isCancel && { backgroundColor: 'transparent' },
                      !isCancel && !isDestructive && { backgroundColor: theme.accent + '1a' },
                    ]}
                  >
                    <Text style={[styles.btnText, { color: btnColor }]} numberOfLines={1}>
                      {b.text}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </Animated.View>
        </View>
      </TouchableOpacity>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: '#000' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 28 },
  card: {
    width: '100%',
    maxWidth: 360,
    borderRadius: 22,
    borderWidth: 1.25,
    padding: 20,
    paddingTop: 22,
    overflow: 'hidden',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 10,
  },
  accentBar: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 3,
  },
  title: { fontSize: 16.5, fontWeight: '700', textAlign: 'center', marginBottom: 8 },
  message: { fontSize: 13.5, textAlign: 'center', lineHeight: 20, marginBottom: 18 },
  btnRow: { flexDirection: 'row', gap: 10 },
  btnColumn: { flexDirection: 'column' },
  btn: {
    borderRadius: 14,
    borderWidth: 1.25,
    paddingVertical: 11,
    alignItems: 'center',
    justifyContent: 'center',
  },
  btnFlex: { flex: 1 },
  btnFull: { width: '100%' },
  btnText: { fontSize: 14, fontWeight: '700' },
});
