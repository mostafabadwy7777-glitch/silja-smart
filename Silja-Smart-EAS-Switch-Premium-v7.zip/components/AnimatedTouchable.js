import React, { useRef } from 'react';
import { Animated, Pressable } from 'react-native';

// ============================================================================
// بديل مباشر لـ TouchableOpacity بيضيف حركة "انكماش" (scale down) لأي زرار
// لما المستخدم يضغط عليه، وبيرجع لحجمه الطبيعي لما يسيب إصبعه — بإحساس
// نابض (spring) بدل حركة جامدة. الاستخدام مطابق تمامًا لـ TouchableOpacity
// العادي (نفس الـ props: style, onPress, disabled, activeOpacity...) عشان
// يشتغل مكانه من غير ما نغيّر أي كود تاني في الشاشات.
//
// ملحوظة مهمة: الأنيميشن بيتطبق على عنصر الزرار (Pressable) نفسه مباشرة —
// مش على View إضافي بيلفه — عشان أي style بييجي من بره (زي flex: 1، أو
// أي خاصية تخطيط تانية بيعتمد عليها والد الزرار) يفضل شغال بالظبط زي ما
// كان بيشتغل مع TouchableOpacity الأصلي. لو الأنيميشن اتطبق على View لفّاف
// جوه الزرار بدل الزرار نفسه، أي style زي flex: 1 كان هيتحط على الـ View
// الداخلي مش على الزرار، فالزرار (الأب فعليًا جوه أي flex container) مكانش
// هياخد المساحة المطلوبة ويكسر التخطيط — وده بالظبط اللي كان بيكسر الدرج
// الجانبي (SideMenu) وأي حاجة تانية معتمدة على flex: 1.
// ============================================================================

const AnimatedPressableBase = Animated.createAnimatedComponent(Pressable);

export default function AnimatedTouchable({
  children,
  style,
  onPress,
  onLongPress,
  onPressIn,
  onPressOut,
  disabled,
  activeOpacity = 0.85,
  scaleTo = 0.94,
  hitSlop,
  ...rest
}) {
  const scale = useRef(new Animated.Value(1)).current;
  const opacity = useRef(new Animated.Value(1)).current;

  const handlePressIn = (e) => {
    Animated.parallel([
      Animated.spring(scale, {
        toValue: scaleTo,
        useNativeDriver: true,
        speed: 50,
        bounciness: 6,
      }),
      Animated.timing(opacity, {
        toValue: activeOpacity,
        duration: 100,
        useNativeDriver: true,
      }),
    ]).start();
    onPressIn && onPressIn(e);
  };

  const handlePressOut = (e) => {
    Animated.parallel([
      Animated.spring(scale, {
        toValue: 1,
        useNativeDriver: true,
        speed: 30,
        bounciness: 8,
      }),
      Animated.timing(opacity, {
        toValue: 1,
        duration: 150,
        useNativeDriver: true,
      }),
    ]).start();
    onPressOut && onPressOut(e);
  };

  return (
    <AnimatedPressableBase
      disabled={disabled}
      hitSlop={hitSlop}
      onPress={onPress}
      onLongPress={onLongPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
      style={[style, { transform: [{ scale }], opacity }]}
      {...rest}
    >
      {children}
    </AnimatedPressableBase>
  );
}
