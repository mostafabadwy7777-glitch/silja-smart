import React, { createContext, useContext, useEffect, useState } from 'react';
import { DEFAULT_THEME_ID, LIGHT_THEME_ID, CUSTOM_THEME_ID, DEFAULT_CUSTOM_THEME, getTheme } from './theme';
import {
  loadThemeId,
  saveThemeId,
  loadLastDarkThemeId,
  saveLastDarkThemeId,
  loadCustomTheme,
  saveCustomTheme,
} from './storage';

const ThemeContext = createContext({
  theme: getTheme(DEFAULT_THEME_ID),
  themeId: DEFAULT_THEME_ID,
  isLight: false,
  customTheme: DEFAULT_CUSTOM_THEME,
  setThemeId: () => {},
  toggleLightDark: () => {},
  updateCustomColor: () => {},
  applyCustomBase: () => {},
  resetCustomTheme: () => {},
});

export function ThemeProvider({ children }) {
  const [themeId, setThemeIdState] = useState(DEFAULT_THEME_ID);
  const [lastDarkThemeId, setLastDarkThemeId] = useState(DEFAULT_THEME_ID);
  const [customTheme, setCustomThemeState] = useState(DEFAULT_CUSTOM_THEME);

  useEffect(() => {
    (async () => {
      const [saved, savedLastDark, savedCustom] = await Promise.all([
        loadThemeId(),
        loadLastDarkThemeId(),
        loadCustomTheme(),
      ]);
      if (saved) setThemeIdState(saved);
      if (savedLastDark) setLastDarkThemeId(savedLastDark);
      if (savedCustom) setCustomThemeState({ ...DEFAULT_CUSTOM_THEME, ...savedCustom });
    })();
  }, []);

  // بيرجع شكل الثيم الكامل لأي id: ثيم جاهز من القايمة الثابتة، أو الثيم
  // المخصص (آخر ألوان حفظها المستخدم بنفسه) لو الid بتاعه "custom".
  const resolveTheme = (id) => (id === CUSTOM_THEME_ID ? customTheme : getTheme(id));

  const setThemeId = async (id) => {
    setThemeIdState(id);
    await saveThemeId(id);
    // أي ثيم غامق (سواء جاهز أو مخصص) بيتسجل كـ"آخر ثيم غامق" عشان نرجعله
    // لما نطفي الوضع النهاري بزرار التبديل السريع.
    if (!resolveTheme(id).isLight) {
      setLastDarkThemeId(id);
      await saveLastDarkThemeId(id);
    }
  };

  // تبديل سريع بين الوضع الغامق (آخر ثيم غامق كان مختار) والوضع النهاري.
  const toggleLightDark = async () => {
    if (resolveTheme(themeId).isLight) {
      await setThemeId(lastDarkThemeId || DEFAULT_THEME_ID);
    } else {
      await setThemeId(LIGHT_THEME_ID);
    }
  };

  // تعديل لون واحد بس في الثيم المخصص (زي اللون الأساسي أو لون التشغيل)
  // وحفظه فورًا. لو الثيم المخصص مش مفعّل حاليًا، بيتفعّل تلقائيًا عشان
  // المستخدم يشوف أثر التعديل على كل شاشات التطبيق على طول.
  const updateCustomColor = async (key, value) => {
    const next = { ...customTheme, [key]: value };
    setCustomThemeState(next);
    await saveCustomTheme(next);
    if (themeId !== CUSTOM_THEME_ID) {
      await setThemeId(CUSTOM_THEME_ID);
    }
  };

  // بداية سريعة: نسخ "سطح" ثيم جاهز (خلفية/كروت/حدود/نصوص) كنقطة انطلاق
  // للثيم المخصص، من غير ما نلمس الألوان الأساسية (accent/on/off) اللي
  // المستخدم يكون غيّرها بنفسه بالفعل.
  const applyCustomBase = async (baseId) => {
    const base = getTheme(baseId);
    const next = {
      ...customTheme,
      isLight: !!base.isLight,
      bg: base.bg,
      card: base.card,
      cardAlt: base.cardAlt,
      border: base.border,
      textPrimary: base.textPrimary,
      textSecondary: base.textSecondary,
      textMuted: base.textMuted,
    };
    setCustomThemeState(next);
    await saveCustomTheme(next);
    if (themeId !== CUSTOM_THEME_ID) {
      await setThemeId(CUSTOM_THEME_ID);
    }
  };

  const resetCustomTheme = async () => {
    setCustomThemeState(DEFAULT_CUSTOM_THEME);
    await saveCustomTheme(DEFAULT_CUSTOM_THEME);
  };

  const theme = resolveTheme(themeId);
  const isLight = !!theme.isLight;

  return (
    <ThemeContext.Provider
      value={{
        theme,
        themeId,
        isLight,
        customTheme,
        setThemeId,
        toggleLightDark,
        updateCustomColor,
        applyCustomBase,
        resetCustomTheme,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
}

// Hook بسيط عشان أي شاشة تاخد الثيم الحالي وتقدر تغيّره
export function useTheme() {
  return useContext(ThemeContext);
}
