// ============================================================================
// مجموعات / مشاهد (Scenes) — تجميع مفاتيح من بوردات مختلفة وتشغيلهم بأمر واحد.
// ============================================================================
// السين نفسها بتتخزن محليًا بس (AsyncStorage عن طريق storage.js)، مفيش حاجة
// سيرفر هنا لأن التشغيل بيحصل وقت ما التطبيق فاتح وبيبعت أوامر MQTT عادية
// لنفس control_topic بتاع كل مفتاح، بالظبط زي لو دوست عليه من شاشته العادية.
// ============================================================================

// بيرجع قايمة مسطحة بكل المفاتيح المتاحة من كل البوردات (switches بس، مش الري)
// عشان تُستخدم في شاشة بناء الـ Scene.
export function flattenSwitchDevices(boards) {
  const result = [];
  (boards || []).forEach((board) => {
    if (board.type === 'irrigation') return;
    (board.devices || []).forEach((device) => {
      result.push({
        boardId: board.id,
        boardName: board.name,
        controlTopic: device.controlTopic,
        name: device.name,
        icon: device.icon,
        controlType: device.controlType || 'toggle',
      });
    });
  });
  return result;
}

// بيشغّل Scene: بينشر أمر MQTT لكل أكشن فيها. الأفعال المتاحة:
// - toggle switches: 'ON' / 'OFF'
// - updown switches: 'UP' / 'DOWN' / 'STOP'
export function runScene(scene, client) {
  if (!client || !client.connected || !scene) return { ok: false, error: 'مفيش اتصال بالسيرفر' };
  (scene.actions || []).forEach((action) => {
    if (!action.controlTopic || !action.value) return;
    client.publish(action.controlTopic, action.value);
  });
  return { ok: true };
}
