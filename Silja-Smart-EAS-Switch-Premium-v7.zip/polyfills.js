// ============================================================================
// Polyfills لازمة عشان مكتبة "mqtt" تشتغل جوه React Native / Expo
// ============================================================================
// مكتبة mqtt (زي أغلب مكتبات الـ Node.js) بتفترض إن فيه Buffer وprocess
// متاحين كمتغيرات عامة (global) - وده موجود في المتصفح وفي Node نفسه، لكن
// React Native مفيهوش أي حاجة من دول افتراضيًا. من غير الملف ده، أول ما
// mqtt.connect() بينفّذ (بعد ما تحفظ الإعدادات وتدوس "حفظ ومتابعة")،
// التطبيق بيعمل crash فوري وبيقفل من غير أي رسالة خطأ ظاهرة، خصوصًا في
// نسخة الـ APK النهائية (مش وضع التطوير اللي بيوريك الخطأ على الشاشة).
//
// الملف ده لازم يتعمله import قبل أي حاجة تانية في أول سطر في App.js
// (وقبل تحديدًا استيراد مكتبة mqtt نفسها) عشان الـ global.Buffer/process
// يكونوا جاهزين قبل ما كود المكتبة يتنفذ.
// ============================================================================
import { Buffer } from 'buffer';
import process from 'process';

if (typeof global.Buffer === 'undefined') {
  global.Buffer = Buffer;
}
if (typeof global.process === 'undefined') {
  global.process = process;
}
// بعض إصدارات مكتبات الـ stream بتدور على process.nextTick وprocess.version
if (!global.process.nextTick) {
  global.process.nextTick = setImmediate;
}
if (!global.process.version) {
  global.process.version = 'v18.0.0';
}
if (!global.process.env) {
  global.process.env = {};
}
