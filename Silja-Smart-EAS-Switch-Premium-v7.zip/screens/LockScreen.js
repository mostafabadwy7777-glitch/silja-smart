import React, { useEffect, useState } from 'react';
import { SafeAreaView, View, Text, StyleSheet, StatusBar } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FONTS } from '../fonts';
import * as LocalAuthentication from 'expo-local-authentication';
import { useTheme } from '../ThemeContext';

// شاشة القفل اللي بتظهر أول ما التطبيق يفتح لو حماية البصمة مفعّلة. بتفضل
// ظاهرة لحد ما المستخدم يتحقق ببصمة إصبعه أو بصمة وجهه (أيًا كان المتاح على
// الموبايل) — مفيش أي طريقة تانية تتخطاها من جوه التطبيق نفسه.
export default function LockScreen({ onUnlocked }) {
  const { theme, isLight } = useTheme();
  const styles = getStyles(theme);
  const [status, setStatus] = useState('idle'); // idle | checking | error
  const [errorMsg, setErrorMsg] = useState('');

  const tryUnlock = async () => {
    setStatus('checking');
    setErrorMsg('');

    const hasHardware = await LocalAuthentication.hasHardwareAsync();
    const isEnrolled = await LocalAuthentication.isEnrolledAsync();

    if (!hasHardware || !isEnrolled) {
      // الموبايل مفيهوش بصمة متسجلة أصلاً — منسمحش بأي حماية وهمية، نسيب المستخدم
      // يدخل عادي بدل ما يتقفل بره التطبيق نهائيًا.
      onUnlocked();
      return;
    }

    const result = await LocalAuthentication.authenticateAsync({
      promptMessage: 'افتح Silja Smart',
      cancelLabel: 'إلغاء',
      disableDeviceFallback: false,
    });

    if (result.success) {
      onUnlocked();
    } else {
      setStatus('error');
      setErrorMsg('مفيش تحقق حصل — جرب تاني');
    }
  };

  useEffect(() => {
    tryUnlock();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} />
      <View style={styles.center}>
        <View style={styles.iconCircle}>
          <MaterialCommunityIcons name="shield-lock-outline" size={40} color={theme.accentSoft} />
        </View>
        <Text style={styles.title}>Silja Smart مقفول</Text>
        <Text style={styles.hint}>افتحه ببصمة إصبعك أو بصمة وجهك</Text>

        {!!errorMsg && <Text style={styles.errorText}>{errorMsg}</Text>}

        <TouchableOpacity
          style={styles.unlockBtn}
          onPress={tryUnlock}
          activeOpacity={0.85}
          disabled={status === 'checking'}
        >
          <MaterialCommunityIcons name="fingerprint" size={20} color="#fff" />
          <Text style={styles.unlockBtnText}>{status === 'checking' ? 'جاري التحقق…' : 'حاول تاني'}</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

function getStyles(theme) {
  return StyleSheet.create({
    container: { flex: 1 },
    center: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 30 },
    iconCircle: {
      width: 84,
      height: 84,
      borderRadius: 42,
      backgroundColor: theme.cardAlt,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 18,
    },
    title: { color: theme.textPrimary, fontSize: 19, fontWeight: '800', fontFamily: FONTS.display, marginBottom: 6 },
    hint: { color: theme.textSecondary, fontSize: 13, marginBottom: 20, textAlign: 'center' },
    errorText: { color: theme.danger, fontSize: 12, marginBottom: 14, textAlign: 'center' },
    unlockBtn: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      backgroundColor: theme.accent,
      borderRadius: 16,
      paddingVertical: 13,
      paddingHorizontal: 26,
    },
    unlockBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  });
}
