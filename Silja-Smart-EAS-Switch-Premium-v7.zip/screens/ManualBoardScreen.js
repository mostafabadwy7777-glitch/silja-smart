import React, { useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  TextInput,
  StyleSheet,
  Modal,
  FlatList,
  Image,
} from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FONTS } from '../fonts';
import { showAlert } from '../components/PremiumAlert';
import { useTheme } from '../ThemeContext';
import { REALISTIC_ICON_OPTIONS, getDeviceIcon } from '../deviceIcons';
import { newId } from '../storage';

// بيحوّل لون hex (#rrggbb) لـ rgba بشفافية معينة — نفس الفكرة المستخدمة في
// SwitchesScreen عشان نديله شكل "كبسولة زجاج" بدل الدايرة المصمتة.
function hexToRgba(hex, alpha) {
  const clean = (hex || '').replace('#', '');
  if (clean.length !== 6) return `rgba(255,255,255,${alpha})`;
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}

// ============================================================================
// إضافة بورد يدوي (من غير رسالة اكتشاف موقّعة)
// ============================================================================
// شاشة "إضافة بورد" التلقائية (BoardsListScreen) بتعتمد كليًا على إن الفيرموير
// ينشر رسالة اكتشاف JSON موقّعة بـ HMAC على `<device_id>/discovery`، ولو
// الفيرموير قديم/مش متحدث ومش بينشرها، مفيش وسيلة إنه يتضاف من هناك.
// الشاشة دي بديل بيسيب المستخدم يكتب توبيكات MQTT بنفسه يدويًا بالكامل —
// مفيش أي تحقق توقيع هنا خالص، فمقصود إنها تفضل حاجة واعية (الشرح فوق
// الفورم) لأن أي حد يعرف نفس التوبيكات يقدر ينشر عليها من غير أي تحقق.
// ============================================================================

function newSwitchRow() {
  return {
    localId: newId(),
    name: '',
    controlTopic: '',
    statusTopic: '',
    icon: 'switch',
    controlType: 'toggle',
  };
}

export default function ManualBoardScreen({ boards, onBack, onAdded }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);

  const [boardType, setBoardType] = useState('switches');
  const [name, setName] = useState('');
  const [deviceId, setDeviceId] = useState('');
  const [prefix, setPrefix] = useState('');
  const [switchesList, setSwitchesList] = useState([newSwitchRow()]);
  const [iconPickerId, setIconPickerId] = useState(null);

  const updateSwitch = (localId, patch) =>
    setSwitchesList((prev) => prev.map((s) => (s.localId === localId ? { ...s, ...patch } : s)));

  const addSwitchRow = () => setSwitchesList((prev) => [...prev, newSwitchRow()]);

  const removeSwitchRow = (localId) =>
    setSwitchesList((prev) => (prev.length > 1 ? prev.filter((s) => s.localId !== localId) : prev));

  const finishAdd = (board) => {
    showAlert('تمت الإضافة', `اتضاف بورد "${board.name}" — تقدر تتحكم فيه دلوقتي من شاشة البوردات.`, [
      { text: 'تمام', onPress: () => onAdded?.(board) },
    ]);
  };

  const handleSubmit = () => {
    const trimmedName = name.trim();
    if (!trimmedName) {
      showAlert('خطأ', 'لازم تكتب اسم للبورد');
      return;
    }

    if (boardType === 'irrigation') {
      const trimmedPrefix = prefix.trim();
      if (!trimmedPrefix) {
        showAlert('خطأ', 'لازم تكتب "بادئة التوبيك" (Prefix) بتاعة بورد الري');
        return;
      }
      const duplicate = (boards || []).some((b) => b.type === 'irrigation' && b.prefix === trimmedPrefix);
      if (duplicate) {
        showAlert('خطأ', 'فيه بورد ري مضاف بالفعل بنفس البادئة دي');
        return;
      }
      finishAdd({ name: trimmedName, type: 'irrigation', prefix: trimmedPrefix, manual: true });
      return;
    }

    const cleanedSwitches = switchesList
      .map((s, i) => ({
        name: s.name.trim() || `مفتاح ${i + 1}`,
        controlTopic: s.controlTopic.trim(),
        statusTopic: s.statusTopic.trim() || undefined,
        icon: s.icon || 'switch',
        controlType: s.controlType === 'updown' ? 'updown' : 'toggle',
      }))
      .filter((s) => s.controlTopic);

    if (cleanedSwitches.length === 0) {
      showAlert('خطأ', 'لازم تضيف مفتاح واحد على الأقل وتكتب له "توبيك التحكم" (Control Topic)');
      return;
    }

    const finalDeviceId = deviceId.trim() || `manual-${newId()}`;
    const duplicate = (boards || []).some((b) => b.type !== 'irrigation' && b.deviceId === finalDeviceId);
    if (duplicate) {
      showAlert('خطأ', 'فيه بورد مضاف بالفعل بنفس معرّف الجهاز ده');
      return;
    }

    finishAdd({
      name: trimmedName,
      type: 'switches',
      deviceId: finalDeviceId,
      devices: cleanedSwitches,
      manual: true,
    });
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={onBack} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Text style={styles.back}>‹ رجوع</Text>
        </TouchableOpacity>
        <Text style={styles.title}>إضافة بورد يدوي</Text>
        <View style={{ width: 50 }} />
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 60 }} keyboardShouldPersistTaps="handled">
        <View style={styles.infoBox}>
          <MaterialCommunityIcons name="information-outline" size={18} color={theme.accentSoft} />
          <Text style={styles.infoText}>
            دي مخصوصة للبوردات اللي الفيرموير بتاعتها قديم ومش بينشر رسالة اكتشاف موقّعة بمفتاح الربط. هنا بتكتب
            توبيكات MQTT بنفسك يدويًا من غير أي تحقق توقيع — يعني التطبيق هيصدّق أي حد ينشر على نفس التوبيك، فاستخدمها
            بس للبوردات اللي انت واثق فيها.
          </Text>
        </View>

        <Text style={styles.label}>نوع البورد</Text>
        <View style={styles.typeRow}>
          <TouchableOpacity
            style={[styles.typeBtn, boardType === 'switches' && styles.typeBtnActive]}
            onPress={() => setBoardType('switches')}
            activeOpacity={0.85}
          >
            <MaterialCommunityIcons
              name="view-grid-outline"
              size={16}
              color={boardType === 'switches' ? '#fff' : theme.textSecondary}
            />
            <Text style={[styles.typeBtnText, boardType === 'switches' && styles.typeBtnTextActive]}>
              لوحة مفاتيح
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.typeBtn, boardType === 'irrigation' && styles.typeBtnActive]}
            onPress={() => setBoardType('irrigation')}
            activeOpacity={0.85}
          >
            <MaterialCommunityIcons
              name="water-pump"
              size={16}
              color={boardType === 'irrigation' ? '#fff' : theme.textSecondary}
            />
            <Text style={[styles.typeBtnText, boardType === 'irrigation' && styles.typeBtnTextActive]}>
              ري / محابس
            </Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.label}>اسم البورد</Text>
        <TextInput
          style={styles.input}
          value={name}
          onChangeText={setName}
          placeholder="مثلاً: مطبخ قديم"
          placeholderTextColor={theme.textMuted}
        />

        {boardType === 'irrigation' ? (
          <>
            <Text style={styles.label}>بادئة التوبيك (Prefix)</Text>
            <TextInput
              style={styles.input}
              value={prefix}
              onChangeText={setPrefix}
              placeholder="irrigation"
              placeholderTextColor={theme.textMuted}
              autoCapitalize="none"
            />
            <Text style={styles.hint}>
              التطبيق هيستخدم التوبيكات "&lt;البادئة&gt;/control" و"&lt;البادئة&gt;/status" و"&lt;البادئة&gt;/status_text"
              و"&lt;البادئة&gt;/availability" — لازم الفيرموير يكون شغال بنفس الأسامي دي بالظبط.
            </Text>
          </>
        ) : (
          <>
            <Text style={styles.label}>معرّف الجهاز (Device ID) — اختياري</Text>
            <TextInput
              style={styles.input}
              value={deviceId}
              onChangeText={setDeviceId}
              placeholder="kitchen-esp32-01"
              placeholderTextColor={theme.textMuted}
              autoCapitalize="none"
            />
            <Text style={styles.hint}>
              بيتحسب منه توبيك التوفر ("&lt;المعرّف&gt;/availability"). لو الفيرموير مش بينشر عليه، سيب الخانة فاضية —
              البورد هيتضاف عادي بس من غير مؤشر أونلاين/أوفلاين دقيق.
            </Text>

            <Text style={[styles.label, { marginTop: 10 }]}>المفاتيح</Text>
            {switchesList.map((s, idx) => (
              <View key={s.localId} style={styles.switchCard}>
                <View style={styles.switchCardHeader}>
                  <TouchableOpacity
                    style={styles.switchIconBtn}
                    onPress={() => setIconPickerId(s.localId)}
                    activeOpacity={0.8}
                  >
                    <MaterialCommunityIcons name={getDeviceIcon(s.icon).icon} size={20} color={theme.accentSoft} />
                  </TouchableOpacity>
                  <TextInput
                    style={[styles.input, { flex: 1, marginBottom: 0 }]}
                    value={s.name}
                    onChangeText={(v) => updateSwitch(s.localId, { name: v })}
                    placeholder={`مفتاح ${idx + 1}`}
                    placeholderTextColor={theme.textMuted}
                  />
                  {switchesList.length > 1 && (
                    <TouchableOpacity
                      onPress={() => removeSwitchRow(s.localId)}
                      hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                    >
                      <MaterialCommunityIcons name="close-circle-outline" size={20} color={theme.danger} />
                    </TouchableOpacity>
                  )}
                </View>

                <Text style={styles.smallLabel}>توبيك التحكم (Control Topic)</Text>
                <TextInput
                  style={styles.input}
                  value={s.controlTopic}
                  onChangeText={(v) => updateSwitch(s.localId, { controlTopic: v })}
                  placeholder="kitchen/relay1/set"
                  placeholderTextColor={theme.textMuted}
                  autoCapitalize="none"
                />

                <Text style={styles.smallLabel}>توبيك الحالة (اختياري، لو مختلف عن توبيك التحكم)</Text>
                <TextInput
                  style={styles.input}
                  value={s.statusTopic}
                  onChangeText={(v) => updateSwitch(s.localId, { statusTopic: v })}
                  placeholder="kitchen/relay1/state"
                  placeholderTextColor={theme.textMuted}
                  autoCapitalize="none"
                />

                <View style={styles.controlTypeRow}>
                  <TouchableOpacity
                    style={[styles.miniToggle, s.controlType === 'toggle' && styles.miniToggleActive]}
                    onPress={() => updateSwitch(s.localId, { controlType: 'toggle' })}
                  >
                    <Text style={[styles.miniToggleText, s.controlType === 'toggle' && styles.miniToggleTextActive]}>
                      تشغيل/إيقاف
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.miniToggle, s.controlType === 'updown' && styles.miniToggleActive]}
                    onPress={() => updateSwitch(s.localId, { controlType: 'updown' })}
                  >
                    <Text style={[styles.miniToggleText, s.controlType === 'updown' && styles.miniToggleTextActive]}>
                      طلوع/نزول
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            ))}

            <TouchableOpacity style={styles.addSwitchBtn} onPress={addSwitchRow} activeOpacity={0.85}>
              <MaterialCommunityIcons name="plus" size={18} color={theme.accentSoft} />
              <Text style={styles.addSwitchBtnText}>مفتاح تاني</Text>
            </TouchableOpacity>
          </>
        )}

        <TouchableOpacity style={styles.submitBtn} onPress={handleSubmit} activeOpacity={0.85}>
          <Text style={styles.submitBtnText}>إضافة البورد</Text>
        </TouchableOpacity>
      </ScrollView>

      <Modal visible={!!iconPickerId} transparent animationType="fade" onRequestClose={() => setIconPickerId(null)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>اختار شكل المفتاح</Text>
            <FlatList
              data={REALISTIC_ICON_OPTIONS}
              keyExtractor={(item) => item.id}
              numColumns={4}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={{ paddingBottom: 6 }}
              renderItem={({ item }) => {
                const current = switchesList.find((s) => s.localId === iconPickerId);
                const selected = current && current.icon === item.id;
                return (
                  <TouchableOpacity
                    style={[styles.iconOption, selected && styles.iconOptionSelected]}
                    onPress={() => {
                      updateSwitch(iconPickerId, { icon: item.id });
                      setIconPickerId(null);
                    }}
                    activeOpacity={0.82}
                  >
                    <View style={[styles.iconOptionGlass, selected && styles.iconOptionGlassSelected]}>
                      <MaterialCommunityIcons name={item.icon} size={26} color={theme.textPrimary} />
                    </View>
                    <Text style={styles.iconOptionLabel} numberOfLines={1}>
                      {item.label}
                    </Text>
                  </TouchableOpacity>
                );
              }}
            />
            <TouchableOpacity style={styles.closeModalBtn} onPress={() => setIconPickerId(null)}>
              <Text style={styles.submitBtnText}>إغلاق</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

function getStyles(theme) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: theme.bg, padding: 18, paddingTop: 55 },
    headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
    back: { fontSize: 15, color: theme.accentSoft },
    title: { fontSize: 17, fontWeight: '700', fontFamily: FONTS.display, color: theme.textPrimary },
    infoBox: {
      flexDirection: 'row',
      gap: 10,
      backgroundColor: theme.card,
      borderRadius: 14,
      borderWidth: 1,
      borderColor: theme.border,
      padding: 14,
      marginBottom: 18,
      alignItems: 'flex-start',
    },
    infoText: { flex: 1, color: theme.textSecondary, fontSize: 12, lineHeight: 18, textAlign: 'right' },
    label: { fontSize: 12.5, fontWeight: '700', color: theme.textPrimary, marginBottom: 6, textAlign: 'right' },
    smallLabel: { fontSize: 11, color: theme.textSecondary, marginBottom: 4, marginTop: 8, textAlign: 'right' },
    hint: { fontSize: 11, color: theme.textMuted, lineHeight: 16, marginBottom: 14, textAlign: 'right' },
    input: {
      backgroundColor: theme.cardAlt,
      borderRadius: 10,
      borderWidth: 1,
      borderColor: theme.border,
      paddingHorizontal: 12,
      paddingVertical: 10,
      color: theme.textPrimary,
      fontSize: 13,
      marginBottom: 12,
      textAlign: 'right',
    },
    typeRow: { flexDirection: 'row', gap: 10, marginBottom: 16 },
    typeBtn: {
      flex: 1,
      flexDirection: 'row',
      gap: 6,
      alignItems: 'center',
      justifyContent: 'center',
      paddingVertical: 12,
      borderRadius: 12,
      borderWidth: 1,
      borderColor: theme.border,
      backgroundColor: theme.card,
    },
    typeBtnActive: { backgroundColor: theme.accent, borderColor: theme.accent },
    typeBtnText: { color: theme.textSecondary, fontSize: 12.5, fontWeight: '700' },
    typeBtnTextActive: { color: '#fff' },
    switchCard: {
      backgroundColor: theme.card,
      borderRadius: 14,
      borderWidth: 1,
      borderColor: theme.border,
      padding: 14,
      marginBottom: 12,
    },
    switchCardHeader: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
    switchIconBtn: {
      width: 36,
      height: 36,
      borderRadius: 18,
      backgroundColor: hexToRgba(theme.cardAlt, 0.6),
      borderWidth: 1,
      borderColor: hexToRgba(theme.border, 0.8),
      alignItems: 'center',
      justifyContent: 'center',
    },
    controlTypeRow: { flexDirection: 'row', gap: 8, marginTop: 4 },
    miniToggle: {
      flex: 1,
      paddingVertical: 8,
      borderRadius: 8,
      borderWidth: 1,
      borderColor: theme.border,
      alignItems: 'center',
      backgroundColor: theme.cardAlt,
    },
    miniToggleActive: { backgroundColor: theme.accent, borderColor: theme.accent },
    miniToggleText: { fontSize: 11.5, color: theme.textSecondary, fontWeight: '600' },
    miniToggleTextActive: { color: '#fff' },
    addSwitchBtn: {
      flexDirection: 'row',
      gap: 6,
      alignItems: 'center',
      justifyContent: 'center',
      paddingVertical: 12,
      borderRadius: 12,
      borderWidth: 1,
      borderStyle: 'dashed',
      borderColor: theme.accentSoft,
      marginBottom: 20,
    },
    addSwitchBtnText: { color: theme.accentSoft, fontSize: 13, fontWeight: '700' },
    submitBtn: {
      backgroundColor: theme.accent,
      borderRadius: 14,
      paddingVertical: 15,
      alignItems: 'center',
      marginTop: 6,
    },
    submitBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', alignItems: 'center' },
    modalBox: {
      width: '88%',
      maxHeight: '70%',
      backgroundColor: theme.card,
      borderRadius: 18,
      borderWidth: 1,
      borderColor: theme.border,
      padding: 16,
    },
    modalTitle: { color: theme.textPrimary, fontSize: 15, fontWeight: '700', marginBottom: 10, textAlign: 'right' },
    iconOption: { width: '20%', alignItems: 'center', paddingVertical: 10, borderRadius: 10 },
    iconOptionSelected: { backgroundColor: theme.cardAlt },
    iconOptionGlass: {
      width: 40,
      height: 40,
      borderRadius: 20,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: hexToRgba(theme.cardAlt, 0.6),
      borderWidth: 1,
      borderColor: hexToRgba(theme.border, 0.8),
      overflow: 'hidden',
    },
    iconOptionGlassSelected: {
      backgroundColor: hexToRgba(theme.accent, 0.18),
      borderColor: theme.accent,
      shadowColor: theme.accent,
      shadowOpacity: 0.9,
      shadowRadius: 10,
      shadowOffset: { width: 0, height: 0 },
      elevation: 6,
    },
    iconOptionLabel: { color: theme.textMuted, fontSize: 9, marginTop: 4, textAlign: 'center' },
    closeModalBtn: {
      backgroundColor: theme.cardAlt,
      borderRadius: 12,
      paddingVertical: 12,
      alignItems: 'center',
      marginTop: 10,
    },
  });
}
