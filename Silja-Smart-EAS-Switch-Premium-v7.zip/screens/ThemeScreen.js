import React, { useEffect, useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, StyleSheet } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { showAlert } from '../components/PremiumAlert';
import { THEMES, COLOR_SWATCHES, CUSTOM_THEME_ID } from '../theme';
import { useTheme } from '../ThemeContext';
import { loadSwitchCardStyle, saveSwitchCardStyle, loadSwitchShape, saveSwitchShape } from '../storage';
import { SWITCH_CARD_STYLES } from '../switchCardStyles';
import ScreenBackground from '../components/ScreenBackground';
import PremiumSwitch from '../components/PremiumSwitch';
import { FONTS } from '../fonts';


const SURFACE_SWATCHES = [
  '#02040d', '#04061a', '#031018', '#090312', '#10050b', '#090909',
  '#f3f7fb', '#f2faf6', '#fdf3f6', '#faf6ef', '#f5f6f9', '#fbf9f3',
];
const CARD_SWATCHES = [
  '#070b1d', '#0a0f2e', '#071b25', '#160722', '#1b0914', '#15120a',
  '#ffffff', '#f4fbf8', '#fff8fb', '#fffdf8', '#ffffff', '#ffffff',
];

// صف اختيار لون: باليتة ألوان جاهزة، واللون المختار عليه علامة صح.
function ColorPickerRow({ styles, value, onChange }) {
  return (
    <View style={styles.colorRow}>
      {COLOR_SWATCHES.map((c) => (
        <TouchableOpacity
          key={c}
          style={[styles.colorSwatch, { backgroundColor: c }, value === c && styles.colorSwatchSelected]}
          onPress={() => onChange(c)}
        >
          {value === c && <MaterialCommunityIcons name="check" size={14} color="#0f1712" />}
        </TouchableOpacity>
      ))}
    </View>
  );
}

export default function ThemeScreen({ onBack }) {
  const { theme, themeId, setThemeId, customTheme, updateCustomColor, applyCustomBase, resetCustomTheme } = useTheme();
  const [customOpen, setCustomOpen] = useState(themeId === CUSTOM_THEME_ID);
  const [switchCardStyle, setSwitchCardStyle] = useState('classic');
  const [switchShape, setSwitchShape] = useState('round');

  useEffect(() => {
    loadSwitchCardStyle().then(setSwitchCardStyle);
    loadSwitchShape().then(setSwitchShape);
  }, []);

  const pickCardStyle = (id) => {
    setSwitchCardStyle(id);
    saveSwitchCardStyle(id);
  };

  const pickSwitchShape = (id) => {
    setSwitchShape(id);
    saveSwitchShape(id);
  };

  const SWITCH_SHAPES = [
    { id: 'square', name: 'مربع', description: 'سويتش بزوايا مربعة وناعمة' },
    { id: 'round', name: 'مدور', description: 'سويتش دائري Premium Glass' },
    { id: 'text', name: 'ON / OFF', description: 'يعرض حالة التشغيل داخل السويتش' },
  ];

  const confirmReset = () => {
    showAlert('استعادة الافتراضي', 'هيرجع الثيم المخصص لألوانه الأصلية. متأكد؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'استعادة', style: 'destructive', onPress: resetCustomTheme },
    ]);
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <ScreenBackground theme={theme} />
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={onBack}>
          <Text style={[styles.back, { color: theme.accentSoft }]}>‹ رجوع</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: theme.textPrimary }]}>الثيمات والمظهر</Text>
        <View style={{ width: 50 }} />
      </View>

      <Text style={[styles.hint, { color: theme.textSecondary }]}>
        اختار الشكل اللي يعجبك، هيتطبق على كل شاشات التطبيق فورًا. أو افتح "ثيم مخصص" تحت وحدد الألوان بنفسك.
      </Text>

      <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
        {/* ---- كارت الثيم المخصص ---- */}
        <View
          style={[
            styles.card,
            { backgroundColor: customTheme.card, borderColor: themeId === CUSTOM_THEME_ID ? customTheme.accent : customTheme.border },
          ]}
        >
          <TouchableOpacity
            onPress={() => {
              setCustomOpen(true);
              if (themeId !== CUSTOM_THEME_ID) setThemeId(CUSTOM_THEME_ID);
            }}
            activeOpacity={0.85}
          >
            <View style={styles.cardTop}>
              <View style={styles.customTitleRow}>
                <MaterialCommunityIcons name="palette" size={18} color={customTheme.accent} />
                <Text style={[styles.themeName, { color: customTheme.textPrimary }]}>ثيم مخصص</Text>
              </View>
              {themeId === CUSTOM_THEME_ID ? (
                <MaterialCommunityIcons name="check-circle" size={22} color={customTheme.accent} />
              ) : (
                <MaterialCommunityIcons name="circle-outline" size={22} color={customTheme.border} />
              )}
            </View>

            <View style={styles.swatchRow}>
              <View style={[styles.swatch, { backgroundColor: customTheme.bg, borderColor: customTheme.border }]} />
              <View style={[styles.swatch, { backgroundColor: customTheme.accent, shadowColor: customTheme.accent }]} />
              <View style={[styles.swatch, { backgroundColor: customTheme.on, shadowColor: customTheme.on }]} />
              <View style={[styles.swatch, { backgroundColor: customTheme.off, shadowColor: customTheme.off }]} />
            </View>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => setCustomOpen((v) => !v)} style={styles.expandRow}>
            <Text style={[styles.expandText, { color: customTheme.accentSoft }]}>
              {customOpen ? 'إخفاء خيارات التخصيص ▲' : 'تخصيص الألوان يدويًا ▼'}
            </Text>
          </TouchableOpacity>

          {customOpen && (
            <View>
              <Text style={[styles.subLabel, { color: customTheme.textSecondary }]}>ابدأ من سطح ثيم جاهز:</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.baseRow}>
                {THEMES.map((t) => (
                  <TouchableOpacity key={t.id} onPress={() => applyCustomBase(t.id)} style={styles.baseChipWrap}>
                    <View style={[styles.baseChip, { backgroundColor: t.bg, borderColor: t.border }]}>
                      <View style={[styles.baseChipDot, { backgroundColor: t.accent }]} />
                    </View>
                    <Text style={[styles.baseChipLabel, { color: customTheme.textMuted }]} numberOfLines={1}>
                      {t.name}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>


              <Text style={[styles.subLabel, { color: customTheme.textSecondary }]}>لون الخلفية:</Text>
              <View style={styles.colorRow}>
                {SURFACE_SWATCHES.map((c) => (
                  <TouchableOpacity
                    key={'bg-' + c}
                    style={[styles.colorSwatch, { backgroundColor: c }, customTheme.bg === c && styles.colorSwatchSelected]}
                    onPress={() => updateCustomColor('bg', c)}
                  >
                    {customTheme.bg === c && <MaterialCommunityIcons name="check" size={14} color="#ffffff" />}
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={[styles.subLabel, { color: customTheme.textSecondary }]}>لون الكروت:</Text>
              <View style={styles.colorRow}>
                {CARD_SWATCHES.map((c, i) => (
                  <TouchableOpacity
                    key={'card-' + i + '-' + c}
                    style={[styles.colorSwatch, { backgroundColor: c }, customTheme.card === c && styles.colorSwatchSelected]}
                    onPress={() => updateCustomColor('card', c)}
                  >
                    {customTheme.card === c && <MaterialCommunityIcons name="check" size={14} color="#ffffff" />}
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={[styles.subLabel, { color: customTheme.textSecondary }]}>اللون الأساسي (الأزرار والعناوين):</Text>
              <ColorPickerRow styles={styles} value={customTheme.accent} onChange={(c) => updateCustomColor('accent', c)} />

              <Text style={[styles.subLabel, { color: customTheme.textSecondary }]}>اللون الثانوي (الروابط والتفاصيل):</Text>
              <ColorPickerRow styles={styles} value={customTheme.accentSoft} onChange={(c) => updateCustomColor('accentSoft', c)} />

              <Text style={[styles.subLabel, { color: customTheme.textSecondary }]}>لون التشغيل (ON):</Text>
              <ColorPickerRow styles={styles} value={customTheme.on} onChange={(c) => updateCustomColor('on', c)} />

              <Text style={[styles.subLabel, { color: customTheme.textSecondary }]}>لون الإيقاف / الخطر (OFF):</Text>
              <ColorPickerRow styles={styles} value={customTheme.off} onChange={(c) => updateCustomColor('off', c)} />

              <TouchableOpacity style={[styles.resetBtn, { borderColor: customTheme.border }]} onPress={confirmReset}>
                <MaterialCommunityIcons name="restore" size={16} color={customTheme.textMuted} />
                <Text style={[styles.resetBtnText, { color: customTheme.textMuted }]}>استعادة الألوان الافتراضية</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* ---- الثيمات الجاهزة ---- */}
        {THEMES.map((t) => {
          const selected = t.id === themeId;
          return (
            <TouchableOpacity
              key={t.id}
              onPress={() => setThemeId(t.id)}
              activeOpacity={0.85}
              style={[
                styles.card,
                { backgroundColor: t.card, borderColor: selected ? t.accent : t.border },
                selected && {
                  shadowColor: t.accent,
                  shadowOffset: { width: 0, height: 6 },
                  shadowOpacity: 0.5,
                  shadowRadius: 16,
                  elevation: 6,
                },
              ]}
            >
              <View style={styles.cardTop}>
                <Text style={[styles.themeName, { color: t.textPrimary }]}>{t.name}</Text>
                {selected ? (
                  <MaterialCommunityIcons name="check-circle" size={22} color={t.accent} />
                ) : (
                  <MaterialCommunityIcons name="circle-outline" size={22} color={t.border} />
                )}
              </View>

              <View style={styles.swatchRow}>
                <View style={[styles.swatch, { backgroundColor: t.bg, borderColor: t.border }]} />
                <View style={[styles.swatch, { backgroundColor: t.accent, shadowColor: t.accent }]} />
                <View style={[styles.swatch, { backgroundColor: t.on, shadowColor: t.on }]} />
                <View style={[styles.swatch, { backgroundColor: t.off, shadowColor: t.off }]} />
              </View>

              <View style={styles.previewRow}>
                <View style={[styles.previewGlow, { borderColor: t.on, shadowColor: t.on, backgroundColor: t.cardAlt }]}>
                  <MaterialCommunityIcons name="lightbulb-on" size={22} color={t.on} />
                </View>
                <Text style={[styles.previewLabel, { color: t.textSecondary }]}>شغال</Text>
                <View style={[styles.previewGlow, { borderColor: t.off, shadowColor: t.off, backgroundColor: t.cardAlt }]}>
                  <MaterialCommunityIcons name="lightbulb-off-outline" size={22} color={t.off} />
                </View>
                <Text style={[styles.previewLabel, { color: t.textSecondary }]}>مطفي</Text>
              </View>
            </TouchableOpacity>
          );
        })}

        {/* ---- شكل السويتش نفسه ---- */}
        <Text style={[styles.sectionTitle, { color: theme.textPrimary }]}>شكل السويتش</Text>
        <Text style={[styles.hint, { color: theme.textSecondary, marginTop: 0 }]}>اختار شكل زر التشغيل والإيقاف اللي يظهر داخل كروت المفاتيح.</Text>

        <View style={styles.shapeOptionsRow}>
          {SWITCH_SHAPES.map((s) => {
            const selected = s.id === switchShape;
            return (
              <TouchableOpacity
                key={s.id}
                onPress={() => pickSwitchShape(s.id)}
                activeOpacity={0.85}
                style={[styles.shapeOption, { backgroundColor: theme.card, borderColor: selected ? theme.accent : theme.border }, selected && { shadowColor: theme.accent, shadowOpacity: 0.35, shadowRadius: 10, elevation: 5 }]}
              >
                <View style={styles.shapePreview}>
                  <PremiumSwitch value={s.id === 'round'} theme={theme} onValueChange={() => {}} shape={s.id} size={0.95} />
                </View>
                <Text style={[styles.shapeOptionName, { color: theme.textPrimary }]}>{s.name}</Text>
                <Text style={[styles.shapeOptionDesc, { color: theme.textSecondary }]}>{s.description}</Text>
                <MaterialCommunityIcons name={selected ? 'check-circle' : 'circle-outline'} size={19} color={selected ? theme.accent : theme.border} style={{ marginTop: 7 }} />
              </TouchableOpacity>
            );
          })}
        </View>

        {/* ---- شكل كروت المفاتيح الذكية ---- */}
        <Text style={[styles.sectionTitle, { color: theme.textPrimary }]}>شكل كروت المفاتيح الذكية</Text>
        <Text style={[styles.hint, { color: theme.textSecondary, marginTop: 0 }]}>
          هيتطبق على كروت المفاتيح في كل البوردات.
        </Text>

        {SWITCH_CARD_STYLES.map((s) => {
          const selected = s.id === switchCardStyle;
          return (
            <TouchableOpacity
              key={s.id}
              onPress={() => pickCardStyle(s.id)}
              activeOpacity={0.85}
              style={[
                styles.card,
                { backgroundColor: theme.card, borderColor: selected ? theme.accent : theme.border },
                selected && {
                  shadowColor: theme.accent,
                  shadowOffset: { width: 0, height: 6 },
                  shadowOpacity: 0.5,
                  shadowRadius: 16,
                  elevation: 6,
                },
              ]}
            >
              <View style={styles.cardTop}>
                <Text style={[styles.themeName, { color: theme.textPrimary }]}>{s.name}</Text>
                {selected ? (
                  <MaterialCommunityIcons name="check-circle" size={22} color={theme.accent} />
                ) : (
                  <MaterialCommunityIcons name="circle-outline" size={22} color={theme.border} />
                )}
              </View>
              <Text style={[styles.subLabel, { color: theme.textSecondary, marginTop: 0 }]}>{s.description}</Text>

              {/* معاينة مصغّرة حية بألوان الثيم الحالي */}
              <View style={[styles.mockWrap, { backgroundColor: theme.cardAlt, borderColor: theme.border }]}>
                {s.id === 'classic' && (
                  <View style={styles.mockClassic}>
                    <View style={[styles.mockCircle, { borderColor: theme.on }]}>
                      <MaterialCommunityIcons name="lightbulb-on" size={16} color={theme.on} />
                    </View>
                    <Text style={[styles.mockText, { color: theme.textPrimary }]}>إضاءة الصالة</Text>
                    <View style={[styles.mockPill, { borderColor: theme.on }]}>
                      <Text style={[styles.mockPillText, { color: theme.on }]}>ON</Text>
                    </View>
                  </View>
                )}

                {s.id === 'horizontal' && (
                  <View style={styles.mockHorizontal}>
                    <View style={[styles.mockCircle, { borderColor: theme.on }]}>
                      <MaterialCommunityIcons name="lightbulb-on" size={16} color={theme.on} />
                    </View>
                    <View style={{ flex: 1, minWidth: 0 }}>
                      <Text style={[styles.mockText, { color: theme.textPrimary, textAlign: 'right' }]}>
                        إضاءة الصالة
                      </Text>
                      <Text style={[styles.mockSubText, { color: theme.accentSoft, textAlign: 'right' }]}>
                        شغال الآن
                      </Text>
                    </View>
                    <PremiumSwitch value theme={theme} onValueChange={() => {}} size={0.8} />
                  </View>
                )}

                {s.id === 'minimal' && (
                  <View style={styles.mockMinimal}>
                    <View style={[styles.mockStripe, { backgroundColor: theme.on }]} />
                    <MaterialCommunityIcons name="lightbulb-on" size={16} color={theme.on} />
                    <Text style={[styles.mockText, { color: theme.textPrimary, flex: 1 }]}>إضاءة الصالة</Text>
                    <PremiumSwitch value theme={theme} onValueChange={() => {}} size={0.7} shape="square" />
                  </View>
                )}
              </View>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 18, paddingTop: 55 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  back: { fontSize: 15 },
  title: { fontSize: 18, fontWeight: '700', fontFamily: FONTS.display },
  hint: { fontSize: 12, marginBottom: 16, lineHeight: 18 },
  card: { borderRadius: 20, borderWidth: 1.25, padding: 16, marginBottom: 14 },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  customTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  themeName: { fontSize: 16, fontWeight: '700', fontFamily: FONTS.displaySemiBold },
  swatchRow: { flexDirection: 'row', gap: 8, marginBottom: 14 },
  swatch: {
    width: 28,
    height: 28,
    borderRadius: 8,
    borderWidth: 1,
    shadowOpacity: 0.8,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 0 },
    elevation: 3,
  },
  previewRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  previewGlow: {
    width: 42,
    height: 42,
    borderRadius: 21,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
    shadowOpacity: 0.9,
    shadowRadius: 9,
    shadowOffset: { width: 0, height: 0 },
    elevation: 5,
  },
  previewLabel: { fontSize: 11, fontWeight: '700', marginRight: 6 },

  sectionTitle: { fontSize: 15, fontWeight: '700', fontFamily: FONTS.displaySemiBold, marginBottom: 4 },
  shapeOptionsRow: { flexDirection: 'row', gap: 8, marginBottom: 18 },
  shapeOption: { flex: 1, minHeight: 122, borderRadius: 16, borderWidth: 1.2, padding: 9, alignItems: 'center', justifyContent: 'center' },
  shapePreview: { height: 40, alignItems: 'center', justifyContent: 'center' },
  shapeOptionName: { fontSize: 12, fontWeight: '800', marginTop: 5 },
  shapeOptionDesc: { fontSize: 8.5, textAlign: 'center', lineHeight: 12, marginTop: 3 },

  // ---- معاينات مصغّرة لأشكال كروت المفاتيح ----
  mockWrap: { borderRadius: 14, borderWidth: 1, padding: 10, marginTop: 4, overflow: 'hidden' },
  mockClassic: { alignItems: 'center', gap: 6 },
  mockHorizontal: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  mockMinimal: { flexDirection: 'row', alignItems: 'center', gap: 8, position: 'relative', overflow: 'hidden', paddingRight: 4 },
  mockCircle: {
    width: 32,
    height: 32,
    borderRadius: 12,
    borderWidth: 1.25,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mockText: { fontSize: 12.5, fontWeight: '700' },
  mockSubText: { fontSize: 10.5, marginTop: 2 },
  mockPill: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 999, borderWidth: 1 },
  mockPillText: { fontSize: 10, fontWeight: '700' },
  mockStripe: { position: 'absolute', top: -10, bottom: -10, left: -10, width: 4 },

  // ---- خيارات التخصيص اليدوي ----
  expandRow: { marginTop: 2 },
  expandText: { fontSize: 12, fontWeight: '700' },
  subLabel: { fontSize: 12, fontWeight: '600', marginTop: 14, marginBottom: 8 },
  baseRow: { gap: 12, paddingBottom: 4 },
  baseChipWrap: { alignItems: 'center', width: 56 },
  baseChip: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  baseChipDot: { width: 14, height: 14, borderRadius: 7 },
  baseChipLabel: { fontSize: 10, marginTop: 4, textAlign: 'center' },
  colorRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  colorSwatch: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  colorSwatchSelected: { borderColor: '#171a21' },
  resetBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    justifyContent: 'center',
    borderWidth: 1,
    borderRadius: 10,
    paddingVertical: 10,
    marginTop: 16,
  },
  resetBtnText: { fontSize: 12, fontWeight: '600' },
});
