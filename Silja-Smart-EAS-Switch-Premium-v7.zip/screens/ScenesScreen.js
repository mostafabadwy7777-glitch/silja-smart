import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, TextInput, StyleSheet } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FONTS } from '../fonts';
import { showAlert } from '../components/PremiumAlert';
import { useTheme } from '../ThemeContext';
import { getDeviceIcon } from '../deviceIcons';
import { flattenSwitchDevices, runScene } from '../scenes';
import { newId } from '../storage';

// أفعال ممكنة لكل نوع مفتاح
const TOGGLE_ACTIONS = [
  { value: 'ON', label: 'شغّل', icon: 'power-plug' },
  { value: 'OFF', label: 'اقفل', icon: 'power-plug-off' },
];
const UPDOWN_ACTIONS = [
  { value: 'UP', label: 'طلوع', icon: 'arrow-up-bold' },
  { value: 'DOWN', label: 'نزول', icon: 'arrow-down-bold' },
  { value: 'STOP', label: 'وقف', icon: 'stop' },
];

export default function ScenesScreen({ boards, scenes, onSaveScenes, client, connected, onBack }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);
  const devices = flattenSwitchDevices(boards);

  const [editing, setEditing] = useState(null); // null | scene draft object
  const [running, setRunning] = useState(null);

  const startNew = () => setEditing({ id: newId(), name: '', icon: 'star-four-points', actions: [] });
  const startEdit = (scene) => setEditing({ ...scene, actions: scene.actions.map((a) => ({ ...a })) });

  const persist = (list) => onSaveScenes(list);

  const deleteScene = (id) => {
    showAlert('مسح المشهد', 'متأكد؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'مسح', style: 'destructive', onPress: () => persist(scenes.filter((s) => s.id !== id)) },
    ]);
  };

  const trigger = async (scene) => {
    setRunning(scene.id);
    const res = runScene(scene, client);
    setRunning(null);
    if (!res.ok) showAlert('خطأ', res.error || 'مقدرش أشغّل المشهد');
  };

  const toggleActionInDraft = (device, value) => {
    setEditing((prev) => {
      const idx = prev.actions.findIndex((a) => a.controlTopic === device.controlTopic);
      const actions = [...prev.actions];
      if (idx >= 0 && actions[idx].value === value) {
        // نفس القيمة تاني = شيل الفعل ده من المشهد
        actions.splice(idx, 1);
      } else if (idx >= 0) {
        actions[idx] = { ...actions[idx], value };
      } else {
        actions.push({
          controlTopic: device.controlTopic,
          boardName: device.boardName,
          name: device.name,
          icon: device.icon,
          controlType: device.controlType,
          value,
        });
      }
      return { ...prev, actions };
    });
  };

  const saveDraft = () => {
    if (!editing.name.trim()) {
      showAlert('خطأ', 'لازم تحط اسم للمشهد');
      return;
    }
    if (editing.actions.length === 0) {
      showAlert('خطأ', 'لازم تختار مفتاح واحد على الأقل وحالته');
      return;
    }
    const exists = scenes.some((s) => s.id === editing.id);
    const list = exists ? scenes.map((s) => (s.id === editing.id ? editing : s)) : [...scenes, editing];
    persist(list);
    setEditing(null);
  };

  // ---------- شاشة تعديل/إنشاء مشهد ----------
  if (editing) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
        <View style={styles.headerRow}>
          <TouchableOpacity onPress={() => setEditing(null)}>
            <Text style={[styles.back, { color: theme.accentSoft }]}>‹ رجوع</Text>
          </TouchableOpacity>
          <Text style={[styles.title, { color: theme.textPrimary }]}>مشهد جديد</Text>
          <View style={{ width: 50 }} />
        </View>

        <TextInput
          style={[styles.input, { backgroundColor: theme.cardAlt, color: theme.textPrimary }]}
          value={editing.name}
          onChangeText={(v) => setEditing({ ...editing, name: v })}
          placeholder="اسم المشهد (مثلاً: وضع النوم)"
          placeholderTextColor={theme.textMuted}
        />

        <Text style={[styles.hint, { color: theme.textSecondary }]}>
          اختار حالة كل مفتاح عايزه يتغيّر لما المشهد يشتغل. المفاتيح اللي مش هتلمسها هتفضل زي ما هي.
        </Text>

        <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
          {devices.length === 0 && (
            <Text style={[styles.emptyText, { color: theme.textMuted }]}>مفيش مفاتيح متاحة — ضيف بوردات الأول.</Text>
          )}
          {devices.map((device) => {
            const current = editing.actions.find((a) => a.controlTopic === device.controlTopic);
            const actionsList = device.controlType === 'updown' ? UPDOWN_ACTIONS : TOGGLE_ACTIONS;
            const meta = getDeviceIcon(device.icon);
            return (
              <View key={device.controlTopic} style={[styles.deviceRow, { backgroundColor: theme.card, borderColor: theme.border }]}>
                <View style={styles.deviceInfo}>
                  <MaterialCommunityIcons name={meta.icon} size={20} color={theme.textSecondary} />
                  <View style={{ marginRight: 8 }}>
                    <Text style={[styles.deviceName, { color: theme.textPrimary }]}>{device.name}</Text>
                    <Text style={[styles.boardName, { color: theme.textMuted }]}>{device.boardName}</Text>
                  </View>
                </View>
                <View style={styles.actionsRow}>
                  {actionsList.map((a) => {
                    const selected = current?.value === a.value;
                    return (
                      <TouchableOpacity
                        key={a.value}
                        onPress={() => toggleActionInDraft(device, a.value)}
                        style={[
                          styles.actionChip,
                          {
                            backgroundColor: selected ? theme.accent : theme.cardAlt,
                            borderColor: selected ? theme.accent : theme.border,
                          },
                        ]}
                      >
                        <Text style={{ color: selected ? '#fff' : theme.textSecondary, fontSize: 11, fontWeight: '700' }}>
                          {a.label}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </View>
            );
          })}
        </ScrollView>

        <TouchableOpacity style={[styles.primaryBtn, { backgroundColor: theme.accent }]} onPress={saveDraft}>
          <Text style={styles.btnText}>حفظ المشهد</Text>
        </TouchableOpacity>
      </SafeAreaView>
    );
  }

  // ---------- قائمة المشاهد ----------
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={onBack}>
          <Text style={[styles.back, { color: theme.accentSoft }]}>‹ رجوع</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: theme.textPrimary }]}>المشاهد (Scenes)</Text>
        <TouchableOpacity onPress={startNew}>
          <MaterialCommunityIcons name="plus-circle" size={24} color={theme.accent} />
        </TouchableOpacity>
      </View>

      <Text style={[styles.hint, { color: theme.textSecondary }]}>
        جمّع مفاتيح من أي بورد في مشهد واحد وشغّلهم كلهم بدوسة واحدة (مثلاً "وضع النوم" يقفل كل حاجة إلا الإنذار).
      </Text>

      <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
        {scenes.length === 0 && (
          <Text style={[styles.emptyText, { color: theme.textMuted }]}>مفيش مشاهد لسه. دوس + عشان تعمل واحد.</Text>
        )}
        {scenes.map((scene) => (
          <View key={scene.id} style={[styles.sceneCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
            <TouchableOpacity
              style={styles.sceneMain}
              activeOpacity={0.8}
              onPress={() => trigger(scene)}
              disabled={!connected || running === scene.id}
            >
              <View style={[styles.sceneIconWrap, { backgroundColor: theme.cardAlt, borderColor: theme.accent }]}>
                <MaterialCommunityIcons name="star-four-points" size={20} color={theme.accent} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.sceneName, { color: theme.textPrimary }]}>{scene.name}</Text>
                <Text style={[styles.sceneMeta, { color: theme.textMuted }]}>{scene.actions.length} مفتاح — دوس للتشغيل</Text>
              </View>
              <MaterialCommunityIcons name="play-circle-outline" size={26} color={connected ? theme.accent : theme.textMuted} />
            </TouchableOpacity>
            <View style={styles.sceneFooter}>
              <TouchableOpacity onPress={() => startEdit(scene)} style={styles.footerBtn}>
                <MaterialCommunityIcons name="pencil-outline" size={16} color={theme.textSecondary} />
                <Text style={[styles.footerBtnText, { color: theme.textSecondary }]}>تعديل</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => deleteScene(scene.id)} style={styles.footerBtn}>
                <MaterialCommunityIcons name="trash-can-outline" size={16} color={theme.danger} />
                <Text style={[styles.footerBtnText, { color: theme.danger }]}>مسح</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const getStyles = (theme) =>
  StyleSheet.create({
    container: { flex: 1, padding: 18, paddingTop: 55 },
    headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
    back: { fontSize: 15 },
    title: { fontSize: 18, fontWeight: '700', fontFamily: FONTS.display },
    hint: { fontSize: 12, marginBottom: 16, lineHeight: 18 },
    emptyText: { fontSize: 13, textAlign: 'center', marginTop: 40 },
    input: { borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10, marginBottom: 12, fontSize: 14 },
    deviceRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      borderWidth: 1,
      borderRadius: 12,
      padding: 12,
      marginBottom: 10,
    },
    deviceInfo: { flexDirection: 'row', alignItems: 'center', flex: 1 },
    deviceName: { fontSize: 13, fontWeight: '700' },
    boardName: { fontSize: 11, marginTop: 2 },
    actionsRow: { flexDirection: 'row', gap: 6 },
    actionChip: { borderWidth: 1, borderRadius: 8, paddingVertical: 6, paddingHorizontal: 10 },
    primaryBtn: { borderRadius: 12, paddingVertical: 14, alignItems: 'center', marginTop: 4 },
    btnText: { color: '#fff', fontWeight: '600', fontSize: 13 },
    sceneCard: { borderWidth: 1, borderRadius: 14, marginBottom: 12, overflow: 'hidden' },
    sceneMain: { flexDirection: 'row', alignItems: 'center', padding: 14, gap: 10 },
    sceneIconWrap: {
      width: 40,
      height: 40,
      borderRadius: 20,
      borderWidth: 1.5,
      alignItems: 'center',
      justifyContent: 'center',
    },
    sceneName: { fontSize: 15, fontWeight: '700' },
    sceneMeta: { fontSize: 11, marginTop: 2 },
    sceneFooter: { flexDirection: 'row', borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: '#0002' },
    footerBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 10, gap: 6 },
    footerBtnText: { fontSize: 12, fontWeight: '600' },
  });
