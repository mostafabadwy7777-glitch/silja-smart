import React, { useEffect, useRef, useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  TextInput,
  StyleSheet,
} from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FONTS } from '../fonts';
import { showAlert } from '../components/PremiumAlert';
import PremiumSwitch from '../components/PremiumSwitch';
import { useTheme } from '../ThemeContext';

const ZONE_NAMES = ['المنطقة 1', 'المنطقة 2', 'المنطقة 3', 'المنطقة 4'];

function TimeBadge({ icon, value, unit, color, bg, border }) {
  return (
    <View style={[styles.timeBadge, { backgroundColor: bg, borderColor: border }]}>
      <Text style={styles.timeBadgeIcon}>{icon}</Text>
      <Text style={[styles.timeBadgeValue, { color }]}>{value}</Text>
      {!!unit && <Text style={[styles.timeBadgeUnit, { color }]}>{unit}</Text>}
    </View>
  );
}

export default function IrrigationScreen({ board, client, connected, onBack }) {
  const { theme } = useTheme();
  const base = board.prefix;

  const [available, setAvailable] = useState(null);
  const [statusText, setStatusText] = useState('');
  const [status, setStatus] = useState({
    running: false,
    current_relay: 0,
    completed_cycles: 0,
    target_cycles: 1,
    remaining_minutes: 0,
    durations_min: [10, 10, 10, 10],
    manual_on: [0, 0, 0, 0],
    manual_remaining_sec: [0, 0, 0, 0],
  });
  const [manualMinutes, setManualMinutes] = useState(['10', '10', '10', '10']);
  const [durationInputs, setDurationInputs] = useState(['10', '10', '10', '10']);
  const [cyclesInput, setCyclesInput] = useState('1');

  // البورد بيبعت حالة عبر MQTT كل 30 ثانية بس، فلو عرضنا manual_remaining_sec
  // زي ما هو هيقف على نفس الرقم لمدة نص دقيقة. عشان يحس المستخدم إنه فعلاً
  // بيشوف عداد حي (زي التحكم المباشر في البورد)، بنسجل وقت وصول آخر رسالة
  // حالة، وبنعمل تيك كل ثانية محليًا نطرح بيه الوقت اللي عدى من الرقم الأخير.
  const lastStatusAtRef = useRef(Date.now());
  const [, forceTick] = useState(0);

  useEffect(() => {
    const id = setInterval(() => forceTick((t) => t + 1), 1000);
    return () => clearInterval(id);
  }, []);

  const remainingSecForZone = (i) => {
    const baseSec = status.manual_remaining_sec?.[i] || 0;
    if (!status.manual_on[i] || baseSec <= 0) return 0;
    const elapsed = Math.floor((Date.now() - lastStatusAtRef.current) / 1000);
    return Math.max(0, baseSec - elapsed);
  };

  const fmtTime = (s) => {
    const sec = Math.max(0, Math.floor(s));
    const m = Math.floor(sec / 60);
    const r = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}`;
  };

  const stepCycles = (delta) => {
    const cur = parseInt(cyclesInput, 10) || 1;
    setCyclesInput(String(Math.max(1, cur + delta)));
  };

  // أول رسالة حالة توصل من الفيرموير، نملى بيها خانات "عدد الدورات" و"مدة
  // كل منطقة" بالقيم الحقيقية المحفوظة على البورد (مش القيم الافتراضية
  // الثابتة اللي التطبيق بيفتح بيها) — عشان لو المستخدم فاتح الشاشة يلاقي
  // القيم الفعلية على طول، مش أرقام وهمية لازم يمسحها الأول. بعد أول
  // مزامنة بس، عشان لو المستخدم بيكتب رقم جديد لسه ما ضغطش "حفظ"، رسايل
  // الحالة الدورية (كل 30 ثانية) متمسحش كتابته.
  const syncedInputsRef = useRef(false);

  useEffect(() => {
    if (!client) return undefined;

    const topics = [`${base}/status`, `${base}/status_text`, `${base}/availability`];
    topics.forEach((t) => client.subscribe(t));

    const handler = (topic, payload) => {
      const msg = payload.toString();
      if (topic === `${base}/status`) {
        try {
          const parsed = JSON.parse(msg);
          setStatus((prev) => ({ ...prev, ...parsed }));
          lastStatusAtRef.current = Date.now();
          if (!syncedInputsRef.current) {
            syncedInputsRef.current = true;
            if (Array.isArray(parsed.durations_min) && parsed.durations_min.length === 4) {
              setDurationInputs(parsed.durations_min.map((v) => String(v)));
            }
            if (typeof parsed.target_cycles === 'number') {
              setCyclesInput(String(parsed.target_cycles));
            }
          }
        } catch (e) {
          // ignore malformed payload
        }
      } else if (topic === `${base}/status_text`) {
        setStatusText(msg);
      } else if (topic === `${base}/availability`) {
        setAvailable(msg);
      }
    };

    client.on('message', handler);
    return () => {
      client.off('message', handler);
      topics.forEach((t) => client.unsubscribe(t));
    };
  }, [client, base]);

  const publish = (subtopic, payload = '') => client?.publish(`${base}/${subtopic}`, String(payload));

  const startAuto = () => publish('cmd/start');
  const stopAll = () => publish('cmd/stop');
  const emergencyStop = () => {
    showAlert('إيقاف طوارئ', 'هيوقف كل المحابس فورًا. متأكد؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'إيقاف الآن', style: 'destructive', onPress: () => publish('cmd/emergency') },
    ]);
  };
  const applyCycles = () => {
    const v = parseInt(cyclesInput, 10);
    if (!Number.isFinite(v) || v < 1) {
      showAlert('عدد غير صحيح', 'لازم يكون عدد الدورات 1 على الأقل (مفيش وضع لا نهائي دلوقتي، للأمان).');
      return;
    }
    publish('cmd/cycles', v);
  };
  const applyDuration = (i) => publish(`cmd/duration/${i + 1}`, durationInputs[i]);
  const manualOn = (i) => publish(`cmd/manual/${i + 1}/on`, manualMinutes[i] || '0');
  const manualOff = (i) => publish(`cmd/manual/${i + 1}/off`);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={onBack}>
          <Text style={[styles.back, { color: theme.accentSoft }]}>‹ رجوع</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: theme.textPrimary }]}>{board.name}</Text>
        <View style={{ width: 50 }} />
      </View>

      <View style={styles.statusRow}>
        <View style={[styles.dot, { backgroundColor: connected ? theme.on : theme.off }]} />
        <Text style={[styles.statusLabel, { color: theme.textSecondary }]}>
          {connected ? 'متصل بالسيرفر' : 'جاري الاتصال…'}
          {available ? `  •  البورد: ${available === 'online' ? 'أونلاين' : 'أوفلاين'}` : ''}
        </Text>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 60 }}>
        {!!statusText && (
          <View style={[styles.card, { backgroundColor: theme.card }]}>
            <Text style={[styles.statusText, { color: theme.textPrimary }]}>{statusText}</Text>
          </View>
        )}

        <Text style={[styles.sectionTitle, { color: theme.accentSoft }]}>الوضع التلقائي</Text>
        <View style={[styles.card, { backgroundColor: theme.card }]}>
          <View style={styles.autoTopRow}>
            <View style={styles.autoInfoCol}>
              <Text style={[styles.rowText, { color: theme.textPrimary }]}>
                المنطقة الشغالة الآن: {status.current_relay > 0 ? ZONE_NAMES[status.current_relay - 1] : 'لا يوجد'}
              </Text>
              <View style={styles.progressWrap}>
                <View style={[styles.progressTrack, { backgroundColor: theme.cardAlt }]}>
                  <View
                    style={[
                      styles.progressFill,
                      {
                        backgroundColor: theme.accent,
                        width: `${status.target_cycles ? Math.min(100, (status.completed_cycles / status.target_cycles) * 100) : 0}%`,
                      },
                    ]}
                  />
                </View>
                <Text style={[styles.progressLabel, { color: theme.textSecondary }]}>
                  دورة {status.completed_cycles} من {status.target_cycles}
                </Text>
              </View>
            </View>

            {status.running && (
              <TimeBadge
                icon="⏱"
                value={String(status.remaining_minutes)}
                unit="دقيقة"
                color={theme.accentSoft}
                bg={theme.cardAlt}
                border={theme.border}
              />
            )}
          </View>

          <View style={styles.btnRow}>
            <TouchableOpacity style={[styles.smallBtn, { backgroundColor: theme.accent }]} onPress={startAuto}>
              <Text style={styles.btnText}>ابدأ تلقائي</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.smallBtn, { backgroundColor: theme.danger }]} onPress={stopAll}>
              <Text style={styles.btnText}>إيقاف الكل</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.cyclesSetRow}>
            <Text style={[styles.label, { color: theme.textSecondary }]}>عدد الدورات المطلوبة</Text>
            <View style={styles.stepperGroup}>
              <View style={[styles.stepper, { backgroundColor: theme.cardAlt, borderColor: theme.border }]}>
                <TouchableOpacity style={styles.stepperBtn} onPress={() => stepCycles(-1)}>
                  <Text style={[styles.stepperBtnText, { color: theme.accent }]}>−</Text>
                </TouchableOpacity>
                <TextInput
                  style={[styles.stepperInput, { color: theme.textPrimary }]}
                  keyboardType="numeric"
                  value={cyclesInput}
                  onChangeText={setCyclesInput}
                  textAlign="center"
                />
                <TouchableOpacity style={styles.stepperBtn} onPress={() => stepCycles(1)}>
                  <Text style={[styles.stepperBtnText, { color: theme.accent }]}>+</Text>
                </TouchableOpacity>
              </View>
              <TouchableOpacity style={[styles.applyBtn, { backgroundColor: theme.accent }]} onPress={applyCycles}>
                <Text style={styles.btnText}>تطبيق</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>


        <Text style={[styles.sectionTitle, { color: theme.accentSoft }]}>المناطق</Text>
        {ZONE_NAMES.map((name, i) => {
          const isOn = !!status.manual_on[i];
          const remain = remainingSecForZone(i);
          return (
            <View style={[styles.card, { backgroundColor: theme.card }]} key={i}>
              <View style={styles.zoneHeader}>
                <View style={styles.zoneNameCol}>
                  <MaterialCommunityIcons
                    name="sprinkler-variant"
                    size={20}
                    color={isOn ? theme.on : theme.accentSoft}
                    style={styles.zoneIcon}
                  />
                  <Text style={[styles.zoneName, { color: theme.textPrimary }]}>{name}</Text>
                </View>
                <View style={styles.zoneRightCol}>
                  <View style={[styles.statusPill, { backgroundColor: isOn ? theme.on + '22' : theme.cardAlt }]}>
                    <View style={[styles.statusDot, { backgroundColor: isOn ? theme.on : theme.textMuted }]} />
                    <Text style={[styles.statusPillText, { color: isOn ? theme.on : theme.textMuted }]}>
                      {isOn ? 'شغالة' : 'متوقفة'}
                    </Text>
                  </View>
                  <PremiumSwitch
                    value={isOn}
                    onValueChange={() => (isOn ? manualOff(i) : manualOn(i))}
                    theme={theme}
                    activeColor={theme.on}
                  />
                </View>
              </View>

              {isOn && remain > 0 && (
                <View style={styles.timeBadgeCenterWrap}>
                  <TimeBadge
                    icon="⏳"
                    value={fmtTime(remain)}
                    color={theme.accentSoft}
                    bg={theme.cardAlt}
                    border={theme.accentSoft}
                  />
                </View>
              )}

              <View style={styles.inlineRow}>
                <Text style={[styles.label, { color: theme.textSecondary }]}>تشغيل يدوي (دقايق):</Text>
                <TextInput
                  style={[styles.smallInput, { backgroundColor: theme.cardAlt, color: theme.textPrimary }]}
                  keyboardType="numeric"
                  value={manualMinutes[i]}
                  onChangeText={(v) => {
                    const arr = [...manualMinutes];
                    arr[i] = v;
                    setManualMinutes(arr);
                  }}
                />
                <TouchableOpacity style={[styles.tinyBtn, { backgroundColor: theme.accent }]} onPress={() => manualOn(i)}>
                  <Text style={styles.btnText}>تشغيل</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.tinyBtn, { backgroundColor: theme.danger }]} onPress={() => manualOff(i)}>
                  <Text style={styles.btnText}>إيقاف</Text>
                </TouchableOpacity>
              </View>

              <View style={styles.inlineRow}>
                <Text style={[styles.label, { color: theme.textSecondary }]}>مدة الوضع التلقائي (دقايق):</Text>
                <TextInput
                  style={[styles.smallInput, { backgroundColor: theme.cardAlt, color: theme.textPrimary }]}
                  keyboardType="numeric"
                  value={durationInputs[i]}
                  onChangeText={(v) => {
                    const arr = [...durationInputs];
                    arr[i] = v;
                    setDurationInputs(arr);
                  }}
                />
                <TouchableOpacity style={[styles.tinyBtn, { backgroundColor: theme.accent }]} onPress={() => applyDuration(i)}>
                  <Text style={styles.btnText}>حفظ</Text>
                </TouchableOpacity>
              </View>
            </View>
          );
        })}

        <TouchableOpacity style={[styles.emergencyBtn, { backgroundColor: theme.danger }]} onPress={emergencyStop}>
          <Text style={styles.emergencyText}>⛔ إيقاف طوارئ فوري</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 18, paddingTop: 55 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  back: { fontSize: 15 },
  title: { fontSize: 18, fontWeight: '700', fontFamily: FONTS.display },
  statusRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  dot: { width: 10, height: 10, borderRadius: 5, marginRight: 8 },
  statusLabel: { fontSize: 13 },
  statusText: { fontSize: 14, textAlign: 'center' },
  sectionTitle: { fontSize: 15, fontWeight: '700', marginTop: 6, marginBottom: 8 },
  card: { borderRadius: 14, padding: 16, marginBottom: 12 },
  rowText: { fontSize: 14, marginBottom: 4 },

  // ---- الوضع التلقائي: صف علوي (تقدم الدورات + بادج الوقت) ----
  autoTopRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  autoInfoCol: { flex: 1 },
  progressWrap: { marginTop: 10 },
  progressTrack: { height: 8, borderRadius: 5, overflow: 'hidden' },
  progressFill: { height: 8, borderRadius: 5 },
  progressLabel: { fontSize: 12, marginTop: 6 },

  // ---- ستيبر عدد الدورات ----
  cyclesSetRow: { marginTop: 14 },
  stepperGroup: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 8 },
  stepper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 10,
    borderWidth: 1,
    overflow: 'hidden',
  },
  stepperBtn: { paddingHorizontal: 14, paddingVertical: 8 },
  stepperBtnText: { fontSize: 18, fontWeight: '700' },
  stepperInput: { width: 46, textAlign: 'center', fontSize: 15, fontWeight: '700' },
  applyBtn: { borderRadius: 10, paddingHorizontal: 16, paddingVertical: 10 },

  // ---- بادج الوقت (مستخدم في الوضع التلقائي واليدوي بنفس الشكل) ----
  timeBadge: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 4,
    borderRadius: 12,
    borderWidth: 1.5,
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  timeBadgeIcon: { fontSize: 13, marginRight: 2 },
  timeBadgeValue: { fontSize: 20, fontWeight: '800', letterSpacing: 1 },
  timeBadgeUnit: { fontSize: 12, fontWeight: '600' },
  timeBadgeCenterWrap: { alignItems: 'center', marginBottom: 12, marginTop: 2 },

  // ---- هيدر كارت المنطقة ----
  zoneHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  zoneNameCol: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  zoneIcon: { marginRight: 2 },
  zoneName: { fontSize: 16, fontWeight: '600' },
  zoneRightCol: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  statusDot: { width: 7, height: 7, borderRadius: 4 },
  statusPillText: { fontSize: 12, fontWeight: '700' },

  btnRow: { flexDirection: 'row', gap: 10, marginTop: 14, marginBottom: 4 },
  inlineRow: { flexDirection: 'row', alignItems: 'center', marginTop: 10, flexWrap: 'wrap', gap: 8 },
  label: { fontSize: 12 },
  smallInput: {
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 6,
    width: 60,
    textAlign: 'center',
  },
  smallBtn: { flex: 1, borderRadius: 10, paddingVertical: 10, alignItems: 'center' },
  tinyBtn: { borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6 },
  emergencyBtn: { borderRadius: 14, paddingVertical: 16, alignItems: 'center', marginTop: 10 },
  emergencyText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  btnText: { color: '#fff', fontWeight: '600', fontSize: 13 },
});
