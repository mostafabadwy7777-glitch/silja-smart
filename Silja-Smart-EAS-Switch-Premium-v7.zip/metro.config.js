// ============================================================================
// إعداد Metro (الـ bundler بتاع Expo/React Native) عشان يعرف يلاقي مكافئات
// متوافقة مع React Native لمكونات Node اللي مكتبة "mqtt" بتحتاجها
// (stream, events) واللي مش موجودة أصلاً في بيئة الموبايل.
// ============================================================================
const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// مكتبة mqtt (وكذلك حزم تانية) بقت بتوصّف نفسها بحقل "exports" في package.json
// بدل "main" بس، وده بيحدد نسخة مخصصة لبيئات المتصفح/React Native بدل نسخة
// Node.js اللي بتستخدم موديولات زي net/tls/dns مش موجودة في React Native.
// من غير السطر ده Metro ممكن يتجاهل حقل exports ويحاول يحمّل نسخة Node.js
// العادية، فيفشل الاستيراد بصمت أو يديك موديول ناقص.
config.resolver.unstable_enablePackageExports = true;

config.resolver.extraNodeModules = {
  ...(config.resolver.extraNodeModules || {}),
  stream: require.resolve('readable-stream'),
  events: require.resolve('events'),
  buffer: require.resolve('buffer'),
};

module.exports = config;
