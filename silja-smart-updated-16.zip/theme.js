// تعريف كل الثيمات (الأشكال اللونية) المتاحة في التطبيق.
// كل ثيم بيحدد ألوان الخلفية، الكروت، النصوص، ولون حالتي التشغيل/الإيقاف الافتراضيين.
// أي مفتاح ينفع يستخدم لون مختلف عن الافتراضي (onColor / offColor) لو المستخدم اختار كده بنفسه.

export const THEMES = [
  {
    id: 'silja',
    name: 'أزرق كهربائي',
    bg: '#04061a',
    card: '#0a0f2e',
    cardAlt: '#111a45',
    border: '#2a3a8f',
    textPrimary: '#ffffff',
    textSecondary: '#a6b8ff',
    textMuted: '#5f6fc4',
    accent: '#3d5afe',
    accentSoft: '#5ce1ff',
    on: '#00e6a8',
    off: '#ff3d68',
    danger: '#ff3d68',
  },
  {
    id: 'forest',
    name: 'أخضر استوائي',
    bg: '#031810',
    card: '#062b1c',
    cardAlt: '#0a3a24',
    border: '#13603c',
    textPrimary: '#ffffff',
    textSecondary: '#9df0bf',
    textMuted: '#4fa377',
    accent: '#00c853',
    accentSoft: '#c6ff00',
    on: '#b6ff2e',
    off: '#ff5252',
    danger: '#ff5252',
  },
  {
    id: 'neon-blue',
    name: 'سماوي نيون',
    bg: '#020a16',
    card: '#051529',
    cardAlt: '#092542',
    border: '#144a78',
    textPrimary: '#ffffff',
    textSecondary: '#84e7ff',
    textMuted: '#3f84ab',
    accent: '#00b8ff',
    accentSoft: '#66ffe0',
    on: '#00ffc6',
    off: '#ff2d6a',
    danger: '#ff2d6a',
  },
  {
    id: 'violet',
    name: 'بنفسجي كهربائي',
    bg: '#130921',
    card: '#1f1034',
    cardAlt: '#2a1444',
    border: '#4a2470',
    textPrimary: '#ffffff',
    textSecondary: '#e0bfff',
    textMuted: '#9a76c4',
    accent: '#a742ff',
    accentSoft: '#ff8ae2',
    on: '#ff5ce8',
    off: '#ff5470',
    danger: '#ff5470',
  },
  {
    id: 'sunset',
    name: 'غروب ناري',
    bg: '#1d0a05',
    card: '#2e0f08',
    cardAlt: '#3c150b',
    border: '#6b2a14',
    textPrimary: '#fff6ee',
    textSecondary: '#ffb488',
    textMuted: '#c27e51',
    accent: '#ff6b1a',
    accentSoft: '#ffd166',
    on: '#ffc300',
    off: '#ff3860',
    danger: '#ff3860',
  },
  {
    id: 'ruby',
    name: 'ياقوت وذهب',
    bg: '#180305',
    card: '#2a0509',
    cardAlt: '#38070c',
    border: '#6b0f18',
    textPrimary: '#fff2f2',
    textSecondary: '#ffa3a3',
    textMuted: '#b8626a',
    accent: '#ff1744',
    accentSoft: '#ffca28',
    on: '#ffd54f',
    off: '#3fd0e0',
    danger: '#ff1744',
  },
  {
    id: 'daylight',
    name: 'فاتح نهاري',
    bg: '#f3f7fb',
    card: '#ffffff',
    cardAlt: '#eaf2fb',
    border: '#d7e3f2',
    textPrimary: '#0f1a2b',
    textSecondary: '#42546b',
    textMuted: '#8b9bb2',
    accent: '#0ea5e9',
    accentSoft: '#0d9488',
    on: '#16a34a',
    off: '#e11d48',
    danger: '#dc2626',
  },
];

// باليتة ألوان جاهزة يقدر المستخدم يختار منها لكل مفتاح (لون التشغيل ولون الإيقاف بشكل منفصل)
export const COLOR_SWATCHES = [
  '#00e6a8', // أخضر نيون
  '#00d4ff', // سماوي نيون
  '#3d5afe', // أزرق كهربائي
  '#a742ff', // بنفسجي
  '#ff5ce8', // ماجنتا
  '#ff6b1a', // برتقالي ناري
  '#ffd166', // أصفر ذهبي
  '#ff3d68', // وردي أحمر
  '#ff1744', // أحمر ياقوتي
  '#ffffff', // أبيض
];

export const DEFAULT_THEME_ID = 'silja';
export const LIGHT_THEME_ID = 'daylight';

export function getTheme(id) {
  return THEMES.find((t) => t.id === id) || THEMES[0];
}
