import AsyncStorage from '@react-native-async-storage/async-storage';

const SETTINGS_KEY = 'iot_mqtt_settings_v1';
const BOARDS_KEY = 'iot_boards_v1';
const THEME_KEY = 'iot_theme_v1';
const LAST_DARK_THEME_KEY = 'iot_last_dark_theme_v1';
const PAIRING_KEY_KEY = 'iot_pairing_key_v1';
const SCENES_KEY = 'iot_scenes_v1';
const INSTALL_ID_KEY = 'iot_install_id_v1';
const PUSH_ENABLED_KEY = 'iot_push_enabled_v1';
const BIOMETRIC_ENABLED_KEY = 'iot_biometric_enabled_v1';
const BOARDS_VIEW_MODE_KEY = 'iot_boards_view_mode_v1';

export const DEFAULT_SETTINGS = {
  protocol: 'wss',
  host: '',
  port: '8884',
  path: '/mqtt',
  username: '',
  password: '',
};

export async function loadSettings() {
  const raw = await AsyncStorage.getItem(SETTINGS_KEY);
  return raw ? JSON.parse(raw) : null;
}

export async function saveSettings(settings) {
  await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

export async function loadBoards() {
  const raw = await AsyncStorage.getItem(BOARDS_KEY);
  return raw ? JSON.parse(raw) : [];
}

export async function saveBoards(boards) {
  await AsyncStorage.setItem(BOARDS_KEY, JSON.stringify(boards));
}

export async function loadThemeId() {
  const raw = await AsyncStorage.getItem(THEME_KEY);
  return raw || null;
}

export async function saveThemeId(id) {
  await AsyncStorage.setItem(THEME_KEY, id);
}

// بيحفظ آخر ثيم "غامق" كان مختار قبل ما المستخدم يحول للوضع النهاري (الفاتح)،
// عشان لو رجع للوضع الغامق تاني يرجع لنفس الثيم اللي كان مختاره، مش الافتراضي.
export async function loadLastDarkThemeId() {
  const raw = await AsyncStorage.getItem(LAST_DARK_THEME_KEY);
  return raw || null;
}

export async function saveLastDarkThemeId(id) {
  await AsyncStorage.setItem(LAST_DARK_THEME_KEY, id);
}

// "مفتاح الربط" — سر مشترك بينك وبين الفيرموير بتاعك بس. التطبيق بيستخدمه عشان
// يتحقق من توقيع أي رسالة اكتشاف قبل ما يضيف بورد أو يزامن مفاتيح، فحتى لو حد تاني
// نصّب نفس التطبيق أو عرف اسم الجهاز (Device ID)، مش هيقدر يضيف بورده لأن الفيرموير
// بتاعه مش هيعرف يعمل توقيع صحيح من غير نفس المفتاح ده بالظبط.
export async function loadPairingKey() {
  const raw = await AsyncStorage.getItem(PAIRING_KEY_KEY);
  return raw || '';
}

export async function savePairingKey(key) {
  await AsyncStorage.setItem(PAIRING_KEY_KEY, key);
}

export function newId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

// ---------- مجموعات / مشاهد (Scenes) ----------
// كل scene = اسم + أيقونة + قايمة أفعال، كل فعل بيحدد مفتاح (من أي بورد) والحالة
// المطلوبة له. التشغيل بيبعت أوامر MQTT مباشرة زي ما لو كنت بتدوس على كل مفتاح لوحده.
export async function loadScenes() {
  const raw = await AsyncStorage.getItem(SCENES_KEY);
  return raw ? JSON.parse(raw) : [];
}

export async function saveScenes(scenes) {
  await AsyncStorage.setItem(SCENES_KEY, JSON.stringify(scenes));
}

// ---------- معرّف تركيب ثابت (Installation ID) ----------
// بيتحدد مرة واحدة ويتخزن محليًا، بنستخدمه كـ "اسم" لتوكن الإشعارات وقت التسجيل
// عند سيرفر الإشعارات (topic ثابت لكل جهاز بدل ما يتغير كل مرة).
export async function loadOrCreateInstallId() {
  let id = await AsyncStorage.getItem(INSTALL_ID_KEY);
  if (!id) {
    id = newId();
    await AsyncStorage.setItem(INSTALL_ID_KEY, id);
  }
  return id;
}

export async function loadPushEnabled() {
  const raw = await AsyncStorage.getItem(PUSH_ENABLED_KEY);
  return raw === '1';
}

export async function savePushEnabled(enabled) {
  await AsyncStorage.setItem(PUSH_ENABLED_KEY, enabled ? '1' : '0');
}

// تفعيل/تعطيل قفل فتح التطبيق بالبصمة (بصمة إصبع أو بصمة وجه — أيًا كان
// المتاح على الموبايل). القفل نفسه بيتحقق وقت التشغيل، هنا بس بنحفظ رغبة
// المستخدم إنه عايز الحماية دي مفعّلة ولا لأ.
export async function loadBiometricEnabled() {
  const raw = await AsyncStorage.getItem(BIOMETRIC_ENABLED_KEY);
  return raw === '1';
}

export async function saveBiometricEnabled(enabled) {
  await AsyncStorage.setItem(BIOMETRIC_ENABLED_KEY, enabled ? '1' : '0');
}

// شكل عرض شاشة "بوردات التحكم" الرئيسية: قائمة (list) أو شبكة (grid).
// بنحفظ اختيار المستخدم عشان يفضل زي ما سابه لما يفتح التطبيق تاني.
export async function loadBoardsViewMode() {
  const raw = await AsyncStorage.getItem(BOARDS_VIEW_MODE_KEY);
  return raw === 'grid' ? 'grid' : 'list';
}

export async function saveBoardsViewMode(mode) {
  await AsyncStorage.setItem(BOARDS_VIEW_MODE_KEY, mode === 'grid' ? 'grid' : 'list');
}

// ============================================================================
// نسخة احتياطية / استيراد — تصدير كل حاجة محفوظة على الموبايل (إعدادات
// الاتصال، مفتاح الربط، البوردات وكل مفاتيحها، المشاهد، الثيم، تفعيل
// الإشعارات) لملف JSON واحد، والقدرة إنك ترجّعه على موبايل تاني أو بعد ما
// تمسح التطبيق. مفيش تواصل بالإنترنت هنا خالص — كله محلي على الموبايل.
// ============================================================================
export const BACKUP_FORMAT_VERSION = 1;

// بيجمع كل البيانات المحفوظة في كائن واحد جاهز للتصدير (JSON.stringify).
export async function exportBackupPayload() {
  const [settings, pairingKey, boards, scenes, pushEnabled, themeId] = await Promise.all([
    loadSettings(),
    loadPairingKey(),
    loadBoards(),
    loadScenes(),
    loadPushEnabled(),
    loadThemeId(),
  ]);

  return {
    app: 'silja-smart',
    formatVersion: BACKUP_FORMAT_VERSION,
    exportedAt: new Date().toISOString(),
    settings: settings || DEFAULT_SETTINGS,
    pairingKey: pairingKey || '',
    boards: boards || [],
    scenes: scenes || [],
    pushEnabled: !!pushEnabled,
    themeId: themeId || null,
  };
}

// بيتحقق إن الملف اللي جاي فعلاً نسخة احتياطية من التطبيق ده قبل ما يكتب أي حاجة.
export function validateBackupPayload(data) {
  if (!data || typeof data !== 'object') return 'الملف مش بصيغة صحيحة';
  if (data.app !== 'silja-smart') return 'الملف ده مش نسخة احتياطية من Silja Smart';
  if (!Array.isArray(data.boards)) return 'الملف ناقصه بيانات البوردات';
  return null;
}

// بيكتب كل البيانات من نسخة احتياطية سبق تصديرها فوق أي بيانات موجودة حاليًا
// على الموبايل. استخدمها بعد تأكيد من المستخدم لأنها بتستبدل كل حاجة.
export async function applyBackupPayload(data) {
  const err = validateBackupPayload(data);
  if (err) throw new Error(err);

  await Promise.all([
    saveSettings(data.settings || DEFAULT_SETTINGS),
    savePairingKey(data.pairingKey || ''),
    saveBoards(Array.isArray(data.boards) ? data.boards : []),
    saveScenes(Array.isArray(data.scenes) ? data.scenes : []),
    savePushEnabled(!!data.pushEnabled),
    data.themeId ? saveThemeId(data.themeId) : Promise.resolve(),
  ]);
}
