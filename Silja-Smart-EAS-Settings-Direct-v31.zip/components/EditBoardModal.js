import React, { useEffect, useState } from 'react';
import {
  Modal,
  View,
  Text,
  TextInput,
  StyleSheet,
  FlatList,
  Image,
  ScrollView,
} from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { showAlert } from './PremiumAlert';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import { useTheme } from '../ThemeContext';
import { PLACE_ICONS, getDeviceIcon } from '../deviceIcons';
import ImageCropperModal from './ImageCropperModal';

// ============================================================================
// مودال "تعديل البورد" الموحّد
// ============================================================================
// بديل واحد للـ 3 عناصر اللي كانت متفرقة على كارت البورد (بادچ القلم الصغير
// فوق الأفاتار، وأيقونة السلة، وضغطة السهم): كله دلوقتي جوه شاشة واحدة —
// تغيير الاسم، تغيير شكل الأيقونة، اختيار صورة حقيقية من المعرض أو الكاميرا
// بدل الأيقونة، وحذف البورد — من غير أي "علامات" زيادة على الكارت نفسه.
// ============================================================================

// بيتحفظ الجزء الدائم من الصورة على الموبايل (مش على الكاش اللي بيتمسح) عشان
// تفضل موجودة حتى لو التطبيق قفل وفتح تاني أو الموبايل عمل ريستارت.
const IMAGES_DIR = FileSystem.documentDirectory + 'board-images/';

async function persistPickedImage(sourceUri, boardId, extension = 'png') {
  await FileSystem.makeDirectoryAsync(IMAGES_DIR, { intermediates: true }).catch(() => {});
  // نحافظ على PNG كما هو حتى تفضل قناة Alpha/الخلفية الشفافة موجودة.
  // الصور العادية من الكاميرا يمكن حفظها JPG، لكن PNG لا يتحول إلى JPG.
  const ext = String(extension || 'png').toLowerCase().replace('.', '');
  const safeExt = ext === 'png' ? 'png' : 'jpg';
  const destUri = `${IMAGES_DIR}${boardId}.${safeExt}`;
  // بنمسح أي نسخة قديمة الأول (لو كانت موجودة) عشان copyAsync ميرفضش الكتابة
  // فوق ملف موجود على بعض المنصات.
  // امسح النسختين القديمة لو البورد كان محفوظ قبل كده بامتداد مختلف.
  await FileSystem.deleteAsync(`${IMAGES_DIR}${boardId}.png`, { idempotent: true }).catch(() => {});
  await FileSystem.deleteAsync(`${IMAGES_DIR}${boardId}.jpg`, { idempotent: true }).catch(() => {});
  await FileSystem.copyAsync({ from: sourceUri, to: destUri });
  return destUri;
}

export default function EditBoardModal({ visible, board, onClose, onSave, onRequestDelete }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);

  const [name, setName] = useState('');
  const [icon, setIcon] = useState('switch');
  const [imageUri, setImageUri] = useState(null);
  const [showIconGrid, setShowIconGrid] = useState(false);
  const [busy, setBusy] = useState(false);
  const [cropSource, setCropSource] = useState(null); // { uri, width, height } الصورة الخام قبل القص

  useEffect(() => {
    if (visible && board) {
      setName(board.name || '');
      setIcon(board.icon || 'switch');
      setImageUri(board.imageUri || null);
      setShowIconGrid(false);
      setCropSource(null);
    }
  }, [visible, board]);

  if (!board) return null;

  const pickFromLibrary = async () => {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      showAlert('مفيش صلاحية', 'لازم تسمح للتطبيق بالدخول على الصور من إعدادات الموبايل الأول');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 1,
    });
    if (result.canceled || !result.assets?.[0]?.uri) return;
    const asset = result.assets[0];
    // لو الصورة PNG، احتفظ بها كما هي وبشفافيتها الأصلية؛ لا نمررها على
    // الكروب/التحويل لأن أي تحويل غير ضروري قد يغيّر الـ alpha أو الخلفية.
    const isPng = String(asset.mimeType || asset.fileName || asset.uri || '').toLowerCase().includes('png');
    if (isPng) {
      setBusy(true);
      try {
        const saved = await persistPickedImage(asset.uri, board.id, 'png');
        setImageUri(saved);
        setShowIconGrid(false);
      } catch (e) {
        showAlert('خطأ', 'مقدرناش نحفظ صورة PNG الشفافة، جرب تاني');
      } finally {
        setBusy(false);
      }
      return;
    }
    setCropSource({ uri: asset.uri, width: asset.width, height: asset.height });
  };

  const takePhoto = async () => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      showAlert('مفيش صلاحية', 'لازم تسمح للتطبيق باستخدام الكاميرا من إعدادات الموبايل الأول');
      return;
    }
    const result = await ImagePicker.launchCameraAsync({ quality: 1 });
    if (result.canceled || !result.assets?.[0]?.uri) return;
    const asset = result.assets[0];
    setCropSource({ uri: asset.uri, width: asset.width, height: asset.height });
  };

  const handleCropConfirm = async (croppedUri, err) => {
    setCropSource(null);
    if (!croppedUri) {
      if (err) showAlert('خطأ', 'مقدرناش نقص الصورة، جرب تاني');
      return;
    }
    setBusy(true);
    try {
      const saved = await persistPickedImage(croppedUri, board.id, 'png');
      setImageUri(saved);
      setShowIconGrid(false);
    } catch (e) {
      showAlert('خطأ', 'مقدرناش نحفظ الصورة، جرب تاني');
    } finally {
      setBusy(false);
    }
  };

  const removeImage = () => {
    setImageUri(null);
    FileSystem.deleteAsync(`${IMAGES_DIR}${board.id}.png`, { idempotent: true }).catch(() => {});
    FileSystem.deleteAsync(`${IMAGES_DIR}${board.id}.jpg`, { idempotent: true }).catch(() => {});
  };

  const handleSave = () => {
    const trimmed = name.trim();
    if (!trimmed) {
      showAlert('خطأ', 'لازم تكتب اسم للبورد');
      return;
    }
    onSave({ name: trimmed, icon, imageUri: imageUri || null });
  };

  const handleDelete = () => {
    showAlert('حذف البورد', `متأكد إنك عايز تمسح "${board.name}"؟`, [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'مسح',
        style: 'destructive',
        onPress: () => {
          FileSystem.deleteAsync(`${IMAGES_DIR}${board.id}.png`, { idempotent: true }).catch(() => {});
          FileSystem.deleteAsync(`${IMAGES_DIR}${board.id}.jpg`, { idempotent: true }).catch(() => {});
          onRequestDelete();
        },
      },
    ]);
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={styles.box}>
          <View style={styles.headerRow}>
            <Text style={styles.title}>تعديل البورد</Text>
            <TouchableOpacity onPress={onClose} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <MaterialCommunityIcons name="close" size={20} color={theme.textMuted} />
            </TouchableOpacity>
          </View>

          <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 6 }}>
            <View style={styles.avatarPreviewWrap}>
              <View style={styles.avatarPreview}>
                {imageUri ? (
                  <Image source={{ uri: imageUri }} style={styles.avatarImage} />
                ) : (
                  <MaterialCommunityIcons name={getDeviceIcon(icon).icon} size={34} color={theme.accent} />
                )}
              </View>
            </View>

            <View style={styles.actionsRow}>
              <TouchableOpacity style={styles.actionBtn} onPress={pickFromLibrary} disabled={busy} activeOpacity={0.85}>
                <MaterialCommunityIcons name="image-outline" size={17} color={theme.accentSoft} />
                <Text style={styles.actionBtnText}>صورة</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionBtn} onPress={takePhoto} disabled={busy} activeOpacity={0.85}>
                <MaterialCommunityIcons name="camera-outline" size={17} color={theme.accentSoft} />
                <Text style={styles.actionBtnText}>كاميرا</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.actionBtn, showIconGrid && styles.actionBtnActive]}
                onPress={() => setShowIconGrid((v) => !v)}
                activeOpacity={0.85}
              >
                <MaterialCommunityIcons
                  name="shape-outline"
                  size={17}
                  color={showIconGrid ? '#fff' : theme.accentSoft}
                />
                <Text style={[styles.actionBtnText, showIconGrid && styles.actionBtnTextActive]}>أيقونة</Text>
              </TouchableOpacity>
            </View>

            {!!imageUri && (
              <TouchableOpacity onPress={removeImage} style={styles.removeImageLink}>
                <Text style={styles.removeImageLinkText}>إزالة الصورة والرجوع للأيقونة</Text>
              </TouchableOpacity>
            )}

            {showIconGrid && (
              <FlatList
                data={PLACE_ICONS}
                keyExtractor={(item) => item.id}
                numColumns={5}
                scrollEnabled={false}
                contentContainerStyle={{ marginTop: 6, marginBottom: 4 }}
                renderItem={({ item }) => {
                  const selected = !imageUri && icon === item.id;
                  return (
                    <TouchableOpacity
                      style={[styles.iconOption, selected && styles.iconOptionSelected]}
                      onPress={() => {
                        setIcon(item.id);
                        setImageUri(null);
                      }}
                    >
                      <MaterialCommunityIcons
                        name={item.icon}
                        size={22}
                        color={selected ? theme.accent : theme.textPrimary}
                      />
                      <Text style={styles.iconOptionLabel} numberOfLines={1}>
                        {item.label}
                      </Text>
                    </TouchableOpacity>
                  );
                }}
              />
            )}

            <Text style={styles.label}>اسم البورد</Text>
            <TextInput
              style={styles.input}
              value={name}
              onChangeText={setName}
              placeholder="اسم البورد"
              placeholderTextColor={theme.textMuted}
            />
          </ScrollView>

          <TouchableOpacity style={styles.saveBtn} onPress={handleSave} activeOpacity={0.85} disabled={busy}>
            <Text style={styles.saveBtnText}>حفظ</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.deleteBtn} onPress={handleDelete} activeOpacity={0.85}>
            <MaterialCommunityIcons name="trash-can-outline" size={16} color={theme.danger} />
            <Text style={styles.deleteBtnText}>حذف البورد</Text>
          </TouchableOpacity>
        </View>
      </View>

      <ImageCropperModal
        visible={!!cropSource}
        imageUri={cropSource?.uri}
        imageWidth={cropSource?.width}
        imageHeight={cropSource?.height}
        onCancel={() => setCropSource(null)}
        onConfirm={handleCropConfirm}
      />
    </Modal>
  );
}

function getStyles(theme) {
  return StyleSheet.create({
    overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', alignItems: 'center' },
    box: {
      width: '88%',
      maxHeight: '84%',
      backgroundColor: theme.card,
      borderRadius: 18,
      borderWidth: 1,
      borderColor: theme.border,
      padding: 18,
    },
    headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
    title: { color: theme.textPrimary, fontSize: 16, fontWeight: '700' },
    avatarPreviewWrap: { alignItems: 'center', marginBottom: 14 },
    avatarPreview: {
      width: 76,
      height: 76,
      borderRadius: 38,
      backgroundColor: theme.cardAlt,
      borderWidth: 1,
      borderColor: theme.border,
      alignItems: 'center',
      justifyContent: 'center',
      overflow: 'hidden',
    },
    avatarImage: { width: '100%', height: '100%' },
    actionsRow: { flexDirection: 'row', gap: 8, marginBottom: 4 },
    actionBtn: {
      flex: 1,
      flexDirection: 'row',
      gap: 5,
      alignItems: 'center',
      justifyContent: 'center',
      paddingVertical: 10,
      borderRadius: 10,
      borderWidth: 1,
      borderColor: theme.border,
      backgroundColor: theme.cardAlt,
    },
    actionBtnActive: { backgroundColor: theme.accent, borderColor: theme.accent },
    actionBtnText: { color: theme.textSecondary, fontSize: 11.5, fontWeight: '700' },
    actionBtnTextActive: { color: '#fff' },
    removeImageLink: { alignSelf: 'center', marginTop: 10 },
    removeImageLinkText: { color: theme.danger, fontSize: 11.5, fontWeight: '600' },
    iconOption: { width: '20%', alignItems: 'center', paddingVertical: 8, borderRadius: 10 },
    iconOptionSelected: { backgroundColor: theme.cardAlt },
    iconOptionLabel: { color: theme.textMuted, fontSize: 9, marginTop: 3, textAlign: 'center' },
    label: { fontSize: 12.5, fontWeight: '700', color: theme.textPrimary, marginTop: 12, marginBottom: 6, textAlign: 'right' },
    input: {
      backgroundColor: theme.cardAlt,
      borderRadius: 10,
      borderWidth: 1,
      borderColor: theme.border,
      paddingHorizontal: 12,
      paddingVertical: 10,
      color: theme.textPrimary,
      fontSize: 13,
      textAlign: 'right',
    },
    saveBtn: { backgroundColor: theme.accent, borderRadius: 12, paddingVertical: 13, alignItems: 'center', marginTop: 14 },
    saveBtnText: { color: '#fff', fontWeight: '700', fontSize: 13.5 },
    deleteBtn: {
      flexDirection: 'row',
      gap: 6,
      alignItems: 'center',
      justifyContent: 'center',
      paddingVertical: 12,
      marginTop: 8,
    },
    deleteBtnText: { color: theme.danger, fontWeight: '700', fontSize: 12.5 },
  });
}
