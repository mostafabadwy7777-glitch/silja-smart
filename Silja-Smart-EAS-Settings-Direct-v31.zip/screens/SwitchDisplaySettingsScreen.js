import React, { useEffect, useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, StyleSheet } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';
import { FONTS } from '../fonts';
import PremiumSwitch from '../components/PremiumSwitch';
import { loadSwitchCardStyle, saveSwitchCardStyle, loadSwitchShape, saveSwitchShape, loadSwitchCardSize, saveSwitchCardSize, loadSwitchCardOpacity, saveSwitchCardOpacity } from '../storage';
import { SWITCH_CARD_STYLES } from '../switchCardStyles';

const SHAPES = [
  { id: 'square', name: 'مربع', icon: 'toggle-switch-outline', desc: 'زوايا ناعمة' },
  { id: 'round', name: 'مدور', icon: 'toggle-switch', desc: 'شكل دائري Premium' },
  { id: 'text', name: 'ON / OFF', icon: 'toggle-switch-variant', desc: 'الحالة داخل السويتش' },
];
const SIZES = [
  { id: 'small', name: 'صغير', icon: 'view-grid-outline', desc: '3 كروت في الصف' },
  { id: 'medium', name: 'متوسط', icon: 'view-grid', desc: '2 كارت في الصف' },
  { id: 'large', name: 'كبير', icon: 'view-agenda-outline', desc: 'بعرض الشاشة' },
];
const OPACITIES = [
  { value: 0.40, label: '40%', name: 'زجاجي جدًا' },
  { value: 0.55, label: '55%', name: 'شفاف' },
  { value: 0.70, label: '70%', name: 'متوازن' },
  { value: 0.82, label: '82%', name: 'Premium' },
  { value: 1.00, label: '100%', name: 'معتم' },
];

export default function SwitchDisplaySettingsScreen({ onBack }) {
  const { theme } = useTheme();
  const [shape, setShape] = useState('round');
  const [cardStyle, setCardStyle] = useState('classic');
  const [size, setSize] = useState('medium');
  const [opacity, setOpacity] = useState(0.82);

  useEffect(() => {
    loadSwitchShape().then(setShape);
    loadSwitchCardStyle().then(setCardStyle);
    loadSwitchCardSize().then(setSize);
    loadSwitchCardOpacity().then(setOpacity);
  }, []);
  const pick = (setter, saver) => (v) => { setter(v); saver(v); };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 35 }}>
        <View style={styles.header}>
          <TouchableOpacity onPress={onBack} style={styles.back}><Text style={[styles.backText,{color:theme.accent}]}>رجوع ‹</Text></TouchableOpacity>
          <Text style={[styles.title,{color:theme.textPrimary}]}>إعدادات المفاتيح</Text>
        </View>
        <Text style={[styles.subtitle,{color:theme.textSecondary}]}>اختار شكل المفاتيح وطريقة عرضها، ونفس التصميم هيتطبق على الشبكة والمستطيل تلقائيًا.</Text>

        <SettingBox theme={theme} icon="toggle-switch" title="شكل السويتش" subtitle="اختار شكل زر التشغيل والإيقاف داخل الكارت.">
          <View style={styles.threeRow}>
            {SHAPES.map(s => {
              const selected=shape===s.id;
              return <TouchableOpacity key={s.id} onPress={()=>pick(setShape,saveSwitchShape)(s.id)} style={[styles.option,{backgroundColor:theme.card,borderColor:selected?theme.accent:theme.border},selected&&{shadowColor:theme.accent,shadowOpacity:.25,shadowRadius:8,elevation:3}]}>
                <PremiumSwitch value={s.id==='round'} theme={theme} onValueChange={()=>{}} shape={s.id} size={.95}/>
                <Text style={[styles.optionName,{color:theme.textPrimary}]}>{s.name}</Text><Text style={[styles.optionDesc,{color:theme.textSecondary}]}>{s.desc}</Text>
                <MaterialCommunityIcons name={selected?'check-circle':'circle-outline'} size={18} color={selected?theme.accent:theme.border}/>
              </TouchableOpacity>
            })}
          </View>
        </SettingBox>

        <SettingBox theme={theme} icon="card-bulleted-outline" title="شكل كارت المفتاح" subtitle="اختار طريقة ترتيب الأيقونة والاسم والسويتش.">
          {SWITCH_CARD_STYLES.map(s=>{
            const selected=cardStyle===s.id;
            return <TouchableOpacity key={s.id} onPress={()=>pick(setCardStyle,saveSwitchCardStyle)(s.id)} style={[styles.styleRow,{backgroundColor:theme.card,borderColor:selected?theme.accent:theme.border},selected&&{shadowColor:theme.accent,shadowOpacity:.22,shadowRadius:8,elevation:3}]}>
              <View style={[styles.styleIcon,{backgroundColor:theme.cardAlt}]}><MaterialCommunityIcons name={s.id==='horizontal'?'gradient':s.id==='minimal'?'crown-outline':'view-dashboard-outline'} size={22} color={selected?theme.accent:theme.textSecondary}/></View>
              <View style={{flex:1}}><Text style={[styles.optionName,{color:theme.textPrimary,textAlign:'right'}]}>{s.name}</Text><Text style={[styles.optionDesc,{color:theme.textSecondary,textAlign:'right'}]}>{s.description}</Text></View>
              <MaterialCommunityIcons name={selected?'check-circle':'circle-outline'} size={20} color={selected?theme.accent:theme.border}/>
            </TouchableOpacity>
          })}
        </SettingBox>

        <SettingBox theme={theme} icon="resize" title="حجم كروت المفاتيح" subtitle="تحكم في حجم الكارت وعدد الكروت الظاهرة في الصف.">
          <View style={styles.threeRow}>{SIZES.map(s=>{const selected=size===s.id;return <TouchableOpacity key={s.id} onPress={()=>pick(setSize,saveSwitchCardSize)(s.id)} style={[styles.option,{backgroundColor:theme.card,borderColor:selected?theme.accent:theme.border},selected&&{shadowColor:theme.accent,shadowOpacity:.25,shadowRadius:8,elevation:3}]}><MaterialCommunityIcons name={s.icon} size={25} color={selected?theme.accent:theme.textSecondary}/><Text style={[styles.optionName,{color:theme.textPrimary}]}>{s.name}</Text><Text style={[styles.optionDesc,{color:theme.textSecondary}]}>{s.desc}</Text><MaterialCommunityIcons name={selected?'check-circle':'circle-outline'} size={18} color={selected?theme.accent:theme.border}/></TouchableOpacity>})}</View>
        </SettingBox>

        <SettingBox theme={theme} icon="blur" title="شفافية كارت المفتاح — Glass" subtitle="حدد مقدار الشفافية حتى تظهر الخلفية من خلال الكارت.">
          <View style={styles.opacityRow}>{OPACITIES.map(o=>{const selected=Math.abs(opacity-o.value)<.01;return <TouchableOpacity key={o.value} onPress={()=>pick(setOpacity,saveSwitchCardOpacity)(o.value)} style={[styles.opacity,{backgroundColor:rgba(theme.card,o.value),borderColor:selected?theme.accent:theme.border},selected&&{shadowColor:theme.accent,shadowOpacity:.25,shadowRadius:8,elevation:3}]}><MaterialCommunityIcons name={o.value<.7?'blur':'square-rounded-outline'} size={19} color={selected?theme.accent:theme.textSecondary}/><Text style={[styles.opacityLabel,{color:theme.textPrimary}]}>{o.label}</Text><Text style={[styles.opacityName,{color:theme.textSecondary}]}>{o.name}</Text></TouchableOpacity>})}</View>
        </SettingBox>
      </ScrollView>
    </SafeAreaView>
  );
}
function SettingBox({theme,icon,title,subtitle,children}){return <View style={[styles.box,{backgroundColor:theme.card,borderColor:theme.border}]}><View style={styles.boxHead}><View style={[styles.boxIcon,{backgroundColor:theme.cardAlt}]}><MaterialCommunityIcons name={icon} size={21} color={theme.accent}/></View><View style={{flex:1}}><Text style={[styles.boxTitle,{color:theme.textPrimary}]}>{title}</Text><Text style={[styles.boxSub,{color:theme.textSecondary}]}>{subtitle}</Text></View></View>{children}</View>}
function rgba(hex,a){const h=String(hex||'').replace('#','');if(h.length!==6)return hex;return `rgba(${parseInt(h.slice(0,2),16)},${parseInt(h.slice(2,4),16)},${parseInt(h.slice(4,6),16)},${Math.max(0,Math.min(1,a))})`}
const styles=StyleSheet.create({container:{flex:1,padding:18,paddingTop:42},header:{flexDirection:'row',alignItems:'center',justifyContent:'space-between',marginBottom:8},backText:{fontSize:15,fontWeight:'700'},title:{fontSize:23,fontWeight:'800',fontFamily:FONTS.display},subtitle:{fontSize:12,lineHeight:19,textAlign:'right',marginBottom:16},box:{borderRadius:20,borderWidth:1,padding:14,marginBottom:14},boxHead:{flexDirection:'row',alignItems:'center',gap:11,marginBottom:13},boxIcon:{width:42,height:42,borderRadius:13,alignItems:'center',justifyContent:'center'},boxTitle:{fontSize:16,fontWeight:'800',textAlign:'right'},boxSub:{fontSize:11.5,lineHeight:17,textAlign:'right',marginTop:2},threeRow:{flexDirection:'row',gap:8},option:{flex:1,minHeight:105,borderRadius:16,borderWidth:1.2,padding:8,alignItems:'center',justifyContent:'center',gap:4},optionName:{fontSize:12,fontWeight:'800',marginTop:3},optionDesc:{fontSize:8.5,textAlign:'center',lineHeight:12},styleRow:{flexDirection:'row',alignItems:'center',gap:10,borderWidth:1.2,borderRadius:15,padding:11,marginBottom:8},styleIcon:{width:40,height:40,borderRadius:12,alignItems:'center',justifyContent:'center'},opacityRow:{flexDirection:'row',flexWrap:'wrap',gap:8},opacity:{width:'18.5%',minWidth:56,minHeight:72,borderRadius:14,borderWidth:1.2,alignItems:'center',justifyContent:'center',paddingVertical:7},opacityLabel:{fontSize:11,fontWeight:'800',marginTop:3},opacityName:{fontSize:7.5,marginTop:1}});
