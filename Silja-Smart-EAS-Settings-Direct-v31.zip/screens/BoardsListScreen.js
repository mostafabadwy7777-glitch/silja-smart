import React, { useEffect, useRef, useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  TextInput,
  StyleSheet,
  Animated,
  StatusBar,
  Modal,
  FlatList,
  Image,
  ImageBackground,
  BackHandler,
} from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { showAlert } from '../components/PremiumAlert';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import { useTheme } from '../ThemeContext';
import { parseBoardDiscovery, boardAvailabilityTopic, parseAvailability } from '../discovery';
import { getDeviceIcon, getDeviceIconImage } from '../deviceIcons';
import { loadBoardsViewMode, saveBoardsViewMode, loadHeroBackground, saveHeroBackground, loadHeroBgOpacity, saveHeroBgOpacity, loadHeroTextColor, saveHeroTextColor } from '../storage';
import { COLOR_SWATCHES } from '../theme';
import { runScene } from '../scenes';
import EditBoardModal from '../components/EditBoardModal';
import ScreenBackground from '../components/ScreenBackground';
import { FONTS } from '../fonts';

// باليتة ألوان بتتلف على البوردات والمشاهد بالترتيب، عشان كل واحد ياخد لون
// دائرة مختلف (بدل ما الكل يبقى بلون الـ accent الموحّد) — إحساس أقرب لكروت
// "الغرف" الملوّنة، من غير ما نستخدم صور تخيّلية مالهاش وجود في بيانات حقيقية.
const AVATAR_PALETTE = ['#22c55e', '#a78bfa', '#f59e0b', '#38bdf8', '#f472b6', '#34d399', '#fb7185', '#60a5fa'];

const BOARD_TYPE_LABELS = {
  switches: 'لوحة مفاتيح',
  irrigation: 'ري / محابس',
};

// أيقونة رمزية لكل نوع بورد — بتتلبس على الأفاتار الدائري في كارت البورد
const BOARD_TYPE_ICONS = {
  switches: 'view-grid-outline',
  irrigation: 'water-pump',
};

const DISCOVERY_TIMEOUT_MS = 10000;

export default function BoardsListScreen({
  boards,
  onAdd,
  onDelete,
  onOpen,
  onOpenSettings,
  onOpenTheme,
  onOpenScenes,
  onOpenHistory,
  onOpenBackup,
  onOpenManualBoard,
  connected,
  mqttError,
  client,
  pairingKey,
  pushEnabled,
  onTogglePush,
  configured,
  onUpdateBoardMeta,
  addBoardSignal,
  onAddBoardSignalHandled,
  scenes,
}) {
  const { theme, isLight, toggleLightDark } = useTheme();
  const styles = getStyles(theme);
  const [showForm, setShowForm] = useState(false);
  const [deviceId, setDeviceId] = useState('');
  const [discovering, setDiscovering] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  // شاشة الاكتشاف التلقائي الجديدة (شكل الرادار) — قائمة الأجهزة اللي وصلت
  // منها رسالة اكتشاف صحيحة ولسه متضافتش، ومفتاح إظهار فورم الإضافة اليدوية.
  const [discoveredMap, setDiscoveredMap] = useState({});
  const [showManual, setShowManual] = useState(false);
  const boardsRef = useRef(boards);
  useEffect(() => {
    boardsRef.current = boards;
  }, [boards]);
  const [editBoardId, setEditBoardId] = useState(null);
  // ملحوظة: الدرج الجانبي (الصفحة الجانبية) اتنقل لمكوّن مستقل SideMenu.js
  // وبقى بيتفتح من App.js عن طريق زرار "الإعدادات" في الشريط السفلي، مش من
  // ترس فوق الشاشة دي بس زي الأول.

  // شكل عرض البوردات: قائمة (list) أو شبكة (grid) — بيتحفظ محليًا عشان
  // يفضل زي ما المستخدم سابه لما يفتح التطبيق تاني.
  const [viewMode, setViewMode] = useState('list');
  useEffect(() => {
    loadBoardsViewMode().then(setViewMode);
  }, []);
  const changeViewMode = (mode) => {
    setViewMode(mode);
    saveBoardsViewMode(mode);
  };

  // خلفية كارت "حالة النظام" (المستطيل اللي فيه الساعة) — صورة مخصوصة اختارها
  // المستخدم بدل الشكل الافتراضي بتاع الثيم، بتتحفظ محليًا وتفضل موجودة بين
  // فتحات التطبيق.
  const [heroBg, setHeroBg] = useState(null);
  const [showHeroBgModal, setShowHeroBgModal] = useState(false);
  // درجة تعتيم الطبقة فوق الصورة (0 لحد 1) — المستخدم هو اللي بيتحكم فيها من
  // نفس مودال اختيار الخلفية، بدل ما تكون قيمة ثابتة في الكود.
  const [heroBgOpacity, setHeroBgOpacity] = useState(0.72);
  // لون كلام كارت "حالة النظام" — null يعني تلقائي (تبع الثيم)، وإلا hex ثابت
  // اختاره المستخدم عشان يفضل واضح حتى لو حط خلفية صورة غامقة أو فاتحة.
  const [heroTextColor, setHeroTextColor] = useState(null);
  useEffect(() => {
    loadHeroBackground().then(setHeroBg);
    loadHeroBgOpacity().then(setHeroBgOpacity);
    loadHeroTextColor().then(setHeroTextColor);
  }, []);

  // حالة "توفر" (Availability) كل بورد لوحده — { [boardId]: 'online' | 'offline' | null }
  // null = لسه محددناش (مستنيين أول رسالة Retained من البروكر بعد الاشتراك).
  const [availability, setAvailability] = useState({});

  // ساعة حقيقية (وقت الجهاز نفسه) بتتحدّث كل نص دقيقة — بتتعرض فوق في كارت
  // "حالة النظام" بدل أي بيانات وهمية (زي طقس أو استهلاك كهربا) مالهاش مصدر حقيقي.
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(t);
  }, []);

  // إحصائيات حقيقية مبنية على بيانات البوردات الفعلية — مفيش أرقام مختلقة هنا.
  const totalBoards = boards.length;
  const onlineBoards = boards.filter((b) => availability[b.id] === 'online').length;
  const totalSwitches = boards
    .filter((b) => b.type !== 'irrigation')
    .reduce((sum, b) => sum + (b.devices || []).length, 0);

  const timeoutRef = useRef(null);
  const topicRef = useRef(null);
  const handlerRef = useRef(null);

  // نشترك في توبيك الأفيلابيليتي بتاع كل بورد لوحده، عشان نعرف لو بورد معين
  // مقطوع حتى لو الاتصال العام بالسيرفر (البروكر) شغال تمام. لو الاتصال العام
  // اتقطع، بنصفّر الحالة كلها (مش عارفين حالة حد لحد ما نتصل تاني).
  useEffect(() => {
    if (!client || !connected) {
      setAvailability({});
      return undefined;
    }

    const topicToBoardIds = new Map(); // topic -> [boardId, ...] (لو أكتر من بورد نادرًا بيشاركوا نفس التوبيك)
    boards.forEach((b) => {
      const topic = boardAvailabilityTopic(b);
      if (!topic) return;
      if (!topicToBoardIds.has(topic)) topicToBoardIds.set(topic, []);
      topicToBoardIds.get(topic).push(b.id);
    });

    if (topicToBoardIds.size === 0) return undefined;

    setAvailability((prev) => {
      const next = { ...prev };
      boards.forEach((b) => {
        if (boardAvailabilityTopic(b) && !(b.id in next)) next[b.id] = null;
      });
      return next;
    });

    const topics = Array.from(topicToBoardIds.keys());
    topics.forEach((t) => client.subscribe(t));

    const handler = (topic, payload) => {
      const ids = topicToBoardIds.get(topic);
      if (!ids) return;
      const state = parseAvailability(payload.toString());
      if (!state) return;
      setAvailability((prev) => {
        const next = { ...prev };
        ids.forEach((id) => (next[id] = state));
        return next;
      });
    };
    client.on('message', handler);

    return () => {
      client.off('message', handler);
      topics.forEach((t) => client.unsubscribe(t));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client, connected, boards.map((b) => `${b.id}:${boardAvailabilityTopic(b)}`).join(',')]);

  const cleanupListener = () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    if (client && topicRef.current) {
      if (handlerRef.current) client.off('message', handlerRef.current);
      client.unsubscribe(topicRef.current);
    }
    topicRef.current = null;
    handlerRef.current = null;
  };

  useEffect(() => cleanupListener, []); // eslint-disable-line react-hooks/exhaustive-deps

  // لو المستخدم دوس على زرار "+" في الشريط السفلي (حتى لو مكناش واقفين على
  // شاشة البوردات وقتها)، بنفتح فورم "إضافة بورد جديد" هنا أوتوماتيك — وبعدين
  // نبلّغ App.js إنه يصفّر الإشارة على طول. لازم نصفّرها بعد الاستخدام مباشرة،
  // مش نسيبها true، عشان لو الشاشة دي اتقفلت وفتحت تاني بعدين بتنقل عادي (مش
  // ضغطة "+" جديدة) الفورم متفتحش لوحده تاني من غير سبب.
  useEffect(() => {
    if (addBoardSignal) {
      setShowForm(true);
      onAddBoardSignalHandled?.();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [addBoardSignal]);

  // زرار الموبايل الفيزيقي للرجوع — لو فيه مودال مفتوح فوق شاشة البوردات
  // (فورم الإضافة، الدرج الجانبي، أو اختيار الأيقونة)، بنسكّره الأول بدل ما
  // نسيب الرجوع يودّي لشاشة تانية أو يقفل التطبيق على طول.
  useEffect(() => {
    const onBackPress = () => {
      if (showHeroBgModal) {
        setShowHeroBgModal(false);
        return true;
      }
      if (editBoardId) {
        setEditBoardId(null);
        return true;
      }
      if (showForm) {
        resetForm();
        return true;
      }
      return false;
    };
    const sub = BackHandler.addEventListener('hardwareBackPress', onBackPress);
    return () => sub.remove();
  }, [editBoardId, showForm, showHeroBgModal]);

  // بينما شاشة "إضافة بورد / جهاز" مفتوحة، بنستمع على توبيك عام
  // (`+/discovery`) عشان أي بورد شغال وناشر رسالة اكتشاف صحيحة (موقّعة
  // بمفتاح الربط) يظهر أوتوماتيك في القائمة من غير ما تكتب اسمه بنفسك —
  // بالظبط زي شاشة "البحث عن الأجهزة" اللي بتفحص وتسرد كل اللي تلاقيه.
  useEffect(() => {
    if (!showForm || !client || !connected) return undefined;

    const wildcardTopic = '+/discovery';
    client.subscribe(wildcardTopic);
    setDiscoveredMap({});

    const handler = (topic, payload) => {
      if (typeof topic !== 'string' || !topic.endsWith('/discovery')) return;
      const result = parseBoardDiscovery(payload.toString(), pairingKey);
      if (!result.ok) return;
      const board = result.board;
      const key = board.type === 'irrigation' ? board.prefix : board.deviceId;
      if (!key) return;
      const alreadyAdded = boardsRef.current.some((b) =>
        board.type === 'irrigation' ? b.prefix === board.prefix : b.deviceId === board.deviceId
      );
      if (alreadyAdded) return;
      setDiscoveredMap((prev) => ({ ...prev, [key]: { ...board, discoveryTopic: topic } }));
    };
    client.on('message', handler);

    return () => {
      client.off('message', handler);
      client.unsubscribe(wildcardTopic);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showForm, client, connected, pairingKey]);

  const resetForm = () => {
    cleanupListener();
    setDeviceId('');
    setDiscovering(false);
    setErrorMsg('');
    setShowForm(false);
    setShowManual(false);
    setDiscoveredMap({});
  };

  const addDiscoveredBoard = (key) => {
    const board = discoveredMap[key];
    if (!board) return;
    onAdd(board);
    setDiscoveredMap((prev) => {
      const next = { ...prev };
      delete next[key];
      return next;
    });
  };

  const startDiscovery = () => {
    const id = deviceId.trim();
    if (!id) {
      showAlert('خطأ', 'لازم تكتب اسم الجهاز (Device ID) اللي ضبطته في الفيرموير');
      return;
    }
    if (!pairingKey) {
      showAlert('خطأ', 'لازم تحط مفتاح الربط (Pairing Key) في الإعدادات الأول');
      return;
    }
    if (!client || !connected) {
      showAlert('خطأ', 'لسه مش متصل بالسيرفر، استنى ثانية وحاول تاني');
      return;
    }

    cleanupListener();
    setErrorMsg('');

    const topic = `${id}/discovery`;
    topicRef.current = topic;
    client.subscribe(topic);
    setDiscovering(true);

    const handler = (t, payload) => {
      if (t !== topic) return;
      const result = parseBoardDiscovery(payload.toString(), pairingKey);
      cleanupListener();
      setDiscovering(false);
      if (!result.ok) {
        setErrorMsg(result.error);
        return;
      }
      onAdd({ ...result.board, discoveryTopic: topic });
      resetForm();
    };
    handlerRef.current = handler;
    client.on('message', handler);

    timeoutRef.current = setTimeout(() => {
      cleanupListener();
      setDiscovering(false);
      setErrorMsg(
        `مفيش رد من "${id}" لحد دلوقتي. اتأكد إن الفيرموير شغالة، متصلة بنفس البروكر، وناشرة رسالة اكتشاف (يفضل Retained) على "${topic}".`
      );
    }, DISCOVERY_TIMEOUT_MS);
  };

  const cancelDiscovery = () => {
    cleanupListener();
    setDiscovering(false);
    setErrorMsg('');
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScreenBackground theme={theme} />
      <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} />
      <View style={styles.headerRow}>
        <View style={styles.brandRow}>
          <View style={styles.brandLogoWrap}>
            <Image source={require('../assets/icon.png')} style={styles.brandLogo} />
          </View>
          <View>
            <Text style={styles.eyebrow}>SILJA SMART</Text>
            <Text style={styles.title}>بوردات التحكم</Text>
          </View>
        </View>

        <View style={styles.viewToggle}>
          <TouchableOpacity
            style={[styles.viewToggleBtn, viewMode === 'list' && styles.viewToggleBtnActive]}
            onPress={() => changeViewMode('list')}
            activeOpacity={0.8}
            hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}
          >
            <MaterialCommunityIcons
              name="view-agenda-outline"
              size={17}
              color={viewMode === 'list' ? '#fff' : theme.textMuted}
            />
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.viewToggleBtn, viewMode === 'grid' && styles.viewToggleBtnActive]}
            onPress={() => changeViewMode('grid')}
            activeOpacity={0.8}
            hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}
          >
            <MaterialCommunityIcons
              name="view-grid-outline"
              size={16}
              color={viewMode === 'grid' ? '#fff' : theme.textMuted}
            />
          </TouchableOpacity>
        </View>
      </View>

      {!configured && (
        <TouchableOpacity style={styles.setupChip} onPress={onOpenSettings} activeOpacity={0.8}>
          <MaterialCommunityIcons name="cog-outline" size={14} color={theme.accentSoft} />
          <Text style={styles.setupChipText}>لسه مفيش سيرفر متظبط — دوس هنا عشان تظبطه</Text>
        </TouchableOpacity>
      )}

      <ScrollView contentContainerStyle={{ paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
        {configured && (
          <>
            <HomeHero
              theme={theme}
              styles={styles}
              connected={connected}
              errorMsg={mqttError}
              onOpenSettings={onOpenSettings}
              now={now}
              backgroundUri={heroBg}
              overlayOpacity={heroBgOpacity}
              textColor={heroTextColor}
              onEditBackground={() => setShowHeroBgModal(true)}
            />

            <View style={styles.quickStatsRow}>
              <QuickStat theme={theme} styles={styles} icon="chip" label="البوردات" value={String(totalBoards)} color={theme.accentSoft} />
              <QuickStat theme={theme} styles={styles} icon="access-point" label="متصلة الآن" value={`${onlineBoards}/${totalBoards}`} color={theme.on} />
              <QuickStat theme={theme} styles={styles} icon="toggle-switch-outline" label="المفاتيح" value={String(totalSwitches)} color="#38bdf8" />
              <QuickStat
                theme={theme}
                styles={styles}
                icon={connected ? 'server-network' : 'server-network-off'}
                label="السيرفر"
                value={connected ? 'متصل' : 'مقطوع'}
                color={connected ? theme.on : theme.off}
              />
            </View>

            {!!(scenes && scenes.length) && (
              <View style={styles.quickScenesSection}>
                <View style={styles.sectionRow}>
                  <Text style={styles.sectionLabel}>السيناريوهات السريعة</Text>
                  {!!onOpenScenes && (
                    <TouchableOpacity onPress={onOpenScenes} hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}>
                      <Text style={styles.sectionLink}>عرض الكل</Text>
                    </TouchableOpacity>
                  )}
                </View>
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.sceneRowContent}
                >
                  {scenes.map((scene, i) => {
                    const color = AVATAR_PALETTE[i % AVATAR_PALETTE.length];
                    return (
                      <TouchableOpacity
                        key={scene.id}
                        style={[styles.sceneChip, !connected && { opacity: 0.5 }]}
                        activeOpacity={0.8}
                        disabled={!connected}
                        onPress={() => {
                          const result = runScene(scene, client);
                          if (!result.ok) showAlert('تعذر التشغيل', result.error);
                        }}
                      >
                        <View style={[styles.sceneChipIcon, { backgroundColor: color + '26', borderColor: color }]}>
                          <MaterialCommunityIcons name={scene.icon || 'star-four-points'} size={18} color={color} />
                        </View>
                        <Text style={styles.sceneChipText} numberOfLines={1}>
                          {scene.name}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </ScrollView>
              </View>
            )}
          </>
        )}
        {boards.length > 0 && (
          <View style={styles.sectionRow}>
            <Text style={styles.sectionLabel}>بوردات مضافة</Text>
            <Text style={styles.sectionCount}>{boards.length}</Text>
          </View>
        )}

        {boards.length === 0 && !showForm && (
          <View style={styles.emptyWrap}>
            <View style={styles.emptyIconCircle}>
              <MaterialCommunityIcons name="access-point" size={30} color={theme.accentSoft} />
            </View>
            <Text style={styles.emptyTitle}>مفيش بوردات لسه</Text>
            <Text style={styles.emptyText}>دوس "بورد جديد" تحت عشان تكتشف أول بورد ليك تلقائيًا</Text>
          </View>
        )}

        <View style={viewMode === 'grid' ? styles.boardsGridWrap : undefined}>
          {boards.map((b, i) => (
            <BoardCard
              key={b.id}
              board={b}
              theme={theme}
              styles={styles}
              viewMode={viewMode}
              connected={connected}
              color={AVATAR_PALETTE[i % AVATAR_PALETTE.length]}
              availability={connected ? availability[b.id] : null}
              onPress={() => onOpen(b)}
              onEdit={() => setEditBoardId(b.id)}
            />
          ))}
        </View>

        <TouchableOpacity style={styles.addBtn} onPress={() => setShowForm(true)} activeOpacity={0.85}>
          <View style={styles.addBtnIconCircle}>
            <MaterialCommunityIcons name="plus" size={18} color="#fff" />
          </View>
          <Text style={styles.addBtnText}>بورد جديد</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* شاشة "إضافة بورد / جهاز" — رادار بيدور على أي بورد بيبعت رسالة اكتشاف
          صحيحة، وبيسردها أول ما توصل، مع اختيار الإضافة اليدوي لمن يحتاجه. */}
      <Modal visible={showForm} animationType="slide" onRequestClose={resetForm} presentationStyle="fullScreen">
        <SafeAreaView style={styles.discoverContainer}>
          <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} />
          <View style={styles.discoverHeader}>
            <TouchableOpacity onPress={resetForm} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <MaterialCommunityIcons name="arrow-right" size={24} color={theme.textPrimary} />
            </TouchableOpacity>
            <Text style={styles.discoverHeaderTitle}>إضافة بورد / جهاز</Text>
            <View style={{ width: 24 }} />
          </View>

          <ScrollView contentContainerStyle={{ paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
            {!connected || !pairingKey ? (
              <View style={styles.discoverWarnBox}>
                <MaterialCommunityIcons name="alert-circle-outline" size={20} color={theme.danger} />
                <Text style={styles.discoverWarnText}>
                  {!pairingKey
                    ? 'لازم تحط مفتاح الربط (Pairing Key) في الإعدادات قبل ما تبدأ البحث'
                    : 'لسه مش متصل بالسيرفر — استنى ثانية أو راجع الإعدادات'}
                </Text>
              </View>
            ) : (
              <>
                <RadarSearch theme={theme} styles={styles} active={showForm} />
                <Text style={styles.discoverStatusTitle}>جاري البحث عن الأجهزة...</Text>
                <Text style={styles.discoverStatusHint}>
                  تأكد من أن البورد شغّال ومتصل بنفس سيرفر MQTT، وناشر رسالة اكتشاف Retained
                </Text>
              </>
            )}

            <TouchableOpacity
              style={styles.manualFullLinkTop}
              onPress={() => {
                resetForm();
                onOpenManualBoard?.();
              }}
              activeOpacity={0.8}
            >
              <MaterialCommunityIcons name="pencil-plus-outline" size={16} color={theme.accentSoft} />
              <Text style={styles.manualFullLinkText}>مش لاقي جهازك بالبحث؟ اكتب التوبيكات يدوي من هنا ›</Text>
            </TouchableOpacity>

            <View style={styles.discoverListSection}>
              <Text style={styles.discoverListLabel}>الأجهزة المكتشفة</Text>

              {Object.keys(discoveredMap).length === 0 ? (
                <Text style={styles.discoverEmptyHint}>هتظهر هنا أي أجهزة توصل منها رسالة اكتشاف صحيحة</Text>
              ) : (
                Object.entries(discoveredMap).map(([key, board]) => (
                  <DiscoveredDeviceCard
                    key={key}
                    board={board}
                    theme={theme}
                    styles={styles}
                    onAdd={() => addDiscoveredBoard(key)}
                  />
                ))
              )}
            </View>

            <TouchableOpacity
              style={styles.manualRow}
              onPress={() => setShowManual((v) => !v)}
              activeOpacity={0.8}
            >
              <View style={styles.manualRowIcon}>
                <MaterialCommunityIcons name="pencil-plus-outline" size={18} color={theme.accentSoft} />
              </View>
              <Text style={styles.manualRowText}>إضافة يدوي</Text>
              <MaterialCommunityIcons
                name={showManual ? 'chevron-up' : 'chevron-down'}
                size={18}
                color={theme.textMuted}
              />
            </TouchableOpacity>

            {showManual && (
              <View style={[styles.card, { marginHorizontal: 20 }]}>
                <Text style={styles.label}>اسم الجهاز (Device ID) زي ما ضبطته في الفيرموير</Text>
                <TextInput
                  style={styles.input}
                  value={deviceId}
                  onChangeText={setDeviceId}
                  placeholder="kitchen-esp32-01"
                  placeholderTextColor={theme.textMuted}
                  autoCapitalize="none"
                  editable={!discovering}
                />
                <Text style={styles.hint}>
                  التطبيق هيسمع على "&lt;اسم الجهاز&gt;/discovery" وينتظر رسالة اكتشاف موقّعة من الفيرموير. لو
                  التوقيع مطابق لمفتاح الربط بتاعك، هيتضاف البورد وكل مفاتيحه أوتوماتيك من غير ما تكتب أي توبيك
                  يدوي.
                </Text>

                {discovering && (
                  <View style={styles.discoveringRow}>
                    <RadarSearch theme={theme} styles={styles} active={discovering} size="small" />
                    <Text style={styles.discoveringText}>بيدور على الجهاز…</Text>
                  </View>
                )}

                {!!errorMsg && <Text style={styles.errorText}>⚠ {errorMsg}</Text>}

                <View style={styles.btnRow}>
                  {!discovering ? (
                    <TouchableOpacity
                      style={[styles.smallBtn, styles.onBtn]}
                      onPress={startDiscovery}
                      activeOpacity={0.85}
                    >
                      <Text style={styles.btnText}>ابدأ الاكتشاف</Text>
                    </TouchableOpacity>
                  ) : (
                    <TouchableOpacity
                      style={[styles.smallBtn, styles.dangerBtn]}
                      onPress={cancelDiscovery}
                      activeOpacity={0.85}
                    >
                      <Text style={styles.btnText}>إلغاء الاكتشاف</Text>
                    </TouchableOpacity>
                  )}
                </View>

                {/* بورد الفيرموير القديم اللي مش بينشر رسالة اكتشاف خالص (لا موقّعة
                    ولا غيرها) — هنا التسجيل بيبقى بكتابة توبيكات كل مفتاح بإيدك
                    بالكامل من غير أي اكتشاف. */}
                <TouchableOpacity
                  style={styles.manualFullLink}
                  onPress={() => {
                    setShowManual(false);
                    onOpenManualBoard?.();
                  }}
                  activeOpacity={0.8}
                >
                  <MaterialCommunityIcons name="tune-variant" size={16} color={theme.accentSoft} />
                  <Text style={styles.manualFullLinkText}>
                    الفيرموير مش بينشر رسالة اكتشاف خالص؟ اكتب كل التوبيكات يدوي من هنا ›
                  </Text>
                </TouchableOpacity>
              </View>
            )}
          </ScrollView>
        </SafeAreaView>
      </Modal>

      {/* مودال "تعديل البورد" الموحّد — اسم، أيقونة/صورة، وحذف — بدل التلات
          عناصر المتفرقة اللي كانت على الكارت نفسه */}
      <EditBoardModal
        visible={!!editBoardId}
        board={boards.find((b) => b.id === editBoardId) || null}
        onClose={() => setEditBoardId(null)}
        onSave={(patch) => {
          onUpdateBoardMeta?.(editBoardId, patch);
          setEditBoardId(null);
        }}
        onRequestDelete={() => {
          onDelete(editBoardId);
          setEditBoardId(null);
        }}
      />

      {/* مودال تغيير خلفية كارت "حالة النظام" فوق شاشة البوردات */}
      <HeroBackgroundModal
        visible={showHeroBgModal}
        theme={theme}
        currentUri={heroBg}
        currentOpacity={heroBgOpacity}
        currentTextColor={heroTextColor}
        onClose={() => setShowHeroBgModal(false)}
        onPicked={(uri) => {
          setHeroBg(uri);
          saveHeroBackground(uri);
          setShowHeroBgModal(false);
        }}
        onRemove={() => {
          setHeroBg(null);
          saveHeroBackground(null);
          setShowHeroBgModal(false);
        }}
        onChangeOpacity={(v) => {
          setHeroBgOpacity(v);
          saveHeroBgOpacity(v);
        }}
        onChangeTextColor={(c) => {
          setHeroTextColor(c);
          saveHeroTextColor(c);
        }}
      />

    </SafeAreaView>
  );
}

// كارت "حالة النظام" الرئيسي فوق الشاشة — بديل حقيقي لصورة الطقس/المنزل في
// التصميم المرجعي: بيوري حالة الاتصال الفعلية بالسيرفر (بينبض لما يكون متصل)
// ووقت وتاريخ الجهاز الحقيقيين، من غير أي بيانات طقس أو استهلاك مختلقة.
function HomeHero({ theme, styles, connected, errorMsg, onOpenSettings, now, backgroundUri, overlayOpacity, textColor, onEditBackground }) {
  const pulse = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!connected) {
      pulse.setValue(0);
      return undefined;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 1000, useNativeDriver: false }),
        Animated.timing(pulse, { toValue: 0, duration: 1000, useNativeDriver: false }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [connected, pulse]);

  const glowOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.5, 1] });
  // وقت وتاريخ الجهاز بالإنجليزي (أرقام وصيغة إنجليزية) بدل العربي.
  const timeStr = now.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  const dateStr = now.toLocaleDateString('en-US', { weekday: 'long', day: 'numeric', month: 'long' });

  // لو المستخدم اختار لون كلام ثابت (عشان يفضل واضح فوق خلفية صورة)، بنستخدمه
  // بدل ألوان الثيم الافتراضية على الحالة/الساعة/التاريخ الثلاثة مع بعض.
  const statusColor = textColor || theme.textSecondary;
  const timeColor = textColor || theme.textPrimary;
  const dateColor = textColor ? hexToRgba(textColor, 0.75) : theme.textMuted;

  const content = (
    <>
      {!backgroundUri && (
        <MaterialCommunityIcons
          name="home-variant"
          size={130}
          color={theme.cardAlt}
          style={styles.heroWatermark}
        />
      )}
      {!!backgroundUri && (
        <View
          style={[styles.heroBgOverlay, { backgroundColor: theme.card, opacity: overlayOpacity ?? 0.72 }]}
        />
      )}
      <View style={styles.heroTopRow}>
        <Animated.View
          style={[
            styles.heroStatusDot,
            { backgroundColor: connected ? theme.on : theme.off, opacity: connected ? glowOpacity : 1 },
          ]}
        />
        <Text style={[styles.heroStatusText, { color: statusColor }]} numberOfLines={2}>
          {connected ? 'النظام متصل ويعمل' : errorMsg ? `تعذر الاتصال — ${errorMsg}` : 'جاري الاتصال…'}
        </Text>
      </View>
      <Text style={[styles.heroTime, { color: timeColor }]}>{timeStr}</Text>
      <Text style={[styles.heroDate, { color: dateColor }]}>{dateStr}</Text>

      <TouchableOpacity
        onPress={onEditBackground}
        style={styles.heroBgEditBtn}
        hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
      >
        <MaterialCommunityIcons name="image-edit-outline" size={16} color={theme.textSecondary} />
      </TouchableOpacity>
    </>
  );

  return (
    <TouchableOpacity
      activeOpacity={errorMsg ? 0.85 : 1}
      onPress={errorMsg ? onOpenSettings : undefined}
      style={styles.heroCard}
    >
      {backgroundUri ? (
        <ImageBackground source={{ uri: backgroundUri }} style={styles.heroBgImage} resizeMode="cover">
          <View style={styles.heroCardContent}>{content}</View>
        </ImageBackground>
      ) : (
        <View style={styles.heroCardContent}>{content}</View>
      )}
    </TouchableOpacity>
  );
}

// مودال بسيط لاختيار/تصوير خلفية كارت "حالة النظام"، أو إزالة الخلفية الحالية
// والرجوع للشكل الافتراضي بتاع الثيم.
const HERO_BG_FILENAME = FileSystem.documentDirectory + 'app-images/hero-bg.jpg';

function HeroBackgroundModal({ visible, theme, currentUri, currentOpacity, currentTextColor, onClose, onPicked, onRemove, onChangeOpacity, onChangeTextColor }) {
  const [busy, setBusy] = useState(false);

  const persist = async (sourceUri) => {
    await FileSystem.makeDirectoryAsync(FileSystem.documentDirectory + 'app-images/', { intermediates: true }).catch(
      () => {}
    );
    await FileSystem.deleteAsync(HERO_BG_FILENAME, { idempotent: true }).catch(() => {});
    await FileSystem.copyAsync({ from: sourceUri, to: HERO_BG_FILENAME });
    // بنضيف باراميتر وهمي (وقت الحفظ) عشان الصورة تتحدث فورًا في الواجهة، لأن
    // بعض المنصات بتكاش الصورة على نفس المسار وميحدثهاش تاني من غير كده.
    return `${HERO_BG_FILENAME}?t=${Date.now()}`;
  };

  const pickFromLibrary = async () => {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      showAlert('مفيش صلاحية', 'لازم تسمح للتطبيق بالدخول على الصور من إعدادات الموبايل الأول');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [16, 9],
      quality: 0.7,
    });
    if (result.canceled || !result.assets?.[0]?.uri) return;
    setBusy(true);
    try {
      onPicked(await persist(result.assets[0].uri));
    } catch (e) {
      showAlert('خطأ', 'مقدرناش نحفظ الصورة، جرب تاني');
    } finally {
      setBusy(false);
    }
  };

  const takePhoto = async () => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      showAlert('مفيش صلاحية', 'لازم تسمح للتطبيق باستخدام الكاميرا من إعدادات الموبايل الأول');
      return;
    }
    const result = await ImagePicker.launchCameraAsync({ allowsEditing: true, aspect: [16, 9], quality: 0.7 });
    if (result.canceled || !result.assets?.[0]?.uri) return;
    setBusy(true);
    try {
      onPicked(await persist(result.assets[0].uri));
    } catch (e) {
      showAlert('خطأ', 'مقدرناش نحفظ الصورة، جرب تاني');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={heroBgModalStyles.overlay}>
        <View style={[heroBgModalStyles.box, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={heroBgModalStyles.headerRow}>
            <Text style={[heroBgModalStyles.title, { color: theme.textPrimary }]}>خلفية كارت الحالة</Text>
            <TouchableOpacity onPress={onClose} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <MaterialCommunityIcons name="close" size={20} color={theme.textMuted} />
            </TouchableOpacity>
          </View>

          <Text style={[heroBgModalStyles.hint, { color: theme.textSecondary }]}>
            اختار صورة تتحط خلفية للمستطيل اللي فيه الساعة فوق شاشة البوردات.
          </Text>

          <View style={heroBgModalStyles.actionsRow}>
            <TouchableOpacity
              style={[heroBgModalStyles.actionBtn, { backgroundColor: theme.cardAlt, borderColor: theme.border }]}
              onPress={pickFromLibrary}
              disabled={busy}
              activeOpacity={0.85}
            >
              <MaterialCommunityIcons name="image-outline" size={17} color={theme.accentSoft} />
              <Text style={[heroBgModalStyles.actionBtnText, { color: theme.textSecondary }]}>صورة</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[heroBgModalStyles.actionBtn, { backgroundColor: theme.cardAlt, borderColor: theme.border }]}
              onPress={takePhoto}
              disabled={busy}
              activeOpacity={0.85}
            >
              <MaterialCommunityIcons name="camera-outline" size={17} color={theme.accentSoft} />
              <Text style={[heroBgModalStyles.actionBtnText, { color: theme.textSecondary }]}>كاميرا</Text>
            </TouchableOpacity>
          </View>

          {!!currentUri && (
            <>
              <Text style={[heroBgModalStyles.opacityLabel, { color: theme.textPrimary }]}>
                درجة تعتيم الصورة — {Math.round((currentOpacity ?? 0.72) * 100)}٪
              </Text>
              <View style={heroBgModalStyles.opacityRow}>
                <TouchableOpacity
                  style={[heroBgModalStyles.opacityBtn, { backgroundColor: theme.cardAlt, borderColor: theme.border }]}
                  onPress={() => onChangeOpacity?.(Math.max(0, Math.round(((currentOpacity ?? 0.72) - 0.1) * 10) / 10))}
                  activeOpacity={0.85}
                >
                  <MaterialCommunityIcons name="minus" size={18} color={theme.accentSoft} />
                </TouchableOpacity>
                <View style={heroBgModalStyles.opacityTrack}>
                  <View
                    style={[
                      heroBgModalStyles.opacityFill,
                      { width: `${Math.round((currentOpacity ?? 0.72) * 100)}%`, backgroundColor: theme.accent },
                    ]}
                  />
                </View>
                <TouchableOpacity
                  style={[heroBgModalStyles.opacityBtn, { backgroundColor: theme.cardAlt, borderColor: theme.border }]}
                  onPress={() => onChangeOpacity?.(Math.min(1, Math.round(((currentOpacity ?? 0.72) + 0.1) * 10) / 10))}
                  activeOpacity={0.85}
                >
                  <MaterialCommunityIcons name="plus" size={18} color={theme.accentSoft} />
                </TouchableOpacity>
              </View>

              <Text style={[heroBgModalStyles.opacityLabel, { color: theme.textPrimary }]}>لون الكلام</Text>
              <View style={heroBgModalStyles.colorRow}>
                <TouchableOpacity
                  style={[
                    heroBgModalStyles.colorSwatch,
                    { backgroundColor: theme.textPrimary },
                    !currentTextColor && heroBgModalStyles.colorSwatchSelected,
                  ]}
                  onPress={() => onChangeTextColor?.(null)}
                >
                  {!currentTextColor && <MaterialCommunityIcons name="check" size={13} color={theme.card} />}
                </TouchableOpacity>
                {['#ffffff', '#000000', ...COLOR_SWATCHES].map((c) => (
                  <TouchableOpacity
                    key={c}
                    style={[
                      heroBgModalStyles.colorSwatch,
                      { backgroundColor: c, borderColor: theme.border },
                      currentTextColor === c && heroBgModalStyles.colorSwatchSelected,
                    ]}
                    onPress={() => onChangeTextColor?.(c)}
                  >
                    {currentTextColor === c && (
                      <MaterialCommunityIcons name="check" size={13} color={c === '#ffffff' || c === '#ffd166' ? '#0f1712' : '#fff'} />
                    )}
                  </TouchableOpacity>
                ))}
              </View>

              <TouchableOpacity onPress={onRemove} style={heroBgModalStyles.removeLink}>
                <Text style={[heroBgModalStyles.removeLinkText, { color: theme.danger }]}>
                  إزالة الخلفية والرجوع لشكل الثيم الافتراضي
                </Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </View>
    </Modal>
  );
}

const heroBgModalStyles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', alignItems: 'center' },
  box: { width: '88%', borderRadius: 18, borderWidth: 1, padding: 18 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  title: { fontSize: 16, fontWeight: '700' },
  hint: { fontSize: 12, lineHeight: 18, marginBottom: 16, textAlign: 'right' },
  actionsRow: { flexDirection: 'row', gap: 10 },
  actionBtn: {
    flex: 1,
    flexDirection: 'row',
    gap: 6,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
  },
  actionBtnText: { fontSize: 12.5, fontWeight: '700' },
  opacityLabel: { fontSize: 12.5, fontWeight: '700', marginTop: 18, marginBottom: 10, textAlign: 'right' },
  opacityRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  opacityBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  opacityTrack: { flex: 1, height: 6, borderRadius: 3, backgroundColor: 'rgba(128,128,128,0.25)', overflow: 'hidden' },
  opacityFill: { height: '100%', borderRadius: 3 },
  colorRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 4 },
  colorSwatch: {
    width: 26,
    height: 26,
    borderRadius: 13,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  colorSwatchSelected: { borderWidth: 2, borderColor: '#fff' },
  removeLink: { alignSelf: 'center', marginTop: 16 },
  removeLinkText: { fontSize: 11.5, fontWeight: '600' },
});



// كارت إحصائية صغير في الصف اللي تحت كارت الحالة — رقم حقيقي واحد + أيقونة ولون مميّز.
function QuickStat({ theme, styles, icon, label, value, color }) {
  return (
    <View style={styles.statCard}>
      <View style={[styles.statIconCircle, { backgroundColor: color + '22' }]}>
        <MaterialCommunityIcons name={icon} size={16} color={color} />
      </View>
      <Text style={styles.statValue} numberOfLines={1}>
        {value}
      </Text>
      <Text style={styles.statLabel} numberOfLines={1}>
        {label}
      </Text>
    </View>
  );
}

// شريحة حالة الاتصال بالسيرفر — بتنبض بهدوء لما تكون متصلة، عشان تدي إحساس إن النظام "شغال وحي"
// ولما يحصل خطأ فعلي في الاتصال (سيرفر غلط، بورت مقفول، بروكر واقع، إلخ)
// بنوريه تحت كنص واضح بدل ما يفضل "جاري الاتصال…" واقف من غير أي تفسير.
// (باقية هنا للتوافق — الاستخدام الأساسي بقى جوه HomeHero فوق).
function StatusChip({ theme, styles, connected, errorMsg, onOpenSettings }) {
  const pulse = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!connected) {
      pulse.setValue(0);
      return undefined;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 1000, useNativeDriver: false }),
        Animated.timing(pulse, { toValue: 0, duration: 1000, useNativeDriver: false }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [connected, pulse]);

  const glowOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.5, 1] });

  return (
    <TouchableOpacity
      activeOpacity={errorMsg ? 0.7 : 1}
      onPress={errorMsg ? onOpenSettings : undefined}
      style={{ alignSelf: 'flex-start' }}
    >
      <View style={styles.statusChip}>
        <Animated.View
          style={[
            styles.statusDot,
            { backgroundColor: connected ? theme.on : theme.off, opacity: connected ? glowOpacity : 1 },
          ]}
        />
        <Text style={styles.statusLabel} numberOfLines={2}>
          {connected ? 'متصل بالسيرفر' : errorMsg ? `تعذر الاتصال — ${errorMsg}` : 'جاري الاتصال…'}
        </Text>
      </View>
    </TouchableOpacity>
  );
}

// كارت بورد واحد — أفاتار دائري بأيقونة البورد (المختارة يدويًا أو الافتراضية حسب نوعه)
// وحلقة بتنبض هادي لما السيرفر متصل. دوس على الأفاتار عشان تغيّر شكل البورد.
// بيدعم شكلين: "list" (صف أفقي زي ما كان) و"grid" (كارت رأسي مربّع جوه شبكة).
function BoardCard({ board, theme, styles, connected, availability, viewMode, color, onPress, onEdit }) {
  const avatarColor = color || theme.accent;
  const pulse = useRef(new Animated.Value(0)).current;
  const isGrid = viewMode === 'grid';

  useEffect(() => {
    if (!connected) {
      pulse.setValue(0);
      return undefined;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 1400, useNativeDriver: false }),
        Animated.timing(pulse, { toValue: 0, duration: 1400, useNativeDriver: false }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [connected, pulse]);

  const glowOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.4, 0.9] });
  const metaIcon = board.type === 'switches' ? 'toggle-switch-outline' : 'water-pump';
  const metaText =
    board.type === 'switches' ? `${(board.devices || []).length} مفتاح` : board.prefix;
  const avatarIconName = board.icon ? getDeviceIcon(board.icon).icon : BOARD_TYPE_ICONS[board.type] || 'chip';
  const realisticBoardImage = board.type === 'irrigation' ? getDeviceIconImage('relayboard') : getDeviceIconImage('board');

  // حالة البورد لوحده (مش السيرفر العام): 'online' | 'offline' | null (لسه مش معروفة)
  const boardDotColor =
    availability === 'online' ? theme.on : availability === 'offline' ? theme.off : theme.textMuted;
  const boardStatusLabel =
    availability === 'online' ? 'البورد متصل' : availability === 'offline' ? 'البورد مقطوع' : 'حالة البورد غير معروفة';

  if (isGrid) {
    return (
      <TouchableOpacity style={styles.boardCardGrid} onPress={onPress} activeOpacity={0.85}>
        <TouchableOpacity onPress={onEdit} style={styles.gridEditBtn} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <MaterialCommunityIcons name="cog-outline" size={15} color={theme.textMuted} />
        </TouchableOpacity>

        <View style={{ alignSelf: 'center' }}>
          <Animated.View
            style={[
              styles.avatarFrameGrid,
              { borderColor: connected ? avatarColor : theme.border, shadowColor: avatarColor, backgroundColor: theme.cardAlt, opacity: connected ? glowOpacity : 0.95 },
            ]}
          >
            {board.imageUri ? (
              <Image source={{ uri: board.imageUri }} style={styles.avatarImageGrid} resizeMode="cover" />
            ) : realisticBoardImage ? (
              <Image source={realisticBoardImage} style={styles.avatarImageGrid} resizeMode="cover" />
            ) : (
              <MaterialCommunityIcons name={avatarIconName} size={28} color={avatarColor} />
            )}
          </Animated.View>
          <View
            style={[styles.availabilityDotGrid, { backgroundColor: boardDotColor, borderColor: theme.card }]}
            accessibilityLabel={boardStatusLabel}
          />
        </View>

        <Text style={styles.boardNameGrid} numberOfLines={1}>
          {board.name}
        </Text>

        <View style={styles.typeBadgeGrid}>
          <Text style={styles.typeBadgeText}>{BOARD_TYPE_LABELS[board.type] || board.type}</Text>
        </View>

        <View style={styles.metaItemGrid}>
          <MaterialCommunityIcons name={metaIcon} size={11} color={theme.textSecondary} />
          <Text style={styles.boardMeta} numberOfLines={1}>
            {metaText}
          </Text>
        </View>

        <Text style={[styles.boardAvailabilityText, { color: boardDotColor, textAlign: 'center' }]} numberOfLines={1}>
          {boardStatusLabel}
        </Text>
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity style={styles.boardCard} onPress={onPress} activeOpacity={0.8}>
      <View>
        <Animated.View
          style={[
            styles.avatarFrame,
            { borderColor: connected ? avatarColor : theme.border, shadowColor: avatarColor, backgroundColor: theme.cardAlt, opacity: connected ? glowOpacity : 0.95 },
          ]}
        >
          {board.imageUri ? (
            <Image source={{ uri: board.imageUri }} style={styles.avatarImage} resizeMode="cover" />
          ) : realisticBoardImage ? (
            <Image source={realisticBoardImage} style={styles.avatarImage} resizeMode="cover" />
          ) : (
            <MaterialCommunityIcons name={avatarIconName} size={26} color={avatarColor} />
          )}
        </Animated.View>
        <View
          style={[styles.availabilityDot, { backgroundColor: boardDotColor, borderColor: theme.card }]}
          accessibilityLabel={boardStatusLabel}
        />
      </View>

      <View style={styles.boardTextWrap}>
        <Text style={styles.boardName} numberOfLines={1}>
          {board.name}
        </Text>
        <View style={styles.boardMetaRow}>
          <View style={styles.typeBadge}>
            <Text style={styles.typeBadgeText}>{BOARD_TYPE_LABELS[board.type] || board.type}</Text>
          </View>
          <View style={styles.metaItem}>
            <MaterialCommunityIcons name={metaIcon} size={12} color={theme.textSecondary} />
            <Text style={styles.boardMeta} numberOfLines={1}>
              {metaText}
            </Text>
          </View>
        </View>
        <Text style={[styles.boardAvailabilityText, { color: boardDotColor }]} numberOfLines={1}>
          {boardStatusLabel}
        </Text>
      </View>

      <TouchableOpacity onPress={onEdit} style={styles.editBtn} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
        <MaterialCommunityIcons name="cog-outline" size={19} color={theme.textMuted} />
      </TouchableOpacity>
    </TouchableOpacity>
  );
}

// دائرة البحث عن البورد — موجات/دوائر متحركة فقط بدون خط أو شعاع دوّار.
// الهدف شكل نظيف وخفيف: الدوائر تكبر وتختفي بالتتابع أثناء البحث.
function RadarSearch({ theme, styles, active, size }) {
  const isSmall = size === 'small';
  const waves = useRef([0, 1, 2].map(() => new Animated.Value(0))).current;

  useEffect(() => {
    if (!active) {
      waves.forEach((w) => w.setValue(0));
      return undefined;
    }

    const waveLoops = waves.map((w, i) =>
      Animated.loop(
        Animated.sequence([
          Animated.delay(i * 650),
          Animated.timing(w, {
            toValue: 1,
            duration: 1950,
            useNativeDriver: true,
          }),
        ])
      )
    );

    waveLoops.forEach((l) => l.start());
    return () => waveLoops.forEach((l) => l.stop());
  }, [active, waves]);

  return (
    <View style={isSmall ? styles.radarWrapSmall : styles.radarWrap}>
      {waves.map((w, i) => (
        <Animated.View
          key={i}
          style={[
            isSmall ? styles.radarWaveSmall : styles.radarWave,
            {
              borderColor: theme.accent,
              opacity: w.interpolate({
                inputRange: [0, 0.7, 1],
                outputRange: [0.55, 0.18, 0],
              }),
              transform: [
                {
                  scale: w.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0.35, 1],
                  }),
                },
              ],
            },
          ]}
        />
      ))}

      {/* دوائر ثابتة فقط لإظهار مركز البحث — بدون خطوط متحركة */}
      <View style={isSmall ? styles.radarRingOuterSmall : styles.radarRingOuter} />
      <View style={isSmall ? styles.radarRingInnerSmall : styles.radarRingInner} />

      <View style={isSmall ? styles.radarCoreSmall : styles.radarCore}>
        <MaterialCommunityIcons
          name="access-point"
          size={isSmall ? 9 : 22}
          color={theme.accentSoft}
        />
      </View>
    </View>
  );
}

// كارت جهاز واحد اتلقط من رسائل الاكتشاف العامة، لسه محتاج ضغطة "+" عشان يتضاف فعليًا
function DiscoveredDeviceCard({ board, theme, styles, onAdd }) {
  const subtitle =
    board.type === 'irrigation' ? board.prefix : board.deviceId || `${(board.devices || []).length} مفتاح`;
  return (
    <View style={styles.discoveredCard}>
      <View style={styles.discoveredIconCircle}>
        <MaterialCommunityIcons
          name={board.type === 'irrigation' ? 'water-pump' : 'chip'}
          size={20}
          color={theme.accentSoft}
        />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.discoveredName} numberOfLines={1}>
          {board.name}
        </Text>
        <Text style={styles.discoveredSubtitle} numberOfLines={1}>
          {subtitle}
        </Text>
      </View>
      <TouchableOpacity style={styles.discoveredAddBtn} onPress={onAdd} activeOpacity={0.8}>
        <MaterialCommunityIcons name="plus" size={18} color={theme.accent} />
      </TouchableOpacity>
    </View>
  );
}

function hexToRgba(hex, alpha) {
  const clean = (hex || '').replace('#', '');
  if (clean.length !== 6) return `rgba(255,255,255,${alpha})`;
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}

// بيمزج بين لونين hex بنسبة t (0 = اللون الأول، 1 = اللون التاني) — مستخدم
// عشان نعمل تدرّج لوني حقيقي على طول شعاع الرادار الدوّار بدل لون واحد ثابت.
function mixHexColors(hexA, hexB, t) {
  const a = (hexA || '#ffffff').replace('#', '');
  const b = (hexB || '#ffffff').replace('#', '');
  if (a.length !== 6 || b.length !== 6) return hexA;
  const ar = parseInt(a.slice(0, 2), 16);
  const ag = parseInt(a.slice(2, 4), 16);
  const ab = parseInt(a.slice(4, 6), 16);
  const br = parseInt(b.slice(0, 2), 16);
  const bg = parseInt(b.slice(2, 4), 16);
  const bb = parseInt(b.slice(4, 6), 16);
  const r = Math.round(ar + (br - ar) * t);
  const g = Math.round(ag + (bg - ag) * t);
  const bl = Math.round(ab + (bb - ab) * t);
  return `rgb(${r}, ${g}, ${bl})`;
}

function getStyles(theme) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: theme.bg, padding: 18, paddingTop: 50 },
    headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    brandRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    brandLogoWrap: {
      borderRadius: 14,
      shadowColor: theme.accent,
      shadowOffset: { width: 0, height: 4 },
      shadowOpacity: 0.35,
      shadowRadius: 10,
      elevation: 4,
    },
    brandLogo: {
      width: 42,
      height: 42,
      borderRadius: 13,
    },
    eyebrow: {
      color: theme.accentSoft,
      fontSize: 11,
      fontWeight: '700',
      fontFamily: FONTS.bodyBold,
      letterSpacing: 1.5,
      marginBottom: 2,
    },
    title: {
      color: theme.textPrimary,
      fontSize: 28,
      fontWeight: '900',
      fontFamily: FONTS.display,
      letterSpacing: -0.5,
      textShadowColor: theme.accentSoft,
      textShadowOffset: { width: 0, height: 0 },
      textShadowRadius: 10,
    },

    // زرار التبديل بين شكل "قائمة" و"شبكة" لعرض البوردات
    viewToggle: {
      flexDirection: 'row',
      backgroundColor: theme.cardAlt,
      borderRadius: 14,
      padding: 3,
      gap: 2,
      borderWidth: 1,
      borderColor: theme.border,
    },
    viewToggleBtn: {
      width: 32,
      height: 32,
      borderRadius: 11,
      alignItems: 'center',
      justifyContent: 'center',
    },
    viewToggleBtnActive: {
      backgroundColor: theme.accent,
    },

    statusChip: {
      flexDirection: 'row',
      alignItems: 'center',
      alignSelf: 'flex-start',
      backgroundColor: theme.cardAlt,
      borderRadius: 20,
      paddingVertical: 6,
      paddingHorizontal: 12,
      marginTop: 14,
      marginBottom: 18,
      gap: 8,
      maxWidth: '100%',
    },
    statusDot: { width: 8, height: 8, borderRadius: 4 },
    statusLabel: { color: theme.textSecondary, fontSize: 12, fontWeight: '600', flexShrink: 1 },

    setupChip: {
      flexDirection: 'row',
      alignItems: 'center',
      alignSelf: 'flex-start',
      backgroundColor: theme.cardAlt,
      borderRadius: 20,
      paddingVertical: 8,
      paddingHorizontal: 14,
      marginTop: 14,
      marginBottom: 18,
      gap: 8,
      borderWidth: 1,
      borderColor: theme.accent,
    },
    setupChipText: { color: theme.accentSoft, fontSize: 12, fontWeight: '600' },

    // ------- كارت "حالة النظام" (بديل الطقس/صورة المنزل) -------
    heroCard: {
      backgroundColor: hexToRgba(theme.card, 0.94),
      borderRadius: 26,
      marginTop: 16,
      marginBottom: 16,
      borderWidth: 1,
      borderColor: theme.accent,
      overflow: 'hidden',
      shadowColor: theme.accent,
      shadowOffset: { width: 0, height: 8 },
      shadowOpacity: 0.42,
      shadowRadius: 22,
      elevation: 4,
    },
    heroCardContent: { padding: 20 },
    heroBgImage: { width: '100%' },
    heroBgOverlay: { ...StyleSheet.absoluteFillObject },
    heroBgEditBtn: {
      position: 'absolute',
      top: 14,
      right: 14,
      width: 30,
      height: 30,
      borderRadius: 15,
      backgroundColor: theme.cardAlt + 'e6',
      alignItems: 'center',
      justifyContent: 'center',
      borderWidth: 1,
      borderColor: theme.border,
    },
    heroWatermark: { position: 'absolute', left: -20, bottom: -22, opacity: 0.6 },
    heroTopRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 14 },
    heroStatusDot: { width: 9, height: 9, borderRadius: 4.5 },
    heroStatusText: { color: theme.textSecondary, fontSize: 12.5, fontWeight: '600', flexShrink: 1 },
    heroTime: { color: theme.textPrimary, fontSize: 34, fontWeight: '800', letterSpacing: -0.5 },
    heroDate: { color: theme.textMuted, fontSize: 12.5, marginTop: 2 },

    quickStatsRow: { flexDirection: 'row', gap: 10, marginBottom: 22 },
    statCard: {
      flex: 1,
      backgroundColor: hexToRgba(theme.card, 0.96),
      borderRadius: 18,
      paddingVertical: 12,
      paddingHorizontal: 8,
      alignItems: 'center',
      borderWidth: 1,
      borderColor: theme.border,
    },
    statIconCircle: {
      width: 30,
      height: 30,
      borderRadius: 15,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 8,
    },
    statValue: { color: theme.textPrimary, fontSize: 14, fontWeight: '800' },
    statLabel: { color: theme.textMuted, fontSize: 10, marginTop: 2, textAlign: 'center' },

    // ------- السيناريوهات السريعة -------
    quickScenesSection: { marginBottom: 24 },
    sectionLink: { color: theme.accentSoft, fontSize: 11.5, fontWeight: '700' },
    sceneRowContent: { gap: 10, paddingBottom: 2 },
    sceneChip: {
      alignItems: 'center',
      width: 74,
      backgroundColor: theme.card,
      borderRadius: 16,
      paddingVertical: 12,
      paddingHorizontal: 6,
      borderWidth: 1,
      borderColor: theme.border,
    },
    sceneChipIcon: {
      width: 34,
      height: 34,
      borderRadius: 17,
      borderWidth: 1.5,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 8,
    },
    sceneChipText: { color: theme.textSecondary, fontSize: 10.5, fontWeight: '600', textAlign: 'center' },

    sectionRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 10,
      paddingHorizontal: 2,
    },
    sectionLabel: { color: theme.textMuted, fontSize: 11, fontWeight: '700', letterSpacing: 0.5 },
    sectionCount: {
      color: theme.accentSoft,
      fontSize: 11,
      fontWeight: '700',
      backgroundColor: theme.cardAlt,
      borderRadius: 10,
      paddingHorizontal: 8,
      paddingVertical: 2,
      overflow: 'hidden',
    },

    emptyWrap: { alignItems: 'center', marginTop: 50, marginBottom: 20, paddingHorizontal: 30 },
    emptyIconCircle: {
      width: 72,
      height: 72,
      borderRadius: 36,
      backgroundColor: theme.cardAlt,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 14,
    },
    emptyTitle: { color: theme.textPrimary, fontSize: 15, fontWeight: '700', marginBottom: 6 },
    emptyText: { color: theme.textSecondary, textAlign: 'center', fontSize: 12.5, lineHeight: 19 },

    boardCard: {
      backgroundColor: hexToRgba(theme.card, 0.96),
      borderRadius: 26,
      paddingVertical: 15,
      paddingHorizontal: 17,
      marginBottom: 12,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 14,
      borderWidth: 1.25,
      borderColor: theme.accent + '55',
      shadowColor: theme.accent,
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.4,
      shadowRadius: 20,
      elevation: 5,
    },
    avatarFrame: {
      width: 92,
      height: 72,
      borderRadius: 18,
      borderWidth: 1.5,
      backgroundColor: theme.cardAlt,
      alignItems: 'center',
      justifyContent: 'center',
      shadowOffset: { width: 0, height: 0 },
      shadowOpacity: 0.65,
      shadowRadius: 10,
      elevation: 3,
      overflow: 'hidden',
    },
    avatarImage: { width: '100%', height: '100%', alignSelf: 'stretch' },
    availabilityDot: {
      position: 'absolute',
      bottom: -1,
      right: -1,
      width: 14,
      height: 14,
      borderRadius: 7,
      borderWidth: 2,
    },
    boardTextWrap: { flex: 1 },
    boardName: { color: theme.textPrimary, fontSize: 15.5, fontWeight: '700', marginBottom: 5 },
    boardAvailabilityText: { fontSize: 10.5, fontWeight: '600', marginTop: 3 },
    boardMetaRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
    typeBadge: {
      backgroundColor: theme.cardAlt,
      borderRadius: 8,
      paddingHorizontal: 7,
      paddingVertical: 2,
    },
    typeBadgeText: { color: theme.accentSoft, fontSize: 10, fontWeight: '700' },
    metaItem: { flexDirection: 'row', alignItems: 'center', gap: 3 },
    boardMeta: { color: theme.textSecondary, fontSize: 11.5 },
    editBtn: { padding: 4 },

    // ------- شكل الشبكة (Grid) لكروت البوردات -------
    boardsGridWrap: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      justifyContent: 'space-between',
    },
    boardCardGrid: {
      width: '48%',
      backgroundColor: theme.card,
      borderRadius: 22,
      paddingVertical: 18,
      paddingHorizontal: 12,
      marginBottom: 14,
      alignItems: 'center',
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 6 },
      shadowOpacity: 0.12,
      shadowRadius: 14,
      elevation: 3,
    },
    gridEditBtn: {
      position: 'absolute',
      top: 10,
      left: 10,
      width: 26,
      height: 26,
      borderRadius: 13,
      backgroundColor: theme.cardAlt,
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 2,
    },
    avatarFrameGrid: {
      width: 104,
      height: 78,
      borderRadius: 18,
      borderWidth: 1.5,
      backgroundColor: theme.cardAlt,
      alignItems: 'center',
      justifyContent: 'center',
      shadowOffset: { width: 0, height: 0 },
      shadowOpacity: 0.65,
      shadowRadius: 10,
      elevation: 3,
      marginTop: 6,
      overflow: 'hidden',
    },
    avatarImageGrid: { width: '100%', height: '100%', alignSelf: 'stretch' },
    availabilityDotGrid: {
      position: 'absolute',
      bottom: 2,
      right: 2,
      width: 14,
      height: 14,
      borderRadius: 7,
      borderWidth: 2,
    },
    boardNameGrid: {
      color: theme.textPrimary,
      fontSize: 14,
      fontWeight: '700',
      marginTop: 10,
      marginBottom: 6,
      textAlign: 'center',
    },
    typeBadgeGrid: {
      backgroundColor: theme.cardAlt,
      borderRadius: 8,
      paddingHorizontal: 8,
      paddingVertical: 3,
      marginBottom: 6,
    },
    metaItemGrid: { flexDirection: 'row', alignItems: 'center', gap: 3, marginBottom: 4 },

    card: {
      backgroundColor: theme.card,
      borderRadius: 20,
      padding: 18,
      marginTop: 6,
      marginBottom: 12,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 6 },
      shadowOpacity: 0.12,
      shadowRadius: 14,
      elevation: 3,
    },
    formHeaderRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 4 },
    formHeaderIcon: {
      width: 32,
      height: 32,
      borderRadius: 16,
      backgroundColor: theme.cardAlt,
      alignItems: 'center',
      justifyContent: 'center',
    },
    formHeaderTitle: { color: theme.textPrimary, fontSize: 15, fontWeight: '700' },
    label: { color: theme.textSecondary, fontSize: 12, marginTop: 12, marginBottom: 6 },
    hint: { color: theme.textMuted, fontSize: 11, marginTop: 10, lineHeight: 17 },
    input: {
      backgroundColor: theme.cardAlt,
      color: theme.textPrimary,
      borderRadius: 10,
      paddingHorizontal: 12,
      paddingVertical: 10,
    },
    discoveringRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 14 },
    discoveringText: { color: theme.accentSoft, fontSize: 12 },
    errorText: { color: theme.danger, fontSize: 12, marginTop: 12, lineHeight: 18 },
    btnRow: { flexDirection: 'row', gap: 10, marginTop: 16 },
    smallBtn: { flex: 1, borderRadius: 10, paddingVertical: 12, alignItems: 'center' },
    onBtn: { backgroundColor: theme.accent },
    dangerBtn: { backgroundColor: theme.danger },
    btnText: { color: '#fff', fontWeight: '600', fontSize: 13 },

    addBtn: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 10,
      backgroundColor: theme.accent,
      borderRadius: 20,
      paddingVertical: 16,
      marginTop: 8,
      shadowColor: theme.accent,
      shadowOffset: { width: 0, height: 8 },
      shadowOpacity: 0.3,
      shadowRadius: 16,
      elevation: 4,
    },
    addBtnIconCircle: {
      width: 22,
      height: 22,
      borderRadius: 11,
      backgroundColor: 'rgba(255,255,255,0.25)',
      alignItems: 'center',
      justifyContent: 'center',
    },
    addBtnText: { color: '#fff', fontWeight: '700', fontSize: 15 },

    // ------- شاشة إضافة بورد / جهاز (رادار) -------
    discoverContainer: { flex: 1, backgroundColor: theme.bg },
    discoverHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingHorizontal: 20,
      paddingTop: 16,
      paddingBottom: 10,
    },
    discoverHeaderTitle: { color: theme.textPrimary, fontSize: 17, fontWeight: '800' },
    discoverWarnBox: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10,
      backgroundColor: theme.cardAlt,
      borderRadius: 14,
      borderWidth: 1,
      borderColor: theme.danger,
      padding: 14,
      marginHorizontal: 20,
      marginTop: 24,
    },
    discoverWarnText: { color: theme.textSecondary, fontSize: 12.5, flex: 1, lineHeight: 19 },

    radarWrap: {
      width: 220,
      height: 220,
      alignSelf: 'center',
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: 28,
      marginBottom: 10,
    },
    radarWave: {
      position: 'absolute',
      width: 220,
      height: 220,
      borderRadius: 110,
      borderWidth: 1.5,
    },
    radarRingOuter: {
      position: 'absolute',
      width: 170,
      height: 170,
      borderRadius: 85,
      borderWidth: 1,
      borderColor: theme.border,
    },
    radarRingInner: {
      position: 'absolute',
      width: 110,
      height: 110,
      borderRadius: 55,
      borderWidth: 1,
      borderColor: theme.border,
    },
    radarCore: {
      // حجم أصغر ودائرة مضبوطة (مش بيضاوي) عشان محدش يغطي مركز الدوران —
      // كده الخط بيبان بيلف من نص الدايرة فعلاً، مش من جنب دايرة كبيرة.
      width: 46,
      height: 46,
      borderRadius: 23,
      backgroundColor: theme.card,
      borderWidth: 1.5,
      borderColor: theme.accent,
      alignItems: 'center',
      justifyContent: 'center',
      shadowColor: theme.accent,
      shadowOffset: { width: 0, height: 0 },
      shadowOpacity: 0.6,
      shadowRadius: 14,
      elevation: 6,
    },
    radarWrapSmall: {
      width: 34,
      height: 34,
      alignItems: 'center',
      justifyContent: 'center',
    },
    radarWaveSmall: {
      position: 'absolute',
      width: 34,
      height: 34,
      borderRadius: 17,
      borderWidth: 1,
    },
    radarRingOuterSmall: {
      position: 'absolute',
      width: 26,
      height: 26,
      borderRadius: 13,
      borderWidth: 1,
      borderColor: theme.border,
    },
    radarRingInnerSmall: {
      position: 'absolute',
      width: 18,
      height: 18,
      borderRadius: 9,
      borderWidth: 1,
      borderColor: theme.border,
    },
    radarCoreSmall: {
      width: 10,
      height: 10,
      borderRadius: 5,
      backgroundColor: theme.card,
      borderWidth: 1,
      borderColor: theme.accent,
      alignItems: 'center',
      justifyContent: 'center',
      shadowColor: theme.accent,
      shadowOffset: { width: 0, height: 0 },
      shadowOpacity: 0.6,
      shadowRadius: 6,
      elevation: 4,
    },
    discoverStatusTitle: {
      color: theme.textPrimary,
      fontSize: 16,
      fontWeight: '800',
      textAlign: 'center',
      marginTop: 4,
    },
    discoverStatusHint: {
      color: theme.textMuted,
      fontSize: 11.5,
      textAlign: 'center',
      marginTop: 8,
      paddingHorizontal: 30,
      lineHeight: 17,
    },

    discoverListSection: { marginTop: 30, paddingHorizontal: 20 },
    discoverListLabel: { color: theme.textMuted, fontSize: 12, fontWeight: '700', marginBottom: 12 },
    discoverEmptyHint: { color: theme.textMuted, fontSize: 12, lineHeight: 18 },
    discoveredCard: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      backgroundColor: theme.card,
      borderRadius: 16,
      padding: 14,
      marginBottom: 10,
    },
    discoveredIconCircle: {
      width: 42,
      height: 42,
      borderRadius: 21,
      backgroundColor: theme.cardAlt,
      alignItems: 'center',
      justifyContent: 'center',
    },
    discoveredName: { color: theme.textPrimary, fontSize: 14.5, fontWeight: '700' },
    discoveredSubtitle: { color: theme.textMuted, fontSize: 11.5, marginTop: 2 },
    discoveredAddBtn: {
      width: 34,
      height: 34,
      borderRadius: 17,
      borderWidth: 1.5,
      borderColor: theme.accent,
      alignItems: 'center',
      justifyContent: 'center',
    },

    manualRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      marginHorizontal: 20,
      marginTop: 22,
      paddingVertical: 14,
      paddingHorizontal: 4,
      borderTopWidth: 1,
      borderTopColor: theme.border,
    },
    manualRowIcon: {
      width: 34,
      height: 34,
      borderRadius: 17,
      backgroundColor: theme.cardAlt,
      alignItems: 'center',
      justifyContent: 'center',
    },
    manualRowText: { flex: 1, color: theme.textPrimary, fontSize: 14, fontWeight: '700' },

    manualFullLink: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      marginTop: 14,
      paddingTop: 12,
      borderTopWidth: 1,
      borderTopColor: theme.border,
    },
    manualFullLinkText: { flex: 1, color: theme.accentSoft, fontSize: 12.5, fontWeight: '600', textAlign: 'right' },
    manualFullLinkTop: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      marginHorizontal: 20,
      marginTop: 4,
      marginBottom: 18,
      paddingVertical: 12,
      paddingHorizontal: 12,
      borderRadius: 12,
      borderWidth: 1,
      borderStyle: 'dashed',
      borderColor: theme.accentSoft,
      backgroundColor: theme.card,
    },
  });
}
