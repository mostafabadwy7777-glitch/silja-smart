import React, { useEffect, useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, StyleSheet } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { showAlert } from '../components/PremiumAlert';
import { THEMES, COLOR_SWATCHES, CUSTOM_THEME_ID } from '../theme';
import { useTheme } from '../ThemeContext';
import ScreenBackground from '../components/ScreenBackground';
import { FONTS } from '../fonts';


const SURFACE_SWATCHES = [
  '#02040d', '#04061a', '#031018', '#090312', '#10050b', '#090909',
  '#f3f7fb', '#f2faf6', '#fdf3f6', '#faf6ef', '#f5f6f9', '#fbf9f3',
];
const CARD_SWATCHES = [
  '#070b1d', '#0a0f2e', '#071b25', '#160722', '#1b0914', '#15120a',
  '#ffffff', '#f4fbf8', '#fff8fb', '#fffdf8', '#ffffff', '#ffffff',
];

// صف اختيار لون: باليتة ألوان جاهزة، واللون المختار عليه علامة صح.
function ColorPickerRow({ styles, value, onChange }) {
  return (
    <View style={styles.colorRow}>
      {COLOR_SWATCHES.map((c) => (
        <TouchableOpacity
          key={c}
          style={[styles.colorSwatch, { backgroundColor: c }, value === c && styles.colorSwatchSelected]}
          onPress={() => onChange(c)}
        >
          {value === c && <MaterialCommunityIcons name="check" size={14} color="#0f1712" />}
        </TouchableOpacity>
      ))}
    </View>
  );
}

export default function ThemeScreen({ onBack }) {
  const { theme, themeId, setThemeId, customTheme, updateCustomColor, applyCustomBase, resetCustomTheme } = useTheme();
  const [customOpen, setCustomOpen] = useState(themeId === CUSTOM_THEME_ID);
  const confirmReset = () => {
    showAlert('استعادة الافتراضي', 'هيرجع الثيم المخصص لألوانه الأصلية. متأكد؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'استعادة', style: 'destructive', onPress: resetCustomTheme },
    ]);
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <ScreenBackground theme={theme} />
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={onBack}>
          <Text style={[styles.back, { color: theme.accentSoft }]}>‹ رجوع</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: theme.textPrimary }]}>الثيمات والمظهر</Text>
        <View style={{ width: 50 }} />
      </View>

      <Text style={[styles.hint, { color: theme.textSecondary }]}>
        اختار الشكل اللي يعجبك، هيتطبق على كل شاشات التطبيق فورًا. أو افتح "ثيم مخصص" تحت وحدد الألوان بنفسك.
      </Text>

      <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
        {/* ---- كارت الثيم المخصص ---- */}
        <View
          style={[
            styles.card,
            { backgroundColor: customTheme.card, borderColor: themeId === CUSTOM_THEME_ID ? customTheme.accent : customTheme.border },
          ]}
        >
          <TouchableOpacity
            onPress={() => {
              setCustomOpen(true);
              if (themeId !== CUSTOM_THEME_ID) setThemeId(CUSTOM_THEME_ID);
            }}
            activeOpacity={0.85}
          >
            <View style={styles.cardTop}>
              <View style={styles.customTitleRow}>
                <MaterialCommunityIcons name="palette" size={18} color={customTheme.accent} />
                <Text style={[styles.themeName, { color: customTheme.textPrimary }]}>ثيم مخصص</Text>
              </View>
              {themeId === CUSTOM_THEME_ID ? (
                <MaterialCommunityIcons name="check-circle" size={22} color={customTheme.accent} />
              ) : (
                <MaterialCommunityIcons name="circle-outline" size={22} color={customTheme.border} />
              )}
            </View>

            <View style={styles.swatchRow}>
              <View style={[styles.swatch, { backgroundColor: customTheme.bg, borderColor: customTheme.border }]} />
              <View style={[styles.swatch, { backgroundColor: customTheme.accent, shadowColor: customTheme.accent }]} />
              <View style={[styles.swatch, { backgroundColor: customTheme.on, shadowColor: customTheme.on }]} />
              <View style={[styles.swatch, { backgroundColor: customTheme.off, shadowColor: customTheme.off }]} />
            </View>
          </TouchableOpacity>

          <TouchableOpacity onPress={() => setCustomOpen((v) => !v)} style={styles.expandRow}>
            <Text style={[styles.expandText, { color: customTheme.accentSoft }]}>
              {customOpen ? 'إخفاء خيارات التخصيص ▲' : 'تخصيص الألوان يدويًا ▼'}
            </Text>
          </TouchableOpacity>

          {customOpen && (
            <View>
              <Text style={[styles.subLabel, { color: customTheme.textSecondary }]}>ابدأ من سطح ثيم جاهز:</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.baseRow}>
                {THEMES.map((t) => (
                  <TouchableOpacity key={t.id} onPress={() => applyCustomBase(t.id)} style={styles.baseChipWrap}>
                    <View style={[styles.baseChip, { backgroundColor: t.bg, borderColor: t.border }]}>
                      <View style={[styles.baseChipDot, { backgroundColor: t.accent }]} />
                    </View>
                    <Text style={[styles.baseChipLabel, { color: customTheme.textMuted }]} numberOfLines={1}>
                      {t.name}
                    </Text>
                  </TouchableOpacity>
                ))}
              </ScrollView>


              <Text style={[styles.subLabel, { color: customTheme.textSecondary }]}>لون الخلفية:</Text>
              <View style={styles.colorRow}>
                {SURFACE_SWATCHES.map((c) => (
                  <TouchableOpacity
                    key={'bg-' + c}
                    style={[styles.colorSwatch, { backgroundColor: c }, customTheme.bg === c && styles.colorSwatchSelected]}
                    onPress={() => updateCustomColor('bg', c)}
                  >
                    {customTheme.bg === c && <MaterialCommunityIcons name="check" size={14} color="#ffffff" />}
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={[styles.subLabel, { color: customTheme.textSecondary }]}>لون الكروت:</Text>
              <View style={styles.colorRow}>
                {CARD_SWATCHES.map((c, i) => (
                  <TouchableOpacity
                    key={'card-' + i + '-' + c}
                    style={[styles.colorSwatch, { backgroundColor: c }, customTheme.card === c && styles.colorSwatchSelected]}
                    onPress={() => updateCustomColor('card', c)}
                  >
                    {customTheme.card === c && <MaterialCommunityIcons name="check" size={14} color="#ffffff" />}
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={[styles.subLabel, { color: customTheme.textSecondary }]}>اللون الأساسي (الأزرار والعناوين):</Text>
              <ColorPickerRow styles={styles} value={customTheme.accent} onChange={(c) => updateCustomColor('accent', c)} />

              <Text style={[styles.subLabel, { color: customTheme.textSecondary }]}>اللون الثانوي (الروابط والتفاصيل):</Text>
              <ColorPickerRow styles={styles} value={customTheme.accentSoft} onChange={(c) => updateCustomColor('accentSoft', c)} />

              <Text style={[styles.subLabel, { color: customTheme.textSecondary }]}>لون التشغيل (ON):</Text>
              <ColorPickerRow styles={styles} value={customTheme.on} onChange={(c) => updateCustomColor('on', c)} />

              <Text style={[styles.subLabel, { color: customTheme.textSecondary }]}>لون الإيقاف / الخطر (OFF):</Text>
              <ColorPickerRow styles={styles} value={customTheme.off} onChange={(c) => updateCustomColor('off', c)} />

              <TouchableOpacity style={[styles.resetBtn, { borderColor: customTheme.border }]} onPress={confirmReset}>
                <MaterialCommunityIcons name="restore" size={16} color={customTheme.textMuted} />
                <Text style={[styles.resetBtnText, { color: customTheme.textMuted }]}>استعادة الألوان الافتراضية</Text>
              </TouchableOpacity>
            </View>
          )}
        </View>

        {/* ---- الثيمات الجاهزة ---- */}
        {THEMES.map((t) => {
          const selected = t.id === themeId;
          return (
            <TouchableOpacity
              key={t.id}
              onPress={() => setThemeId(t.id)}
              activeOpacity={0.85}
              style={[
                styles.card,
                { backgroundColor: t.card, borderColor: selected ? t.accent : t.border },
                selected && {
                  shadowColor: t.accent,
                  shadowOffset: { width: 0, height: 6 },
                  shadowOpacity: 0.5,
                  shadowRadius: 16,
                  elevation: 6,
                },
              ]}
            >
              <View style={styles.cardTop}>
                <Text style={[styles.themeName, { color: t.textPrimary }]}>{t.name}</Text>
                {selected ? (
                  <MaterialCommunityIcons name="check-circle" size={22} color={t.accent} />
                ) : (
                  <MaterialCommunityIcons name="circle-outline" size={22} color={t.border} />
                )}
              </View>

              <View style={styles.swatchRow}>
                <View style={[styles.swatch, { backgroundColor: t.bg, borderColor: t.border }]} />
                <View style={[styles.swatch, { backgroundColor: t.accent, shadowColor: t.accent }]} />
                <View style={[styles.swatch, { backgroundColor: t.on, shadowColor: t.on }]} />
                <View style={[styles.swatch, { backgroundColor: t.off, shadowColor: t.off }]} />
              </View>

              <View style={styles.previewRow}>
                <View style={[styles.previewGlow, { borderColor: t.on, shadowColor: t.on, backgroundColor: t.cardAlt }]}>
                  <MaterialCommunityIcons name="lightbulb-on" size={22} color={t.on} />
                </View>
                <Text style={[styles.previewLabel, { color: t.textSecondary }]}>شغال</Text>
                <View style={[styles.previewGlow, { borderColor: t.off, shadowColor: t.off, backgroundColor: t.cardAlt }]}>
                  <MaterialCommunityIcons name="lightbulb-off-outline" size={22} color={t.off} />
                </View>
                <Text style={[styles.previewLabel, { color: t.textSecondary }]}>مطفي</Text>
              </View>
            </TouchableOpacity>
          );
        })}

      </ScrollView>
    </SafeAreaView>
  );
}

function hexToRgba(hex, alpha) {
  const h = String(hex || '').replace('#', '');
  if (h.length !== 6) return hex;
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${Math.max(0, Math.min(1, alpha))})`;
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 18, paddingTop: 55 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  back: { fontSize: 15 },
  title: { fontSize: 18, fontWeight: '700', fontFamily: FONTS.display },
  hint: { fontSize: 12, marginBottom: 16, lineHeight: 18 },
  card: { borderRadius: 20, borderWidth: 1.25, padding: 16, marginBottom: 14 },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  customTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  themeName: { fontSize: 16, fontWeight: '700', fontFamily: FONTS.displaySemiBold },
  swatchRow: { flexDirection: 'row', gap: 8, marginBottom: 14 },
  sectionTitle: { fontSize: 15, fontWeight: '800', marginTop: 18, marginBottom: 6, textAlign: 'right' },
  segmentRow: { flexDirection: 'row', gap: 8, marginBottom: 6 },
  segment: { flex: 1, minHeight: 92, borderRadius: 16, borderWidth: 1.2, padding: 9, alignItems: 'center', justifyContent: 'center' },
  segmentName: { fontSize: 12, fontWeight: '800', marginTop: 5 },
  segmentDesc: { fontSize: 8.5, textAlign: 'center', marginTop: 2 },
  opacityRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 10 },
  opacityChip: { width: '18.5%', minWidth: 56, minHeight: 70, borderRadius: 14, borderWidth: 1.2, alignItems: 'center', justifyContent: 'center', paddingVertical: 6 },
  opacityLabel: { fontSize: 11, fontWeight: '800', marginTop: 3 },
  opacityName: { fontSize: 7.5, marginTop: 1 },
  swatch: {
    width: 28,
    height: 28,
    borderRadius: 8,
    borderWidth: 1,
    shadowOpacity: 0.8,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 0 },
    elevation: 3,
  },
  previewRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  previewGlow: {
    width: 42,
    height: 42,
    borderRadius: 21,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
    shadowOpacity: 0.9,
    shadowRadius: 9,
    shadowOffset: { width: 0, height: 0 },
    elevation: 5,
  },
  previewLabel: { fontSize: 11, fontWeight: '700', marginRight: 6 },

  sectionTitle: { fontSize: 15, fontWeight: '700', fontFamily: FONTS.displaySemiBold, marginBottom: 4 },
  shapeOptionsRow: { flexDirection: 'row', gap: 8, marginBottom: 18 },
  shapeOption: { flex: 1, minHeight: 122, borderRadius: 16, borderWidth: 1.2, padding: 9, alignItems: 'center', justifyContent: 'center' },
  shapePreview: { height: 40, alignItems: 'center', justifyContent: 'center' },
  shapeOptionName: { fontSize: 12, fontWeight: '800', marginTop: 5 },
  shapeOptionDesc: { fontSize: 8.5, textAlign: 'center', lineHeight: 12, marginTop: 3 },

  // ---- معاينات مصغّرة لأشكال كروت المفاتيح ----
  mockWrap: { borderRadius: 14, borderWidth: 1, padding: 10, marginTop: 4, overflow: 'hidden' },
  mockClassic: { alignItems: 'center', gap: 6 },
  mockHorizontal: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  mockMinimal: { flexDirection: 'row', alignItems: 'center', gap: 8, position: 'relative', overflow: 'hidden', paddingRight: 4 },
  mockCircle: {
    width: 32,
    height: 32,
    borderRadius: 12,
    borderWidth: 1.25,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mockText: { fontSize: 12.5, fontWeight: '700' },
  mockSubText: { fontSize: 10.5, marginTop: 2 },
  mockPill: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 999, borderWidth: 1 },
  mockPillText: { fontSize: 10, fontWeight: '700' },
  mockStripe: { position: 'absolute', top: -10, bottom: -10, left: -10, width: 4 },

  // ---- خيارات التخصيص اليدوي ----
  expandRow: { marginTop: 2 },
  expandText: { fontSize: 12, fontWeight: '700' },
  subLabel: { fontSize: 12, fontWeight: '600', marginTop: 14, marginBottom: 8 },
  baseRow: { gap: 12, paddingBottom: 4 },
  baseChipWrap: { alignItems: 'center', width: 56 },
  baseChip: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  baseChipDot: { width: 14, height: 14, borderRadius: 7 },
  baseChipLabel: { fontSize: 10, marginTop: 4, textAlign: 'center' },
  colorRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  colorSwatch: {
    width: 30,
    height: 30,
    borderRadius: 15,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  colorSwatchSelected: { borderColor: '#171a21' },
  resetBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    justifyContent: 'center',
    borderWidth: 1,
    borderRadius: 10,
    paddingVertical: 10,
    marginTop: 16,
  },
  resetBtnText: { fontSize: 12, fontWeight: '600' },
});
