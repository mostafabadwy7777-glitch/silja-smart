import React, { useEffect, useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import TouchableOpacity from '../components/AnimatedTouchable';
import { useTheme } from '../ThemeContext';
import { getDeviceIcon } from '../deviceIcons';
import { boardAvailabilityTopic, parseAvailability } from '../discovery';

export default function DevicesScreen({ boards = [], client, connected = false, onOpenBoard, onBack }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);
  const devices = boards.flatMap((board) => (board.devices || []).map((device) => ({ ...device, board })));
  const [availability, setAvailability] = useState({});
  const [states, setStates] = useState({});
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    if (!client || !connected) { setAvailability({}); return undefined; }
    const topics = boards.map(boardAvailabilityTopic).filter(Boolean);
    topics.forEach((t) => client.subscribe(t));
    const handler = (topic, payload) => {
      const state = parseAvailability(payload.toString());
      if (state) setAvailability((prev) => ({ ...prev, [topic]: state }));
    };
    client.on('message', handler);
    return () => { client.off('message', handler); topics.forEach((t) => client.unsubscribe(t)); };
  }, [client, connected, boards]);

  useEffect(() => {
    if (!client || !connected) { setStates({}); return undefined; }
    const topics = Array.from(new Set(devices.map((d) => d.statusTopic || d.controlTopic).filter(Boolean)));
    topics.forEach((t) => client.subscribe(t));
    const handler = (topic, payload) => {
      const raw = payload.toString().trim();
      let value = raw.toUpperCase();
      try { const data = JSON.parse(raw); value = String(data.state ?? data.status ?? data.value ?? data.on ?? '').toUpperCase(); } catch (_) {}
      if (value === 'ON' || value === '1' || value === 'TRUE') setStates((p) => ({ ...p, [topic]: true }));
      if (value === 'OFF' || value === '0' || value === 'FALSE') setStates((p) => ({ ...p, [topic]: false }));
    };
    client.on('message', handler);
    return () => { client.off('message', handler); topics.forEach((t) => client.unsubscribe(t)); };
  }, [client, connected, boards, devices.length]);

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <TouchableOpacity onPress={onBack} style={styles.back}>
          <Text style={styles.backText}>‹ رجوع</Text>
        </TouchableOpacity>
        <View style={styles.header}>
          <View style={styles.headerIcon}><MaterialCommunityIcons name="devices" size={25} color={theme.accent} /></View>
          <View style={{ flex: 1 }}>
            <Text style={styles.title}>الأجهزة</Text>
            <Text style={styles.subtitle}>كل المفاتيح والأجهزة المرتبطة بالبوردات</Text>
          </View>
        </View>

        {devices.length === 0 ? (
          <View style={styles.empty}>
            <MaterialCommunityIcons name="devices-off-outline" size={52} color={theme.textMuted} />
            <Text style={styles.emptyTitle}>لا توجد أجهزة</Text>
            <Text style={styles.emptyText}>أضف بوردًا ثم أضف المفاتيح والأجهزة الخاصة به.</Text>
          </View>
        ) : (
          devices.map((device) => {
            const meta = getDeviceIcon(device.icon);
            const availabilityState = availability[boardAvailabilityTopic(device.board)];
            const status = states[device.statusTopic || device.controlTopic];
            const statusColor = status === true ? theme.on : status === false ? theme.off : theme.textMuted;
            return (
              <TouchableOpacity key={`${device.board.id}-${device.id}`} onPress={() => setSelected(device)} style={styles.card}>
                <View style={[styles.iconBox, { borderColor: `${theme.accent}55`, backgroundColor: `${theme.accent}16` }]}>
                  <MaterialCommunityIcons name={meta?.icon || 'light-switch'} size={25} color={theme.accent} />
                </View>
                <View style={styles.info}>
                  <Text style={styles.name} numberOfLines={1}>{device.name || 'جهاز بدون اسم'}</Text>
                  <Text style={styles.board} numberOfLines={1}>{device.board.name || 'البورد'}</Text>
                  <View style={styles.statusRow}>
                    <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
                    <Text style={[styles.statusText, { color: statusColor }]}>{status === true ? 'يعمل' : status === false ? 'متوقف' : 'غير معروف'}</Text>
                    <Text style={styles.sep}>•</Text>
                    <Text style={[styles.statusText, { color: availabilityState === 'online' ? theme.on : availabilityState === 'offline' ? theme.off : theme.textMuted }]}>{availabilityState === 'online' ? 'البورد متصل' : availabilityState === 'offline' ? 'البورد غير متصل' : 'الاتصال غير معروف'}</Text>
                  </View>
                </View>
                <MaterialCommunityIcons name="chevron-left" size={22} color={theme.textMuted} />
              </TouchableOpacity>
            );
          })
        )}

      </ScrollView>
      {selected && (
        <View style={styles.overlay}>
          <TouchableOpacity style={styles.overlayBg} onPress={() => setSelected(null)} />
          <View style={styles.modal}>
            <View style={styles.modalIcon}><MaterialCommunityIcons name={getDeviceIcon(selected.icon)?.icon || 'light-switch'} size={32} color={theme.accent} /></View>
            <Text style={styles.modalTitle}>{selected.name || 'جهاز بدون اسم'}</Text>
            <Text style={styles.modalBoard}>{selected.board.name || 'البورد'}</Text>
            <View style={styles.detailRow}><Text style={styles.detailLabel}>حالة البورد</Text><Text style={[styles.detailValue, { color: availability[boardAvailabilityTopic(selected.board)] === 'online' ? theme.on : theme.off }]}>{availability[boardAvailabilityTopic(selected.board)] === 'online' ? 'متصل' : availability[boardAvailabilityTopic(selected.board)] === 'offline' ? 'غير متصل' : 'غير معروفة'}</Text></View>
            <View style={styles.detailRow}><Text style={styles.detailLabel}>حالة الجهاز</Text><Text style={[styles.detailValue, { color: states[selected.statusTopic || selected.controlTopic] === true ? theme.on : states[selected.statusTopic || selected.controlTopic] === false ? theme.off : theme.textMuted }]}>{states[selected.statusTopic || selected.controlTopic] === true ? 'ON' : states[selected.statusTopic || selected.controlTopic] === false ? 'OFF' : 'غير معروفة'}</Text></View>
            <TouchableOpacity style={[styles.openBoardBtn, { backgroundColor: theme.accent }]} onPress={() => { setSelected(null); onOpenBoard?.(selected.board); }}><Text style={styles.openBoardText}>فتح البورد والتحكم</Text></TouchableOpacity>
            <TouchableOpacity style={styles.closeBtn} onPress={() => setSelected(null)}><Text style={styles.closeText}>إغلاق</Text></TouchableOpacity>
          </View>
        </View>
      )}
    </SafeAreaView>
  );
}

const getStyles = (theme) => StyleSheet.create({
  safe: { flex: 1, backgroundColor: theme.bg },
  content: { padding: 18, paddingBottom: 120 },
  back: { alignSelf: 'flex-start', paddingVertical: 4, marginBottom: 16 },
  backText: { color: theme.textSecondary, fontSize: 15 },
  header: { flexDirection: 'row', alignItems: 'center', marginBottom: 22, gap: 12 },
  headerIcon: { width: 48, height: 48, borderRadius: 16, alignItems: 'center', justifyContent: 'center', backgroundColor: `${theme.accent}18`, borderWidth: 1, borderColor: `${theme.accent}45` },
  title: { color: theme.textPrimary, fontSize: 23, fontWeight: '800', textAlign: 'right' },
  subtitle: { color: theme.textSecondary, fontSize: 12, marginTop: 3, textAlign: 'right' },
  card: { minHeight: 72, borderRadius: 20, marginBottom: 12, padding: 12, flexDirection: 'row', alignItems: 'center', backgroundColor: `${theme.card}E8`, borderWidth: 1, borderColor: `${theme.border}88` },
  iconBox: { width: 48, height: 48, borderRadius: 15, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  info: { flex: 1, marginHorizontal: 12 },
  name: { color: theme.textPrimary, fontSize: 15, fontWeight: '700', textAlign: 'right' },
  board: { color: theme.textMuted, fontSize: 11, marginTop: 4, textAlign: 'right' },
  empty: { alignItems: 'center', justifyContent: 'center', paddingVertical: 90 },
  emptyTitle: { color: theme.textPrimary, fontSize: 17, fontWeight: '700', marginTop: 14 },
  emptyText: { color: theme.textMuted, fontSize: 12, textAlign: 'center', marginTop: 7, maxWidth: 270 },
  statusRow: { flexDirection: 'row', alignItems: 'center', marginTop: 5, gap: 5 },
  statusDot: { width: 7, height: 7, borderRadius: 4 },
  statusText: { fontSize: 9, fontWeight: '700' },
  sep: { color: theme.textMuted, fontSize: 9 },
  overlay: { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, justifyContent: 'center', alignItems: 'center', zIndex: 50 },
  overlayBg: { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, backgroundColor: '#00000099' },
  modal: { width: '88%', borderRadius: 28, padding: 22, backgroundColor: theme.card, borderWidth: 1, borderColor: `${theme.accent}55`, alignItems: 'center' },
  modalIcon: { width: 70, height: 70, borderRadius: 22, alignItems: 'center', justifyContent: 'center', backgroundColor: `${theme.accent}18`, borderWidth: 1, borderColor: `${theme.accent}45`, marginBottom: 12 },
  modalTitle: { color: theme.textPrimary, fontSize: 20, fontWeight: '800' },
  modalBoard: { color: theme.textMuted, fontSize: 12, marginTop: 4, marginBottom: 18 },
  detailRow: { width: '100%', flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: `${theme.border}55` },
  detailLabel: { color: theme.textSecondary, fontSize: 12 },
  detailValue: { fontSize: 12, fontWeight: '800' },
  openBoardBtn: { width: '100%', marginTop: 20, paddingVertical: 13, borderRadius: 15, alignItems: 'center' },
  openBoardText: { color: '#fff', fontSize: 13, fontWeight: '800' },
  closeBtn: { paddingVertical: 12 },
  closeText: { color: theme.textSecondary, fontSize: 12, fontWeight: '700' },
});
