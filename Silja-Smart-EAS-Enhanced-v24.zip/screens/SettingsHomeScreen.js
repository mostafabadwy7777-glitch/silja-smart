import React from 'react';
import { SafeAreaView, ScrollView, View, Text, StyleSheet, StatusBar } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { showAlert } from '../components/PremiumAlert';
import PremiumSwitch from '../components/PremiumSwitch';
import ScreenBackground from '../components/ScreenBackground';
import { FONTS } from '../fonts';
import { useTheme } from '../ThemeContext';
import appJson from '../app.json';

// شاشة الإعدادات الرئيسية (تبويب "الإعدادات" في الشريط السفلي) — قائمة صفوف
// زي أي تطبيق منزل ذكي محترم: كل صف بأيقونته جوه مربع ملوّن، عنوان وسطر
// فرعي، وإما سهم للدخول لصفحة تانية أو سويتش تبديل مباشر.
export default function SettingsHomeScreen({
  connected,
  configured,
  themeName,
  onOpenConnection,
  onOpenTheme,
  onOpenSwitchSettings,
  onOpenBottomNavSettings,
  onOpenHistory,
  onOpenBackup,
  onOpenManualBoard,
  pushEnabled,
  onTogglePush,
  biometricEnabled,
  onToggleBiometric,
}) {
  const { theme, isLight, toggleLightDark } = useTheme();
  const styles = getStyles(theme);
  const version = appJson?.expo?.version || '1.0.0';

  return (
    <SafeAreaView style={styles.container}>
      <ScreenBackground theme={theme} />
      <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} />
      <ScrollView contentContainerStyle={{ paddingBottom: 24 }} showsVerticalScrollIndicator={false}>
        <Text style={styles.pageTitle}>الإعدادات</Text>

        <View style={styles.profileCard}>
          <View style={styles.avatar}>
            <MaterialCommunityIcons name="home-automation" size={26} color="#fff" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.profileName}>Silja Smart</Text>
            <Text style={styles.profileSub}>{configured ? (connected ? 'متصل بالسيرفر' : 'مش متصل حاليًا') : 'لسه محتاج إعداد'}</Text>
          </View>
          <View style={[styles.dot, { backgroundColor: connected ? theme.on : theme.off }]} />
        </View>

        <View style={styles.section}>
          <Row
            icon="server-network"
            title="السيرفر و MQTT"
            subtitle="إعدادات الاتصال بالسيرفر"
            theme={theme}
            styles={styles}
            onPress={onOpenConnection}
          />
          <Row
            icon="pencil-plus-outline"
            title="إضافة بورد يدوي"
            subtitle="للبوردات اللي الفيرموير قديم وميبعتش مفاتيح اكتشاف"
            theme={theme}
            styles={styles}
            onPress={onOpenManualBoard}
          />
          <Row
            icon="palette-outline"
            title="المظهر والثيمات"
            subtitle={themeName}
            theme={theme}
            styles={styles}
            onPress={onOpenTheme}
          />
          <Row
            icon="toggle-switch-outline"
            title="إعدادات المفاتيح"
            subtitle="شكل السويتش، شكل الكارت، الحجم والشفافية"
            theme={theme}
            styles={styles}
            onPress={onOpenSwitchSettings}
          />
          <Row
            icon="dock-bottom"
            title="شريط الأيقونات"
            subtitle="شفافية الشريط وتدريج الألوان الزجاجي"
            theme={theme}
            styles={styles}
            onPress={onOpenBottomNavSettings}
          />
          <Row
            icon="bell-outline"
            title="الإشعارات"
            subtitle="إدارة تنبيهات التطبيق"
            theme={theme}
            styles={styles}
            trailing={
              <PremiumSwitch value={pushEnabled} onValueChange={onTogglePush} theme={theme} />
            }
          />
          <Row
            icon={isLight ? 'weather-sunny' : 'weather-night'}
            title="الوضع الليلي"
            subtitle={isLight ? 'فاتح' : 'داكن'}
            theme={theme}
            styles={styles}
            trailing={
              <PremiumSwitch value={!isLight} onValueChange={toggleLightDark} theme={theme} />
            }
          />
          <Row
            icon="shield-lock-outline"
            title="الأمان"
            subtitle="بصمة الإصبع وكلمة المرور"
            theme={theme}
            styles={styles}
            trailing={
              <PremiumSwitch value={biometricEnabled} onValueChange={onToggleBiometric} theme={theme} />
            }
          />
          <Row
            icon="history"
            title="سجل الأحداث"
            subtitle="آخر الأحداث والتنبيهات"
            theme={theme}
            styles={styles}
            onPress={onOpenHistory}
          />
          <Row
            icon="cloud-upload-outline"
            title="النسخ الاحتياطي والاستعادة"
            subtitle="حفظ واستعادة البيانات"
            theme={theme}
            styles={styles}
            onPress={onOpenBackup}
          />
          <Row
            icon="information-outline"
            title="حول التطبيق"
            subtitle={`الإصدار ${version}`}
            theme={theme}
            styles={styles}
            last
            onPress={() => showAlert('Silja Smart', `الإصدار ${version}`)}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function Row({ icon, title, subtitle, trailing, onPress, theme, styles, last }) {
  const Wrapper = trailing ? View : TouchableOpacity;
  return (
    <Wrapper
      style={[styles.row, last && { borderBottomWidth: 0 }]}
      activeOpacity={0.7}
      onPress={trailing ? undefined : onPress}
    >
      <View style={styles.rowIconBox}>
        <MaterialCommunityIcons name={icon} size={20} color={theme.accentSoft} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.rowTitle}>{title}</Text>
        <Text style={styles.rowSub}>{subtitle}</Text>
      </View>
      {trailing || <MaterialCommunityIcons name="chevron-left" size={18} color={theme.textMuted} />}
    </Wrapper>
  );
}

const getStyles = (theme) =>
  StyleSheet.create({
    container: { flex: 1, backgroundColor: theme.bg, paddingHorizontal: 18, paddingTop: 14 },
    pageTitle: { fontSize: 24, fontWeight: '700', fontFamily: FONTS.display, color: theme.textPrimary, marginBottom: 14, textAlign: 'right' },
    profileCard: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: theme.card,
      borderRadius: 18,
      padding: 16,
      gap: 12,
      marginBottom: 18,
      borderWidth: 1,
      borderColor: theme.border,
    },
    avatar: {
      width: 52,
      height: 52,
      borderRadius: 26,
      backgroundColor: theme.accent,
      alignItems: 'center',
      justifyContent: 'center',
    },
    profileName: { fontSize: 16, fontWeight: '700', color: theme.textPrimary, textAlign: 'right' },
    profileSub: { fontSize: 12, color: theme.textSecondary, marginTop: 2, textAlign: 'right' },
    dot: { width: 10, height: 10, borderRadius: 5 },
    section: {
      backgroundColor: theme.card,
      borderRadius: 18,
      borderWidth: 1,
      borderColor: theme.border,
      overflow: 'hidden',
    },
    row: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      paddingHorizontal: 14,
      paddingVertical: 14,
      borderBottomWidth: 1,
      borderBottomColor: theme.border,
    },
    rowIconBox: {
      width: 36,
      height: 36,
      borderRadius: 10,
      backgroundColor: theme.cardAlt,
      alignItems: 'center',
      justifyContent: 'center',
    },
    rowTitle: { fontSize: 14.5, fontWeight: '700', color: theme.textPrimary, textAlign: 'right' },
    rowSub: { fontSize: 11.5, color: theme.textSecondary, marginTop: 2, textAlign: 'right' },
  });
