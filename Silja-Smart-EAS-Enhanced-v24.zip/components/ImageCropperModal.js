import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Modal, View, Text, StyleSheet, Image, PanResponder, Dimensions } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as ImageManipulator from 'expo-image-manipulator';
import { useTheme } from '../ThemeContext';

// ============================================================================
// كنترول تحديد/تكبير/تحريك الصورة — بديل موحّد لكروب نظام التشغيل
// ============================================================================
// بدل ما نسيب المستخدم يعتمد على شاشة القص بتاعة الموبايل نفسه (اللي بتفرق
// شكلها من جهاز لجهاز وأحيانًا مش بتديله دليل دائري أصلاً)، الكنترول ده بيديه
// تحكم كامل جوه التطبيق: يكبّر/يصغّر بإصبعين (pinch)، يسحب الصورة يمين/شمال/
// فوق/تحت، وشايف طول الوقت الدليل الدائري اللي هيبين بيه شكل الصورة النهائي
// (لأن الصورة بتتعرض في التطبيق جوه إطار دائري). لما يضغط "تم" بنحسب بالظبط
// المستطيل اللي شايفه على الشاشة ونقصّه من الصورة الأصلية بأعلى جودة ممكنة.
// ============================================================================

const { width: SCREEN_W } = Dimensions.get('window');
const VIEW_SIZE = Math.min(300, SCREEN_W - 80);
const MIN_ZOOM = 1;
const MAX_ZOOM = 4;

export default function ImageCropperModal({ visible, imageUri, imageWidth, imageHeight, onCancel, onConfirm }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);

  const [imgSize, setImgSize] = useState(null); // { w, h } للصورة الأصلية
  const [zoom, setZoom] = useState(1);
  const [translate, setTranslate] = useState({ x: 0, y: 0 });
  const [busy, setBusy] = useState(false);
  const [rotation, setRotation] = useState(0);
  const rotationRef = useRef(0);

  // مراجع حية (بتتحدث فورًا، من غير ما تستنى إعادة رسم) عشان نستخدمها جوه
  // PanResponder وحساب القص النهائي بدقة.
  const zoomRef = useRef(1);
  const translateRef = useRef({ x: 0, y: 0 });
  const gestureStartRef = useRef({ translate: { x: 0, y: 0 }, zoom: 1, pinchDist: 0 });

  useEffect(() => {
    if (!visible) return;
    setZoom(1);
    setTranslate({ x: 0, y: 0 });
    setRotation(0);
    rotationRef.current = 0;
    zoomRef.current = 1;
    translateRef.current = { x: 0, y: 0 };
    if (imageWidth && imageHeight) {
      setImgSize({ w: imageWidth, h: imageHeight });
    } else if (imageUri) {
      Image.getSize(
        imageUri,
        (w, h) => setImgSize({ w, h }),
        () => setImgSize({ w: 1, h: 1 })
      );
    }
  }, [visible, imageUri, imageWidth, imageHeight]);

  const visualSize = useMemo(() => {
    if (!imgSize) return { w: 1, h: 1 };
    const r = ((rotation % 360) + 360) % 360;
    return (r === 90 || r === 270)
      ? { w: imgSize.h, h: imgSize.w }
      : { w: imgSize.w, h: imgSize.h };
  }, [imgSize, rotation]);

  const coverScale = useMemo(() => {
    if (!visualSize) return 1;
    return VIEW_SIZE / Math.min(visualSize.w, visualSize.h);
  }, [visualSize]);

  const clampTranslate = (t, z) => {
    if (!imgSize) return { x: 0, y: 0 };
    const totalScale = coverScale * z;
    const dispW = visualSize.w * totalScale;
    const dispH = visualSize.h * totalScale;
    const maxX = Math.max(0, (dispW - VIEW_SIZE) / 2);
    const maxY = Math.max(0, (dispH - VIEW_SIZE) / 2);
    return {
      x: Math.min(maxX, Math.max(-maxX, t.x)),
      y: Math.min(maxY, Math.max(-maxY, t.y)),
    };
  };

  const touchDistance = (touches) => {
    const [a, b] = touches;
    return Math.hypot(a.pageX - b.pageX, a.pageY - b.pageY);
  };

  const panResponder = useMemo(
    () =>
      PanResponder.create({
        onStartShouldSetPanResponder: () => true,
        onMoveShouldSetPanResponder: () => true,
        onPanResponderGrant: (evt) => {
          gestureStartRef.current.translate = { ...translateRef.current };
          gestureStartRef.current.zoom = zoomRef.current;
          if (evt.nativeEvent.touches.length === 2) {
            gestureStartRef.current.pinchDist = touchDistance(evt.nativeEvent.touches);
          }
        },
        onPanResponderMove: (evt, gestureState) => {
          const touches = evt.nativeEvent.touches;
          if (touches.length === 2) {
            // تكبير بإصبعين
            if (!gestureStartRef.current.pinchDist) {
              gestureStartRef.current.pinchDist = touchDistance(touches);
              return;
            }
            const dist = touchDistance(touches);
            const ratio = dist / gestureStartRef.current.pinchDist;
            const nextZoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, gestureStartRef.current.zoom * ratio));
            zoomRef.current = nextZoom;
            setZoom(nextZoom);
            const clamped = clampTranslate(translateRef.current, nextZoom);
            translateRef.current = clamped;
            setTranslate(clamped);
          } else {
            // سحب بإصبع واحد
            const next = {
              x: gestureStartRef.current.translate.x + gestureState.dx,
              y: gestureStartRef.current.translate.y + gestureState.dy,
            };
            const clamped = clampTranslate(next, zoomRef.current);
            translateRef.current = clamped;
            setTranslate(clamped);
          }
        },
        onPanResponderRelease: () => {
          gestureStartRef.current.pinchDist = 0;
        },
      }),
    [imgSize, coverScale]
  );

  const applyZoomStep = (delta) => {
    const nextZoom = Math.min(MAX_ZOOM, Math.max(MIN_ZOOM, zoomRef.current + delta));
    zoomRef.current = nextZoom;
    setZoom(nextZoom);
    const clamped = clampTranslate(translateRef.current, nextZoom);
    translateRef.current = clamped;
    setTranslate(clamped);
  };

  const resetView = () => {
    zoomRef.current = 1;
    translateRef.current = { x: 0, y: 0 };
    setZoom(1);
    setTranslate({ x: 0, y: 0 });
    rotationRef.current = 0;
    setRotation(0);
  };

  const rotateBy = (delta) => {
    const next = (((rotationRef.current + delta) % 360) + 360) % 360;
    rotationRef.current = next;
    setRotation(next);
    const clamped = clampTranslate(translateRef.current, zoomRef.current);
    translateRef.current = clamped;
    setTranslate(clamped);
  };

  const handleConfirm = async () => {
    if (!imgSize) return;
    setBusy(true);
    try {
      const r = ((rotationRef.current % 360) + 360) % 360;
      // التدوير 90/180/270 درجة يتم أولًا، ثم نحسب القص على أبعاد الصورة الجديدة
      // حتى يطابق الناتج تمامًا ما يراه المستخدم في المعاينة.
      const rotatedSize = (r === 90 || r === 270)
        ? { w: imgSize.h, h: imgSize.w }
        : { w: imgSize.w, h: imgSize.h };
      const totalScale = coverScale * zoom;
      const centerX = rotatedSize.w / 2 - translate.x / totalScale;
      const centerY = rotatedSize.h / 2 - translate.y / totalScale;
      const cropSize = Math.min(VIEW_SIZE / totalScale, rotatedSize.w, rotatedSize.h);
      const originX = Math.min(Math.max(centerX - cropSize / 2, 0), Math.max(0, rotatedSize.w - cropSize));
      const originY = Math.min(Math.max(centerY - cropSize / 2, 0), Math.max(0, rotatedSize.h - cropSize));

      const actions = [];
      if (r) actions.push({ rotate: r });
      actions.push({ crop: { originX, originY, width: cropSize, height: cropSize } });
      actions.push({ resize: { width: 800, height: 800 } });

      const result = await ImageManipulator.manipulateAsync(
        imageUri,
        actions,
        { compress: 0.9, format: ImageManipulator.SaveFormat.PNG }
      );
      onConfirm(result.uri);
    } catch (e) {
      onConfirm(null, e);
    } finally {
      setBusy(false);
    }
  };

  if (!visible) return null;

  const totalScale = coverScale * zoom;
  const dispW = imgSize ? visualSize.w * totalScale : VIEW_SIZE;
  const dispH = imgSize ? visualSize.h * totalScale : VIEW_SIZE;

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onCancel}>
      <View style={styles.overlay}>
        <View style={styles.box}>
          <Text style={styles.title}>اضبط الصورة</Text>
          <Text style={styles.subtitle}>كبّر وصغّر واسحب الصورة، ودوّرها 90° يمين أو شمال لحد ما الشكل يبقى مضبوط</Text>

          <View style={styles.viewportWrap} {...panResponder.panHandlers}>
            <View style={styles.viewport}>
              {imgSize && (
                <Image
                  source={{ uri: imageUri }}
                  style={{
                    position: 'absolute',
                    width: dispW,
                    height: dispH,
                    left: VIEW_SIZE / 2 - dispW / 2 + translate.x,
                    top: VIEW_SIZE / 2 - dispH / 2 + translate.y,
                    transform: [{ rotate: `${rotation}deg` }],
                  }}
                />
              )}
            </View>
            {/* دليل دائري بس (بدون تعتيم) بيوريك شكل الصورة لما تتعرض جوه الأفاتار الدائري */}
            <View pointerEvents="none" style={styles.circleGuide} />
          </View>

          <View style={styles.zoomRow}>
            <TouchableOpacity style={styles.zoomBtn} onPress={() => applyZoomStep(-0.3)} disabled={busy}>
              <MaterialCommunityIcons name="magnify-minus-outline" size={18} color={theme.textPrimary} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.zoomBtn} onPress={resetView} disabled={busy}>
              <MaterialCommunityIcons name="restore" size={16} color={theme.textPrimary} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.zoomBtn} onPress={() => applyZoomStep(0.3)} disabled={busy}>
              <MaterialCommunityIcons name="magnify-plus-outline" size={18} color={theme.textPrimary} />
            </TouchableOpacity>
          </View>

          <View style={styles.rotateRow}>
            <TouchableOpacity style={styles.rotateBtn} onPress={() => rotateBy(-90)} disabled={busy}>
              <MaterialCommunityIcons name="rotate-left" size={19} color={theme.textPrimary} />
              <Text style={styles.rotateText}>تدوير يسار</Text>
            </TouchableOpacity>
            <Text style={styles.rotationValue}>{rotation}°</Text>
            <TouchableOpacity style={styles.rotateBtn} onPress={() => rotateBy(90)} disabled={busy}>
              <Text style={styles.rotateText}>تدوير يمين</Text>
              <MaterialCommunityIcons name="rotate-right" size={19} color={theme.textPrimary} />
            </TouchableOpacity>
          </View>

          <View style={styles.actionsRow}>
            <TouchableOpacity style={styles.cancelBtn} onPress={onCancel} disabled={busy}>
              <Text style={styles.cancelBtnText}>إلغاء</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.confirmBtn} onPress={handleConfirm} disabled={busy || !imgSize}>
              <Text style={styles.confirmBtnText}>{busy ? 'جاري القص...' : 'تم'}</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </Modal>
  );
}

function getStyles(theme) {
  return StyleSheet.create({
    overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.75)', justifyContent: 'center', alignItems: 'center' },
    box: {
      width: '90%',
      backgroundColor: theme.card,
      borderRadius: 18,
      borderWidth: 1,
      borderColor: theme.border,
      padding: 16,
      alignItems: 'center',
    },
    title: { color: theme.textPrimary, fontSize: 15, fontWeight: '700', marginBottom: 4 },
    subtitle: { color: theme.textMuted, fontSize: 11.5, marginBottom: 14, textAlign: 'center' },
    viewportWrap: {
      width: VIEW_SIZE,
      height: VIEW_SIZE,
      alignItems: 'center',
      justifyContent: 'center',
    },
    viewport: {
      width: VIEW_SIZE,
      height: VIEW_SIZE,
      overflow: 'hidden',
      backgroundColor: '#000',
      borderRadius: 12,
    },
    circleGuide: {
      position: 'absolute',
      width: VIEW_SIZE,
      height: VIEW_SIZE,
      borderRadius: VIEW_SIZE / 2,
      borderWidth: 2,
      borderColor: 'rgba(255,255,255,0.85)',
    },
    zoomRow: { flexDirection: 'row', gap: 10, marginTop: 16 },
    zoomBtn: {
      width: 40,
      height: 40,
      borderRadius: 20,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: theme.cardAlt,
      borderWidth: 1,
      borderColor: theme.border,
    },
    rotateRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 10, width: '100%' },
    rotateBtn: { minWidth: 104, height: 38, paddingHorizontal: 10, borderRadius: 19, alignItems: 'center', justifyContent: 'center', flexDirection: 'row', gap: 5, backgroundColor: theme.cardAlt, borderWidth: 1, borderColor: theme.border },
    rotateText: { color: theme.textPrimary, fontSize: 11, fontWeight: '700' },
    rotationValue: { minWidth: 42, textAlign: 'center', color: theme.textMuted, fontSize: 11, fontWeight: '700' },
    actionsRow: { flexDirection: 'row', gap: 10, marginTop: 18, width: '100%' },
    cancelBtn: {
      flex: 1,
      paddingVertical: 12,
      borderRadius: 12,
      alignItems: 'center',
      backgroundColor: theme.cardAlt,
      borderWidth: 1,
      borderColor: theme.border,
    },
    cancelBtnText: { color: theme.textSecondary, fontWeight: '700', fontSize: 13 },
    confirmBtn: { flex: 1, paddingVertical: 12, borderRadius: 12, alignItems: 'center', backgroundColor: theme.accent },
    confirmBtnText: { color: '#fff', fontWeight: '700', fontSize: 13 },
  });
}
