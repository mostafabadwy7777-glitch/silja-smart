// أدوات ألوان صغيرة مشتركة — بتخلّي النصوص/الأيقونات فوق أي لون (أزرار، شريط، سويتش)
// مقروءة في كل الثيمات بدل ما نثبّت لون أسود أو أبيض.
export function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
  if (!m) return null;
  const n = parseInt(m[1], 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

export function withAlpha(hex, a) {
  const c = hexToRgb(hex);
  return c ? `rgba(${c.r},${c.g},${c.b},${Math.max(0, Math.min(1, a))})` : hex;
}

// لون النص/الأيقونة المناسب فوق خلفية بلون معيّن (غامق فوق الفاتح، وأبيض فوق الغامق)
export function readableOn(hex) {
  const c = hexToRgb(hex);
  if (!c) return '#FFFFFF';
  const lum = (0.299 * c.r + 0.587 * c.g + 0.114 * c.b) / 255;
  return lum > 0.6 ? '#10161C' : '#FFFFFF';
}
