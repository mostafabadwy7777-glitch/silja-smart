import React, { useEffect, useRef } from 'react';
import { Animated, Easing, TouchableWithoutFeedback, View, Text, StyleSheet } from 'react-native';
import { readableOn } from '../colorUtils';

// سويتش بثلاثة أشكال مختلفة فعلًا (مش نفس الشكل بأحجام مختلفة):
//  - round  "دائري":  مسار مصمت بلون التشغيل وإبهام دائري أبيض (ستايل iOS الهادي).
//  - square "مربع":   مسار بإطار فقط وإبهام مربع ملوّن (شكل مفتاح صناعي/Outline).
//  - text   "ON/OFF": مسار أعرض فيه كلمة الحالة مكتوبة جواه وإبهام دائري.
const HEIGHT = 32;
const WIDTHS = { round: 58, square: 58, text: 76 };

export default function PremiumSwitch({
  value,
  onValueChange,
  theme,
  activeColor,
  disabled = false,
  size = 1,
  shape = 'round',
}) {
  const anim = useRef(new Animated.Value(value ? 1 : 0)).current;
  const onTint = activeColor || theme?.accent || '#2DE0A8';
  const isLight = !!theme?.isLight;
  const offTint = isLight ? '#D9DDE3' : '#2A3340';
  const offBorder = isLight ? '#AEB5BF' : '#4B5868';
  const offLabel = isLight ? '#5B6573' : '#9AA7B6';
  const onLabel = readableOn(onTint);

  useEffect(() => {
    Animated.timing(anim, { toValue: value ? 1 : 0, duration: 260, easing: Easing.out(Easing.back(1.3)), useNativeDriver: false }).start();
  }, [value, anim]);

  const kind = WIDTHS[shape] ? shape : 'round';
  const w = WIDTHS[kind] * size;
  const h = HEIGHT * size;
  const pad = 3 * size;

  const trackBg = anim.interpolate({ inputRange: [0, 1], outputRange: [offTint, onTint], extrapolate: 'clamp' });
  const outlineColor = anim.interpolate({ inputRange: [0, 1], outputRange: [offBorder, onTint], extrapolate: 'clamp' });
  const glow = anim.interpolate({ inputRange: [0, 1], outputRange: [0, 0.45], extrapolate: 'clamp' });

  let body;
  if (kind === 'square') {
    const thumb = h - 12 * size;
    const travel = w - thumb - 12 * size;
    body = (
      <Animated.View style={[styles.track, { width: w, height: h, borderRadius: 8 * size, borderWidth: 2 * size, borderColor: outlineColor, backgroundColor: 'transparent' }]}>
        <Animated.View
          style={{
            position: 'absolute', top: 4 * size, left: 4 * size, width: thumb, height: thumb, borderRadius: 4 * size,
            backgroundColor: outlineColor,
            transform: [{ translateX: anim.interpolate({ inputRange: [0, 1], outputRange: [0, travel] }) }],
          }}
        />
      </Animated.View>
    );
  } else {
    const thumb = h - pad * 2;
    const travel = w - thumb - pad * 2;
    body = (
      <Animated.View style={[styles.track, { width: w, height: h, borderRadius: h / 2, backgroundColor: trackBg, shadowColor: onTint, shadowOpacity: glow, shadowRadius: 8 * size, shadowOffset: { width: 0, height: 0 }, elevation: value ? 4 : 0 }]}>
        {kind === 'text' && (
          <Text
            style={[styles.label, { color: value ? onLabel : offLabel, fontSize: Math.max(9, 11 * size), [value ? 'left' : 'right']: 10 * size }]}
          >
            {value ? 'ON' : 'OFF'}
          </Text>
        )}
        <Animated.View
          style={{
            position: 'absolute', top: pad, left: pad, width: thumb, height: thumb, borderRadius: thumb / 2,
            backgroundColor: '#FFFFFF', shadowColor: '#000', shadowOpacity: 0.25, shadowRadius: 3, shadowOffset: { width: 0, height: 1 }, elevation: 3,
            transform: [{ translateX: anim.interpolate({ inputRange: [0, 1], outputRange: [0, travel] }) }],
          }}
        />
      </Animated.View>
    );
  }

  return (
    <TouchableWithoutFeedback onPress={() => !disabled && onValueChange && onValueChange(!value)} disabled={disabled}>
      <View style={[styles.hitBox, { width: w, height: h + 6, opacity: disabled ? 0.45 : 1, direction: 'ltr' }]}>{body}</View>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  hitBox: { alignItems: 'center', justifyContent: 'center', overflow: 'visible' },
  track: { justifyContent: 'center', direction: 'ltr' },
  label: { position: 'absolute', fontWeight: '800', top: '50%', marginTop: -7, lineHeight: 14 },
});
