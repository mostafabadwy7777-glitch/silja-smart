import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  TextInput,
  StyleSheet,
  Modal,
  FlatList,
  Animated,
  Easing,
  ActivityIndicator,
  BackHandler,
  Image,
} from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { showAlert } from '../components/PremiumAlert';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import { DEVICE_ICONS, getDeviceIcon, getDeviceIconImage } from '../deviceIcons';
import { COLOR_SWATCHES } from '../theme';
import { useTheme } from '../ThemeContext';
import { newId, loadSwitchCardStyle, loadSwitchShape, loadSwitchCardSize, loadSwitchCardOpacity } from '../storage';
import { parseBoardDiscovery, boardAvailabilityTopic, parseAvailability } from '../discovery';
import { notifyLocal } from '../notifications';
import ScreenBackground from '../components/ScreenBackground';
import PremiumSwitch from '../components/PremiumSwitch';
import ImageCropperModal from '../components/ImageCropperModal';
import { FONTS } from '../fonts';
import ConnectionStatusBanner from '../components/ConnectionStatusBanner';
import ScreenHeader from '../components/ScreenHeader';
import { readableOn } from '../colorUtils';
import { LinearGradient } from 'expo-linear-gradient';
import DeviceGlyph from '../components/DeviceGlyph';

// لون الإضاءة "الحقيقي" لما لمبة/نجفة/فانوس/سبوت... يبقى شغال —
// نفس دفء لون اللمبة الأصفر بدل لون الثيم العام.
const LIGHT_WARM_ON = '#F4C86A';
// لون التحذير الأحمر الثابت لزرار الطوارئ لما يبقى نشط — بغض النظر عن
// لون الثيم، عشان يفضل واضح إنه حالة خطر مش مجرد "تشغيل" عادي.
const EMERGENCY_ON = '#FF3B30';

// بيتحفظ الجزء الدائم من صور المفتاح المخصوصة (اللي المستخدم اختارها من
// المعرض/الكاميرا) على الموبايل نفسه (مش على الكاش اللي بيتمسح)، عشان تفضل
// موجودة حتى لو التطبيق قفل وفتح تاني أو الموبايل عمل ريستارت. نفس فكرة
// صورة البورد في EditBoardModal.js بس هنا لكل مفتاح لوحده، وبصورتين
// منفصلتين (شغال / مطفي) عشان الصورة نفسها تبين حالة المفتاح.
const DEVICE_IMAGES_DIR = FileSystem.documentDirectory + 'device-images/';

async function persistPickedDeviceImage(sourceUri, deviceId, state) {
  await FileSystem.makeDirectoryAsync(DEVICE_IMAGES_DIR, { intermediates: true }).catch(() => {});

  // كل صورة جديدة لازم تاخد اسم ملف فريد. قبل كده كان اسم الملف ثابتًا
  // (deviceId-state.jpg)، وده ممكن يخلي Image cache يعرض الصورة القديمة
  // بعد تغييرها، خصوصًا مع صور القص التي ينتجها ImageManipulator.
  // نحفظ PNG كما هو، ونغيّر الاسم كل مرة لمنع أي cache collision.
  const token = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const destUri = `${DEVICE_IMAGES_DIR}${deviceId}-${state}-${token}.png`;

  await FileSystem.copyAsync({ from: sourceUri, to: destUri });
  return destUri;
}

// شكل المفتاح المعروض حسب حالته الحالية: لو المستخدم حاطط صورة مخصوصة
// لحالة "شغال" (customImageOn) ولحالة "مطفي" (customImageOff) نعرض الصورة
// المناسبة للحالة الحالية بدل أيقونة المكتبة. لو صورة حالة واحدة بس متحطة
// (مش الاتنين)، بتترجع هي في الحالتين لحد ما يحط التانية. غير كده بترجع
// أيقونة المكتبة العادية زي ما هي.
// isOn = undefined معناها "مفيش حالة تشغيل معروفة دلوقتي" (زي شاشة اختيار
// الأيقونة نفسها) فبنفضّل صورة الـ OFF كصورة تمثيلية افتراضية.
function deviceImageSource(device, isOn) {
  if (!device) return getDeviceIconImage(undefined);
  const on = device.customImageOn;
  const off = device.customImageOff || device.customImage; // customImage = التوافق مع نسخة قديمة كانت بتحفظ صورة واحدة بس
  if (isOn && on) return { uri: on };
  if (!isOn && off) return { uri: off };
  // مفيش صورة للحالة الحالية بالتحديد؛ استخدم أي صورة مخصوصة موجودة كبديل
  // أفضل من الرجوع للأيقونة الجاهزة على طول.
  if (on) return { uri: on };
  if (off) return { uri: off };
  // الأيقونات الجاهزة أصبحت أيقونات فيكتور عادية.
  // صور ON/OFF المدمجة القديمة لا تُستخدم هنا؛ حالة المفتاح يوضحها لون
  // الأيقونة والتوهج، بينما الصورة لا تُستخدم إلا إذا اختار المستخدم صورة من المعرض/الكاميرا.
  return getDeviceIconImage(device.icon);
}

function getBuiltInStateImage(iconId, isOn) {
  // متروك للتوافق فقط؛ المكتبة الآن تعرض أيقونات عادية فقط.
  return null;
}

// هل المستخدم رفع صورة حقيقية لنفس المفتاح (من الكاميرا/المعرض)؟ لو لأ،
// بنعرض أيقونة فيكتور من المكتبة بدل الصور الجاهزة المقصوصة.
function hasCustomPhoto(device) {
  return !!(device && (device.customImageOn || device.customImageOff || device.customImage));
}

// بورد قديم كان بيستخدم شكل ثابت (relay1..relayN تحت prefix معيّن).
// الدالة دي بتحوّله لقايمة "أجهزة" عادية عشان يفضل شغال زي ما هو من غير ما يتمسح.
function deriveInitialDevices(board) {
  if (board.devices) return board.devices;
  if (board.prefix && board.relayCount) {
    const relayNames =
      board.relayNames && board.relayNames.length === board.relayCount
        ? board.relayNames
        : Array.from({ length: board.relayCount }, (_, i) => `المفتاح ${i + 1}`);
    return relayNames.map((name, i) => ({
      id: newId(),
      name,
      icon: (board.relayIcons && board.relayIcons[i]) || 'switch',
      controlType: 'toggle',
      controlTopic: `${board.prefix}/control/relay${i + 1}`,
      statusTopic: `${board.prefix}/status/relay${i + 1}`,
    }));
  }
  return [];
}

const SYNC_TIMEOUT_MS = 10000;

// تحقق من صيغة الوقت "HH:MM" بنظام 24 ساعة
function isValidHHMM(str) {
  return /^([01]\d|2[0-3]):([0-5]\d)$/.test(str);
}

export default function SwitchesScreen({ board, client, connected, pairingKey, onBack, onUpdateBoard }) {
  const { theme } = useTheme();
  const [devices, setDevices] = useState(() => deriveInitialDevices(board));
  const [deviceState, setDeviceState] = useState({}); // { [deviceId]: boolean } — لمفاتيح التشغيل/الإيقاف
  const [boardAvailable, setBoardAvailable] = useState(null); // 'online' | 'offline' | null = مش معروفة
  const [deviceRawStatus, setDeviceRawStatus] = useState({}); // { [deviceId]: string } — لأجهزة الطلوع/النزول
  const commandCooldownRef = useRef({});

  // شكل كروت المفاتيح المختار من شاشة الثيمات (كلاسيك / نيون متدرج / فخم Glass)
  const [cardStyle, setCardStyle] = useState('tile');
  const [filter, setFilter] = useState('all'); // all | light | fan | other
  const [switchShape, setSwitchShape] = useState('round');
  const [cardSize, setCardSize] = useState('medium');
  const [cardOpacity, setCardOpacity] = useState(0.82);
  useEffect(() => {
    loadSwitchCardStyle().then(setCardStyle);
    loadSwitchShape().then(setSwitchShape);
    loadSwitchCardSize().then(setCardSize);
    loadSwitchCardOpacity().then(setCardOpacity);
  }, []);

  // مؤشر بصري لحظي لزرار الاختبار (لحد ما يوصل رد OFF من الفيرموير) —
  // مش حالة حقيقية محفوظة، بس عشان يحس المستخدم إن الضغطة اتسجلت فورًا.
  const [testSending, setTestSending] = useState(false);

  const [formVisible, setFormVisible] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [fName, setFName] = useState('');
  const [fIcon, setFIcon] = useState('switch');
  const [fOnColor, setFOnColor] = useState(null); // null = لون الثيم الافتراضي
  const [fOffColor, setFOffColor] = useState(null);

  // صفحة "تعديل شكل المفاتيح" — نافذة واحدة منفصلة بتوريك كل المفاتيح مع
  // شكلها الحالي، وتقدر تغيّر شكل أي مفتاح على طول من غير ما تدخل على كارت
  // المفتاح نفسه وتفتح فورم التعديل الكامل (اللي فيه اسم وألوان وتوبيكات
  // كمان) — ده كان بيسبب لخبطة لو كل اللي عايزه بس تغيير الشكل.
  const [iconSettingsVisible, setIconSettingsVisible] = useState(false);
  const [iconEditDeviceId, setIconEditDeviceId] = useState(null);
  const [deviceImageBusy, setDeviceImageBusy] = useState(false);
  const [deviceCropSource, setDeviceCropSource] = useState(null); // { uri, width, height, id, state }

  // تايمر لكل مفتاح: التايمر شغال جوه الفيرموير نفسه (مش من التطبيق)، عشان
  // يفضل شغال حتى لو التطبيق مقفول. التطبيق بس بيبعت أمر الإعداد للفيرموير
  // على `<control_topic>/timer/set`، وبيسمع حالة التايمر الحالية من
  // الفيرموير على `<control_topic>/timer/state` (شوف بروتوكول التايمر في
  // README.md) وبيعرضها زي ما هي.
  const [timerModalVisible, setTimerModalVisible] = useState(false);
  const [timerDeviceId, setTimerDeviceId] = useState(null);
  const [timerTab, setTimerTab] = useState('countdown'); // 'countdown' | 'schedule'
  const [countdownInput, setCountdownInput] = useState('30');
  const [scheduleOnInput, setScheduleOnInput] = useState('07:00');
  const [scheduleOffInput, setScheduleOffInput] = useState('22:00');
  const [scheduleEnabledInput, setScheduleEnabledInput] = useState(false);
  const [, forceTick] = useState(0); // بيتحدث كل ثانية عشان يحدّث عرض الوقت المتبقي بين رسايل الفيرموير
  // { [deviceId]: { mode: 'off'|'countdown'|'schedule', secondsLeft, receivedAt, scheduleEnabled, on, off } }
  const [deviceTimerState, setDeviceTimerState] = useState({});

  // مزامنة من الفيرموير: بيعيد الاستماع على نفس توبيك الاكتشاف بتاع البورد
  // (لازم يكون موقّع بنفس مفتاح الربط) ويضيف/يحدّث المفاتيح منه. مفيش أي
  // إضافة يدوية للتوبيكات — كل حاجة جاية من الفيرموير بتاعك فقط.
  const [syncing, setSyncing] = useState(false);
  const [syncError, setSyncError] = useState('');
  const syncTimeoutRef = useRef(null);
  const syncHandlerRef = useRef(null);

  const discoveryTopic = board.discoveryTopic || (board.prefix ? `${board.prefix}/discovery` : null);

  // زرار الموبايل الفيزيقي للرجوع — لو فيه مودال مفتوح (فورم إضافة/تعديل
  // مفتاح، أو مودال التايمر، أو صفحة تعديل الشكل)، بنسكّره الأول بدل ما نرجع لشاشة البوردات على طول.
  useEffect(() => {
    const onBackPress = () => {
      if (timerModalVisible) {
        setTimerModalVisible(false);
        return true;
      }
      if (formVisible) {
        setFormVisible(false);
        return true;
      }
      if (iconEditDeviceId) {
        setIconEditDeviceId(null);
        return true;
      }
      if (iconSettingsVisible) {
        setIconSettingsVisible(false);
        return true;
      }
      return false;
    };
    const sub = BackHandler.addEventListener('hardwareBackPress', onBackPress);
    return () => sub.remove();
  }, [timerModalVisible, formVisible, iconEditDeviceId, iconSettingsVisible]);

  const persistDevices = (list) => {
    // حدّث المرجع فورًا قبل أي إعادة رسم حتى لا يقرأ أي handler القيمة القديمة.
    devicesRef.current = list;
    setDevices(list);
    // تحديث البورد الأب فورًا حتى لا يرجع الاختيار القديم عند إغلاق الصفحة.
    onUpdateBoard?.({ ...board, devices: list });
  };

  // أول مرة نفتح بورد قديم اتحوّل لأجهزة، نحفظه بالشكل الجديد على طول
  useEffect(() => {
    if (!board.devices) {
      onUpdateBoard?.({ ...board, devices, relayNames: undefined, relayIcons: undefined, relayCount: undefined });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // نسخة دايمًا محدّثة من devices تُقرأ جوه الـ handlers، عشان الاشتراكات
  // في المقبس (subscribe/unsubscribe) متتربطش بأي تغيير في الأجهزة (زي تغيير
  // شكل مفتاح) وترتبط بس بتغيّر التوبيكات الفعلي. لو سبناها معتمدة على
  // devices نفسه، أي تعديل شكل (icon) كان بيعمل unsubscribe/resubscribe
  // لكل مفاتيح الحالة مرة واحدة، وده كان بيسبب فوات أو تلخبط في الرسايل
  // الواصلة لحظة التغيير — وده اللي كان بيبان إنه "كل الحالات بتتغير".
  const devicesRef = useRef(devices);
  useEffect(() => {
    devicesRef.current = devices;
  }, [devices]);

  const statusTopics = useMemo(() => {
    const set = new Set();
    devices.forEach((d) => set.add(d.statusTopic || d.controlTopic));
    return Array.from(set);
  }, [devices]);

  // توبيكات حالة التايمر: `<control_topic>/timer/state` — الفيرموير هو اللي بينشرها (Retained يفضل).
  // مفيش تايمر لأجهزة الطلوع/النزول (updown).
  const timerStateTopics = useMemo(() => {
    const set = new Set();
    devices.forEach((d) => d.controlType !== 'updown' && set.add(`${d.controlTopic}/timer/state`));
    return Array.from(set);
  }, [devices]);

  // مفتاح نصي ثابت من التوبيكات الفعلية بس (مش من كائن devices كله)، عشان
  // نستخدمه كـ dependency للـ effects بتاعة الاشتراك بدل الاعتماد على
  // statusTopics/timerStateTopics كمصفوفات — دول بيتعملهم إنشاء مصفوفة
  // جديدة (reference) في كل مرة devices يتغيّر فيها أي حاجة (زي تغيير شكل
  // مفتاح)، حتى لو التوبيكات نفسها متغيّرتش، وده كان بيخلي الـ effect يعمل
  // unsubscribe/resubscribe لكل المفاتيح من غير داعي.
  const statusTopicsKey = statusTopics.join('|');
  const timerStateTopicsKey = timerStateTopics.join('|');

  // حالة "توفر" البورد ده لوحده (مش الاتصال العام بالسيرفر) — بتتقرأ من
  // `<device_id>/availability` اللي الفيرموير بينشرها Retained + كـ Last Will.
  useEffect(() => {
    const topic = boardAvailabilityTopic(board);
    if (!client || !connected || !topic) {
      setBoardAvailable(null);
      return undefined;
    }

    client.subscribe(topic);
    const handler = (t, payload) => {
      if (t !== topic) return;
      const state = parseAvailability(payload.toString());
      if (state) setBoardAvailable(state);
    };
    client.on('message', handler);

    return () => {
      client.off('message', handler);
      client.unsubscribe(topic);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client, connected, board.deviceId]);

  useEffect(() => {
    if (!client || statusTopics.length === 0) return undefined;

    statusTopics.forEach((t) => client.subscribe(t));

    const handler = (topic, payload) => {
      const raw = payload.toString().trim();
      const msg = raw.toUpperCase();
      const devicesNow = devicesRef.current;

      // مهم جدًا: بعض نسخ الـFirmware القديمة كانت تستخدم status topic واحد
      // لأكثر من ريليه. لو لفّينا على كل الأجهزة هنا، رسالة ON واحدة كانت
      // تغيّر كل المفاتيح معًا. لا نوزّع الحالة على أكثر من جهاز إلا لو قدرنا
      // تحديد الريليه بوضوح من التوبيك أو من JSON الرسالة.
      let targets = devicesNow.filter((d) => (d.statusTopic || d.controlTopic) === topic);

      // لو الـstatus topic مشترك، حاول تحديد الريليه من آخر رقم في التوبيك
      // (مثل relay1 / relay2)، أو من JSON مثل {relay: 2, state: "ON"}.
      if (targets.length > 1) {
        const relayMatch = topic.match(/(?:relay|switch)[_\/-]?(\d+)$/i);
        let relayNo = relayMatch ? Number(relayMatch[1]) : null;
        let jsonState = null;
        try {
          const data = JSON.parse(raw);
          if (relayNo == null && Number.isFinite(Number(data.relay ?? data.relay_index ?? data.switch))) {
            relayNo = Number(data.relay ?? data.relay_index ?? data.switch);
          }
          jsonState = data.state ?? data.status ?? data.value ?? data.on;
        } catch (_) {}

        if (relayNo != null) {
          const suffix = `relay${relayNo}`;
          targets = devicesNow.filter((d) =>
            String(d.controlTopic || '').toLowerCase().endsWith(suffix.toLowerCase()) ||
            String(d.statusTopic || '').toLowerCase().endsWith(suffix.toLowerCase())
          );
        }

        if (targets.length > 1) targets = [];
      }

      let stateValue = null;
      if (msg === 'ON' || msg === '1' || msg === 'TRUE') stateValue = true;
      else if (msg === 'OFF' || msg === '0' || msg === 'FALSE') stateValue = false;
      else {
        try {
          const data = JSON.parse(raw);
          // الفيرموير قد يرسل الحالة داخل state/status/value أو on؛
          // نقبل أيضًا قيم Boolean الحقيقية بدل تحويلها إلى نص غير متوقع.
          const candidate = data?.state ?? data?.status ?? data?.value ?? data?.on;
          if (typeof candidate === 'boolean') {
            stateValue = candidate;
          } else {
            const v = String(candidate ?? '').trim().toUpperCase();
            if (['ON', '1', 'TRUE'].includes(v)) stateValue = true;
            if (['OFF', '0', 'FALSE'].includes(v)) stateValue = false;
          }
        } catch (_) {
          // تجاهل الرسائل غير الصالحة دون تعطيل مستمع MQTT.
        }
      }

      if (targets.length !== 1) return;
      const d = targets[0];
      if (d.controlType === 'updown') {
        setDeviceRawStatus((prev) => ({ ...prev, [d.id]: raw }));
      } else if (stateValue !== null) {
        setDeviceState((prev) => ({ ...prev, [d.id]: stateValue }));
      }
    };

    client.on('message', handler);
    return () => {
      client.off('message', handler);
      statusTopics.forEach((t) => client.unsubscribe(t));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client, statusTopicsKey]);

  useEffect(() => {
    if (!client || timerStateTopics.length === 0) return undefined;

    timerStateTopics.forEach((t) => client.subscribe(t));

    const handler = (topic, payload) => {
      const device = devicesRef.current.find((d) => `${d.controlTopic}/timer/state` === topic);
      if (!device) return;
      let data;
      try {
        data = JSON.parse(payload.toString());
      } catch (e) {
        return; // رسالة تايمر مش JSON صحيح — اتجاهلها
      }
      setDeviceTimerState((prev) => ({
        ...prev,
        [device.id]: {
          mode: data.mode === 'countdown' || data.mode === 'schedule' ? data.mode : 'off',
          secondsLeft: typeof data.seconds_left === 'number' ? data.seconds_left : null,
          receivedAt: Date.now(),
          scheduleEnabled: !!data.schedule_enabled,
          on: typeof data.on === 'string' ? data.on : null,
          off: typeof data.off === 'string' ? data.off : null,
        },
      }));
    };

    client.on('message', handler);
    return () => {
      client.off('message', handler);
      timerStateTopics.forEach((t) => client.unsubscribe(t));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client, timerStateTopicsKey]);

  const cleanupSync = () => {
    if (syncTimeoutRef.current) {
      clearTimeout(syncTimeoutRef.current);
      syncTimeoutRef.current = null;
    }
    if (client && discoveryTopic && syncHandlerRef.current) {
      client.off('message', syncHandlerRef.current);
      client.unsubscribe(discoveryTopic);
    }
    syncHandlerRef.current = null;
  };

  useEffect(() => cleanupSync, []); // eslint-disable-line react-hooks/exhaustive-deps

  const startSync = () => {
    if (!discoveryTopic) {
      showAlert('خطأ', 'البورد ده مضاف قديم ومش متسجل عليه توبيك اكتشاف — احذفه وأضفه تاني بالاكتشاف التلقائي.');
      return;
    }
    if (!pairingKey) {
      showAlert('خطأ', 'لازم تحط مفتاح الربط (Pairing Key) في الإعدادات الأول');
      return;
    }
    if (!client || !connected) {
      showAlert('خطأ', 'لسه مش متصل بالسيرفر، استنى ثانية وحاول تاني');
      return;
    }

    cleanupSync();
    setSyncError('');
    setSyncing(true);
    client.subscribe(discoveryTopic);

    const handler = (t, payload) => {
      if (t !== discoveryTopic) return;
      const result = parseBoardDiscovery(payload.toString(), pairingKey);
      cleanupSync();
      setSyncing(false);
      if (!result.ok) {
        setSyncError(result.error);
        return;
      }
      if (result.board.type !== 'switches') {
        setSyncError('رسالة الاكتشاف اللي وصلت مش لبورد لوحة مفاتيح.');
        return;
      }
      const incoming = result.board.devices;
      let addedCount = 0;
      let updatedCount = 0;
      const byTopic = new Map(devices.map((d) => [d.controlTopic, d]));
      const merged = devices.map((d) => {
        const inc = byTopic.get(d.controlTopic) && incoming.find((i) => i.controlTopic === d.controlTopic);
        if (!inc) return d;
        updatedCount += 1;
        return { ...d, name: inc.name, icon: d.iconSource === 'user' ? d.icon : inc.icon, controlType: inc.controlType, statusTopic: inc.statusTopic };
      });
      incoming.forEach((inc) => {
        if (!byTopic.has(inc.controlTopic)) {
          addedCount += 1;
          merged.push({ id: newId(), ...inc, iconSource: 'firmware' });
        }
      });
      persistDevices(merged);
      showAlert('تمت المزامنة', `تمت إضافة ${addedCount} مفتاح جديد وتحديث ${updatedCount} مفتاح موجود.`);
    };
    syncHandlerRef.current = handler;
    client.on('message', handler);

    syncTimeoutRef.current = setTimeout(() => {
      cleanupSync();
      setSyncing(false);
      setSyncError('مفيش رد من الفيرموير. اتأكد إنها شغالة ومتصلة وناشرة رسالة الاكتشاف Retained.');
    }, SYNC_TIMEOUT_MS);
  };

  // منع التكرار السريع لنفس الأمر (double-tap) من غير تعطيل الاستخدام الطبيعي.
  const allowCommand = (key, cooldownMs = 450) => {
    const now = Date.now();
    const previous = commandCooldownRef.current[key] || 0;
    if (now - previous < cooldownMs) return false;
    commandCooldownRef.current[key] = now;
    return true;
  };

  // حارس موحّد لأوامر التحكم: لا نرسل أي أمر فعلي لو اتصال MQTT غير قائم.
  // لا يغيّر صيغة الأوامر أو الـ Topics؛ يمنع فقط الإرسال وقت انقطاع الاتصال.
  const ensureConnected = (actionLabel = 'تنفيذ الأمر') => {
    if (client && connected) return true;
    showAlert('الاتصال غير متاح', `لا يمكن ${actionLabel} الآن. اتأكد إن التطبيق متصل بالسيرفر وحاول تاني.`);
    return false;
  };

  const toggleDevice = (device) => {
    if (!ensureConnected('تشغيل المفتاح')) return;
    if (!device?.controlTopic) {
      showAlert('تعذر تشغيل المفتاح', 'عنوان التحكم لهذا المفتاح غير مضبوط. افتح إعدادات المفتاح وراجع Control Topic.');
      return;
    }

    // لا نفترض أن المفتاح OFF إذا لم تصل حالته بعد؛ هذا الافتراض كان يجعل
    // أول ضغطة ترسل ON دائمًا وقد يبدو المفتاح معكوسًا إذا كان يعمل بالفعل.
    // نستخدم آخر حالة مؤكدة من الفيرموير، وإذا كانت مجهولة نطلب مزامنتها بدل
    // إرسال أمر قد يغيّر الحالة في الاتجاه الخطأ.
    const current = deviceState[device.id];
    if (typeof current !== 'boolean') {
      try {
        const topic = device.statusTopic || device.controlTopic;
        client.subscribe(topic);
      } catch (error) {
        console.warn('[Silja Smart] تعذر طلب حالة المفتاح:', error?.message);
      }
      showAlert('جاري مزامنة الحالة', 'لسه ماوصلتش حالة مؤكدة من البوردة. انتظر لحظة ثم جرّب مرة أخرى.');
      return;
    }

    if (!allowCommand(`toggle:${device.controlTopic}`, 700)) return;
    const next = !current;
    try {
      client.publish(device.controlTopic, next ? 'ON' : 'OFF', { qos: 1 }, (error) => {
        if (error) {
          showAlert('فشل إرسال الأمر', 'لم يتم إرسال أمر المفتاح. راجع الاتصال بالسيرفر.');
        }
      });
      // لا نغيّر الحالة المعروضة هنا؛ ننتظر تأكيد الحالة من الفيرموير حتى
      // لا يعرض التطبيق نجاحًا وهميًا إذا لم ينفّذ الريليه الأمر.
    } catch (error) {
      showAlert('فشل إرسال الأمر', error?.message || 'تعذر إرسال الأمر إلى البوردة.');
    }
  };

  const moveDevice = (device, direction) => {
    if (!ensureConnected('تحريك الجهاز')) return;
    if (!device?.controlTopic) return showAlert('تعذر التحكم', 'عنوان التحكم لهذا الجهاز غير مضبوط.');
    if (!['UP', 'DOWN', 'STOP'].includes(direction)) return;
    if (!allowCommand(`move:${device.controlTopic}`, direction === 'STOP' ? 180 : 300)) return;
    client.publish(device.controlTopic, direction, { qos: 1 }, (error) => { if (error) showAlert('فشل إرسال الأمر', 'راجع الاتصال بالسيرفر وحاول مرة أخرى.'); });
  };

  // بروتوكول التايمر (شوف README.md "بروتوكول التايمر"):
  // أمر يتبعت على `<control_topic>/timer/set` كـ JSON، والفيرموير هو اللي بينفذه ويحتفظ بيه.
  const publishTimerCommand = (device, payload) => {
    if (!ensureConnected('تعديل المؤقت')) return false;
    if (!device?.controlTopic) { showAlert('تعذر التحكم', 'عنوان التحكم لهذا الجهاز غير مضبوط.'); return false; }
    try {
      client.publish(`${device.controlTopic}/timer/set`, JSON.stringify(payload));
      return true;
    } catch (error) {
      showAlert('فشل إرسال الأمر', error?.message || 'تعذر إرسال إعداد المؤقت.');
      return false;
    }
  };

  const startCountdown = (device, minutesStr) => {
    const mins = parseInt(minutesStr, 10);
    if (!Number.isFinite(mins) || mins < 1) {
      showAlert('خطأ', 'اكتب عدد دقايق صحيح (رقم أكبر من صفر).');
      return;
    }
    if (publishTimerCommand(device, { mode: 'countdown', minutes: mins })) setTimerModalVisible(false);
  };

  const cancelCountdown = (device) => {
    publishTimerCommand(device, { mode: 'off' });
  };

  const saveSchedule = (device, onTime, offTime, enabled) => {
    if (enabled && (!isValidHHMM(onTime) || !isValidHHMM(offTime))) {
      showAlert('خطأ', 'اكتب الوقت بصيغة صحيحة زي 07:00 (24 ساعة)');
      return;
    }
    if (publishTimerCommand(device, { mode: 'schedule', enabled, on: onTime, off: offTime })) setTimerModalVisible(false);
  };

  const openTimerModal = (device) => {
    const st = deviceTimerState[device.id];
    setTimerDeviceId(device.id);
    setTimerTab('countdown');
    setCountdownInput(st?.mode === 'countdown' && st.secondsLeft ? String(Math.ceil(st.secondsLeft / 60)) : '30');
    setScheduleOnInput(st?.on || '07:00');
    setScheduleOffInput(st?.off || '22:00');
    setScheduleEnabledInput(!!st?.scheduleEnabled);
    setTimerModalVisible(true);
  };

  // بيحدّث العرض كل ثانية طول ما فيه عد تنازلي شغال، عشان نعرض الوقت المتبقي وهو بينزل
  // بين رسالة وتانية من الفيرموير (interpolation)، مش إنه هو اللي بيتحكم في المفتاح.
  useEffect(() => {
    const hasActive = Object.values(deviceTimerState).some((s) => s.mode === 'countdown');
    if (!hasActive) return undefined;
    const id = setInterval(() => forceTick((t) => t + 1), 1000);
    return () => clearInterval(id);
  }, [deviceTimerState]);

  const getCountdownLabel = (device) => {
    const st = deviceTimerState[device.id];
    if (!st || st.mode !== 'countdown' || st.secondsLeft == null) return null;
    const elapsed = Math.floor((Date.now() - st.receivedAt) / 1000);
    const remaining = st.secondsLeft - elapsed;
    if (remaining <= 0) return null;
    const m = Math.floor(remaining / 60);
    const s = remaining % 60;
    return `${m}:${String(s).padStart(2, '0')}`;
  };

  // زرار الطوارئ وزرار الاختبار مش مفاتيح عادية — الفيرموير بيوزّعهم زي أي
  // مفتاح عادي في رسالة الاكتشاف (control_topic/status_topic/icon) عشان
  // ينضموا للمزامنة تلقائي، بس شكلهم في الآيقونة (emergency-button / bell)
  // بيميّزهم عشان نطلعهم برا الشبكة العادية ونتحكم فيهم من شريط سفلي صغير.
  const emergencyDevice = devices.find((d) => getDeviceIcon(d.icon).isEmergency);
  const testDevice = devices.find((d) => d.icon === 'bell');
  const regularDevices = devices.filter((d) => d !== emergencyDevice && d !== testDevice);
  // تصنيف المفاتيح للفلاتر: إضاءة / مراوح وتهوية / أخرى (حسب نوع الأيقونة المختارة).
  const deviceCategory = (d) => {
    const def = getDeviceIcon(d.icon);
    if (def?.isLight) return 'light';
    if (String(def?.icon || '').includes('fan')) return 'fan';
    return 'other';
  };
  const shownDevices = filter === 'all' ? regularDevices : regularDevices.filter((d) => deviceCategory(d) === filter);
  const emergencyOn = emergencyDevice ? !!deviceState[emergencyDevice.id] : false;

  const allOn = () => {
    if (!ensureConnected('تشغيل كل المفاتيح')) return;
    if (!allowCommand('all-on', 900)) return;
    regularDevices.forEach((d) => d.controlType !== 'updown' && d.controlTopic && client.publish(d.controlTopic, 'ON'));
  };
  const allOff = () => {
    if (!ensureConnected('إيقاف كل المفاتيح')) return;
    if (!allowCommand('all-off', 900)) return;
    regularDevices.forEach((d) => d.controlTopic && client.publish(d.controlTopic, d.controlType === 'updown' ? 'STOP' : 'OFF'));
  };

  // زرار الطوارئ الفعلي — بيبعت ON/OFF على control_topic بتاعه (نفس أي
  // مفتاح toggle عادي)، والفيرموير هو اللي بيشغّل/يوقف الريليهات المحددة
  // له ويرجّع الحالة الحقيقية على status_topic (مش تفاؤلي من الابلكيشن).
  // بنأكد قبل أي تغيير (تفعيل أو إلغاء) لأنه بيأثر على أجهزة فعلية فورًا.
  const handleEmergencyPress = () => {
    if (!emergencyDevice) return;
    const turningOn = !emergencyOn;
    showAlert(
      turningOn ? 'تأكيد تفعيل الطوارئ' : 'تأكيد إلغاء الطوارئ',
      turningOn
        ? 'هيتفعل وضع الطوارئ ويشغّل المخارج المحددة له فورًا. متأكد؟'
        : 'هيرجع البورد للوضع الطبيعي ويوقف وضع الطوارئ. متأكد؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: turningOn ? 'تفعيل الآن' : 'تأكيد',
          style: turningOn ? 'destructive' : 'default',
          onPress: () => {
            if (!ensureConnected('تغيير وضع الطوارئ')) return;
            client.publish(emergencyDevice.controlTopic, turningOn ? 'ON' : 'OFF');
            if (turningOn) {
              notifyLocal('🚨 طوارئ', `تم تفعيل زرار الطوارئ في ${board.name}`);
            }
          },
        },
      ]
    );
  };

  // زرار الاختبار الفعلي — نبضة بس (ON)، والفيرموير بيبعت إشعار ntfy ويرجع
  // OFF لوحده تاني على طول، فمفيش داعي لأي تأكيد أو حالة "شغال" دايمة هنا.
  const sendTest = () => {
    if (!testDevice || !ensureConnected('إرسال اختبار')) return;
    if (!allowCommand(`test:${testDevice.controlTopic}`, 1600)) return;
    client.publish(testDevice.controlTopic, 'ON', { qos: 1 }, (error) => { if (error) showAlert('فشل الاختبار', 'لم يتم تأكيد إرسال أمر الاختبار.'); });
    setTestSending(true);
    setTimeout(() => setTestSending(false), 1500);
  };

  const openEditForm = (device) => {
    setEditingId(device.id);
    setFName(device.name);
    setFIcon(device.icon || 'switch');
    setFOnColor(device.onColor || null);
    setFOffColor(device.offColor || null);
    setFormVisible(true);
  };

  const deleteDevice = (id) => {
    showAlert('حذف المفتاح', 'متأكد إنك عايز تمسح المفتاح ده؟ (لو الفيرموير لسه بينشره، هيرجع تاني أول مزامنة)', [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'مسح',
        style: 'destructive',
        onPress: () => persistDevices(devices.filter((d) => d.id !== id)),
      },
    ]);
  };

  // تغيير شكل مفتاح واحد بس (من صفحة "تعديل شكل المفاتيح")، من غير ما يلمس
  // أي حاجة تانية في المفتاح (اسمه، ألوانه، توبيكاته).
  const setDeviceIconOnly = (id, icon) => {
    // اختيار المستخدم هو المصدر الأعلى للأيقونة؛ لا تسمح مزامنة الفيرموير
    // باستبداله لاحقًا. نستخدم المرجع الحالي حتى لا نعتمد على state قديم.
    // اختيار أيقونة جاهزة من المكتبة معناه التراجع عن أي صور مخصوصة كانت متحطة (شغال/مطفي).
    const next = devicesRef.current.map((d) => (d.id === id ? { ...d, icon, iconSource: 'user', customImage: null, customImageOn: null, customImageOff: null } : d));
    persistDevices(next);
    // حذف ملفات الصور القديمة ذات الأسماء الثابتة من الإصدارات السابقة
    // (الصور الجديدة أصبحت بأسماء فريدة لتجنب الكاش).
    FileSystem.deleteAsync(`${DEVICE_IMAGES_DIR}${id}-on.jpg`, { idempotent: true }).catch(() => {});
    FileSystem.deleteAsync(`${DEVICE_IMAGES_DIR}${id}-off.jpg`, { idempotent: true }).catch(() => {});
    FileSystem.deleteAsync(`${DEVICE_IMAGES_DIR}${id}.jpg`, { idempotent: true }).catch(() => {});
    // لا نغلق شاشة الاختيار؛ خلي المستخدم يشوف الأيقونة الجديدة فورًا
    // ويقدر يختار أيقونة أخرى بدون فتح الشاشة من جديد.
    setIconEditDeviceId(id);
  };

  // اختيار صورة حقيقية من معرض الصور بدل أيقونة المفتاح — لحالة "شغال" أو
  // "مطفي" على حدة، عشان الصورة نفسها تبين حالة المفتاح.
  const pickDeviceImageFromLibrary = async (id, state) => {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      showAlert('مفيش صلاحية', 'لازم تسمح للتطبيق بالدخول على الصور من إعدادات الموبايل الأول');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 1,
    });
    if (result.canceled || !result.assets?.[0]?.uri) return;
    const asset = result.assets[0];
    setDeviceCropSource({ uri: asset.uri, width: asset.width, height: asset.height, id, state });
  };

  // التقاط صورة بالكاميرا بدل أيقونة المفتاح — لحالة "شغال" أو "مطفي".
  const takeDeviceImage = async (id, state) => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      showAlert('مفيش صلاحية', 'لازم تسمح للتطبيق باستخدام الكاميرا من إعدادات الموبايل الأول');
      return;
    }
    const result = await ImagePicker.launchCameraAsync({ quality: 1 });
    if (result.canceled || !result.assets?.[0]?.uri) return;
    const asset = result.assets[0];
    setDeviceCropSource({ uri: asset.uri, width: asset.width, height: asset.height, id, state });
  };

  // بعد ما المستخدم يضبط الصورة (تكبير/تحريك) وياخد "تم" من كنترول القص —
  // بنحفظ النسخة المقصوصة النهائية مكان الصورة القديمة بتاعة نفس الحالة.
  const handleDeviceCropConfirm = async (croppedUri, err) => {
    const source = deviceCropSource;
    setDeviceCropSource(null);
    if (!source) return;
    if (!croppedUri) {
      if (err) showAlert('خطأ', 'مقدرناش نقص الصورة، جرب تاني');
      return;
    }
    setDeviceImageBusy(true);
    try {
      const saved = await persistPickedDeviceImage(croppedUri, source.id, source.state);
      const field = source.state === 'on' ? 'customImageOn' : 'customImageOff';
      const next = devicesRef.current.map((d) => (d.id === source.id ? { ...d, [field]: saved, iconSource: 'user' } : d));
      persistDevices(next);
    } catch (e) {
      showAlert('خطأ', 'مقدرناش نحفظ الصورة، جرب تاني');
    } finally {
      setDeviceImageBusy(false);
    }
  };

  // رجوع لأيقونة المكتبة العادية بدل الصورة المخصوصة — لحالة واحدة بس
  // (شغال أو مطفي)؛ الحالة التانية بتفضل زي ما هي لو متحطة.
  const removeDeviceImage = (id, state) => {
    const field = state === 'on' ? 'customImageOn' : 'customImageOff';
    const next = devicesRef.current.map((d) => (d.id === id ? { ...d, [field]: null, ...(field === 'customImageOff' ? { customImage: null } : {}) } : d));
    persistDevices(next);
    // الصور الجديدة أسماءها فريدة؛ لا نحذف الملف الحالي هنا لأن URI القديم
    // ممكن يكون ما زال مستخدمًا أثناء إعادة الرسم. يكفي إزالة المرجع من الجهاز.
    FileSystem.deleteAsync(`${DEVICE_IMAGES_DIR}${id}-${state}.jpg`, { idempotent: true }).catch(() => {});
  };

  const saveForm = () => {
    if (!editingId) return;
    const current = devices.find((d) => d.id === editingId);
    if (!current) return;
    const payload = {
      name: fName.trim() || current.name,
      icon: fIcon,
      iconSource: 'user',
      onColor: current.controlType === 'toggle' ? fOnColor || undefined : undefined,
      offColor: current.controlType === 'toggle' ? fOffColor || undefined : undefined,
    };
    persistDevices(devices.map((d) => (d.id === editingId ? { ...d, ...payload } : d)));
    setFormVisible(false);
  };

  const styles = getStyles(theme);
  const editingDevice = devices.find((d) => d.id === editingId);
  const timerDevice = devices.find((d) => d.id === timerDeviceId);
  const timerDeviceState = timerDevice ? deviceTimerState[timerDevice.id] : null;
  const activeCountdownLabel = timerDevice ? getCountdownLabel(timerDevice) : null;

  return (
    <SafeAreaView style={styles.container}>
      <ScreenBackground theme={theme} />
      <ScreenHeader title={board.name} onBack={onBack} right={
        <TouchableOpacity onPress={() => setIconSettingsVisible(true)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}><MaterialCommunityIcons name="cog-outline" size={22} color={theme.textSecondary} /></TouchableOpacity>
      } />

      <ConnectionStatusBanner
        theme={theme}
        connected={!!connected}
        title={connected ? 'متصل بالسيرفر' : 'غير متصل — التحكم متوقف'}
        detail={connected && boardAvailabilityTopic(board)
          ? `حالة البورد: ${boardAvailable === 'online' ? 'متصل' : boardAvailable === 'offline' ? 'غير متصل' : 'بانتظار الحالة'}. حالة المفتاح تُحدّث بعد رد الفيرموير.`
          : connected ? 'حالة المفتاح تعتمد على آخر تأكيد وصل من الفيرموير.' : 'لن يتم إرسال أوامر تشغيل أو إيقاف أثناء انقطاع الاتصال.'}
      />

      <ScrollView contentContainerStyle={{ paddingBottom: 130 }}>
        {regularDevices.length > 0 && (
          <View style={styles.filterRow}>
            {[['all', 'الكل'], ['light', 'الإضاءة'], ['fan', 'المراوح'], ['other', 'أخرى']].map(([key, label]) => (
              <TouchableOpacity
                key={key}
                style={[styles.filterChip, filter === key && styles.filterChipActive]}
                onPress={() => setFilter(key)}
                activeOpacity={0.8}
              >
                <Text style={[styles.filterChipText, filter === key && styles.filterChipTextActive]}>{label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {regularDevices.length > 0 && (
          <View style={styles.btnRow}>
            <TouchableOpacity style={[styles.smallBtn, styles.allOnBtn]} onPress={allOn}>
              <MaterialCommunityIcons name="power" size={16} color={readableOn(theme.accent)} />
              <Text style={styles.allOnText}>تشغيل الكل</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.smallBtn, styles.allOffBtn]} onPress={allOff}>
              <MaterialCommunityIcons name="power-off" size={16} color={theme.accentSoft} />
              <Text style={styles.allOffText}>إيقاف الكل</Text>
            </TouchableOpacity>
          </View>
        )}

        {regularDevices.length === 0 && (
          <Text style={styles.emptyText}>
            مفيش مفاتيح لسه في البورد ده. دوس "🔄 مزامنة من الفيرموير" عشان الفيرموير يبعت المفاتيح تلقائي.
          </Text>
        )}

        <View style={[styles.grid, styles.gridSizing[cardSize], (cardStyle === 'ring' || cardStyle === 'tile') && { justifyContent: 'flex-start' }]}>
          {shownDevices.map((device) => (
            <DeviceCard
              key={device.id}
              device={device}
              theme={theme}
              cardStyle={cardStyle}
              switchShape={switchShape}
              cardSize={cardSize}
              cardOpacity={cardOpacity}
              isOn={!!deviceState[device.id]}
              rawStatus={deviceRawStatus[device.id]}
              countdownLabel={getCountdownLabel(device)}
              scheduleActive={!!deviceTimerState[device.id]?.scheduleEnabled}
              onToggle={() => toggleDevice(device)}
              onUp={() => moveDevice(device, 'UP')}
              onStop={() => moveDevice(device, 'STOP')}
              onDown={() => moveDevice(device, 'DOWN')}
              onOpenTimer={() => openTimerModal(device)}
            />
          ))}
        </View>

        {syncing && (
          <View style={styles.syncRow}>
            <ActivityIndicator color={theme.accent} />
            <Text style={styles.listeningHint}>بيزامن مع الفيرموير…</Text>
          </View>
        )}
        {!!syncError && <Text style={styles.errorText}>⚠ {syncError}</Text>}

        <View style={styles.btnRow}>
          <TouchableOpacity
            style={[styles.addBtn, styles.discoverBtn, { flex: 1 }]}
            onPress={startSync}
            disabled={syncing}
          >
            <Text style={styles.discoverBtnText}>🔄 مزامنة من الفيرموير</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* شريط سفلي صغير — أيقونتين بس: اختبار وطوارئ، منفصلين عن باقي أزرار
          الشاشة عشان يفضلوا واضحين وسهل الوصول لهم من غير ما يتلخبطوا مع
          كروت المفاتيح. بيظهروا بس لو الفيرموير بعتهم في آخر مزامنة. */}
      {(emergencyDevice || testDevice) && (
        <View style={styles.utilityRow}>
          {testDevice && (
            <TouchableOpacity
              style={styles.utilityBtn}
              onPress={sendTest}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            >
              <MaterialCommunityIcons
                name={testSending ? 'bell-ring' : 'bell-ring-outline'}
                size={22}
                color={theme.accent}
              />
              <Text style={[styles.utilityLabel, { color: theme.textSecondary }]}>
                {testSending ? 'جاري الإرسال…' : 'اختبار'}
              </Text>
            </TouchableOpacity>
          )}

          {emergencyDevice && (
            <TouchableOpacity
              style={styles.utilityBtn}
              onPress={handleEmergencyPress}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            >
              <View>
                <MaterialCommunityIcons
                  name="alarm-light-outline"
                  size={22}
                  color={emergencyOn ? EMERGENCY_ON : theme.danger}
                />
                {emergencyOn && <View style={styles.emergencyLiveDot} />}
              </View>
              <Text
                style={[
                  styles.utilityLabel,
                  { color: emergencyOn ? EMERGENCY_ON : theme.textSecondary, fontWeight: emergencyOn ? '700' : '600' },
                ]}
              >
                {emergencyOn ? 'طوارئ نشطة' : 'طوارئ'}
              </Text>
            </TouchableOpacity>
          )}
        </View>
      )}

      {/* مودال تعديل شكل المفتاح — الاسم والأيقونة والألوان بس، مش التوبيكات.
          التوبيكات بتيجي من الفيرموير عن طريق الاكتشاف الموقّع فقط. */}
      <Modal visible={formVisible} transparent animationType="fade" onRequestClose={() => setFormVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <ScrollView keyboardShouldPersistTaps="handled">
              <Text style={styles.modalTitle}>تعديل شكل المفتاح</Text>

              <Text style={styles.label}>اسم المفتاح</Text>
              <TextInput
                style={styles.input}
                value={fName}
                onChangeText={setFName}
                placeholder="لمبة الصالة"
                placeholderTextColor={theme.textMuted}
              />

              <Text style={styles.label}>توبيك التحكم (من الفيرموير — مش قابل للتعديل)</Text>
              <View style={styles.codeBox}>
                <Text style={styles.codeText}>{editingDevice?.controlTopic}</Text>
              </View>

              <Text style={styles.label}>توبيك الحالة (من الفيرموير)</Text>
              <View style={styles.codeBox}>
                <Text style={styles.codeText}>{editingDevice?.statusTopic || editingDevice?.controlTopic}</Text>
              </View>

              {editingDevice?.controlType !== 'updown' && (
                <>
                  <Text style={styles.label}>لون حالة التشغيل (ON)</Text>
                  <ColorPickerRow
                    styles={styles}
                    themeColor={
                      getDeviceIcon(fIcon).isLight
                        ? LIGHT_WARM_ON
                        : getDeviceIcon(fIcon).isEmergency
                        ? EMERGENCY_ON
                        : theme.on
                    }
                    value={fOnColor}
                    onChange={setFOnColor}
                  />

                  <Text style={styles.label}>لون حالة الإيقاف (OFF)</Text>
                  <ColorPickerRow styles={styles} themeColor={theme.off} value={fOffColor} onChange={setFOffColor} />
                </>
              )}

              <Text style={styles.label}>شكل المفتاح</Text>
              <FlatList
                data={DEVICE_ICONS.filter((x) => !x.isPlace)}
                keyExtractor={(item) => item.id}
                numColumns={4}
                scrollEnabled={false}
                contentContainerStyle={{ marginTop: 4 }}
                renderItem={({ item }) => {
                  const selected = fIcon === item.id;
                  return (
                    <TouchableOpacity
                      style={[styles.iconOption, selected && styles.iconOptionSelected]}
                      onPress={() => setFIcon(item.id)}
                    >
                      <MaterialCommunityIcons name={item.icon} size={30} color={theme.textPrimary} />
                      <Text style={styles.iconOptionLabel} numberOfLines={1}>
                        {item.label}
                      </Text>
                    </TouchableOpacity>
                  );
                }}
              />

              <View style={styles.btnRow}>
                <TouchableOpacity style={[styles.smallBtn, styles.onBtn]} onPress={saveForm}>
                  <Text style={styles.btnText}>حفظ</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.smallBtn, styles.offBtn]} onPress={() => setFormVisible(false)}>
                  <Text style={styles.btnText}>إلغاء</Text>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* صفحة "تعديل شكل المفاتيح" — قايمة كل المفاتيح مع شكلها، تدوس على أي
          واحد فيهم يفتحلك شبكة الأيقونات تختار منها على طول، من غير فورم
          تعديل كامل (اسم/ألوان/توبيكات) عشان محدش يتلخبط. */}
      <Modal
        visible={iconSettingsVisible}
        transparent
        animationType="fade"
        onRequestClose={() => {
          setIconEditDeviceId(null);
          setIconSettingsVisible(false);
        }}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <ScrollView keyboardShouldPersistTaps="handled">
              {iconEditDeviceId ? (
                <>
                  <Text style={styles.modalTitle}>
                    شكل — {devices.find((d) => d.id === iconEditDeviceId)?.name}
                  </Text>

                  {/* اختيار صورتين حقيقيتين بدل أيقونة المفتاح — واحدة للحالة
                      "شغال" وواحدة للحالة "مطفي"، عشان الصورة نفسها تبين حالة
                      المفتاح لحظة ما تشغّله أو تطفيه. */}
                  <Text style={styles.hint}>حط صورة لكل حالة (اختياري) — تقدر تحط صورة واحدة بس وهتتستخدم للحالتين لحد ما تحط التانية.</Text>
                  <View style={styles.deviceImageStatesRow}>
                    {[
                      { key: 'off', label: 'الحالة: مطفي', field: 'customImageOff' },
                      { key: 'on', label: 'الحالة: شغال', field: 'customImageOn' },
                    ].map(({ key, label, field }) => {
                      const current = devices.find((d) => d.id === iconEditDeviceId);
                      const hasImage = !!current?.[field] || (key === 'off' && !!current?.customImage);
                      return (
                        <View key={key} style={styles.deviceImageStateCol}>
                          <Text style={styles.deviceImageStateLabel}>{label}</Text>
                          {hasImage ? (
                            <Image
                              source={key === 'on' ? deviceImageSource(current, true) : deviceImageSource(current, false)}
                              style={styles.deviceImagePreview}
                              resizeMode="contain"
                            />
                          ) : (
                            <View style={[styles.deviceImagePreview, { alignItems: 'center', justifyContent: 'center' }]}>
                              <MaterialCommunityIcons name={getDeviceIcon(current?.icon).icon} size={30} color={theme.textSecondary} />
                            </View>
                          )}
                          <TouchableOpacity
                            style={styles.imagePickBtn}
                            onPress={() => pickDeviceImageFromLibrary(iconEditDeviceId, key)}
                            disabled={deviceImageBusy}
                          >
                            <MaterialCommunityIcons name="image-outline" size={14} color={theme.textPrimary} />
                            <Text style={styles.imagePickBtnText}>من المعرض</Text>
                          </TouchableOpacity>
                          <TouchableOpacity
                            style={styles.imagePickBtn}
                            onPress={() => takeDeviceImage(iconEditDeviceId, key)}
                            disabled={deviceImageBusy}
                          >
                            <MaterialCommunityIcons name="camera-outline" size={14} color={theme.textPrimary} />
                            <Text style={styles.imagePickBtnText}>كاميرا</Text>
                          </TouchableOpacity>
                          {hasImage && (
                            <TouchableOpacity
                              style={styles.imagePickBtn}
                              onPress={() => removeDeviceImage(iconEditDeviceId, key)}
                              disabled={deviceImageBusy}
                            >
                              <MaterialCommunityIcons name="close-circle-outline" size={14} color={theme.danger} />
                              <Text style={[styles.imagePickBtnText, { color: theme.danger }]}>إزالة</Text>
                            </TouchableOpacity>
                          )}
                        </View>
                      );
                    })}
                  </View>
                  {deviceImageBusy && <ActivityIndicator color={theme.accent} style={{ marginBottom: 8 }} />}

                  <Text style={styles.hint}>أو اختار شكل جاهز من المكتبة تحت:</Text>
                  <FlatList
                    data={DEVICE_ICONS.filter((x) => !x.isPlace)}
                    keyExtractor={(item) => item.id}
                    numColumns={4}
                    scrollEnabled={false}
                    contentContainerStyle={{ marginTop: 4 }}
                    renderItem={({ item }) => {
                      const current = devices.find((d) => d.id === iconEditDeviceId);
                      const selected = (current?.icon || 'switch') === item.id;
                      return (
                        <TouchableOpacity
                          style={[styles.iconOption, selected && styles.iconOptionSelected]}
                          onPress={() => setDeviceIconOnly(iconEditDeviceId, item.id)}
                        >
                          <View style={[styles.iconOptionGlass, selected && styles.iconOptionGlassSelected]}>
                            <MaterialCommunityIcons name={item.icon} size={30} color={theme.textPrimary} />
                          </View>
                          <Text style={styles.iconOptionLabel} numberOfLines={1}>
                            {item.label}
                          </Text>
                        </TouchableOpacity>
                      );
                    }}
                  />
                  <View style={styles.btnRow}>
                    <TouchableOpacity style={[styles.smallBtn, styles.offBtn]} onPress={() => setIconEditDeviceId(null)}>
                      <Text style={styles.btnText}>‹ رجوع لقايمة المفاتيح</Text>
                    </TouchableOpacity>
                  </View>
                </>
              ) : (
                <>
                  <Text style={styles.modalTitle}>تعديل المفاتيح</Text>
                  <Text style={styles.hint}>
                    دوس على المفتاح عشان تغيّر شكله، ✏️ للتعديل الكامل (الاسم والألوان)، 🗑 للحذف.
                  </Text>
                  {devices.map((d) => {
                    const iconDef = getDeviceIcon(d.icon);
                    return (
                      <View key={d.id} style={styles.shapeListRow}>
                        <TouchableOpacity
                          style={styles.shapeListMain}
                          onPress={() => setIconEditDeviceId(d.id)}
                        >
                          <View style={styles.shapeListIconWrap}>
                            {hasCustomPhoto(d) ? (
                              <Image source={deviceImageSource(d, !!deviceState[d.id])} style={styles.shapeListImage} resizeMode="contain" />
                            ) : (
                              <MaterialCommunityIcons name={iconDef.icon} size={22} color={theme.textPrimary} />
                            )}
                          </View>
                          <Text style={styles.shapeListName} numberOfLines={1}>
                            {d.name}
                          </Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          style={styles.shapeListAction}
                          onPress={() => {
                            setIconSettingsVisible(false);
                            openEditForm(d);
                          }}
                          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                        >
                          <MaterialCommunityIcons name="pencil-outline" size={18} color={theme.textSecondary} />
                        </TouchableOpacity>
                        <TouchableOpacity
                          style={styles.shapeListAction}
                          onPress={() => deleteDevice(d.id)}
                          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                        >
                          <MaterialCommunityIcons name="trash-can-outline" size={18} color={theme.danger} />
                        </TouchableOpacity>
                      </View>
                    );
                  })}
                  {devices.length === 0 && (
                    <Text style={styles.emptyText}>مفيش مفاتيح لسه في البورد ده.</Text>
                  )}
                  <View style={styles.btnRow}>
                    <TouchableOpacity style={[styles.smallBtn, styles.offBtn]} onPress={() => setIconSettingsVisible(false)}>
                      <Text style={styles.btnText}>تم</Text>
                    </TouchableOpacity>
                  </View>
                </>
              )}
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* مودال التايمر: عد تنازلي (يقفل بعد مدة) أو جدولة يومية (يشتغل ويقفل في وقت معين) */}
      <Modal visible={timerModalVisible} transparent animationType="fade" onRequestClose={() => setTimerModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <ScrollView keyboardShouldPersistTaps="handled">
              <Text style={styles.modalTitle}>تايمر — {timerDevice?.name}</Text>

              <View style={styles.tabRow}>
                <TouchableOpacity
                  style={[styles.tabBtn, timerTab === 'countdown' && styles.tabBtnActive]}
                  onPress={() => setTimerTab('countdown')}
                >
                  <Text style={[styles.tabBtnText, timerTab === 'countdown' && styles.tabBtnTextActive]}>
                    عد تنازلي
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.tabBtn, timerTab === 'schedule' && styles.tabBtnActive]}
                  onPress={() => setTimerTab('schedule')}
                >
                  <Text style={[styles.tabBtnText, timerTab === 'schedule' && styles.tabBtnTextActive]}>
                    جدولة يومية
                  </Text>
                </TouchableOpacity>
              </View>

              {timerTab === 'countdown' ? (
                <>
                  <Text style={styles.label}>هيشتغل المفتاح دلوقتي ويقفل لوحده بعد كام دقيقة؟</Text>
                  <TextInput
                    style={styles.input}
                    value={countdownInput}
                    onChangeText={setCountdownInput}
                    keyboardType="number-pad"
                    placeholder="30"
                    placeholderTextColor={theme.textMuted}
                  />
                  <Text style={styles.hint}>
                    الأمر بيتبعت للفيرموير وهو اللي بيحسب العد التنازلي ويقفل المفتاح — يفضل شغال حتى لو قفلت التطبيق.
                  </Text>

                  {activeCountdownLabel && (
                    <Text style={[styles.hint, { color: theme.accentSoft, marginTop: 8 }]}>
                      متبقي دلوقتي: {activeCountdownLabel}
                    </Text>
                  )}

                  <View style={styles.btnRow}>
                    <TouchableOpacity
                      style={[styles.smallBtn, styles.onBtn]}
                      onPress={() => timerDevice && startCountdown(timerDevice, countdownInput)}
                    >
                      <Text style={styles.btnText}>ابدأ العد التنازلي</Text>
                    </TouchableOpacity>
                    {timerDeviceState?.mode === 'countdown' && (
                      <TouchableOpacity
                        style={[styles.smallBtn, styles.offBtn]}
                        onPress={() => {
                          cancelCountdown(timerDevice);
                          setTimerModalVisible(false);
                        }}
                      >
                        <Text style={styles.btnText}>إلغاء التايمر</Text>
                      </TouchableOpacity>
                    )}
                  </View>
                </>
              ) : (
                <>
                  <TouchableOpacity
                    style={styles.syncRow}
                    onPress={() => setScheduleEnabledInput((v) => !v)}
                  >
                    <MaterialCommunityIcons
                      name={scheduleEnabledInput ? 'toggle-switch' : 'toggle-switch-off-outline'}
                      size={30}
                      color={scheduleEnabledInput ? theme.accent : theme.textMuted}
                    />
                    <Text style={styles.statusLabel}>{scheduleEnabledInput ? 'الجدولة مفعّلة' : 'الجدولة متوقفة'}</Text>
                  </TouchableOpacity>

                  <Text style={styles.label}>وقت التشغيل (24 ساعة، مثال 07:00)</Text>
                  <TextInput
                    style={styles.input}
                    value={scheduleOnInput}
                    onChangeText={setScheduleOnInput}
                    placeholder="07:00"
                    placeholderTextColor={theme.textMuted}
                  />

                  <Text style={styles.label}>وقت الإيقاف (24 ساعة، مثال 22:00)</Text>
                  <TextInput
                    style={styles.input}
                    value={scheduleOffInput}
                    onChangeText={setScheduleOffInput}
                    placeholder="22:00"
                    placeholderTextColor={theme.textMuted}
                  />
                  <Text style={styles.hint}>
                    بيتكرر كل يوم في نفس الميعاد — محسوب جوه الفيرموير نفسه، فمش لازم التطبيق يكون فاتح وقت الميعاد.
                  </Text>

                  <View style={styles.btnRow}>
                    <TouchableOpacity
                      style={[styles.smallBtn, styles.onBtn]}
                      onPress={() =>
                        timerDevice && saveSchedule(timerDevice, scheduleOnInput, scheduleOffInput, scheduleEnabledInput)
                      }
                    >
                      <Text style={styles.btnText}>حفظ</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.smallBtn, styles.offBtn]} onPress={() => setTimerModalVisible(false)}>
                      <Text style={styles.btnText}>إلغاء</Text>
                    </TouchableOpacity>
                  </View>
                </>
              )}
            </ScrollView>
          </View>
        </View>
      </Modal>

      <ImageCropperModal
        visible={!!deviceCropSource}
        imageUri={deviceCropSource?.uri}
        imageWidth={deviceCropSource?.width}
        imageHeight={deviceCropSource?.height}
        onCancel={() => setDeviceCropSource(null)}
        onConfirm={handleDeviceCropConfirm}
      />
    </SafeAreaView>
  );
}
// بيحوّل لون hex (بالشكل #rrggbb) لـ rgba بشفافية معينة — مستخدم عشان نعمل
// توهج نيون (خلفية شفافة ملونة حوالين الأيقونة) من غير ما نحتاج مكتبة ألوان.
function hexToRgba(hex, alpha) {
  const clean = (hex || '').replace('#', '');
  if (clean.length !== 6) return `rgba(255,255,255,${alpha})`;
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}

// كارت جهاز واحد — بيدير نبضة الضوء (الـ glow) بنفسه لما يكون شغال، وبيرسم لوحة طلوع/نزول للأجهزة المتحركة
function DeviceCard({
  device,
  theme,
  cardStyle = 'classic',
  switchShape = 'round',
  cardSize = 'medium',
  cardOpacity = 0.82,
  isOn,
  rawStatus,
  countdownLabel,
  scheduleActive,
  onToggle,
  onUp,
  onStop,
  onDown,
  onOpenTimer,
}) {
  const pulse = useRef(new Animated.Value(0)).current;
  const wave1 = useRef(new Animated.Value(0)).current;
  const wave2 = useRef(new Animated.Value(0)).current;
  const wave3 = useRef(new Animated.Value(0)).current;
  const isUpdown = device.controlType === 'updown';
  const iconDef = getDeviceIcon(device.icon);
  // أيقونات الإضاءة بتضيء أصفر دافئ، وزرار الطوارئ بيضيء أحمر تحذيري ثابت،
  // لما الجهاز يبقى ON — إلا لو المستخدم اختار لون مخصوص بنفسه.
  const onColor =
    device.onColor || (iconDef.isLight ? LIGHT_WARM_ON : iconDef.isEmergency ? EMERGENCY_ON : (theme.accentSoft || '#D6B36A'));
  const offColor = device.offColor || (theme.isLight ? '#8B929D' : '#8D887F');
  const color = isUpdown ? theme.accentSoft : isOn ? onColor : offColor;
  const styles = getStyles(theme);
  // أجهزة الطلوع/النزول (بوابات/ستائر) ليها عناصر تحكم خاصة (فوق/وقف/تحت)
  // مش هتتماشى مع تخطيطات النيون المتدرج/الفخم، فبتفضل دايمًا كلاسيك.
  const effectiveStyle = isUpdown ? 'classic' : cardStyle;
  const cardBg = hexToRgba(theme.card, cardOpacity);
  const cardAltBg = hexToRgba(theme.cardAlt, Math.max(0.45, cardOpacity));
  // نفس شكل التصميم المختار يفضل ظاهرًا سواء كان العرض شبكة صغيرة/متوسطة أو مستطيل بعرض الشاشة.
  // حتى في الحجم الصغير نحتفظ بعمودين؛ 3 أعمدة كانت تضيق الاسم العربي وتقطّع الحروف.
  // تخطيط النيون الأفقي يحتاج عرض الصف كاملًا حتى لا يضغط الاسم والسويتش داخل نصف كارت.
  const responsiveCardWidth = cardSize === 'large' || effectiveStyle === 'horizontal' ? '100%' : '48%';

  useEffect(() => {
    if (isUpdown || !isOn || effectiveStyle === 'minimal' || effectiveStyle === 'ring' || effectiveStyle === 'tile') {
      pulse.setValue(0);
      wave1.setValue(0);
      wave2.setValue(0);
      wave3.setValue(0);
      return undefined;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 900, useNativeDriver: false }),
        Animated.timing(pulse, { toValue: 0, duration: 900, useNativeDriver: false }),
      ])
    );
    const makeWave = (value, delay) => Animated.loop(
      Animated.sequence([
        Animated.delay(delay),
        Animated.timing(value, { toValue: 1, duration: 1200, useNativeDriver: false }),
        Animated.timing(value, { toValue: 0, duration: 0, useNativeDriver: false }),
      ])
    );
    const w1 = makeWave(wave1, 0);
    const w2 = makeWave(wave2, 400);
    const w3 = makeWave(wave3, 800);
    loop.start();
    w1.start();
    w2.start();
    w3.start();
    return () => { loop.stop(); w1.stop(); w2.stop(); w3.stop(); };
  }, [isOn, isUpdown, effectiveStyle, pulse, wave1, wave2, wave3]);

  // تنفّس هادي (توهج بيعلى ويهبط) لبلاطة الجهاز الشغال.
  const breath = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (effectiveStyle !== 'tile' || !isOn || isUpdown) {
      breath.setValue(0);
      return undefined;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(breath, { toValue: 1, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(breath, { toValue: 0, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [effectiveStyle, isOn, isUpdown, breath]);

  const glowOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.08, 0.16] });
  const waveStyles = [
    { value: wave1, color: theme.accentSoft, size: 48 },
    { value: wave2, color: theme.accentSoft, size: 55 },
    { value: wave3, color: theme.border, size: 62 },
  ].map((w) => ({
    borderColor: w.color,
    width: w.size,
    height: w.size,
    borderRadius: w.size / 2,
    opacity: w.value.interpolate({ inputRange: [0, 0.18, 1], outputRange: [0, 0.52, 0] }),
    transform: [{ scale: w.value.interpolate({ inputRange: [0, 1], outputRange: [0.72, 1.22] }) }],
  }));
  const glowScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.08] });

  // ---- تخطيط "نيون متدرج": قائمة أفقية بإطار ألوان متحرك ----
  if (effectiveStyle === 'horizontal') {
    const rainbowBorder = pulse.interpolate({
      inputRange: [0, 0.25, 0.5, 0.75, 1],
      outputRange: [theme.border, theme.accentSoft, theme.border, theme.accentSoft, theme.border],
    });
    const rainbowGlow = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.04, 0.16] });
    return (
      <Animated.View style={[styles.cardH, cardSize === 'small' && { flexWrap: 'wrap' }, { width: responsiveCardWidth, padding: cardSize === 'small' ? 9 : 12, gap: cardSize === 'small' ? 8 : 12, borderRadius: cardSize === 'small' ? 16 : 20,
        backgroundColor: cardBg,
        borderColor: isOn ? rainbowBorder : theme.border,
        shadowColor: isOn ? theme.accentSoft : '#000',
        shadowOpacity: isOn ? rainbowGlow : 0.07,
        shadowRadius: isOn ? 12 : 7,
        shadowOffset: { width: 0, height: isOn ? 5 : 3 },
        elevation: isOn ? 6 : 3,
      }]}>
        <View pointerEvents="none" style={{ position: 'absolute', top: 0, bottom: 0, start: 0, width: 5, backgroundColor: isOn ? onColor : theme.border }} />
        {isOn && !isUpdown && (
          <Animated.View pointerEvents="none" style={[styles.hRainbowInner, { borderColor: rainbowBorder, opacity: rainbowGlow }]} />
        )}
        <View style={[styles.hIconBadge, cardSize === 'small' && { width: 38, height: 38, borderRadius: 13 }, { backgroundColor: cardAltBg, borderColor: isOn ? rainbowBorder : color }]}>
          {isOn && !isUpdown && waveStyles.map((w, i) => (
            <Animated.View key={`wave-${i}`} pointerEvents="none" style={[styles.hIconWave, w]} />
          ))}
          {hasCustomPhoto(device) ? (
            <Image source={deviceImageSource(device, isOn)} style={styles.hDeviceImage} resizeMode="contain" />
          ) : (
            <DeviceGlyph icon={iconDef.icon} size={28} color={color} isOn={isOn && !isUpdown} />
          )}
        </View>
        {cardSize !== 'small' && <View style={{ flex: 1, minWidth: 0, maxWidth: '100%' }}>
          <Text style={styles.hName} numberOfLines={3} ellipsizeMode="tail">{device.name || 'مفتاح بدون اسم'}</Text>
          <Text style={[styles.hSub, { color: isOn ? theme.accentSoft : theme.textMuted }]} numberOfLines={1}>
            {isOn ? 'شغال الآن' : 'متوقف'}
            {countdownLabel ? ` · ⏱ ${countdownLabel}` : scheduleActive ? ' · 🕐 مجدول' : ''}
          </Text>
        </View>}
        <TouchableOpacity onPress={onOpenTimer} style={[styles.hTimerBtn, cardSize === 'small' && { paddingHorizontal: 2 }]}>
          <MaterialCommunityIcons name={countdownLabel || scheduleActive ? 'timer' : 'timer-outline'} size={16} color={countdownLabel || scheduleActive ? theme.accentSoft : theme.textMuted} />
        </TouchableOpacity>
        <PremiumSwitch value={isOn} onValueChange={onToggle} theme={theme} activeColor={onColor} shape={switchShape} size={cardSize === 'small' ? 0.82 : 1} />
        {cardSize === 'small' && (
          <View style={{ width: '100%', flexBasis: '100%', alignSelf: 'stretch', paddingTop: 7 }}>
            <Text style={{ color: theme.textPrimary, fontSize: 14, fontWeight: '800', textAlign: 'center', lineHeight: 20 }} numberOfLines={2} ellipsizeMode="tail">{device.name || 'مفتاح بدون اسم'}</Text>
            <Text style={{ color: isOn ? theme.accentSoft : theme.textMuted, fontSize: 11, textAlign: 'center', marginTop: 2 }}>{isOn ? 'شغال الآن' : 'متوقف'}</Text>
          </View>
        )}
      </Animated.View>
    );
  }

  // ---- تخطيط "بلاطة زجاجية": كارت بتدرج ناعم، أيقونة جوه دايرة منوّرة بحلقة، واسم وسويتش ----
  // دوسة على الكارت = تشغيل/إيقاف، دوسة مطوّلة = المؤقت. الإضاءة بتنوّر بهالة، والمراوح بتلف.
  if (effectiveStyle === 'tile') {
    const isSmall = cardSize === 'small';
    const isLarge = cardSize === 'large';
    const tileWidth = isLarge ? '97%' : isSmall ? '30.5%' : '47%';
    const tileMargin = isLarge ? '1.5%' : isSmall ? '1.4%' : '1.5%';
    const well = isSmall ? 48 : isLarge ? 76 : 62;
    const edge = isOn ? hexToRgba(onColor, 0.62) : theme.border;
    const timerOn = !!(countdownLabel || scheduleActive);
    return (
      <TouchableOpacity
        onPress={onToggle}
        onLongPress={onOpenTimer}
        delayLongPress={350}
        activeOpacity={0.9}
        style={{
          width: tileWidth, marginHorizontal: tileMargin, marginBottom: 14,
          borderRadius: isSmall ? 20 : 26, borderWidth: 1.2, borderColor: edge, overflow: 'hidden',
          shadowColor: onColor, shadowOpacity: isOn ? 0.34 : 0, shadowRadius: isOn ? 14 : 0,
          shadowOffset: { width: 0, height: 6 }, elevation: isOn ? 6 : 2,
        }}
      >
        <LinearGradient
          colors={isOn ? [hexToRgba(onColor, 0.26), hexToRgba(onColor, 0.05)] : [cardBg, cardAltBg]}
          start={{ x: 0.1, y: 0 }}
          end={{ x: 0.9, y: 1 }}
          style={{ paddingTop: isSmall ? 8 : 11, paddingBottom: isSmall ? 10 : 14, paddingHorizontal: isSmall ? 6 : 10, alignItems: 'center' }}
        >
          {isOn && (
            <Animated.View
              pointerEvents="none"
              style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, backgroundColor: onColor, opacity: breath.interpolate({ inputRange: [0, 1], outputRange: [0, 0.1] }) }}
            />
          )}
          <View style={{ width: '100%', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: isSmall ? 4 : 6 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
              <View style={{ width: 7, height: 7, borderRadius: 3.5, backgroundColor: isOn ? onColor : hexToRgba(theme.textMuted, 0.5) }} />
              <Text style={{ fontSize: isSmall ? 10 : 11, fontWeight: '700', color: isOn ? onColor : theme.textMuted }}>{isOn ? 'شغال' : 'متوقف'}</Text>
            </View>
            <TouchableOpacity onPress={onOpenTimer} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <MaterialCommunityIcons name={timerOn ? 'timer' : 'timer-outline'} size={isSmall ? 14 : 16} color={timerOn ? theme.accentSoft : theme.textMuted} />
            </TouchableOpacity>
          </View>
          <View style={{ padding: 4, borderRadius: (well + 8) / 2, borderWidth: 1, borderColor: isOn ? hexToRgba(onColor, 0.3) : 'transparent' }}>
            <View style={{
              width: well, height: well, borderRadius: well / 2, alignItems: 'center', justifyContent: 'center', overflow: hasCustomPhoto(device) ? 'hidden' : 'visible',
              backgroundColor: isOn ? hexToRgba(onColor, 0.2) : hexToRgba(theme.textMuted, 0.1),
              borderWidth: 1.5, borderColor: isOn ? hexToRgba(onColor, 0.6) : hexToRgba(theme.textMuted, 0.22),
            }}>
              {hasCustomPhoto(device) ? (
                <Image source={deviceImageSource(device, isOn)} style={{ width: '100%', height: '100%' }} resizeMode="cover" />
              ) : (
                <DeviceGlyph icon={iconDef.icon} size={Math.round(well * 0.5)} color={isOn ? onColor : theme.textMuted} isOn={isOn} glow={!!iconDef.isLight} />
              )}
            </View>
          </View>
          <Text style={{ marginTop: isSmall ? 6 : 9, color: theme.textPrimary, fontSize: isSmall ? 12 : 14, fontWeight: '800', textAlign: 'center', lineHeight: isSmall ? 17 : 20, minHeight: isSmall ? 34 : 40 }} numberOfLines={2} ellipsizeMode="tail">
            {device.name || 'مفتاح بدون اسم'}
          </Text>
          {timerOn && (
            <Text style={{ fontSize: 10.5, color: theme.accentSoft, marginTop: 1 }} numberOfLines={1}>
              {countdownLabel ? `⏱ ${countdownLabel}` : '🕐 مجدول'}
            </Text>
          )}
          <View style={{ marginTop: isSmall ? 6 : 9 }}>
            <PremiumSwitch value={isOn} onValueChange={onToggle} theme={theme} activeColor={onColor} shape={switchShape} size={isSmall ? 0.8 : 0.95} />
          </View>
        </LinearGradient>
      </TouchableOpacity>
    );
  }

  // ---- تخطيط "دوائر": زرار دائري بحلقة (زي لوحة المخارج)، الاسم والحالة تحته بس ----
  // دوسة = تشغيل/إيقاف، دوسة مطوّلة = المؤقت. صور الأجهزة المخصصة مش بتتعرض هنا
  // (خلفياتها البيضا كانت بتظهر مستطيل جوه الدايرة)، الأيقونة الافتراضية بس.
  if (effectiveStyle === 'ring') {
    const cols = cardSize === 'large' ? 2 : cardSize === 'small' ? 4 : 3;
    const tileWidth = cols === 4 ? '22.5%' : cols === 3 ? '30.5%' : '47%';
    const tileMargin = cols === 4 ? '1.2%' : cols === 3 ? '1.4%' : '1.5%';
    const dia = cols === 4 ? 58 : cols === 3 ? 68 : 80;
    const ringColor = isOn ? onColor : hexToRgba(theme.textMuted, 0.42);
    return (
      <View style={[styles.ringTile, { width: tileWidth, marginHorizontal: tileMargin }]}>
        <TouchableOpacity
          onPress={onToggle}
          onLongPress={onOpenTimer}
          delayLongPress={350}
          activeOpacity={0.8}
          style={[styles.ringBtn, {
            width: dia, height: dia, borderRadius: dia / 2, borderColor: ringColor,
            backgroundColor: isOn ? hexToRgba(onColor, 0.16) : cardAltBg,
            shadowColor: onColor, shadowOpacity: isOn ? 0.5 : 0, shadowRadius: isOn ? 12 : 0, elevation: isOn ? 6 : 0,
          }]}
        >
          <DeviceGlyph icon={iconDef.icon} size={Math.round(dia * 0.44)} color={isOn ? onColor : theme.textMuted} isOn={isOn} />
        </TouchableOpacity>
        <Text style={styles.ringName} numberOfLines={2} ellipsizeMode="tail">{device.name || 'مفتاح بدون اسم'}</Text>
        <Text style={[styles.ringSub, { color: isOn ? onColor : theme.textMuted }]} numberOfLines={1}>
          {isOn ? 'قيد التشغيل' : 'مقفول'}
          {countdownLabel ? ` · ⏱ ${countdownLabel}` : scheduleActive ? ' · 🕐' : ''}
        </Text>
      </View>
    );
  }

  // ---- تخطيط Noir Champagne: كارت عمودي مدمج (أيقونة فوق، الاسم، ثم السويتش تحت) ----
  if (effectiveStyle === 'minimal') {
    // الكارت هادي عمدًا: حد شامبين ثابت وقت التشغيل، بدون نبض أو حركة مستمرة.
    const luxuryBorder = isOn ? (theme.accentSoft || '#D6B36A') : theme.border;
    const isSmall = cardSize === 'small';
    return (
      <Animated.View style={[styles.cardLuxury, { width: responsiveCardWidth, paddingVertical: isSmall ? 12 : 16, paddingHorizontal: isSmall ? 8 : 12, borderRadius: isSmall ? 18 : 22,
        backgroundColor: cardBg,
        borderColor: luxuryBorder,
        shadowColor: isOn ? onColor : '#000',
        shadowOpacity: isOn ? 0.22 : 0.03,
        shadowRadius: isOn ? 9 : 3,
      }]}>
        <TouchableOpacity onPress={onOpenTimer} style={styles.luxuryTimerCorner} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <MaterialCommunityIcons name={countdownLabel || scheduleActive ? 'timer' : 'timer-outline'} size={16} color={countdownLabel || scheduleActive ? theme.accentSoft : theme.textMuted} />
        </TouchableOpacity>
        <View style={[styles.luxuryIconV, isSmall && { width: 52, height: 52, borderRadius: 26 }, { backgroundColor: cardAltBg, borderColor: luxuryBorder }]}>
          {hasCustomPhoto(device) ? (
            <Image source={deviceImageSource(device, isOn)} style={styles.luxuryImage} resizeMode="cover" />
          ) : (
            <DeviceGlyph icon={iconDef.icon} size={isSmall ? 28 : 34} color={color} isOn={isOn && !isUpdown} />
          )}
        </View>
        <Text style={[styles.luxuryNameV, isSmall && { fontSize: 12.5, lineHeight: 18 }]} numberOfLines={2} ellipsizeMode="tail">{device.name || 'مفتاح بدون اسم'}</Text>
        <Text style={[styles.luxurySubV, { color: isOn ? theme.accentSoft : theme.textMuted }]} numberOfLines={1}>
          {isOn ? 'شغال' : 'متوقف'}
          {countdownLabel ? ` · ⏱ ${countdownLabel}` : scheduleActive ? ' · 🕐 مجدول' : ''}
        </Text>
        <View style={{ marginTop: 10 }}>
          <PremiumSwitch value={isOn} onValueChange={onToggle} theme={theme} activeColor={onColor} shape={switchShape} size={isSmall ? 0.82 : 0.95} />
        </View>
      </Animated.View>
    );
  }

  // ---- تخطيط "كلاسيك" (الافتراضي) ----
  return (
    <View style={[styles.card, { backgroundColor: cardBg, width: cardSize === 'large' ? '100%' : '48%', padding: cardSize === 'small' ? 10 : cardSize === 'large' ? 16 : 14, borderColor: isOn ? onColor : theme.border, borderWidth: isOn ? 1.3 : 1.0, overflow: 'hidden', shadowColor: isOn ? onColor : '#000', shadowOpacity: isOn ? 0.10 : 0.045, shadowRadius: isOn ? 7 : 4, elevation: isOn ? 5 : 2 }]}>
      <View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 5, backgroundColor: isOn && !isUpdown ? onColor : 'transparent' }} />
      <View style={styles.cardTopRow}>
        {!isUpdown && (
          <TouchableOpacity onPress={onOpenTimer}>
            <MaterialCommunityIcons
              name={countdownLabel || scheduleActive ? 'timer' : 'timer-outline'}
              size={16}
              color={countdownLabel || scheduleActive ? theme.accentSoft : theme.textSecondary}
            />
          </TouchableOpacity>
        )}
      </View>

      <TouchableOpacity
        style={styles.iconWrap}
        onPress={isUpdown ? undefined : onToggle}
        activeOpacity={isUpdown ? 1 : 0.7}
      >
        {isOn && !isUpdown && (
          <Animated.View
            pointerEvents="none"
            style={[
              styles.iconNeonHalo,
              {
                backgroundColor: color,
                shadowColor: color,
                opacity: glowOpacity.interpolate({ inputRange: [0.55, 1], outputRange: [0.22, 0.4] }),
                transform: [{ scale: glowScale.interpolate({ inputRange: [1, 1.08], outputRange: [1, 1.12] }) }],
              },
            ]}
          />
        )}
        <Animated.View
          style={[
            styles.iconGlow,
            {
              opacity: isOn && !isUpdown ? glowOpacity : 1,
              transform: [{ scale: isOn && !isUpdown ? glowScale : 1 }],
            },
          ]}
        >
          {hasCustomPhoto(device) ? (
            <Image source={deviceImageSource(device, isOn && !isUpdown)} style={styles.deviceRealImage} resizeMode="contain" />
          ) : (
            <DeviceGlyph icon={iconDef.icon} size={54} color={color} isOn={isOn && !isUpdown} />
          )}
        </Animated.View>
      </TouchableOpacity>

      <Text style={[styles.deviceName, cardSize === 'small' && { fontSize: 12, lineHeight: 17, minHeight: 51 }]} numberOfLines={3} ellipsizeMode="tail">
        {device.name}
      </Text>
      <Text style={styles.deviceTopic} numberOfLines={1}>
        {device.controlTopic}
      </Text>

      {!isUpdown && (countdownLabel || scheduleActive) && (
        <Text style={[styles.deviceTopic, { color: theme.accentSoft }]} numberOfLines={1}>
          {countdownLabel ? `⏱ باقي ${countdownLabel}` : '🕐 مجدول يوميًا'}
        </Text>
      )}

      {isUpdown ? (
        <>
          <View style={styles.updownRow}>
            <TouchableOpacity style={[styles.updownBtn, { backgroundColor: theme.accent }]} onPress={onUp}>
              <MaterialCommunityIcons name="chevron-up" size={20} color="#fff" />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.updownBtn, styles.updownStopBtn]} onPress={onStop}>
              <MaterialCommunityIcons name="stop" size={14} color={theme.textSecondary} />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.updownBtn, { backgroundColor: theme.danger }]} onPress={onDown}>
              <MaterialCommunityIcons name="chevron-down" size={20} color="#fff" />
            </TouchableOpacity>
          </View>
          {!!rawStatus && (
            <Text style={styles.deviceTopic} numberOfLines={1}>
              آخر حالة: {rawStatus}
            </Text>
          )}
        </>
      ) : (
        <TouchableOpacity
          style={[styles.pill, { borderColor: color, backgroundColor: isOn ? theme.cardAlt : theme.cardAlt }]}
          onPress={onToggle}
        >
          <View style={[styles.pillDot, { backgroundColor: color }]} />
          <Text style={[styles.pillText, { color }]}>{isOn ? 'ON' : 'OFF'}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

// صف اختيار لون: أول خيار "افتراضي" (لون الثيم)، وبعده باليتة الألوان الجاهزة
function ColorPickerRow({ styles, themeColor, value, onChange }) {
  return (
    <View style={styles.colorRow}>
      <TouchableOpacity
        style={[styles.colorSwatch, { backgroundColor: themeColor }, value === null && styles.colorSwatchSelected]}
        onPress={() => onChange(null)}
      >
        {value === null && <MaterialCommunityIcons name="check" size={14} color="#fff" />}
      </TouchableOpacity>
      {COLOR_SWATCHES.map((c) => (
        <TouchableOpacity
          key={c}
          style={[styles.colorSwatch, { backgroundColor: c }, value === c && styles.colorSwatchSelected]}
          onPress={() => onChange(c)}
        >
          {value === c && <MaterialCommunityIcons name="check" size={14} color="#0f1712" />}
        </TouchableOpacity>
      ))}
    </View>
  );
}

function getStyles(theme) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: theme.bg, padding: 18, paddingTop: 55 },
    headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
    back: { color: theme.accentSoft, fontSize: 15 },
    title: { color: theme.textPrimary, fontSize: 18, fontWeight: '700', fontFamily: FONTS.display },
    statusRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
    dot: { width: 10, height: 10, borderRadius: 5, marginRight: 8 },
    statusLabel: { color: theme.textSecondary, fontSize: 13 },
    btnRow: { flexDirection: 'row', gap: 10, marginBottom: 14 },
    smallBtn: { flex: 1, borderRadius: 10, paddingVertical: 12, alignItems: 'center' },
    onBtn: { backgroundColor: theme.accent },
    offBtn: { backgroundColor: theme.danger },
    emptyText: { color: theme.textSecondary, textAlign: 'center', marginTop: 20, marginBottom: 10, fontSize: 13, lineHeight: 20 },

    utilityRow: {
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
      gap: 48,
      paddingTop: 10,
      paddingBottom: 4,
    },
    utilityBtn: { alignItems: 'center', gap: 2, minWidth: 60 },
    utilityLabel: { fontSize: 11, fontWeight: '600' },
    emergencyLiveDot: {
      position: 'absolute',
      top: -2,
      right: -2,
      width: 8,
      height: 8,
      borderRadius: 4,
      backgroundColor: EMERGENCY_ON,
    },

    grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
    gridSizing: {
      small: {},
      medium: {},
      large: {},
    },
    list: { flexDirection: 'column' },

    // ---- تخطيط "قائمة أفقية" ----
    cardH: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      backgroundColor: hexToRgba(theme.card, 0.82),
      borderRadius: 20,
      borderWidth: 1.4,
      padding: 12,
      marginBottom: 12,
      overflow: 'hidden',
      shadowColor: '#000',
      shadowOpacity: 0.07,
      shadowRadius: 7,
      shadowOffset: { width: 0, height: 6 },
      elevation: 4,
    },
    hIconBadge: {
      width: 48,
      height: 48,
      borderRadius: 16,
      borderWidth: 1.25,
      alignItems: 'center',
      justifyContent: 'center',
      overflow: 'visible',
    },
    hIconWave: {
      position: 'absolute',
      borderWidth: 2,
      backgroundColor: 'transparent',
    },
    hDeviceImage: { width: 34, height: 34 },
    hName: { color: theme.textPrimary, fontSize: 14.5, fontWeight: '900', textAlign: 'right', flexShrink: 1, flexWrap: 'wrap', minWidth: 0, width: '100%', lineHeight: 20 },
    hSub: { fontSize: 11.5, marginTop: 2, textAlign: 'right' },
    hTimerBtn: { paddingHorizontal: 4 },
    hRainbowInner: { position: 'absolute', left: 3, right: 3, top: 3, bottom: 3, borderRadius: 17, borderWidth: 1.2 },

    // ---- تخطيط "فخم Glass" ----
    cardLuxury: {
      width: '100%',
      borderRadius: 24,
      borderWidth: 1.1,
      padding: 14,
      marginBottom: 13,
      shadowOffset: { width: 0, height: 5 },
      elevation: 3,
      overflow: 'hidden',
    },
    luxuryTop: { flexDirection: 'row', alignItems: 'center', gap: 11, marginBottom: 11 },
    luxuryIcon: { width: 58, height: 58, borderRadius: 18, borderWidth: 1.1, alignItems: 'center', justifyContent: 'center', overflow: 'visible' },
    luxuryImage: { width: '100%', height: '100%' },
    luxuryName: { color: theme.textPrimary, fontSize: 15, fontWeight: '900', textAlign: 'right', flexShrink: 1, flexWrap: 'wrap', minWidth: 0, width: '100%', lineHeight: 21 },
    luxurySub: { fontSize: 11.5, marginTop: 3, textAlign: 'right' },
    luxuryTimer: { width: 34, height: 34, borderRadius: 17, backgroundColor: theme.cardAlt, alignItems: 'center', justifyContent: 'center' },
    luxuryControl: { flexDirection: 'row', alignItems: 'center', gap: 12, borderRadius: 16, borderWidth: 1, paddingVertical: 10, paddingHorizontal: 12 },
    luxuryControlTitle: { fontSize: 12.5, fontWeight: '800', textAlign: 'right' },
    luxuryControlSub: { fontSize: 10.5, marginTop: 2, textAlign: 'right' },
    luxuryTimerCorner: { position: 'absolute', top: 10, left: 10, zIndex: 3 },
    luxuryIconV: { width: 64, height: 64, borderRadius: 32, overflow: 'hidden', borderWidth: 1.6, alignItems: 'center', justifyContent: 'center', marginBottom: 10 },
    luxuryNameV: { color: theme.textPrimary, fontSize: 14, fontWeight: '800', textAlign: 'center', lineHeight: 20, width: '100%' },
    luxurySubV: { fontSize: 11, marginTop: 3, textAlign: 'center' },

    // ---- فلاتر المفاتيح + أزرار تشغيل/إيقاف الكل (Noir Champagne) ----
    filterRow: { flexDirection: 'row', gap: 8, marginBottom: 12, backgroundColor: theme.card, borderRadius: 16, borderWidth: 1, borderColor: theme.border, padding: 4 },
    filterChip: { flex: 1, borderRadius: 12, paddingVertical: 9, alignItems: 'center' },
    filterChipActive: { backgroundColor: theme.accent },
    filterChipText: { color: theme.textSecondary, fontSize: 12.5, fontWeight: '700' },
    filterChipTextActive: { color: readableOn(theme.accent), fontWeight: '800' },
    allOnBtn: { flexDirection: 'row', gap: 6, justifyContent: 'center', backgroundColor: theme.accent, borderRadius: 14 },
    allOnText: { color: readableOn(theme.accent), fontWeight: '800', fontSize: 13.5 },
    allOffBtn: { flexDirection: 'row', gap: 6, justifyContent: 'center', backgroundColor: theme.card, borderWidth: 1, borderColor: theme.accentSoft, borderRadius: 14 },
    allOffText: { color: theme.accentSoft, fontWeight: '800', fontSize: 13.5 },

    ringTile: { alignItems: 'center', marginBottom: 20 },
    ringBtn: { borderWidth: 3, alignItems: 'center', justifyContent: 'center', shadowOffset: { width: 0, height: 0 } },
    ringName: { marginTop: 9, fontSize: 13, fontWeight: '700', textAlign: 'center', color: theme.textPrimary, lineHeight: 18 },
    ringSub: { fontSize: 11, marginTop: 2, textAlign: 'center' },
    card: {
      backgroundColor: hexToRgba(theme.card, 0.82),
      borderRadius: 26,
      borderWidth: 1.25,
      borderColor: hexToRgba(theme.accent, 0.48),
      width: '48%',
      padding: 14,
      shadowColor: '#000',
      shadowOpacity: 0.08,
      shadowRadius: 9,
      shadowOffset: { width: 0, height: 8 },
      elevation: 2,
      marginBottom: 12,
      alignItems: 'center',
    },
    cardTopRow: { flexDirection: 'row', justifyContent: 'flex-end', width: '100%' },
    iconWrap: { marginTop: 6, marginBottom: 12, alignItems: 'center', justifyContent: 'center' },
    // هالة ضوء ناعمة خلف اللوحة، بتظهر بس لما المفتاح شغال — إحساس إضاءة
    // فاخرة من غير ما تحدد شكل دائرة مقفولة حوالين الصورة.
    iconNeonHalo: {
      position: 'absolute',
      width: 104,
      height: 104,
      borderRadius: 32,
      shadowOffset: { width: 0, height: 0 },
      shadowOpacity: 1,
      shadowRadius: 22,
      elevation: 10,
      opacity: 0.5,
    },
    // مجرد حاوية شفافة لتحديد المساحة والمحاذاة — مفيش إطار ولا خلفية ولا
    // ظل حوالين الأيقونة، عشان أي أيقونة (مش صورة مربعة بس) تبان طبيعية.
    iconGlow: {
      width: 84,
      height: 84,
      alignItems: 'center',
      justifyContent: 'center',
    },
    deviceName: { color: theme.textPrimary, fontSize: 14, fontWeight: '800', textAlign: 'center', lineHeight: 21, minHeight: 42, width: '100%', paddingHorizontal: 3, flexShrink: 0, flexWrap: 'wrap' },
    deviceTopic: { color: theme.textMuted, fontSize: 10, marginBottom: 6, textAlign: 'center' },
    pill: {
      flexDirection: 'row',
      alignItems: 'center',
      borderWidth: 1,
      borderRadius: 20,
      paddingHorizontal: 14,
      paddingVertical: 6,
      gap: 6,
      marginTop: 4,
    },
    pillDot: { width: 8, height: 8, borderRadius: 4 },
    pillText: { fontSize: 12, fontWeight: '700' },

    updownRow: { flexDirection: 'row', gap: 8, marginTop: 4, marginBottom: 4 },
    updownBtn: {
      width: 40,
      height: 34,
      borderRadius: 10,
      alignItems: 'center',
      justifyContent: 'center',
    },
    updownStopBtn: { backgroundColor: theme.cardAlt, borderWidth: 1, borderColor: theme.border },

    addBtn: { borderWidth: 1, borderColor: theme.accent, borderRadius: 12, paddingVertical: 14, alignItems: 'center', marginTop: 6 },
    addBtnText: { color: theme.accentSoft, fontWeight: '700', fontSize: 15 },
    discoverBtn: { borderColor: theme.accentSoft },
    discoverBtnText: { color: theme.accentSoft, fontWeight: '700', fontSize: 15 },
    listeningHint: { color: theme.accentSoft, fontSize: 11, marginBottom: 10, textAlign: 'center' },
    syncRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 6, marginBottom: 4 },
    discoveredRow: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: theme.bg,
      borderRadius: 10,
      padding: 10,
      marginBottom: 8,
      borderWidth: 1,
      borderColor: theme.border,
    },
    discoveredRowSelected: { borderColor: theme.accent },
    discoveredTopic: { color: theme.textPrimary, fontSize: 13, fontWeight: '600' },
    discoveredPayload: { color: theme.textSecondary, fontSize: 11, marginTop: 2 },

    tabRow: { flexDirection: 'row', gap: 8, marginBottom: 12 },
    tabBtn: { flex: 1, borderRadius: 10, paddingVertical: 10, alignItems: 'center', backgroundColor: theme.bg, borderWidth: 1, borderColor: theme.border },
    tabBtnActive: { backgroundColor: theme.accent, borderColor: theme.accent },
    tabBtnText: { color: theme.textSecondary, fontSize: 12, fontWeight: '700' },
    tabBtnTextActive: { color: '#fff' },
    codeBox: { backgroundColor: theme.bg, borderRadius: 10, padding: 10, marginBottom: 8, borderWidth: 1, borderColor: theme.border },
    codeText: { color: theme.accentSoft, fontSize: 11, fontFamily: 'monospace' },
    errorText: { color: theme.off, fontSize: 12, marginBottom: 8, textAlign: 'center' },

    colorRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 4, marginBottom: 4 },
    colorSwatch: {
      width: 30,
      height: 30,
      borderRadius: 15,
      alignItems: 'center',
      justifyContent: 'center',
      borderWidth: 2,
      borderColor: 'transparent',
    },
    colorSwatchSelected: { borderColor: theme.textPrimary },

    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.3)', justifyContent: 'center', padding: 20 },
    modalBox: { backgroundColor: theme.cardAlt, borderRadius: 16, padding: 16, maxHeight: '85%' },
    modalTitle: { color: theme.textPrimary, fontSize: 16, fontWeight: '700', marginBottom: 10, textAlign: 'center' },
    label: { color: theme.textSecondary, fontSize: 12, marginTop: 10, marginBottom: 6 },
    hint: { color: theme.textMuted, fontSize: 10, marginTop: 4 },
    input: { backgroundColor: theme.bg, color: theme.textPrimary, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10 },
    iconOption: { width: '25%', alignItems: 'center', paddingVertical: 8, paddingHorizontal: 3, borderRadius: 14 },
    iconOptionSelected: { backgroundColor: hexToRgba(theme.on, 0.10), borderWidth: 1, borderColor: theme.on },
    iconOptionGlass: {
      width: 42,
      height: 42,
      borderRadius: 21,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: hexToRgba(theme.cardAlt, 0.6),
      borderWidth: 1,
      borderColor: hexToRgba(theme.border, 0.8),
      overflow: 'hidden',
    },
    iconOptionGlassSelected: {
      backgroundColor: hexToRgba(theme.on, 0.18),
      borderColor: theme.on,
      shadowColor: theme.on,
      shadowOpacity: 0.9,
      shadowRadius: 10,
      shadowOffset: { width: 0, height: 0 },
      elevation: 6,
    },
    iconOptionLabel: { color: theme.textPrimary, fontSize: 9, marginTop: 4, textAlign: 'center', fontWeight: '600' },
    deviceImagePreviewRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      marginTop: 4,
      marginBottom: 10,
    },
    deviceImageStatesRow: {
      flexDirection: 'row',
      justifyContent: 'space-around',
      gap: 12,
      marginTop: 8,
      marginBottom: 10,
    },
    deviceImageStateCol: { alignItems: 'center', flex: 1 },
    deviceImageStateLabel: { color: theme.textSecondary, fontSize: 11, fontWeight: '700', marginBottom: 6, textAlign: 'center' },
    deviceImagePreview: {
      width: 64,
      height: 64,
      borderRadius: 14,
      backgroundColor: hexToRgba(theme.cardAlt, 0.6),
      borderWidth: 1,
      borderColor: hexToRgba(theme.border, 0.8),
      marginBottom: 4,
    },
    imagePickBtn: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
      paddingVertical: 4,
    },
    imagePickBtnText: { color: theme.textPrimary, fontSize: 11, fontWeight: '600' },
    iconOptionImage: { width: 68, height: 68 },
    iconOptionImageSmall: { width: 64, height: 64 },
    iconStatePair: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 2 },
    iconStateCell: { alignItems: 'center', justifyContent: 'center' },
    iconStateImage: { width: 29, height: 29 },
    iconStateTiny: { fontSize: 6, fontWeight: '800', color: theme.textMuted, marginTop: -1 },
    shapeListImage: { width: 38, height: 38, borderRadius: 10 },
    deviceRealImage: { width: 84, height: 84 },

    shapeListRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10,
      paddingVertical: 12,
      paddingHorizontal: 12,
      marginBottom: 8,
      borderRadius: 16,
      backgroundColor: theme.cardAlt,
    },
    shapeListMain: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12 },
    shapeListAction: { padding: 6 },
    shapeListIconWrap: {
      width: 38,
      height: 38,
      borderRadius: 19,
      backgroundColor: hexToRgba(theme.cardAlt, 0.6),
      borderWidth: 1,
      borderColor: hexToRgba(theme.border, 0.8),
      alignItems: 'center',
      justifyContent: 'center',
    },
    shapeListName: { flex: 1, color: theme.textPrimary, fontSize: 14, fontWeight: '600' },
  });
}
