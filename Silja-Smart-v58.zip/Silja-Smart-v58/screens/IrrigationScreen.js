import React, { useEffect, useRef, useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  TextInput,
  StyleSheet,
} from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FONTS } from '../fonts';
import { showAlert } from '../components/PremiumAlert';
import { showToast } from '../components/Toast';
import PremiumSwitch from '../components/PremiumSwitch';
import { useTheme } from '../ThemeContext';
import ConnectionStatusBanner from '../components/ConnectionStatusBanner';
import ScreenBackground from '../components/ScreenBackground';
import ScreenHeader from '../components/ScreenHeader';
import PulseRings from '../components/PulseRings';
import { LinearGradient } from 'expo-linear-gradient';
import { withAlpha } from '../colorUtils';
import { readableOn } from '../colorUtils';

const ZONE_NAMES = ['المنطقة 1', 'المنطقة 2', 'المنطقة 3', 'المنطقة 4'];

function TimeBadge({ icon, value, unit, color, bg, border }) {
  return (
    <View style={[styles.timeBadge, { backgroundColor: bg, borderColor: border }]}>
      <Text style={styles.timeBadgeIcon}>{icon}</Text>
      <Text style={[styles.timeBadgeValue, { color }]}>{value}</Text>
      {!!unit && <Text style={[styles.timeBadgeUnit, { color }]}>{unit}</Text>}
    </View>
  );
}

export default function IrrigationScreen({ board, client, connected, onBack }) {
  const { theme } = useTheme();
  const base = board.prefix;
  const cardBorder = theme.isLight ? theme.border : 'rgba(214,179,106,0.18)';
  const [tab, setTab] = useState('manual'); // manual | timers

  const [available, setAvailable] = useState(null);
  const [statusText, setStatusText] = useState('');
  const [status, setStatus] = useState({
    running: false,
    current_relay: 0,
    completed_cycles: 0,
    target_cycles: 1,
    remaining_minutes: 0,
    durations_min: [10, 10, 10, 10],
    manual_on: [0, 0, 0, 0],
    manual_remaining_sec: [0, 0, 0, 0],
  });
  const [manualMinutes, setManualMinutes] = useState(['10', '10', '10', '10']);
  const [durationInputs, setDurationInputs] = useState(['10', '10', '10', '10']);
  const [cyclesInput, setCyclesInput] = useState('1');

  // البورد بيبعت حالة عبر MQTT كل 30 ثانية بس، فلو عرضنا manual_remaining_sec
  // زي ما هو هيقف على نفس الرقم لمدة نص دقيقة. عشان يحس المستخدم إنه فعلاً
  // بيشوف عداد حي (زي التحكم المباشر في البورد)، بنسجل وقت وصول آخر رسالة
  // حالة، وبنعمل تيك كل ثانية محليًا نطرح بيه الوقت اللي عدى من الرقم الأخير.
  const lastStatusAtRef = useRef(Date.now());
  const [, forceTick] = useState(0);

  useEffect(() => {
    const id = setInterval(() => forceTick((t) => t + 1), 1000);
    return () => clearInterval(id);
  }, []);

  const remainingSecForZone = (i) => {
    const baseSec = status.manual_remaining_sec?.[i] || 0;
    if (!status.manual_on[i] || baseSec <= 0) return 0;
    const elapsed = Math.floor((Date.now() - lastStatusAtRef.current) / 1000);
    return Math.max(0, baseSec - elapsed);
  };

  const fmtTime = (s) => {
    const sec = Math.max(0, Math.floor(s));
    const m = Math.floor(sec / 60);
    const r = sec % 60;
    return `${String(m).padStart(2, '0')}:${String(r).padStart(2, '0')}`;
  };

  const stepCycles = (delta) => {
    const cur = parseInt(cyclesInput, 10) || 1;
    setCyclesInput(String(Math.max(1, cur + delta)));
  };

  // أول رسالة حالة توصل من الفيرموير، نملى بيها خانات "عدد الدورات" و"مدة
  // كل منطقة" بالقيم الحقيقية المحفوظة على البورد (مش القيم الافتراضية
  // الثابتة اللي التطبيق بيفتح بيها) — عشان لو المستخدم فاتح الشاشة يلاقي
  // القيم الفعلية على طول، مش أرقام وهمية لازم يمسحها الأول. بعد أول
  // مزامنة بس، عشان لو المستخدم بيكتب رقم جديد لسه ما ضغطش "حفظ"، رسايل
  // الحالة الدورية (كل 30 ثانية) متمسحش كتابته.
  const syncedInputsRef = useRef(false);
  // "جاري الإرسال…": بتفضل لحد ما توصل حالة جديدة من البورد (أو 4 ثواني بالكتير)
  const [sending, setSending] = useState(false);
  const sendingTimerRef = useRef(null);
  const commandCooldownRef = useRef({});

  useEffect(() => {
    if (!client) return undefined;

    const topics = [`${base}/status`, `${base}/status_text`, `${base}/availability`];
    topics.forEach((t) => client.subscribe(t));

    const handler = (topic, payload) => {
      const msg = payload.toString();
      if (topic === `${base}/status`) {
        try {
          const parsed = JSON.parse(msg);
          setStatus((prev) => ({ ...prev, ...parsed }));
          clearTimeout(sendingTimerRef.current);
          setSending(false);
          lastStatusAtRef.current = Date.now();
          if (!syncedInputsRef.current) {
            syncedInputsRef.current = true;
            if (Array.isArray(parsed.durations_min) && parsed.durations_min.length === 4) {
              setDurationInputs(parsed.durations_min.map((v) => String(v)));
            }
            if (typeof parsed.target_cycles === 'number') {
              setCyclesInput(String(parsed.target_cycles));
            }
          }
        } catch (e) {
          // ignore malformed payload
        }
      } else if (topic === `${base}/status_text`) {
        setStatusText(msg);
      } else if (topic === `${base}/availability`) {
        setAvailable(msg);
      }
    };

    client.on('message', handler);
    return () => {
      client.off('message', handler);
      topics.forEach((t) => client.unsubscribe(t));
    };
  }, [client, base]);

  // كل أوامر الري متوقفة أثناء انقطاع MQTT. حارس قصير يمنع إرسال نفس الأمر
  // عدة مرات بسبب الضغط المتكرر، مع الحفاظ على نفس الـ Topics والـ payloads.
  const publish = (subtopic, payload = '') => {
    if (!client || !connected) {
      showAlert('الاتصال غير متاح', 'أوامر الري متوقفة حتى يتصل التطبيق بالسيرفر.');
      return false;
    }
    const now = Date.now();
    const previous = commandCooldownRef.current[subtopic] || 0;
    if (now - previous < 600) return false;
    commandCooldownRef.current[subtopic] = now;
    try {
      client.publish(`${base}/${subtopic}`, String(payload), { qos: 1 }, (error) => {
        if (error) showAlert('فشل إرسال الأمر', 'السيرفر لم يستقبل أمر الري. راجع الاتصال وحاول مرة أخرى.');
        else {
          showToast('تم الإرسال');
          setSending(true);
          clearTimeout(sendingTimerRef.current);
          sendingTimerRef.current = setTimeout(() => setSending(false), 4000);
        }
      });
      return true;
    } catch (error) {
      showAlert('فشل إرسال الأمر', error?.message || 'تعذر إرسال أمر الري.');
      return false;
    }
  };

  const startAuto = () => publish('cmd/start');
  const stopAll = () => publish('cmd/stop');
  const emergencyStop = () => {
    showAlert('إيقاف طوارئ', 'هيوقف كل المحابس فورًا. متأكد؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'إيقاف الآن', style: 'destructive', onPress: () => publish('cmd/emergency') },
    ]);
  };
  const applyCycles = () => {
    const v = parseInt(cyclesInput, 10);
    if (!Number.isFinite(v) || v < 1) {
      showAlert('عدد غير صحيح', 'لازم يكون عدد الدورات 1 على الأقل (مفيش وضع لا نهائي دلوقتي، للأمان).');
      return;
    }
    publish('cmd/cycles', v);
  };
  const applyDuration = (i) => {
    const minutes = Number(durationInputs[i]);
    if (!Number.isInteger(minutes) || minutes < 1 || minutes > 1440) {
      showAlert('مدة غير صحيحة', 'اكتب مدة من دقيقة واحدة إلى 1440 دقيقة.');
      return;
    }
    publish(`cmd/duration/${i + 1}`, String(minutes));
  };
  const manualOn = (i) => {
    const minutes = Number(manualMinutes[i]);
    if (!Number.isInteger(minutes) || minutes < 1 || minutes > 1440) {
      showAlert('مدة غير صحيحة', 'اكتب مدة تشغيل من دقيقة واحدة إلى 1440 دقيقة.');
      return;
    }
    publish(`cmd/manual/${i + 1}/on`, String(minutes));
  };
  const manualOff = (i) => publish(`cmd/manual/${i + 1}/off`);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <ScreenBackground theme={theme} />
      <ScreenHeader title={board.name} onBack={onBack} />

      <ConnectionStatusBanner theme={theme} connected={!!connected} detail={connected ? (available === 'online' ? 'السيرفر متصل والبورد متاح.' : available === 'offline' ? 'السيرفر متصل لكن البورد معلن أنه غير متصل.' : 'السيرفر متصل؛ ننتظر حالة البورد.') : 'لن تُرسل أوامر للري أثناء انقطاع الاتصال.'} />

      <View style={styles.statusRow}>
        <View style={[styles.dot, { backgroundColor: connected ? theme.on : theme.off }]} />
        <Text style={[styles.statusLabel, { color: theme.textSecondary }]}>
          {connected ? 'متصل بالسيرفر' : 'غير متصل — أوامر الري متوقفة'}
          {available ? `  •  البورد: ${available === 'online' ? 'أونلاين' : 'أوفلاين'}` : ''}
          {sending ? '  •  جاري الإرسال…' : ''}
        </Text>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 130 }}>
        {!!statusText && (
          <View style={[styles.card, { backgroundColor: theme.card, borderColor: cardBorder }]}>
            <Text style={[styles.statusText, { color: theme.textPrimary }]}>{statusText}</Text>
          </View>
        )}

        <View style={[styles.tabsRow, { backgroundColor: theme.card, borderColor: theme.border }]}>
          {[['timers', 'المؤقتات'], ['manual', 'التحكم اليدوي']].map(([key, label]) => (
            <TouchableOpacity
              key={key}
              onPress={() => setTab(key)}
              style={[styles.tabBtn, tab === key && { backgroundColor: theme.accentSoft }]}
            >
              <Text style={[styles.tabText, { color: tab === key ? readableOn(theme.accentSoft) : theme.textSecondary }]}>{label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {tab === 'manual' && (
          <>
            <View style={styles.heroWrap}>
              <View style={{ width: 128, height: 128, alignItems: 'center', justifyContent: 'center' }}>
                <PulseRings
                  active={!!(status.running || status.manual_on.some((v) => !!v))}
                  color={theme.on}
                  size={128}
                  rings={3}
                  duration={2600}
                  maxScale={1.55}
                />
                <LinearGradient
                  colors={[withAlpha(theme.accentSoft, status.running || status.manual_on.some((v) => !!v) ? 0.32 : 0.14), withAlpha(theme.accentSoft, 0.03)]}
                  start={{ x: 0.2, y: 0 }}
                  end={{ x: 0.8, y: 1 }}
                  style={[styles.heroCircle, { borderColor: status.running || status.manual_on.some((v) => !!v) ? theme.on : theme.accentSoft, backgroundColor: theme.cardAlt, shadowColor: theme.on, shadowOpacity: status.running || status.manual_on.some((v) => !!v) ? 0.45 : 0, shadowRadius: 16, shadowOffset: { width: 0, height: 0 }, elevation: 6 }]}
                >
                  <MaterialCommunityIcons name="water" size={52} color={status.running || status.manual_on.some((v) => !!v) ? theme.on : theme.accentSoft} />
                </LinearGradient>
              </View>
              <Text style={[styles.heroTitle, { color: theme.accentSoft }]}>
                {status.running || status.manual_on.some((v) => !!v) ? 'الري شغال' : 'الري متوقف'}
              </Text>
              <Text style={[styles.heroSub, { color: theme.textSecondary }]}>إجمالي المناطق: {ZONE_NAMES.length}</Text>
            </View>

            <View style={styles.zoneGrid}>
              {ZONE_NAMES.map((name, i) => {
                const isOn = !!status.manual_on[i];
                const remain = remainingSecForZone(i);
                return (
                  <View style={[styles.zoneTile, { backgroundColor: theme.card, borderColor: isOn ? theme.on : cardBorder }]} key={i}>
                    <View style={styles.zoneTileTop}>
                      <View style={[styles.zoneTileIcon, { backgroundColor: theme.cardAlt }]}>
                        <MaterialCommunityIcons name="water-outline" size={22} color={isOn ? theme.on : theme.accentSoft} />
                      </View>
                      <PremiumSwitch
                        value={isOn}
                        onValueChange={() => (isOn ? manualOff(i) : manualOn(i))}
                        theme={theme}
                        activeColor={theme.on}
                      />
                    </View>
                    <Text style={[styles.zoneName, { color: theme.textPrimary }]} numberOfLines={1}>{name}</Text>
                    <Text style={[styles.zoneTileSub, { color: isOn ? theme.on : theme.textMuted }]}>
                      {isOn ? (remain > 0 ? `شغالة • ${fmtTime(remain)}` : 'شغالة') : 'متوقفة'}
                    </Text>
                    <View style={styles.zoneMinutesRow}>
                      <Text style={[styles.label, { color: theme.textSecondary }]}>دقائق</Text>
                      <TextInput
                        style={[styles.smallInput, { backgroundColor: theme.cardAlt, color: theme.textPrimary }]}
                        keyboardType="numeric"
                        value={manualMinutes[i]}
                        onChangeText={(v) => {
                          const arr = [...manualMinutes];
                          arr[i] = v;
                          setManualMinutes(arr);
                        }}
                      />
                    </View>
                  </View>
                );
              })}
            </View>
          </>
        )}

        {tab === 'timers' && (
          <>
            <Text style={[styles.sectionTitle, { color: theme.accentSoft }]}>الوضع التلقائي</Text>
        <View style={[styles.card, { backgroundColor: theme.card, borderColor: cardBorder }]}>
          <View style={styles.autoTopRow}>
            <View style={styles.autoInfoCol}>
              <Text style={[styles.rowText, { color: theme.textPrimary }]}>
                المنطقة الشغالة الآن: {status.current_relay > 0 ? ZONE_NAMES[status.current_relay - 1] : 'لا يوجد'}
              </Text>
              <View style={styles.progressWrap}>
                <View style={[styles.progressTrack, { backgroundColor: theme.cardAlt }]}>
                  <View
                    style={[
                      styles.progressFill,
                      {
                        backgroundColor: theme.accent,
                        width: `${status.target_cycles ? Math.min(100, (status.completed_cycles / status.target_cycles) * 100) : 0}%`,
                      },
                    ]}
                  />
                </View>
                <Text style={[styles.progressLabel, { color: theme.textSecondary }]}>
                  دورة {status.completed_cycles} من {status.target_cycles}
                </Text>
              </View>
            </View>

            {status.running && (
              <TimeBadge
                icon="⏱"
                value={String(status.remaining_minutes)}
                unit="دقيقة"
                color={theme.accentSoft}
                bg={theme.cardAlt}
                border={theme.border}
              />
            )}
          </View>

          <View style={styles.btnRow}>
            <TouchableOpacity style={[styles.smallBtn, { backgroundColor: theme.accent }]} onPress={startAuto}>
              <Text style={[styles.btnText, { color: readableOn(theme.accent) }]}>ابدأ تلقائي</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.smallBtn, { backgroundColor: theme.danger }]} onPress={stopAll}>
              <Text style={[styles.btnText, { color: readableOn(theme.danger) }]}>إيقاف الكل</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.cyclesSetRow}>
            <Text style={[styles.label, { color: theme.textSecondary }]}>عدد الدورات المطلوبة</Text>
            <View style={styles.stepperGroup}>
              <View style={[styles.stepper, { backgroundColor: theme.cardAlt, borderColor: theme.border }]}>
                <TouchableOpacity style={styles.stepperBtn} onPress={() => stepCycles(-1)}>
                  <Text style={[styles.stepperBtnText, { color: theme.accent }]}>−</Text>
                </TouchableOpacity>
                <TextInput
                  style={[styles.stepperInput, { color: theme.textPrimary }]}
                  keyboardType="numeric"
                  value={cyclesInput}
                  onChangeText={setCyclesInput}
                  textAlign="center"
                />
                <TouchableOpacity style={styles.stepperBtn} onPress={() => stepCycles(1)}>
                  <Text style={[styles.stepperBtnText, { color: theme.accent }]}>+</Text>
                </TouchableOpacity>
              </View>
              <TouchableOpacity style={[styles.applyBtn, { backgroundColor: theme.accent }]} onPress={applyCycles}>
                <Text style={[styles.btnText, { color: readableOn(theme.accent) }]}>تطبيق</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

            <Text style={[styles.sectionTitle, { color: theme.accentSoft }]}>مدة كل منطقة</Text>
            <View style={[styles.card, { backgroundColor: theme.card, borderColor: cardBorder }]}>
              {ZONE_NAMES.map((name, i) => (
                <View key={i}>
                  <Text style={[styles.zoneName, { color: theme.textPrimary, marginTop: i ? 12 : 0 }]}>{name}</Text>
              <View style={styles.inlineRow}>
                <Text style={[styles.label, { color: theme.textSecondary }]}>مدة الوضع التلقائي (دقايق):</Text>
                <TextInput
                  style={[styles.smallInput, { backgroundColor: theme.cardAlt, color: theme.textPrimary }]}
                  keyboardType="numeric"
                  value={durationInputs[i]}
                  onChangeText={(v) => {
                    const arr = [...durationInputs];
                    arr[i] = v;
                    setDurationInputs(arr);
                  }}
                />
                <TouchableOpacity style={[styles.tinyBtn, { backgroundColor: theme.accent }]} onPress={() => applyDuration(i)}>
                  <Text style={[styles.btnText, { color: readableOn(theme.accent) }]}>حفظ</Text>
                </TouchableOpacity>
              </View>
                </View>
              ))}
            </View>
          </>
        )}

        <TouchableOpacity style={[styles.emergencyBtn, { backgroundColor: theme.danger }]} onPress={emergencyStop}>
          <Text style={[styles.emergencyText, { color: readableOn(theme.danger) }]}>⛔ إيقاف طوارئ فوري</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 20, paddingTop: 48 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14, minHeight: 48, paddingBottom: 12 },
  back: { fontSize: 15 },
  title: { fontSize: 21, fontWeight: '800', fontFamily: FONTS.display },
  statusRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  dot: { width: 10, height: 10, borderRadius: 5, marginEnd: 8 },
  statusLabel: { fontSize: 13 },
  statusText: { fontSize: 14, textAlign: 'center' },
  sectionTitle: { fontSize: 15, fontWeight: '700', marginTop: 6, marginBottom: 8 },
  card: { borderRadius: 21, padding: 18, marginBottom: 15, borderWidth: 1, shadowColor: '#000', shadowOpacity: 0.12, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 2 },
  rowText: { fontSize: 14, marginBottom: 4 },

  // ---- الوضع التلقائي: صف علوي (تقدم الدورات + بادج الوقت) ----
  autoTopRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },
  autoInfoCol: { flex: 1 },
  progressWrap: { marginTop: 10 },
  progressTrack: { height: 8, borderRadius: 5, overflow: 'hidden' },
  progressFill: { height: 8, borderRadius: 5 },
  progressLabel: { fontSize: 12, marginTop: 6 },

  // ---- ستيبر عدد الدورات ----
  cyclesSetRow: { marginTop: 14 },
  stepperGroup: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 8 },
  stepper: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 10,
    borderWidth: 1,
    overflow: 'hidden',
  },
  stepperBtn: { paddingHorizontal: 14, paddingVertical: 8 },
  stepperBtnText: { fontSize: 18, fontWeight: '700' },
  stepperInput: { width: 46, textAlign: 'center', fontSize: 15, fontWeight: '700' },
  applyBtn: { borderRadius: 14, paddingHorizontal: 18, paddingVertical: 12 },

  // ---- بادج الوقت (مستخدم في الوضع التلقائي واليدوي بنفس الشكل) ----
  timeBadge: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 4,
    borderRadius: 12,
    borderWidth: 1.5,
    paddingHorizontal: 14,
    paddingVertical: 8,
  },
  timeBadgeIcon: { fontSize: 13, marginRight: 2 },
  timeBadgeValue: { fontSize: 20, fontWeight: '800', letterSpacing: 1 },
  timeBadgeUnit: { fontSize: 12, fontWeight: '600' },
  timeBadgeCenterWrap: { alignItems: 'center', marginBottom: 12, marginTop: 2 },

  // ---- تابات + هيرو الري + شبكة المناطق ----
  tabsRow: { flexDirection: 'row', borderRadius: 16, borderWidth: 1, padding: 4, marginBottom: 14 },
  tabBtn: { flex: 1, paddingVertical: 10, borderRadius: 12, alignItems: 'center' },
  tabText: { fontSize: 14, fontWeight: '800' },
  heroWrap: { alignItems: 'center', marginVertical: 14 },
  heroCircle: { width: 128, height: 128, borderRadius: 64, borderWidth: 2, alignItems: 'center', justifyContent: 'center' },
  heroTitle: { fontSize: 20, fontWeight: '800', marginTop: 12, fontFamily: FONTS.display },
  heroSub: { fontSize: 13, marginTop: 4 },
  zoneGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', rowGap: 12, marginBottom: 6 },
  zoneTile: { width: '48%', borderRadius: 20, borderWidth: 1, padding: 14 },
  zoneTileTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  zoneTileIcon: { width: 40, height: 40, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  zoneTileSub: { fontSize: 12, marginTop: 3, fontWeight: '600' },
  zoneMinutesRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 10 },

  // ---- هيدر كارت المنطقة ----
  zoneHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 },
  zoneNameCol: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  zoneIcon: { marginRight: 2 },
  zoneName: { fontSize: 16, fontWeight: '600' },
  zoneRightCol: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  statusDot: { width: 7, height: 7, borderRadius: 4 },
  statusPillText: { fontSize: 12, fontWeight: '700' },

  btnRow: { flexDirection: 'row', gap: 10, marginTop: 14, marginBottom: 4 },
  inlineRow: { flexDirection: 'row', alignItems: 'center', marginTop: 10, flexWrap: 'wrap', gap: 8 },
  label: { fontSize: 12 },
  smallInput: {
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 6,
    width: 60,
    textAlign: 'center',
  },
  smallBtn: { flex: 1, borderRadius: 10, paddingVertical: 10, alignItems: 'center' },
  tinyBtn: { borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6 },
  emergencyBtn: { borderRadius: 14, paddingVertical: 16, alignItems: 'center', marginTop: 10 },
  emergencyText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  btnText: { color: '#fff', fontWeight: '600', fontSize: 13 },
});
