import React, { useEffect, useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, TextInput, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import TouchableOpacity from '../components/AnimatedTouchable';
import { useTheme } from '../ThemeContext';
import { getDeviceIcon } from '../deviceIcons';
import { boardAvailabilityTopic, parseAvailability } from '../discovery';
import ConnectionStatusBanner from '../components/ConnectionStatusBanner';
import { FONTS } from '../fonts';
import ScreenBackground from '../components/ScreenBackground';
import { readableOn } from '../colorUtils';
import { LinearGradient } from 'expo-linear-gradient';
import DeviceGlyph from '../components/DeviceGlyph';
import EmptyState from '../components/EmptyState';

export default function DevicesScreen({ boards = [], client, connected = false, onOpenBoard, onBack }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);
  const devices = boards.flatMap((board) => (board.devices || []).map((device) => ({ ...device, board })));
  const [availability, setAvailability] = useState({});
  const [states, setStates] = useState({});
  const [selected, setSelected] = useState(null);
  // حالة البورد: availability الصريحة أولًا، وإلا لو وصلت أي حالة من مفاتيحه يبقى متصل فعلًا.
  const boardState = (board) => {
    const a = availability[boardAvailabilityTopic(board)];
    if (a === 'offline') return 'offline';
    if (a === 'online') return 'online';
    return (board.devices || []).some((d) => states[d.statusTopic || d.controlTopic] !== undefined) ? 'online' : null;
  };
  const [selectedBoardId, setSelectedBoardId] = useState('all');
  const [query, setQuery] = useState('');
  const q = query.trim().toLowerCase();
  const visibleDevices = (selectedBoardId === 'all' ? devices : devices.filter((device) => String(device.board.id) === String(selectedBoardId)))
    .filter((device) => !q || String(device.name || '').toLowerCase().includes(q) || String(device.board?.name || '').toLowerCase().includes(q));

  useEffect(() => {
    if (!client || !connected) { setAvailability({}); return undefined; }
    const topics = boards.map(boardAvailabilityTopic).filter(Boolean);
    topics.forEach((t) => client.subscribe(t));
    const handler = (topic, payload) => {
      const state = parseAvailability(payload.toString());
      if (state) setAvailability((prev) => ({ ...prev, [topic]: state }));
    };
    client.on('message', handler);
    return () => { client.off('message', handler); topics.forEach((t) => client.unsubscribe(t)); };
  }, [client, connected, boards]);

  useEffect(() => {
    if (!client || !connected) { setStates({}); return undefined; }
    const topics = Array.from(new Set(devices.map((d) => d.statusTopic || d.controlTopic).filter(Boolean)));
    topics.forEach((t) => client.subscribe(t));
    const handler = (topic, payload) => {
      const raw = payload.toString().trim();
      let value = raw.toUpperCase();
      try { const data = JSON.parse(raw); value = String(data.state ?? data.status ?? data.value ?? data.on ?? '').toUpperCase(); } catch (_) {}
      if (value === 'ON' || value === '1' || value === 'TRUE') setStates((p) => ({ ...p, [topic]: true }));
      if (value === 'OFF' || value === '0' || value === 'FALSE') setStates((p) => ({ ...p, [topic]: false }));
    };
    client.on('message', handler);
    return () => { client.off('message', handler); topics.forEach((t) => client.unsubscribe(t)); };
  }, [client, connected, boards, devices.length]);

  return (
    <SafeAreaView style={styles.safe}>
      <ScreenBackground theme={theme} />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <TouchableOpacity onPress={onBack} style={styles.back} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <MaterialCommunityIcons name="chevron-right" size={26} color={theme.accentSoft} />
          </TouchableOpacity>
          <Text style={styles.title}>الأجهزة</Text>
          <View style={styles.back} />
        </View>

        <ConnectionStatusBanner theme={theme} connected={connected} detail={connected ? 'حالة كل بورد وجهاز تظهر بشكل منفصل.' : undefined} />

        {devices.length > 0 && (
          <View style={styles.searchBox}>
            <MaterialCommunityIcons name="magnify" size={19} color={theme.textMuted} />
            <TextInput
              style={styles.searchInput}
              value={query}
              onChangeText={setQuery}
              placeholder="بحث عن جهاز..."
              placeholderTextColor={theme.textMuted}
              textAlign="right"
            />
          </View>
        )}

        {devices.length > 0 && (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.roomFilters}>
            <TouchableOpacity onPress={() => setSelectedBoardId('all')} style={[styles.roomChip, selectedBoardId === 'all' && styles.roomChipActive]}>
              <MaterialCommunityIcons name="view-grid-outline" size={15} color={selectedBoardId === 'all' ? readableOn(theme.accent) : theme.textSecondary} />
              <Text style={[styles.roomChipText, selectedBoardId === 'all' && styles.roomChipTextActive]}>كل الأجهزة</Text>
            </TouchableOpacity>
            {boards.map((board) => (
              <TouchableOpacity key={String(board.id)} onPress={() => setSelectedBoardId(String(board.id))} style={[styles.roomChip, String(selectedBoardId) === String(board.id) && styles.roomChipActive]}>
                <MaterialCommunityIcons name="home-outline" size={15} color={String(selectedBoardId) === String(board.id) ? readableOn(theme.accent) : theme.textSecondary} />
                <Text style={[styles.roomChipText, String(selectedBoardId) === String(board.id) && styles.roomChipTextActive]} numberOfLines={1}>{board.name || 'غرفة'}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        )}

        {devices.length === 0 ? (
          <EmptyState icon="devices" title="لا توجد أجهزة" text="أضف بوردًا ثم أضف المفاتيح والأجهزة الخاصة به." />
        ) : visibleDevices.length === 0 ? (
          <EmptyState icon="home-search-outline" title="لا توجد أجهزة هنا" text="اختار بورد تاني أو اعرض كل الأجهزة." actionLabel="عرض كل الأجهزة" onAction={() => { setSelectedBoardId('all'); setQuery(''); }} />
        ) : (
          visibleDevices.map((device) => {
            const meta = getDeviceIcon(device.icon);
            const availabilityState = boardState(device.board);
            const status = states[device.statusTopic || device.controlTopic];
            const statusColor = status === true ? theme.on : status === false ? theme.off : theme.textMuted;
            return (
              <TouchableOpacity key={`${device.board.id}-${device.id}`} onPress={() => setSelected(device)} style={[styles.card, status === true && { borderColor: theme.accentSoft }]}>
                <LinearGradient
                  pointerEvents="none"
                  colors={[status === true ? `${theme.accentSoft}2E` : `${theme.accentSoft}12`, 'transparent']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, borderRadius: 22 }}
                />
                <View style={[styles.iconBox, { borderColor: status === true ? theme.accentSoft : `${theme.accent}55`, backgroundColor: status === true ? `${theme.accentSoft}1F` : theme.cardAlt }]}>
                  <DeviceGlyph icon={meta?.icon || 'light-switch'} size={26} color={status === true ? theme.accentSoft : theme.textSecondary} isOn={status === true} />
                </View>
                <View style={styles.info}>
                  <Text style={styles.name} numberOfLines={1}>{device.name || 'جهاز بدون اسم'}</Text>
                  <Text style={styles.board} numberOfLines={1}>{device.board.name || 'البورد'}{device.board.ip ? `  •  ${device.board.ip}` : ''}</Text>
                  <View style={styles.statusRow}>
                    <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
                    <Text style={[styles.statusText, { color: statusColor }]}>{status === true ? 'يعمل' : status === false ? 'متوقف' : 'غير معروف'}</Text>
                    <Text style={styles.sep}>•</Text>
                    <Text style={[styles.statusText, { color: availabilityState === 'online' ? theme.on : availabilityState === 'offline' ? theme.off : theme.textMuted }]}>{availabilityState === 'online' ? 'البورد متصل' : availabilityState === 'offline' ? 'البورد غير متصل' : connected ? 'بانتظار رد البورد' : 'غير متصل بالسيرفر'}</Text>
                  </View>
                </View>
                <MaterialCommunityIcons name="chevron-left" size={22} color={theme.textMuted} />
              </TouchableOpacity>
            );
          })
        )}

      </ScrollView>
      {selected && (
        <View style={styles.overlay}>
          <TouchableOpacity style={styles.overlayBg} onPress={() => setSelected(null)} />
          <View style={styles.modal}>
            <View style={styles.modalIcon}><MaterialCommunityIcons name={getDeviceIcon(selected.icon)?.icon || 'light-switch'} size={32} color={theme.accent} /></View>
            <Text style={styles.modalTitle}>{selected.name || 'جهاز بدون اسم'}</Text>
            <Text style={styles.modalBoard}>{selected.board.name || 'البورد'}</Text>
            <View style={styles.detailRow}><Text style={styles.detailLabel}>حالة البورد</Text><Text style={[styles.detailValue, { color: boardState(selected.board) === 'online' ? theme.on : boardState(selected.board) === 'offline' ? theme.off : theme.textMuted }]}>{boardState(selected.board) === 'online' ? 'متصل' : boardState(selected.board) === 'offline' ? 'غير متصل' : connected ? 'بانتظار رد البورد' : 'غير متصل بالسيرفر'}</Text></View>
            <View style={styles.detailRow}><Text style={styles.detailLabel}>حالة الجهاز</Text><Text style={[styles.detailValue, { color: states[selected.statusTopic || selected.controlTopic] === true ? theme.on : states[selected.statusTopic || selected.controlTopic] === false ? theme.textSecondary : theme.textMuted }]}>{states[selected.statusTopic || selected.controlTopic] === true ? 'ON' : states[selected.statusTopic || selected.controlTopic] === false ? 'OFF' : 'غير معروفة'}</Text></View>
            <TouchableOpacity style={[styles.openBoardBtn, { backgroundColor: theme.accent }]} onPress={() => { setSelected(null); onOpenBoard?.(selected.board); }}><Text style={styles.openBoardText}>فتح البورد والتحكم</Text></TouchableOpacity>
            <TouchableOpacity style={styles.closeBtn} onPress={() => setSelected(null)}><Text style={styles.closeText}>إغلاق</Text></TouchableOpacity>
          </View>
        </View>
      )}
    </SafeAreaView>
  );
}

const getStyles = (theme) => StyleSheet.create({
  safe: { flex: 1, backgroundColor: theme.bg },
  content: { paddingHorizontal: 20, paddingTop: 18, paddingBottom: 132 },
  back: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center' },
  backText: { color: theme.textSecondary, fontSize: 15 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, paddingBottom: 4 },
  searchBox: { flexDirection: 'row', alignItems: 'center', gap: 8, height: 50, borderRadius: 18, paddingHorizontal: 14, marginBottom: 12, backgroundColor: theme.card, borderWidth: 1, borderColor: theme.border },
  searchInput: { flex: 1, color: theme.textPrimary, fontSize: 13.5, paddingVertical: 0 },
  headerIcon: { width: 52, height: 52, borderRadius: 18, alignItems: 'center', justifyContent: 'center', backgroundColor: `${theme.accent}18`, borderWidth: 1, borderColor: `${theme.accent}45` },
  title: { color: theme.textPrimary, fontSize: 20, fontWeight: '800', fontFamily: FONTS.display, textAlign: 'center' },
  subtitle: { color: theme.textSecondary, fontSize: 12, marginTop: 3, textAlign: 'right' },
  roomFilters: { gap: 8, paddingBottom: 16, paddingRight: 1 },
  roomChip: { flexDirection: 'row', alignItems: 'center', gap: 6, borderRadius: 18, paddingVertical: 9, paddingHorizontal: 13, backgroundColor: theme.card, borderWidth: 1, borderColor: theme.border, maxWidth: 180 },
  roomChipActive: { backgroundColor: theme.accent, borderColor: theme.accent },
  roomChipText: { color: theme.textSecondary, fontSize: 12, fontWeight: '700', maxWidth: 130 },
  roomChipTextActive: { color: readableOn(theme.accent) },
  card: { minHeight: 86, borderRadius: 22, marginBottom: 12, padding: 14, shadowColor: '#000', shadowOpacity: 0.18, shadowRadius: 8, shadowOffset: { width: 0, height: 3 }, elevation: 3, flexDirection: 'row', alignItems: 'center', backgroundColor: theme.card, borderWidth: 1, borderColor: theme.isLight ? theme.border : 'rgba(214,179,106,0.18)' },
  iconBox: { width: 54, height: 54, borderRadius: 18, alignItems: 'center', justifyContent: 'center', borderWidth: 1.4 },
  info: { flex: 1, marginHorizontal: 12 },
  name: { color: theme.textPrimary, fontSize: 15, fontWeight: '700', textAlign: 'right' },
  board: { color: theme.textMuted, fontSize: 11, marginTop: 4, textAlign: 'right' },
  empty: { alignItems: 'center', justifyContent: 'center', paddingVertical: 90 },
  emptyTitle: { color: theme.textPrimary, fontSize: 17, fontWeight: '700', marginTop: 14 },
  emptyText: { color: theme.textMuted, fontSize: 12, textAlign: 'center', marginTop: 7, maxWidth: 270 },
  statusRow: { flexDirection: 'row', alignItems: 'center', marginTop: 5, gap: 5 },
  statusDot: { width: 7, height: 7, borderRadius: 4 },
  statusText: { fontSize: 11, fontWeight: '700' },
  sep: { color: theme.textMuted, fontSize: 10 },
  overlay: { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, justifyContent: 'center', alignItems: 'center', zIndex: 50 },
  overlayBg: { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, backgroundColor: '#00000099' },
  modal: { width: '88%', borderRadius: 24, padding: 22, backgroundColor: theme.card, borderWidth: 1, borderColor: `${theme.accent}55`, alignItems: 'center' },
  modalIcon: { width: 70, height: 70, borderRadius: 22, alignItems: 'center', justifyContent: 'center', backgroundColor: `${theme.accent}18`, borderWidth: 1, borderColor: `${theme.accent}45`, marginBottom: 12 },
  modalTitle: { color: theme.textPrimary, fontSize: 20, fontWeight: '800' },
  modalBoard: { color: theme.textMuted, fontSize: 12, marginTop: 4, marginBottom: 18 },
  detailRow: { width: '100%', flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10, borderRadius: 12, paddingHorizontal: 12, marginBottom: 6, backgroundColor: theme.cardAlt },
  detailLabel: { color: theme.textSecondary, fontSize: 12 },
  detailValue: { fontSize: 12, fontWeight: '800' },
  openBoardBtn: { width: '100%', marginTop: 20, paddingVertical: 13, borderRadius: 15, alignItems: 'center' },
  openBoardText: { color: readableOn(theme.accent), fontSize: 13, fontWeight: '800' },
  closeBtn: { paddingVertical: 12 },
  closeText: { color: theme.textSecondary, fontSize: 12, fontWeight: '700' },
});
