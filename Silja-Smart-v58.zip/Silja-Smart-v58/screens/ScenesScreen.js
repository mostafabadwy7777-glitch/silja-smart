import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, TextInput, StyleSheet, Animated } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { showAlert } from '../components/PremiumAlert';
import { showToast } from '../components/Toast';
import { useTheme } from '../ThemeContext';
import { getDeviceIcon } from '../deviceIcons';
import { flattenSwitchDevices, runScene } from '../scenes';
import { newId } from '../storage';
import ConnectionStatusBanner from '../components/ConnectionStatusBanner';
import ScreenBackground from '../components/ScreenBackground';
import ScreenHeader from '../components/ScreenHeader';
import EmptyState from '../components/EmptyState';
import { readableOn, withAlpha } from '../colorUtils';
import { LinearGradient } from 'expo-linear-gradient';

// أفعال ممكنة لكل نوع مفتاح
const TOGGLE_ACTIONS = [
  { value: 'ON', label: 'شغّل', icon: 'power-plug' },
  { value: 'OFF', label: 'اقفل', icon: 'power-plug-off' },
];
const UPDOWN_ACTIONS = [
  { value: 'UP', label: 'طلوع', icon: 'arrow-up-bold' },
  { value: 'DOWN', label: 'نزول', icon: 'arrow-down-bold' },
  { value: 'STOP', label: 'وقف', icon: 'stop' },
];

const SCENE_TABS = [
  { id: 'all', label: 'الكل' },
  { id: 'home', label: 'المنزل' },
  { id: 'away', label: 'الخروج' },
  { id: 'sleep', label: 'النوم' },
];

// تصنيف المشهد من اسمه (مفيش حقل نوع محفوظ في بيانات المشهد).
// بنفضّل النوع المحفوظ في المشهد (kind)؛ والمشاهد القديمة اللي ملهاش نوع بتتصنّف من اسمها.
function sceneKind(name = '', kind) {
  if (kind === 'home' || kind === 'away' || kind === 'sleep') return kind;
  const n = String(name);
  if (/خروج|سفر|مغادر|بره|برا|خارج/.test(n)) return 'away';
  if (/نوم|ليل|نايم|راحة/.test(n)) return 'sleep';
  return 'home';
}

// أيقونة مناسبة لاسم المشهد؛ لو المشهد ملهوش اسم معروف بنرجع للنجمة.
function sceneIcon(scene) {
  const n = String(scene?.name || '');
  if (/استقبال|ضيوف|ضيف/.test(n)) return 'account-group-outline';
  if (/نوم|ليل|نايم/.test(n)) return 'weather-night';
  if (/خروج|سفر|مغادر|بره|برا/.test(n)) return 'exit-run';
  if (/عودة|وصول|رجوع|دخول/.test(n)) return 'home-import-outline';
  if (/صباح|فجر|استيقاظ|صحيان/.test(n)) return 'weather-sunset-up';
  if (/سينما|فيلم|مشاهدة|تلفزيون/.test(n)) return 'movie-open-outline';
  if (/عشاء|غداء|سفرة|أكل|فطار/.test(n)) return 'silverware-fork-knife';
  if (/سهر|حفلة|احتفال/.test(n)) return 'party-popper';
  if (/ري|حديقة/.test(n)) return 'sprinkler-variant';
  return 'star-four-points';
}

export default function ScenesScreen({ boards, scenes, onSaveScenes, client, connected, onBack }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);
  const devices = flattenSwitchDevices(boards);

  const [editing, setEditing] = useState(null); // null | scene draft object
  const [running, setRunning] = useState(null);
  const [tab, setTab] = useState('all');
  const [ranId, setRanId] = useState(null);
  const pop = React.useRef(new Animated.Value(1)).current;
  const lastSceneRunRef = React.useRef({});

  const startNew = () => setEditing({ id: newId(), name: '', kind: 'home', icon: 'star-four-points', actions: [] });
  const startEdit = (scene) => setEditing({ ...scene, kind: sceneKind(scene.name, scene.kind), actions: scene.actions.map((a) => ({ ...a })) });

  const persist = (list) => onSaveScenes(list);

  const deleteScene = (id) => {
    showAlert('مسح المشهد', 'متأكد؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'مسح', style: 'destructive', onPress: () => persist(scenes.filter((s) => s.id !== id)) },
    ]);
  };

  const trigger = async (scene) => {
    if (!connected || !client) { showAlert('الاتصال غير متاح', 'اتصل بالسيرفر قبل تشغيل المشهد.'); return; }
    if (running) return;
    const lastRunAt = lastSceneRunRef.current[scene.id] || 0;
    if (Date.now() - lastRunAt < 900) return;
    lastSceneRunRef.current[scene.id] = Date.now();
    setRunning(scene.id);
    try {
      const res = await runScene(scene, client);
      if (!res.ok) {
        showAlert('تعذر التشغيل', res.error || 'مقدرش أشغّل المشهد');
      } else {
        setRanId(scene.id);
        showToast(`تم تشغيل «${scene.name}»`);
        pop.setValue(0.8);
        Animated.spring(pop, { toValue: 1, friction: 3, tension: 120, useNativeDriver: true }).start();
        setTimeout(() => setRanId(null), 1300);
      }
    } catch (error) {
      showAlert('فشل تشغيل المشهد', error?.message || 'تعذر إرسال أوامر المشهد.');
    } finally {
      setRunning(null);
    }
  };

  const toggleActionInDraft = (device, value) => {
    setEditing((prev) => {
      const idx = prev.actions.findIndex((a) => a.controlTopic === device.controlTopic);
      const actions = [...prev.actions];
      if (idx >= 0 && actions[idx].value === value) {
        // نفس القيمة تاني = شيل الفعل ده من المشهد
        actions.splice(idx, 1);
      } else if (idx >= 0) {
        actions[idx] = { ...actions[idx], value };
      } else {
        actions.push({
          controlTopic: device.controlTopic,
          boardName: device.boardName,
          name: device.name,
          icon: device.icon,
          controlType: device.controlType,
          value,
        });
      }
      return { ...prev, actions };
    });
  };

  const saveDraft = () => {
    if (!editing.name.trim()) {
      showAlert('خطأ', 'لازم تحط اسم للمشهد');
      return;
    }
    if (editing.actions.length === 0) {
      showAlert('خطأ', 'لازم تختار مفتاح واحد على الأقل وحالته');
      return;
    }
    const exists = scenes.some((s) => s.id === editing.id);
    const list = exists ? scenes.map((s) => (s.id === editing.id ? editing : s)) : [...scenes, editing];
    persist(list);
    setEditing(null);
  };

  // ---------- شاشة تعديل/إنشاء مشهد ----------
  if (editing) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <ScreenBackground theme={theme} />
        <ScreenHeader title={scenes.some((s) => s.id === editing.id) ? 'تعديل المشهد' : 'مشهد جديد'} onBack={() => setEditing(null)} />

        <TextInput
          style={[styles.input, { backgroundColor: theme.cardAlt, color: theme.textPrimary }]}
          value={editing.name}
          onChangeText={(v) => setEditing({ ...editing, name: v })}
          placeholder="اسم المشهد (مثلاً: وضع النوم)"
          placeholderTextColor={theme.textMuted}
        />

        <View style={[styles.tabsWrap, { backgroundColor: theme.card, borderColor: theme.border, marginBottom: 12 }]}>
          {SCENE_TABS.filter((t) => t.id !== 'all').map((t) => {
            const active = (editing.kind || 'home') === t.id;
            return (
              <TouchableOpacity key={t.id} onPress={() => setEditing({ ...editing, kind: t.id })} style={[styles.tabBtn, active && { backgroundColor: theme.accent }]}>
                <Text style={{ color: active ? readableOn(theme.accent) : theme.textSecondary, fontSize: 12.5, fontWeight: '800' }}>{t.label}</Text>
              </TouchableOpacity>
            );
          })}
        </View>

        <Text style={[styles.hint, { color: theme.textSecondary }]}>
          اختار حالة كل مفتاح عايزه يتغيّر لما المشهد يشتغل. المفاتيح اللي مش هتلمسها هتفضل زي ما هي.
        </Text>

        <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
          {devices.length === 0 && (
            <Text style={[styles.emptyText, { color: theme.textMuted }]}>مفيش مفاتيح متاحة — ضيف بوردات الأول.</Text>
          )}
          {devices.map((device) => {
            const current = editing.actions.find((a) => a.controlTopic === device.controlTopic);
            const actionsList = device.controlType === 'updown' ? UPDOWN_ACTIONS : TOGGLE_ACTIONS;
            const meta = getDeviceIcon(device.icon);
            return (
              <View key={device.controlTopic} style={[styles.deviceRow, { backgroundColor: theme.card, borderColor: current ? theme.accent : theme.border }]}>
                <View style={styles.deviceInfo}>
                  <MaterialCommunityIcons name={meta.icon} size={20} color={theme.textSecondary} />
                  <View style={{ marginRight: 8 }}>
                    <Text style={[styles.deviceName, { color: theme.textPrimary }]}>{device.name}</Text>
                    <Text style={[styles.boardName, { color: theme.textMuted }]}>{device.boardName}</Text>
                  </View>
                </View>
                <View style={styles.actionsRow}>
                  {actionsList.map((a) => {
                    const selected = current?.value === a.value;
                    return (
                      <TouchableOpacity
                        key={a.value}
                        onPress={() => toggleActionInDraft(device, a.value)}
                        style={[
                          styles.actionChip,
                          {
                            backgroundColor: selected ? theme.accent : theme.cardAlt,
                            borderColor: selected ? theme.accent : theme.border,
                          },
                        ]}
                      >
                        <Text style={{ color: selected ? readableOn(theme.accent) : theme.textSecondary, fontSize: 11, fontWeight: '700' }}>
                          {a.label}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </View>
            );
          })}
        </ScrollView>

        <TouchableOpacity style={[styles.primaryBtn, { backgroundColor: theme.accent }]} onPress={saveDraft}>
          <Text style={[styles.btnText, { color: readableOn(theme.accent) }]}>{`حفظ المشهد${editing.actions.length ? ` (${editing.actions.length})` : ''}`}</Text>
        </TouchableOpacity>
      </SafeAreaView>
    );
  }

  // ---------- قائمة المشاهد ----------
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <ScreenBackground theme={theme} />
      <ScreenHeader title="المشاهد" onBack={onBack} right={
        <TouchableOpacity onPress={startNew}><MaterialCommunityIcons name="plus-circle" size={26} color={theme.accentSoft} /></TouchableOpacity>
      } />

      <Text style={[styles.hint, { color: theme.textSecondary }]}>
        جمّع مفاتيح من أي بورد في مشهد واحد وشغّلهم كلهم بدوسة واحدة (مثلاً "وضع النوم" يقفل كل حاجة إلا الإنذار).
      </Text>
      <View style={{ marginHorizontal: 16 }}><ConnectionStatusBanner theme={theme} connected={connected} title={connected ? 'جاهز لتشغيل المشاهد' : 'المشاهد محفوظة — التشغيل متوقف'} detail={connected ? 'التشغيل يرسل الأوامر المحفوظة للبوردات.' : 'ارجع الاتصال قبل تشغيل أي مشهد.'} /></View>

      <ScrollView contentContainerStyle={{ paddingBottom: 130 }}>
        {scenes.length === 0 && (
          <EmptyState icon="movie-open-outline" title="مفيش مشاهد لسه" text="اجمع مفاتيح كتير في مشهد واحد وشغّلهم بدوسة." actionLabel="مشهد جديد" onAction={startNew} />
        )}
        {scenes.length > 0 && (
          <View style={[styles.tabsWrap, { backgroundColor: theme.card, borderColor: theme.border }]}>
            {SCENE_TABS.map((t) => {
              const active = tab === t.id;
              return (
                <TouchableOpacity key={t.id} onPress={() => setTab(t.id)} style={[styles.tabBtn, active && { backgroundColor: theme.accent }]}>
                  <Text style={{ color: active ? readableOn(theme.accent) : theme.textSecondary, fontSize: 12.5, fontWeight: '800' }}>{t.label}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        )}
        {scenes.length > 0 && scenes.filter((sc) => tab === 'all' || sceneKind(sc.name, sc.kind) === tab).length === 0 && (
          <Text style={[styles.emptyText, { color: theme.textMuted }]}>مفيش مشاهد في التصنيف ده.</Text>
        )}
        {scenes.filter((sc) => tab === 'all' || sceneKind(sc.name, sc.kind) === tab).map((scene) => (
          <View key={scene.id} style={[styles.sceneCard, { backgroundColor: theme.card, borderColor: ranId === scene.id ? theme.on : withAlpha(theme.accentSoft, 0.28) }]}>
            <LinearGradient
              pointerEvents="none"
              colors={[withAlpha(theme.accentSoft, 0.14), 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
            />
            <TouchableOpacity
              style={styles.sceneMain}
              activeOpacity={0.8}
              onPress={() => trigger(scene)}
              disabled={!connected || running === scene.id}
            >
              <View style={[styles.sceneIconWrap, { backgroundColor: theme.cardAlt, borderColor: withAlpha(theme.accentSoft, 0.6) }]}>
                <MaterialCommunityIcons name={sceneIcon(scene)} size={24} color={theme.accentSoft} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.sceneName, { color: theme.textPrimary }]}>{scene.name}</Text>
                <Text style={[styles.sceneMeta, { color: theme.textMuted }]} numberOfLines={1}>
                  {scene.actions.length === 1 ? 'إجراء واحد' : scene.actions.length === 2 ? 'إجراءان' : `${scene.actions.length} إجراءات`}
                  {scene.actions.length ? ` • ${scene.actions.slice(0, 2).map((a) => a.name).filter(Boolean).join('، ')}${scene.actions.length > 2 ? '…' : ''}` : ''}
                </Text>
              </View>
              <Animated.View style={[styles.playCircle, ranId === scene.id && { transform: [{ scale: pop }] }, { backgroundColor: ranId === scene.id ? theme.on : connected ? theme.accentSoft : theme.cardAlt, shadowColor: theme.accentSoft, shadowOpacity: connected ? 0.45 : 0, shadowRadius: 10, shadowOffset: { width: 0, height: 0 }, elevation: connected ? 4 : 0 }]}>
                <MaterialCommunityIcons name={ranId === scene.id ? 'check' : 'play'} size={22} color={ranId === scene.id ? readableOn(theme.on) : connected ? readableOn(theme.accentSoft) : theme.textMuted} />
              </Animated.View>
            </TouchableOpacity>
            <View style={styles.sceneFooter}>
              <TouchableOpacity onPress={() => startEdit(scene)} style={styles.footerBtn}>
                <MaterialCommunityIcons name="pencil-outline" size={16} color={theme.textSecondary} />
                <Text style={[styles.footerBtnText, { color: theme.textSecondary }]}>تعديل</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => deleteScene(scene.id)} style={styles.footerBtn}>
                <MaterialCommunityIcons name="trash-can-outline" size={16} color={theme.danger} />
                <Text style={[styles.footerBtnText, { color: theme.danger }]}>مسح</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const getStyles = (theme) =>
  StyleSheet.create({
    container: { flex: 1, paddingHorizontal: 20, paddingTop: 50, backgroundColor: theme.bg },
    hint: { fontSize: 12, marginBottom: 16, lineHeight: 18 },
    emptyText: { fontSize: 13, textAlign: 'center', marginTop: 40 },
    input: { borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12, marginBottom: 14, fontSize: 14, borderWidth: 1 },
    deviceRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      borderWidth: 1,
      borderRadius: 18,
      padding: 14,
      marginBottom: 12,
    },
    deviceInfo: { flexDirection: 'row', alignItems: 'center', flex: 1 },
    deviceName: { fontSize: 13, fontWeight: '700' },
    boardName: { fontSize: 11, marginTop: 2 },
    actionsRow: { flexDirection: 'row', gap: 6 },
    actionChip: { borderWidth: 1, borderRadius: 11, paddingVertical: 8, paddingHorizontal: 12 },
    primaryBtn: { borderRadius: 15, paddingVertical: 15, alignItems: 'center', marginTop: 4 },
    btnText: { color: '#fff', fontWeight: '600', fontSize: 13 },
    sceneCard: { borderWidth: 1, borderRadius: 22, marginBottom: 15, overflow: 'hidden', shadowColor: '#000', shadowOpacity: 0.14, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 3 },
    sceneMain: { flexDirection: 'row', alignItems: 'center', padding: 15, gap: 12 },
    sceneIconWrap: {
      width: 52,
      height: 52,
      borderRadius: 17,
      borderWidth: 1.5,
      alignItems: 'center',
      justifyContent: 'center',
    },
    playCircle: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
    sceneName: { fontSize: 15, fontWeight: '700' },
    sceneMeta: { fontSize: 11, marginTop: 2 },
    sceneFooter: { flexDirection: 'row', paddingBottom: 4, paddingHorizontal: 8 },
    tabsWrap: { flexDirection: 'row', borderRadius: 18, borderWidth: 1, padding: 4, gap: 4, marginBottom: 16 },
    tabBtn: { flex: 1, borderRadius: 14, paddingVertical: 10, alignItems: 'center' },
    footerBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 10, gap: 6 },
    footerBtnText: { fontSize: 12, fontWeight: '600' },
  });
