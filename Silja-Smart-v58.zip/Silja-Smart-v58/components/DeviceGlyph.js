// أيقونة الجهاز بشكل أحلى: لما الجهاز يشتغل بتتحوّل لنسخة معبّية (لمبة منوّرة،
// فانوس مضيء...)، والمراوح بتلف، والإضاءة ليها هالة ضوء ناعمة حواليها.
import React, { useEffect, useRef } from 'react';
import { View, Animated, Easing } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { ON_VARIANTS, SPIN_ICONS } from '../deviceIcons';
import { withAlpha } from '../colorUtils';

export default function DeviceGlyph({ icon, size = 34, color, isOn = false, glow = false }) {
  const spin = useRef(new Animated.Value(0)).current;
  const shouldSpin = !!isOn && SPIN_ICONS.includes(icon);

  useEffect(() => {
    if (!shouldSpin) {
      spin.stopAnimation();
      spin.setValue(0);
      return undefined;
    }
    const loop = Animated.loop(
      Animated.timing(spin, { toValue: 1, duration: 1300, easing: Easing.linear, useNativeDriver: true })
    );
    loop.start();
    return () => loop.stop();
  }, [shouldSpin, spin]);

  // لو اسم النسخة المعبّية مش موجود في نسخة المكتبة الحالية نفضل على الأصلية.
  const glyphMap = MaterialCommunityIcons.glyphMap || {};
  const onName = ON_VARIANTS[icon];
  const name = isOn && onName && glyphMap[onName] ? onName : icon;
  const rotate = spin.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });

  const halo = (d, a) => (
    <View
      pointerEvents="none"
      style={{
        position: 'absolute',
        width: d,
        height: d,
        borderRadius: d / 2,
        top: -(d - size) / 2,
        left: -(d - size) / 2,
        backgroundColor: withAlpha(color, a),
      }}
    />
  );

  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      {isOn && glow && halo(size * 2.1, 0.07)}
      {isOn && glow && halo(size * 1.6, 0.12)}
      <Animated.View style={shouldSpin ? { transform: [{ rotate }] } : null}>
        <MaterialCommunityIcons name={name} size={size} color={color} />
      </Animated.View>
    </View>
  );
}
