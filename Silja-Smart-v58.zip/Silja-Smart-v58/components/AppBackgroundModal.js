import React, { useState } from 'react';
import { Modal, View, Text, Image, StyleSheet } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import { showAlert } from './PremiumAlert';
import { useTheme } from '../ThemeContext';
import { FONTS } from '../fonts';

const APP_BG_FILE = FileSystem.documentDirectory + 'app-images/app-bg.jpg';

// نافذة اختيار خلفية التطبيق: صورة من المعرض أو الكاميرا + درجة التعتيم + إزالة.
export default function AppBackgroundModal({ visible, onClose }) {
  const { theme, appBg, appBgDim, setAppBg, setAppBgDim } = useTheme();
  const [busy, setBusy] = useState(false);

  const persist = async (sourceUri) => {
    await FileSystem.makeDirectoryAsync(FileSystem.documentDirectory + 'app-images/', { intermediates: true }).catch(() => {});
    await FileSystem.deleteAsync(APP_BG_FILE, { idempotent: true }).catch(() => {});
    await FileSystem.copyAsync({ from: sourceUri, to: APP_BG_FILE });
    // باراميتر الوقت بيخلّي الصورة تتحدّث فورًا لو اتغيّرت على نفس المسار
    return `${APP_BG_FILE}?t=${Date.now()}`;
  };

  const handle = async (launcher, permFn, permMsg) => {
    const perm = await permFn();
    if (!perm.granted) {
      showAlert('مفيش صلاحية', permMsg);
      return;
    }
    const result = await launcher();
    if (result.canceled || !result.assets?.[0]?.uri) return;
    setBusy(true);
    try {
      await setAppBg(await persist(result.assets[0].uri));
    } catch (e) {
      showAlert('خطأ', 'مقدرناش نحفظ الصورة، جرب تاني');
    } finally {
      setBusy(false);
    }
  };

  const pickFromLibrary = () =>
    handle(
      () => ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, aspect: [9, 19], quality: 0.8 }),
      ImagePicker.requestMediaLibraryPermissionsAsync,
      'لازم تسمح للتطبيق بالدخول على الصور من إعدادات الموبايل الأول'
    );
  const takePhoto = () =>
    handle(
      () => ImagePicker.launchCameraAsync({ allowsEditing: true, aspect: [9, 19], quality: 0.8 }),
      ImagePicker.requestCameraPermissionsAsync,
      'لازم تسمح للتطبيق باستخدام الكاميرا من إعدادات الموبايل الأول'
    );

  const pct = Math.round(appBgDim * 100);
  const step = (d) => setAppBgDim(Math.round((appBgDim + d) * 10) / 10);

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={[styles.box, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={styles.headerRow}>
            <Text style={[styles.title, { color: theme.textPrimary }]}>خلفية التطبيق</Text>
            <TouchableOpacity onPress={onClose} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <MaterialCommunityIcons name="close" size={20} color={theme.textMuted} />
            </TouchableOpacity>
          </View>
          <Text style={[styles.hint, { color: theme.textSecondary }]}>اختار صورة تتحط خلفية لكل شاشات التطبيق.</Text>

          {!!appBg && <Image source={{ uri: appBg }} style={[styles.preview, { borderColor: theme.border }]} resizeMode="cover" />}

          <View style={styles.actions}>
            <TouchableOpacity style={[styles.btn, { backgroundColor: theme.cardAlt, borderColor: theme.border }]} onPress={pickFromLibrary} disabled={busy}>
              <MaterialCommunityIcons name="image-outline" size={17} color={theme.accentSoft} />
              <Text style={[styles.btnText, { color: theme.textSecondary }]}>صورة</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.btn, { backgroundColor: theme.cardAlt, borderColor: theme.border }]} onPress={takePhoto} disabled={busy}>
              <MaterialCommunityIcons name="camera-outline" size={17} color={theme.accentSoft} />
              <Text style={[styles.btnText, { color: theme.textSecondary }]}>كاميرا</Text>
            </TouchableOpacity>
          </View>

          {!!appBg && (
            <>
              <Text style={[styles.label, { color: theme.textPrimary }]}>درجة التعتيم — {pct}٪</Text>
              <View style={styles.dimRow}>
                <TouchableOpacity style={[styles.stepBtn, { backgroundColor: theme.cardAlt, borderColor: theme.border }]} onPress={() => step(-0.1)}>
                  <MaterialCommunityIcons name="minus" size={18} color={theme.accentSoft} />
                </TouchableOpacity>
                <View style={[styles.track, { backgroundColor: theme.cardAlt }]}>
                  <View style={[styles.fill, { width: `${pct}%`, backgroundColor: theme.accentSoft }]} />
                </View>
                <TouchableOpacity style={[styles.stepBtn, { backgroundColor: theme.cardAlt, borderColor: theme.border }]} onPress={() => step(0.1)}>
                  <MaterialCommunityIcons name="plus" size={18} color={theme.accentSoft} />
                </TouchableOpacity>
              </View>
              <TouchableOpacity style={styles.remove} onPress={() => setAppBg(null)}>
                <MaterialCommunityIcons name="trash-can-outline" size={16} color={theme.danger} />
                <Text style={[styles.removeText, { color: theme.danger }]}>إزالة الخلفية</Text>
              </TouchableOpacity>
            </>
          )}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', padding: 24 },
  box: { borderRadius: 24, borderWidth: 1, padding: 18 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  title: { fontSize: 17, fontWeight: '800', fontFamily: FONTS.display },
  hint: { fontSize: 12.5, marginBottom: 12, textAlign: 'right' },
  preview: { height: 150, borderRadius: 16, borderWidth: 1, marginBottom: 12 },
  actions: { flexDirection: 'row', gap: 10 },
  btn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderWidth: 1, borderRadius: 14, paddingVertical: 12 },
  btnText: { fontSize: 13.5, fontWeight: '700' },
  label: { fontSize: 13, fontWeight: '700', marginTop: 16, marginBottom: 8, textAlign: 'right' },
  dimRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  stepBtn: { width: 36, height: 36, borderRadius: 12, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  track: { flex: 1, height: 8, borderRadius: 4, overflow: 'hidden' },
  fill: { height: 8, borderRadius: 4 },
  remove: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 16 },
  removeText: { fontSize: 13, fontWeight: '700' },
});
