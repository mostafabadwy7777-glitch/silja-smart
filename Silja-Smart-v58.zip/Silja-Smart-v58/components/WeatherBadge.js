import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { withAlpha } from '../colorUtils';
import { DEFAULT_CITY, autoDetectOnFirstRun, loadWeatherCity, subscribeWeatherCity } from '../weather';

// طقس حقيقي من Open-Meteo (مجاني، من غير مفتاح API). المدينة من الإعدادات (الافتراضي القاهرة).
// لو الطلب فشل أو مفيش نت بنخفي الشارة تمامًا بدل ما نعرض رقم مختلق.
const REFRESH_MS = 30 * 60 * 1000;

function iconFor(code, isDay) {
  if (code === 0) return isDay ? 'weather-sunny' : 'weather-night';
  if (code <= 2) return isDay ? 'weather-partly-cloudy' : 'weather-night-partly-cloudy';
  if (code === 3) return 'weather-cloudy';
  if (code === 45 || code === 48) return 'weather-fog';
  if (code >= 51 && code <= 67) return 'weather-rainy';
  if (code >= 71 && code <= 77) return 'weather-snowy';
  if (code >= 80 && code <= 82) return 'weather-pouring';
  if (code >= 95) return 'weather-lightning-rainy';
  return 'weather-partly-cloudy';
}

function labelFor(code) {
  if (code === 0) return 'صافي';
  if (code <= 2) return 'غائم جزئيًا';
  if (code === 3) return 'غائم';
  if (code === 45 || code === 48) return 'ضباب';
  if (code >= 51 && code <= 67) return 'أمطار';
  if (code >= 71 && code <= 77) return 'ثلوج';
  if (code >= 80 && code <= 82) return 'زخات';
  if (code >= 95) return 'عاصفة';
  return 'معتدل';
}

export default function WeatherBadge({ color, mutedColor, accent, inline }) {
  const [w, setW] = useState(null);
  const [city, setCity] = useState(DEFAULT_CITY);

  useEffect(() => {
    loadWeatherCity().then(setCity);
    const unsub = subscribeWeatherCity((c) => { setW(null); setCity(c); });
    // أول تشغيل: نحدد منطقة المستخدم تلقائيًا مرة واحدة (بيتحدّث الاسم عبر الاشتراك فوق)
    autoDetectOnFirstRun();
    return unsub;
  }, []);

  useEffect(() => {
    let alive = true;
    const cacheKey = `iot_weather_last_${city.lat.toFixed(2)}_${city.lon.toFixed(2)}`;
    // لو مفيش نت نعرض آخر قراءة محفوظة بدل ما الشارة تختفي
    const showCached = async () => {
      try {
        const raw = await AsyncStorage.getItem(cacheKey);
        const c = raw ? JSON.parse(raw) : null;
        if (alive && c && typeof c.temp === 'number') setW((cur) => cur || c);
      } catch (_) {}
    };
    const load = async () => {
      try {
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}&current=temperature_2m,weather_code,is_day`;
        const res = await fetch(url);
        if (!res.ok) { showCached(); return; }
        const data = await res.json();
        const c = data && data.current;
        if (alive && c && typeof c.temperature_2m === 'number') {
          const reading = { temp: Math.round(c.temperature_2m), code: c.weather_code, isDay: c.is_day === 1 };
          setW(reading);
          AsyncStorage.setItem(cacheKey, JSON.stringify(reading)).catch(() => {});
        } else {
          showCached();
        }
      } catch (_) {
        showCached();
      }
    };
    load();
    const t = setInterval(load, REFRESH_MS);
    return () => { alive = false; clearInterval(t); };
  }, [city]);

  if (!w) return null;
  return (
    <View
      style={inline ? [styles.inline, { backgroundColor: withAlpha(accent, 0.1), borderColor: withAlpha(accent, 0.32) }] : styles.wrap}
      pointerEvents="none"
    >
      <MaterialCommunityIcons name={iconFor(w.code, w.isDay)} size={inline ? 38 : 34} color={accent} />
      <View>
        <Text style={[styles.temp, { color }, inline && { fontSize: 28 }]}>{w.temp}°</Text>
        <Text style={[styles.label, { color: mutedColor }]}>{labelFor(w.code)} • {city.name}</Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { position: 'absolute', end: 20, bottom: 22, flexDirection: 'row', alignItems: 'center', gap: 8 },
  inline: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10, paddingHorizontal: 14, borderRadius: 20, borderWidth: 1 },
  temp: { fontSize: 24, fontWeight: '800' },
  label: { fontSize: 11.5, marginTop: -2 },
});
