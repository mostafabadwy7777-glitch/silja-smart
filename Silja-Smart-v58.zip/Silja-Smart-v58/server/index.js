// سيرفر إشعارات Silja Smart — شغّله على أي جهاز شغال طول الوقت (VPS / Raspberry Pi / PC).
// بيعمل 3 حاجات:
//  1) بيقرأ توكنات الموبايلات اللي التطبيق بينشرها على silja/app/push_tokens/<installId> (Retained).
//  2) بيقرأ رسائل الاكتشاف +/discovery عشان يعرف أسماء المفاتيح وتوبيكات حالتها.
//  3) لما حالة مفتاح تتغيّر، أو بورد يقطع/يرجع، بيبعت إشعار لكل الموبايلات عن طريق Expo Push.
//
// التشغيل:
//   cd server && npm install
//   MQTT_URL=mqtt://broker.example.com:1883 MQTT_USER=user MQTT_PASS=pass node index.js
// متغيرات اختيارية: NOTIFY_SWITCHES=0 (يوقف إشعارات التشغيل/الإيقاف)، NOTIFY_BOARDS=0 (يوقف إشعارات قطع البورد)
const mqtt = require('mqtt');
const { Expo } = require('expo-server-sdk');

const MQTT_URL = process.env.MQTT_URL;
if (!MQTT_URL) {
  console.error('لازم تحدد MQTT_URL، مثال: MQTT_URL=mqtt://host:1883');
  process.exit(1);
}
const NOTIFY_SWITCHES = process.env.NOTIFY_SWITCHES !== '0';
const NOTIFY_BOARDS = process.env.NOTIFY_BOARDS !== '0';

const expo = new Expo();
const tokens = new Map();      // installId -> expo push token
const statusTopics = new Map(); // status topic -> { name, board }
const lastState = new Map();   // status topic -> true/false
const boardNames = new Map();  // availability topic -> board name
const lastAvail = new Map();   // availability topic -> online/offline
const startedAt = Date.now();
const WARMUP_MS = 8000;        // نتجاهل رسائل Retained القديمة أول ما نتصل

const client = mqtt.connect(MQTT_URL, {
  username: process.env.MQTT_USER || undefined,
  password: process.env.MQTT_PASS || undefined,
  clientId: `silja-push-${Math.random().toString(16).slice(2, 8)}`,
  reconnectPeriod: 3000,
});

client.on('connect', () => {
  console.log('متصل بالبروكر');
  client.subscribe(['silja/app/push_tokens/+', '+/discovery', '+/availability']);
  statusTopics.forEach((_, t) => client.subscribe(t));
});
client.on('error', (e) => console.error('MQTT error:', e.message));

async function broadcast(title, body) {
  const messages = [...tokens.values()]
    .filter((t) => Expo.isExpoPushToken(t))
    .map((to) => ({ to, title, body, sound: 'default', channelId: 'silja-default', priority: 'high' }));
  for (const chunk of expo.chunkPushNotifications(messages)) {
    try {
      const receipts = await expo.sendPushNotificationsAsync(chunk);
      receipts.forEach((r, i) => {
        if (r.status === 'error') {
          console.error('فشل إرسال إشعار:', r.message);
          if (r.details && r.details.error === 'DeviceNotRegistered') {
            for (const [id, tk] of tokens) if (tk === chunk[i].to) tokens.delete(id);
          }
        }
      });
    } catch (e) {
      console.error('Expo push error:', e.message);
    }
  }
}

function parseState(raw) {
  const v = raw.trim().toUpperCase();
  if (['ON', '1', 'TRUE'].includes(v)) return true;
  if (['OFF', '0', 'FALSE'].includes(v)) return false;
  try {
    const d = JSON.parse(raw);
    const c = d.state ?? d.status ?? d.value ?? d.on;
    if (typeof c === 'boolean') return c;
    const s = String(c ?? '').trim().toUpperCase();
    if (['ON', '1', 'TRUE'].includes(s)) return true;
    if (['OFF', '0', 'FALSE'].includes(s)) return false;
  } catch (_) {}
  return null;
}

client.on('message', (topic, payload) => {
  const raw = payload.toString();

  if (topic.startsWith('silja/app/push_tokens/')) {
    const id = topic.split('/').pop();
    if (!raw) { tokens.delete(id); return; }
    try {
      const { token } = JSON.parse(raw);
      if (token) tokens.set(id, token);
      console.log(`توكن مسجّل (${tokens.size} جهاز)`);
    } catch (_) {}
    return;
  }

  if (topic.endsWith('/discovery')) {
    try {
      const d = JSON.parse(raw);
      const boardName = d.name || d.device_id || topic;
      if (d.device_id) boardNames.set(`${d.device_id}/availability`, boardName);
      if (d.prefix) boardNames.set(`${d.prefix}/availability`, boardName);
      (d.switches || []).forEach((sw) => {
        const t = sw.status_topic || sw.state_topic || sw.control_topic || sw.topic;
        if (!t || sw.control_type === 'updown') return;
        const isNew = !statusTopics.has(t);
        statusTopics.set(t, { name: sw.name || 'مفتاح', board: boardName });
        if (isNew && client.connected) client.subscribe(t);
      });
    } catch (_) {}
    return;
  }

  if (topic.endsWith('/availability')) {
    const v = raw.trim().toLowerCase();
    if (v !== 'online' && v !== 'offline') return;
    const prev = lastAvail.get(topic);
    lastAvail.set(topic, v);
    if (!NOTIFY_BOARDS || prev === undefined || prev === v) return;
    if (Date.now() - startedAt < WARMUP_MS) return;
    const name = boardNames.get(topic) || topic.replace('/availability', '');
    broadcast(v === 'offline' ? '⚠️ البورد مقطوع' : '✅ البورد رجع', name);
    return;
  }

  const info = statusTopics.get(topic);
  if (!info) return;
  const state = parseState(raw);
  if (state === null) return;
  const prev = lastState.get(topic);
  lastState.set(topic, state);
  if (!NOTIFY_SWITCHES || prev === undefined || prev === state) return; // أول قراءة = مجرد معرفة الحالة الحالية
  if (Date.now() - startedAt < WARMUP_MS) return;
  broadcast(info.name, `${state ? 'اتشغّل' : 'اتقفل'} — ${info.board}`);
});
