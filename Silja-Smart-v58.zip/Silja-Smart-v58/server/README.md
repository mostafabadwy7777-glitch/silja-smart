# سيرفر إشعارات Silja Smart

يحتاج Node 18+ وجهاز شغال طول الوقت.

    cd server
    npm install
    MQTT_URL=mqtt://HOST:1883 MQTT_USER=... MQTT_PASS=... npm start

- التطبيق لازم يكون متفعّل فيه "الإشعارات" عشان توكن الموبايل يتنشر.
- البروكر لازم يقبل اتصال TCP عادي (1883/8883). لو عندك WebSocket بس، استخدم `ws://` أو `wss://HOST:PORT/path` في MQTT_URL.
- لازم الفيرموير ينشر رسالة الاكتشاف `<device_id>/discovery` Retained (زي ما التطبيق بيعتمد عليها).
- لإشعارات الأندرويد لازم `google-services.json` في جذر مشروع التطبيق + رفع بيانات FCM V1 على Expo (`eas credentials`).
