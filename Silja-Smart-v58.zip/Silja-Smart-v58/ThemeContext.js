import React, { createContext, useContext, useEffect, useState } from 'react';
import { DEFAULT_THEME_ID, LIGHT_THEME_ID, CUSTOM_THEME_ID, DEFAULT_CUSTOM_THEME, getTheme } from './theme';
import {
  loadThemeId,
  saveThemeId,
  loadLastDarkThemeId,
  saveLastDarkThemeId,
  loadCustomTheme,
  saveCustomTheme,
  loadBottomNavOpacity,
  saveBottomNavOpacity,
  loadBottomNavGradient,
  saveBottomNavGradient,
  loadBottomNavSize, saveBottomNavSize, loadBottomNavLift, saveBottomNavLift,
  loadAppBg, saveAppBg, loadAppBgDim, saveAppBgDim, DEFAULT_APP_BG_DIM,
} from './storage';

const ThemeContext = createContext({
  theme: getTheme(DEFAULT_THEME_ID),
  themeId: DEFAULT_THEME_ID,
  isLight: false,
  customTheme: DEFAULT_CUSTOM_THEME,
  setThemeId: () => {},
  toggleLightDark: () => {},
  updateCustomColor: () => {},
  applyCustomBase: () => {},
  resetCustomTheme: () => {},
  bottomNavOpacity: 0.90,
  bottomNavGradient: 'theme',
  bottomNavSize: 'compact', bottomNavLift: 12, setBottomNavSize: () => {}, setBottomNavLift: () => {},
  setBottomNavOpacity: () => {},
  setBottomNavGradient: () => {},
  appBg: null, appBgDim: 0.55, setAppBg: () => {}, setAppBgDim: () => {},
});

export function ThemeProvider({ children }) {
  const [themeId, setThemeIdState] = useState(DEFAULT_THEME_ID);
  const [lastDarkThemeId, setLastDarkThemeId] = useState(DEFAULT_THEME_ID);
  const [customTheme, setCustomThemeState] = useState(DEFAULT_CUSTOM_THEME);
  const [bottomNavOpacity, setBottomNavOpacityState] = useState(0.90);
  const [bottomNavGradient, setBottomNavGradientState] = useState('theme');
  const [bottomNavSize, setBottomNavSizeState] = useState('compact');
  const [bottomNavLift, setBottomNavLiftState] = useState(12);
  const [appBg, setAppBgState] = useState(null);
  const [appBgDim, setAppBgDimState] = useState(DEFAULT_APP_BG_DIM);

  useEffect(() => {
    loadAppBg().then(setAppBgState).catch(() => {});
    loadAppBgDim().then(setAppBgDimState).catch(() => {});
  }, []);

  useEffect(() => {
    (async () => {
      const [saved, savedLastDark, savedCustom, savedBottomNavOpacity, savedBottomNavGradient, savedBottomNavSize, savedBottomNavLift] = await Promise.all([
        loadThemeId(),
        loadLastDarkThemeId(),
        loadCustomTheme(),
        loadBottomNavOpacity(),
        loadBottomNavGradient(),
        loadBottomNavSize(), loadBottomNavLift(),
      ]);
      if (saved) setThemeIdState(saved);
      if (savedLastDark) setLastDarkThemeId(savedLastDark);
      if (savedCustom) setCustomThemeState({ ...DEFAULT_CUSTOM_THEME, ...savedCustom });
      if (Number.isFinite(savedBottomNavOpacity)) setBottomNavOpacityState(savedBottomNavOpacity);
      if (savedBottomNavGradient) setBottomNavGradientState(savedBottomNavGradient);
      if (savedBottomNavSize) setBottomNavSizeState(savedBottomNavSize);
      if (Number.isFinite(savedBottomNavLift)) setBottomNavLiftState(savedBottomNavLift);
    })();
  }, []);

  // بيرجع شكل الثيم الكامل لأي id: ثيم جاهز من القايمة الثابتة، أو الثيم
  // المخصص (آخر ألوان حفظها المستخدم بنفسه) لو الid بتاعه "custom".
  const resolveTheme = (id) => (id === CUSTOM_THEME_ID ? customTheme : getTheme(id));

  const setThemeId = async (id) => {
    setThemeIdState(id);
    await saveThemeId(id);
    // أي ثيم غامق (سواء جاهز أو مخصص) بيتسجل كـ"آخر ثيم غامق" عشان نرجعله
    // لما نطفي الوضع النهاري بزرار التبديل السريع.
    if (!resolveTheme(id).isLight) {
      setLastDarkThemeId(id);
      await saveLastDarkThemeId(id);
    }
  };

  // تبديل سريع بين الوضع الغامق (آخر ثيم غامق كان مختار) والوضع النهاري.
  const toggleLightDark = async () => {
    if (resolveTheme(themeId).isLight) {
      await setThemeId(lastDarkThemeId || DEFAULT_THEME_ID);
    } else {
      await setThemeId(LIGHT_THEME_ID);
    }
  };

  // تعديل لون واحد بس في الثيم المخصص (زي اللون الأساسي أو لون التشغيل)
  // وحفظه فورًا. لو الثيم المخصص مش مفعّل حاليًا، بيتفعّل تلقائيًا عشان
  // المستخدم يشوف أثر التعديل على كل شاشات التطبيق على طول.
  const updateCustomColor = async (key, value) => {
    const next = { ...customTheme, [key]: value };
    setCustomThemeState(next);
    await saveCustomTheme(next);
    if (themeId !== CUSTOM_THEME_ID) {
      await setThemeId(CUSTOM_THEME_ID);
    }
  };

  // بداية سريعة: نسخ "سطح" ثيم جاهز (خلفية/كروت/حدود/نصوص) كنقطة انطلاق
  // للثيم المخصص، من غير ما نلمس الألوان الأساسية (accent/on/off) اللي
  // المستخدم يكون غيّرها بنفسه بالفعل.
  const applyCustomBase = async (baseId) => {
    const base = getTheme(baseId);
    const next = {
      ...customTheme,
      isLight: !!base.isLight,
      bg: base.bg,
      card: base.card,
      cardAlt: base.cardAlt,
      border: base.border,
      textPrimary: base.textPrimary,
      textSecondary: base.textSecondary,
      textMuted: base.textMuted,
    };
    setCustomThemeState(next);
    await saveCustomTheme(next);
    if (themeId !== CUSTOM_THEME_ID) {
      await setThemeId(CUSTOM_THEME_ID);
    }
  };

  const setBottomNavOpacity = async (value) => {
    const n = Number(value);
    const safe = Number.isFinite(n) ? Math.max(0.35, Math.min(1, n)) : 0.90;
    setBottomNavOpacityState(safe);
    await saveBottomNavOpacity(safe);
  };

  const setBottomNavGradient = async (id) => {
    setBottomNavGradientState(id);
    await saveBottomNavGradient(id);
  };

  const setBottomNavSize = async (value) => { const safe = ['compact','standard','large'].includes(value) ? value : 'compact'; setBottomNavSizeState(safe); await saveBottomNavSize(safe); };
  const setBottomNavLift = async (value) => { const n = Number(value); const safe = Number.isFinite(n) ? Math.max(0,Math.min(24,n)) : 12; setBottomNavLiftState(safe); await saveBottomNavLift(safe); };

  const setAppBg = async (uri) => { setAppBgState(uri || null); await saveAppBg(uri || null); };
  const setAppBgDim = async (v) => { const n = Math.max(0, Math.min(1, Number(v) || 0)); setAppBgDimState(n); await saveAppBgDim(n); };

  const resetCustomTheme = async () => {
    setCustomThemeState(DEFAULT_CUSTOM_THEME);
    await saveCustomTheme(DEFAULT_CUSTOM_THEME);
  };

  const theme = resolveTheme(themeId);
  const isLight = !!theme.isLight;

  return (
    <ThemeContext.Provider
      value={{
        theme,
        themeId,
        isLight,
        customTheme,
        setThemeId,
        toggleLightDark,
        updateCustomColor,
        applyCustomBase,
        resetCustomTheme,
        bottomNavOpacity,
        bottomNavGradient, bottomNavSize, bottomNavLift, setBottomNavSize, setBottomNavLift,
        setBottomNavOpacity,
        setBottomNavGradient,
        appBg, appBgDim, setAppBg, setAppBgDim,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
}

// Hook بسيط عشان أي شاشة تاخد الثيم الحالي وتقدر تغيّره
export function useTheme() {
  return useContext(ThemeContext);
}
