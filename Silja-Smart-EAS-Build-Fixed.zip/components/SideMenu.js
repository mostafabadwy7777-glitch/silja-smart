import React, { useEffect, useRef, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Modal, ScrollView, SafeAreaView, Animated, Switch } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

// الدرج الجانبي (الصفحة الجانبية) — كان قبل كده جوه BoardsListScreen بس
// (بيتفتح من ترس فوق شاشة البوردات بس). اتنقل هنا كمكوّن مستقل عشان زرار
// "الإعدادات" في الشريط السفلي يقدر يفتحه من أي شاشة في التطبيق، مش من
// شاشة البوردات بس.
export default function SideMenu({
  visible,
  onClose,
  theme,
  isLight,
  toggleLightDark,
  pushEnabled,
  onTogglePush,
  biometricEnabled,
  onToggleBiometric,
  onOpenSettings,
  onOpenTheme,
  onOpenScenes,
  onOpenHistory,
  onOpenBackup,
}) {
  const styles = getStyles(theme);
  const [menuVisible, setMenuVisible] = useState(false);
  const menuSlide = useRef(new Animated.Value(1)).current; // 1 = مخفي (خارج الشاشة)، 0 = ظاهر بالكامل

  useEffect(() => {
    if (visible) {
      setMenuVisible(true);
      Animated.timing(menuSlide, { toValue: 0, duration: 260, useNativeDriver: true }).start();
    } else if (menuVisible) {
      Animated.timing(menuSlide, { toValue: 1, duration: 220, useNativeDriver: true }).start(({ finished }) => {
        if (finished) setMenuVisible(false);
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [visible]);

  const go = (fn) => {
    onClose();
    fn && fn();
  };

  return (
    <Modal visible={menuVisible} transparent animationType="none" onRequestClose={onClose}>
      <View style={styles.drawerRoot}>
        <TouchableOpacity style={styles.drawerScrim} activeOpacity={1} onPress={onClose} />

        <Animated.View
          style={[
            styles.drawerPanel,
            {
              transform: [
                {
                  translateX: menuSlide.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0, 340],
                  }),
                },
              ],
            },
          ]}
        >
          <SafeAreaView style={{ flex: 1 }}>
            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.drawerScroll}>
              <View style={styles.drawerHeader}>
                <View style={styles.drawerLogoBadge}>
                  <MaterialCommunityIcons name="home-automation" size={30} color={theme.on} />
                </View>
                <Text style={styles.drawerBrandName}>
                  <Text style={{ color: theme.on }}>Silja</Text> Smart
                </Text>
                <Text style={styles.drawerBrandSub}>منزلك الذكي، أسهل وأذكى</Text>

                <TouchableOpacity onPress={onClose} style={styles.drawerCloseBtn} activeOpacity={0.75}>
                  <MaterialCommunityIcons name="close" size={20} color={theme.textSecondary} />
                </TouchableOpacity>
              </View>

              <View style={styles.drawerSection}>
                <DrawerRow
                  icon="cog-outline"
                  label="إعدادات الاتصال"
                  styles={styles}
                  theme={theme}
                  onPress={() => go(onOpenSettings)}
                />
                <DrawerRow
                  icon="palette-outline"
                  label="المظهر والثيمات"
                  styles={styles}
                  theme={theme}
                  onPress={() => go(onOpenTheme)}
                />
                <DrawerRow
                  icon="star-four-points-outline"
                  label="المشاهد"
                  styles={styles}
                  theme={theme}
                  onPress={() => go(onOpenScenes)}
                />
                <DrawerRow
                  icon="history"
                  label="سجل الأحداث"
                  styles={styles}
                  theme={theme}
                  onPress={() => go(onOpenHistory)}
                />
                <DrawerRow
                  icon="cloud-upload-outline"
                  label="نسخة احتياطية"
                  styles={styles}
                  theme={theme}
                  onPress={() => go(onOpenBackup)}
                />
              </View>

              <View style={styles.drawerDivider} />

              <View style={styles.drawerSection}>
                <DrawerRow
                  icon={isLight ? 'weather-sunny' : 'weather-night'}
                  label={isLight ? 'وضع نهاري' : 'وضع ليلي'}
                  styles={styles}
                  theme={theme}
                  onPress={toggleLightDark}
                  trailing={<MaterialCommunityIcons name="swap-horizontal" size={17} color={theme.textMuted} />}
                />
                <DrawerRow
                  icon={pushEnabled ? 'bell-ring' : 'bell-off-outline'}
                  label="الإشعارات"
                  styles={styles}
                  theme={theme}
                  onPress={onTogglePush}
                  trailing={
                    <Switch
                      value={pushEnabled}
                      onValueChange={onTogglePush}
                      trackColor={{ false: theme.border, true: theme.accent }}
                      thumbColor="#fff"
                    />
                  }
                />
              </View>

              {/* خانة الحماية بالبصمة — لوحدها في صندوق منفصل عن باقي عناصر
                  الإعدادات، بعد ما كانت متحطة قبل كده جوه فورم إعدادات
                  الاتصال بالسيرفر (مع الـ Host والـ Port) وده كان مربك. */}
              <View style={styles.drawerDivider} />

              <View style={styles.drawerSection}>
                <DrawerRow
                  icon="shield-lock-outline"
                  label="الحماية بالبصمة"
                  styles={styles}
                  theme={theme}
                  onPress={onToggleBiometric}
                  trailing={
                    <Switch
                      value={biometricEnabled}
                      onValueChange={onToggleBiometric}
                      trackColor={{ false: theme.border, true: theme.accent }}
                      thumbColor="#fff"
                    />
                  }
                />
              </View>
            </ScrollView>
          </SafeAreaView>
        </Animated.View>
      </View>
    </Modal>
  );
}

function DrawerRow({ icon, label, onPress, styles, theme, trailing }) {
  return (
    <TouchableOpacity style={styles.drawerRow} onPress={onPress} activeOpacity={0.7}>
      <View style={styles.drawerRowIconBox}>
        <MaterialCommunityIcons name={icon} size={20} color={theme.accentSoft} />
      </View>
      <Text style={styles.drawerRowLabel}>{label}</Text>
      {trailing || <MaterialCommunityIcons name="chevron-left" size={18} color={theme.textMuted} />}
    </TouchableOpacity>
  );
}

const getStyles = (theme) =>
  StyleSheet.create({
    drawerRoot: { flex: 1, flexDirection: 'row-reverse' },
    drawerScrim: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)' },
    drawerPanel: {
      width: '82%',
      maxWidth: 340,
      backgroundColor: theme.bg,
      borderLeftWidth: 1,
      borderLeftColor: theme.border,
      shadowColor: '#000',
      shadowOffset: { width: -6, height: 0 },
      shadowOpacity: 0.35,
      shadowRadius: 24,
      elevation: 16,
    },
    drawerScroll: { paddingBottom: 30 },
    drawerHeader: {
      alignItems: 'center',
      paddingTop: 26,
      paddingBottom: 22,
      paddingHorizontal: 20,
      borderBottomWidth: 1,
      borderBottomColor: theme.border,
    },
    drawerCloseBtn: {
      position: 'absolute',
      top: 14,
      left: 14,
      width: 34,
      height: 34,
      borderRadius: 17,
      backgroundColor: theme.cardAlt,
      alignItems: 'center',
      justifyContent: 'center',
    },
    drawerLogoBadge: {
      width: 62,
      height: 62,
      borderRadius: 20,
      backgroundColor: theme.card,
      borderWidth: 1,
      borderColor: theme.border,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 10,
      shadowColor: theme.on,
      shadowOffset: { width: 0, height: 0 },
      shadowOpacity: 0.5,
      shadowRadius: 12,
      elevation: 6,
    },
    drawerBrandName: { color: theme.textPrimary, fontSize: 20, fontWeight: '800' },
    drawerBrandSub: { color: theme.textMuted, fontSize: 12, marginTop: 3, fontWeight: '600' },
    drawerSection: { paddingHorizontal: 14, paddingTop: 14 },
    drawerRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      paddingVertical: 13,
      paddingHorizontal: 10,
      borderRadius: 14,
    },
    drawerRowIconBox: {
      width: 36,
      height: 36,
      borderRadius: 12,
      backgroundColor: theme.cardAlt,
      borderWidth: 1,
      borderColor: theme.border,
      alignItems: 'center',
      justifyContent: 'center',
    },
    drawerRowLabel: { flex: 1, color: theme.textPrimary, fontSize: 14.5, fontWeight: '700' },
    drawerDivider: { height: 1, backgroundColor: theme.border, marginTop: 10, marginHorizontal: 20, opacity: 0.6 },
  });
