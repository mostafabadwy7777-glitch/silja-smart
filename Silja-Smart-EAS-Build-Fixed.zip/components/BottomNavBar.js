import React, { useEffect, useRef } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Platform, Animated } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';

// شريط التنقل السفلي — 5 عناصر: الرئيسية / الأجهزة / زرار الإضافة العائم في
// النص / المشاهد / الإعدادات. العنصر النشط بياخد لون accent الثيم الحالي
// وهالة متوهجة حواليه، والباقي بلون رمادي باهت. كل أيقونة كمان بتتوهج لحظة
// الدوس عليها (حتى لو مش هي العنصر النشط) عشان تدي إحساس فيه استجابة فورية.
export default function BottomNavBar({ screen, onNavigate, onAddPress, onSettingsPress, menuOpen }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);

  const isScenesActive = screen === 'scenes';
  // بقى بيتفعّل كمان لو الصفحة الجانبية (الدرج) فاتحة، أو لو واحدة من
  // الشاشات الفرعية اللي بتتفتح من جواها (إعدادات الاتصال/الثيمات/السجل/
  // النسخ الاحتياطي) هي الظاهرة دلوقتي.
  const isSettingsActive = menuOpen || screen === 'settings' || screen === 'theme' || screen === 'history' || screen === 'backup';

  return (
    <View style={styles.wrap}>
      <View style={styles.bar}>
        <NavItem
          icon="plus"
          label="إضافة"
          active={false}
          theme={theme}
          onPress={onAddPress}
          radar
        />
        <NavItem
          icon="chip"
          label="الأجهزة"
          active={false}
          theme={theme}
          onPress={() => onNavigate('boards')}
        />

        <View style={styles.fabSlot}>
          <GlowFab theme={theme} icon="home-variant" onPress={() => onNavigate('boards')} />
        </View>

        <NavItem
          icon="weather-night"
          label="المشاهد"
          active={isScenesActive}
          theme={theme}
          onPress={() => onNavigate('scenes')}
        />
        <NavItem
          icon="cog"
          label="الإعدادات"
          active={isSettingsActive}
          theme={theme}
          onPress={onSettingsPress}
        />
      </View>
    </View>
  );
}

// عنصر واحد في الشريط — أيقونة جوه هالة توهج بتتحرك بـ Animated:
// - لما يبقى "active" (التاب الحالي) الهالة بتفضل ظاهرة بهدوء طول الوقت.
// - لما تدوس عليه (حتى لو مش active) الهالة بتومض بسرعة كإحساس لمسي فوري،
//   وبعدين بترجع لحالتها (فاضية لو مش active، أو متوهجة لو active).
function NavItem({ icon, label, active, theme, onPress, radar }) {
  const color = active ? theme.accent : theme.textMuted;
  const glow = useRef(new Animated.Value(active ? 1 : 0)).current;

  useEffect(() => {
    Animated.timing(glow, {
      toValue: active ? 1 : 0,
      duration: 220,
      useNativeDriver: true,
    }).start();
  }, [active]);

  const flashOn = () => {
    Animated.timing(glow, { toValue: 1, duration: 90, useNativeDriver: true }).start();
  };
  const flashOff = () => {
    Animated.timing(glow, {
      toValue: active ? 1 : 0,
      duration: 260,
      useNativeDriver: true,
    }).start();
  };

  const glowOpacityOuter = glow.interpolate({ inputRange: [0, 1], outputRange: [0, 0.35] });
  const glowOpacityInner = glow.interpolate({ inputRange: [0, 1], outputRange: [0, 0.55] });
  const glowScale = glow.interpolate({ inputRange: [0, 1], outputRange: [0.5, 1] });

  return (
    <TouchableOpacity
      style={styles_.item}
      activeOpacity={0.7}
      onPress={onPress}
      onPressIn={flashOn}
      onPressOut={flashOff}
    >
      <View style={styles_.iconWrap}>
        {radar ? (
          <RadarWaves theme={theme} />
        ) : (
          <>
            <Animated.View
              pointerEvents="none"
              style={[
                styles_.glowOuter,
                { backgroundColor: theme.accent, opacity: glowOpacityOuter, transform: [{ scale: glowScale }] },
              ]}
            />
            <Animated.View
              pointerEvents="none"
              style={[
                styles_.glowInner,
                { backgroundColor: theme.accent, opacity: glowOpacityInner, transform: [{ scale: glowScale }] },
              ]}
            />
          </>
        )}
        <MaterialCommunityIcons name={icon} size={22} color={color} style={{ zIndex: 1 }} />
      </View>
      <Text style={[styles_.label, { color }]} numberOfLines={1}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

// حلقات رادار صغيرة بتتوسع وتخفت بشكل متتابع حوالين أيقونة "الإضافة" —
// نفس فكرة شاشة البحث عن الأجهزة، عشان الأيقونة نفسها تدي إحساس إن في
// بحث مستمر عن بوردات جديدة حتى وهي واقفة في الشريط.
function RadarWaves({ theme }) {
  const waves = useRef([0, 1, 2].map(() => new Animated.Value(0))).current;

  useEffect(() => {
    const loops = waves.map((w, i) =>
      Animated.loop(
        Animated.sequence([
          Animated.delay(i * 650),
          Animated.timing(w, { toValue: 1, duration: 1950, useNativeDriver: true }),
        ])
      )
    );
    loops.forEach((l) => l.start());
    return () => loops.forEach((l) => l.stop());
  }, [waves]);

  return (
    <>
      {waves.map((w, i) => (
        <Animated.View
          key={i}
          pointerEvents="none"
          style={[
            styles_.radarWave,
            {
              borderColor: theme.accent,
              opacity: w.interpolate({ inputRange: [0, 0.7, 1], outputRange: [0.55, 0.18, 0] }),
              transform: [{ scale: w.interpolate({ inputRange: [0, 1], outputRange: [0.3, 1] }) }],
            },
          ]}
        />
      ))}
    </>
  );
}

// زرار "+" العائم في النص — نفس فكرة التوهج، مع نبضة تكبير بسيطة لحظة الدوس
// عشان يحس المستخدم إنه ضغط بجد.
function GlowFab({ theme, onPress, icon = 'plus' }) {
  const glow = useRef(new Animated.Value(0)).current;
  const scale = useRef(new Animated.Value(1)).current;

  const pressIn = () => {
    Animated.parallel([
      Animated.timing(glow, { toValue: 1, duration: 100, useNativeDriver: true }),
      Animated.spring(scale, { toValue: 1.12, useNativeDriver: true, friction: 5 }),
    ]).start();
  };
  const pressOut = () => {
    Animated.parallel([
      Animated.timing(glow, { toValue: 0, duration: 260, useNativeDriver: true }),
      Animated.spring(scale, { toValue: 1, useNativeDriver: true, friction: 5 }),
    ]).start();
  };

  const glowOpacity = glow.interpolate({ inputRange: [0, 1], outputRange: [0, 0.6] });
  const glowScale = glow.interpolate({ inputRange: [0, 1], outputRange: [0.8, 1.5] });

  return (
    <TouchableOpacity
      style={getStyles(theme).fab}
      activeOpacity={0.85}
      onPress={onPress}
      onPressIn={pressIn}
      onPressOut={pressOut}
    >
      <Animated.View
        pointerEvents="none"
        style={[
          styles_.fabGlow,
          { backgroundColor: theme.accent, opacity: glowOpacity, transform: [{ scale: glowScale }] },
        ]}
      />
      <Animated.View style={{ transform: [{ scale }] }}>
        <MaterialCommunityIcons name={icon} size={26} color="#fff" />
      </Animated.View>
    </TouchableOpacity>
  );
}

const styles_ = StyleSheet.create({
  item: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 3, paddingTop: 4 },
  iconWrap: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
  glowOuter: { position: 'absolute', width: 40, height: 40, borderRadius: 20 },
  glowInner: { position: 'absolute', width: 28, height: 28, borderRadius: 14 },
  radarWave: { position: 'absolute', width: 40, height: 40, borderRadius: 20, borderWidth: 1.5 },
  label: { fontSize: 10.5, fontWeight: '600' },
  fabGlow: { position: 'absolute', width: 50, height: 50, borderRadius: 25 },
});

const getStyles = (theme) =>
  StyleSheet.create({
    wrap: {
      paddingHorizontal: 14,
      paddingBottom: Platform.OS === 'ios' ? 22 : 12,
      backgroundColor: theme.bg,
    },
    bar: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: theme.card,
      borderRadius: 22,
      borderWidth: 1,
      borderColor: theme.border,
      paddingVertical: 8,
      paddingHorizontal: 6,
      shadowColor: '#000',
      shadowOpacity: 0.25,
      shadowRadius: 10,
      shadowOffset: { width: 0, height: 6 },
      elevation: 10,
    },
    fabSlot: { width: 58, alignItems: 'center' },
    fab: {
      width: 50,
      height: 50,
      borderRadius: 25,
      backgroundColor: theme.accent,
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: -28,
      borderWidth: 4,
      borderColor: theme.bg,
      shadowColor: theme.accent,
      shadowOpacity: 0.5,
      shadowRadius: 8,
      shadowOffset: { width: 0, height: 3 },
      elevation: 8,
    },
  });
