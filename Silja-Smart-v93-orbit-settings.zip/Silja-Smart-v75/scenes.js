// ============================================================================
// مجموعات / مشاهد (Scenes) — تجميع مفاتيح من بوردات مختلفة وتشغيلهم بأمر واحد.
// ============================================================================
// السين نفسها بتتخزن محليًا بس (AsyncStorage عن طريق storage.js)، مفيش حاجة
// سيرفر هنا لأن التشغيل بيحصل وقت ما التطبيق فاتح وبيبعت أوامر MQTT عادية
// لنفس control_topic بتاع كل مفتاح، بالظبط زي لو دوست عليه من شاشته العادية.
// ============================================================================

// بيرجع قايمة مسطحة بكل المفاتيح المتاحة من كل البوردات (switches بس، مش الري)
// عشان تُستخدم في شاشة بناء الـ Scene.
export function flattenSwitchDevices(boards) {
  const result = [];
  (boards || []).forEach((board) => {
    if (board.type === 'irrigation') return;
    (board.devices || []).forEach((device) => {
      result.push({
        boardId: board.id,
        boardName: board.name,
        controlTopic: device.controlTopic,
        name: device.name,
        icon: device.icon,
        controlType: device.controlType || 'toggle',
      });
    });
  });
  return result;
}

// بيشغّل Scene: بينشر أمر MQTT (QoS 1) لكل أكشن فيها، وبيستنى تأكيد الإرسال من كل أمر.
// بيرجّع Promise: { ok, count, failed } — ok=true بس لو كل الأوامر اتبعتت فعلًا.
// الأفعال المتاحة:
// - toggle switches: 'ON' / 'OFF'
// - updown switches: 'UP' / 'DOWN' / 'STOP'
export async function runScene(scene, client) {
  if (!client || !client.connected || !scene) return { ok: false, error: 'مفيش اتصال بالسيرفر' };
  const actions = (Array.isArray(scene.actions) ? scene.actions : []).filter(
    (action) => action && typeof action.controlTopic === 'string' && action.controlTopic.trim() && typeof action.value === 'string' && action.value.trim()
  );
  if (actions.length === 0) return { ok: false, error: 'المشهد مفيهوش أوامر صالحة للتنفيذ.' };
  const results = await Promise.all(
    actions.map(
      (action) =>
        new Promise((resolve) => {
          try {
            client.publish(action.controlTopic, action.value, { qos: 1 }, (error) => resolve(!error));
          } catch (error) {
            resolve(false);
          }
        })
    )
  );
  const failed = results.filter((r) => !r).length;
  if (failed > 0) {
    return {
      ok: false,
      count: actions.length - failed,
      failed,
      error: failed === actions.length ? 'تعذر إرسال أوامر المشهد.' : `اتبعت ${actions.length - failed} من ${actions.length} أمر، و${failed} فشلوا. راجع الاتصال وشغّل المشهد تاني.`,
    };
  }
  return { ok: true, count: actions.length, failed: 0 };
}
