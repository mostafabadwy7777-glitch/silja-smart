// عدّاد اشتراكات مركزي لعميل MQTT.
// المشكلة القديمة: كل شاشة كانت بتعمل subscribe/unsubscribe لنفس التوبيك لوحدها، فلما شاشة
// تتقفل كانت بتلغي اشتراك شاشة تانية لسه محتاجاه (فحالة المفاتيح تفضل "غير معروفة").
// دلوقتي: الاشتراك الفعلي بيحصل مرة واحدة، والإلغاء الفعلي بس لما آخر شاشة تخلص منه.
// وكمان بنحتفظ بآخر رسالة Retained لكل توبيك ونعيد تسليمها لأي شاشة تشترك بعدين،
// لأن البروكر مش هيبعتها تاني للاشتراك الموجود أصلًا.
export function patchClientSubscriptions(client) {
  if (!client || client.__siljaRefCounted) return client;
  client.__siljaRefCounted = true;

  const counts = new Map();
  const retained = new Map();
  const origSubscribe = client.subscribe.bind(client);
  const origUnsubscribe = client.unsubscribe.bind(client);

  client.on('message', (topic, payload, packet) => {
    if (packet && packet.retain) retained.set(topic, { payload, packet });
  });

  const toList = (t) => (Array.isArray(t) ? t : typeof t === 'string' ? [t] : null);

  client.subscribe = (topic, ...rest) => {
    const list = toList(topic);
    if (!list) return origSubscribe(topic, ...rest);
    const cb = rest.find((r) => typeof r === 'function');
    const fresh = [];
    list.forEach((t) => {
      const n = counts.get(t) || 0;
      counts.set(t, n + 1);
      if (n === 0) fresh.push(t);
      else if (retained.has(t)) {
        const m = retained.get(t);
        setTimeout(() => client.emit('message', t, m.payload, m.packet), 0);
      }
    });
    if (fresh.length) return origSubscribe(fresh.length === 1 ? fresh[0] : fresh, ...rest);
    if (cb) setTimeout(() => cb(null, []), 0);
    return client;
  };

  client.unsubscribe = (topic, ...rest) => {
    const list = toList(topic);
    if (!list) return origUnsubscribe(topic, ...rest);
    const gone = [];
    list.forEach((t) => {
      const n = (counts.get(t) || 0) - 1;
      if (n <= 0) { counts.delete(t); retained.delete(t); gone.push(t); } else counts.set(t, n);
    });
    if (gone.length) return origUnsubscribe(gone.length === 1 ? gone[0] : gone, ...rest);
    const cb = rest.find((r) => typeof r === 'function');
    if (cb) setTimeout(() => cb(), 0);
    return client;
  };
  return client;
}
