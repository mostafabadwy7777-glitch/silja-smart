// ============================================================================
// محاكاة التواجد — تشغيل وإطفاء كشافات مختارة بأوقات شبه عشوائية بالليل.
// ============================================================================
// الإعدادات بتتخزن محليًا وبتتنشر (Retained) على silja/app/presence_sim عن طريق
// sceneScheduler.js، والتنفيذ بيحصل على السيرفر (server/) لو شغال، وإلا من التطبيق
// نفسه وهو مفتوح ومتصل. منطق الخطة المشترك في sceneScheduleCore.js (presencePlan).
// ============================================================================
import { useCallback, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = 'silja_presence_sim_v1';
export const PRESENCE_CONFIG_TOPIC = 'silja/app/presence_sim';

export const DEFAULT_PRESENCE = {
  enabled: false,
  startMode: 'sunset', // 'sunset' | 'time'
  startTime: '18:00',
  endTime: '23:30',
  targets: [], // controlTopics
};

const TIME_RE = /^([01]?\d|2[0-3]):[0-5]\d$/;
export const isValidTime = (t) => TIME_RE.test(String(t || '').trim());

function sanitize(raw) {
  const o = raw && typeof raw === 'object' ? raw : {};
  return {
    enabled: !!o.enabled,
    startMode: o.startMode === 'time' ? 'time' : 'sunset',
    startTime: isValidTime(o.startTime) ? String(o.startTime).trim() : DEFAULT_PRESENCE.startTime,
    endTime: isValidTime(o.endTime) ? String(o.endTime).trim() : DEFAULT_PRESENCE.endTime,
    targets: Array.isArray(o.targets) ? o.targets.filter((t) => typeof t === 'string' && t) : [],
  };
}

// الإعدادات اللي السيرفر محتاجها (tz و city من التطبيق).
export function buildPresenceConfig(cfg, city) {
  let tz = null;
  try { tz = Intl.DateTimeFormat().resolvedOptions().timeZone || null; } catch (_) {}
  return {
    v: 1,
    ...sanitize(cfg),
    tz,
    city: city && Number.isFinite(city.lat) && Number.isFinite(city.lon) ? { name: city.name, lat: city.lat, lon: city.lon } : null,
  };
}

// بيرجّع { config, setConfig }
export function usePresenceConfig() {
  const [config, setConfigState] = useState(DEFAULT_PRESENCE);

  useEffect(() => {
    let alive = true;
    AsyncStorage.getItem(KEY)
      .then((raw) => { if (alive && raw) setConfigState(sanitize(JSON.parse(raw))); })
      .catch(() => {});
    return () => { alive = false; };
  }, []);

  const setConfig = useCallback((next) => {
    const clean = sanitize(next);
    setConfigState(clean);
    AsyncStorage.setItem(KEY, JSON.stringify(clean)).catch(() => {});
  }, []);

  return { config, setConfig };
}
