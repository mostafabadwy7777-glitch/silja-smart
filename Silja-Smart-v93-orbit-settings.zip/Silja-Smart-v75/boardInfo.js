// ============================================================================
// معلومات الشبكة والجهاز للبوردات (IP / MAC / SSID / RSSI / مدة التشغيل).
// ============================================================================
// فيرموير ESP32 بينشر JSON Retained على `<device_id>/status/info` كل دقيقة:
// {chip,panel,ip,mac,ssid,rssi,uptime,heap,time}. الهوك بيرجّع { [boardId]: {..., receivedAt} }.
// ============================================================================
import { useEffect, useState } from 'react';

export function boardInfoTopic(board) {
  if (!board || board.type === 'irrigation') return null;
  return board.deviceId ? `${board.deviceId}/status/info` : null;
}

export function formatUptime(sec) {
  const s = Math.max(0, Math.floor(sec || 0));
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (d) return `${d} يوم ${h} ساعة`;
  if (h) return `${h} ساعة ${m} دقيقة`;
  return `${m} دقيقة`;
}

export function useBoardInfo(client, connected, boards = []) {
  const [info, setInfo] = useState({});
  const key = boards.map((b) => `${b.id}:${boardInfoTopic(b)}`).join(',');

  useEffect(() => {
    if (!client || !connected) return undefined;
    const topicToIds = new Map();
    boards.forEach((b) => {
      const t = boardInfoTopic(b);
      if (!t) return;
      if (!topicToIds.has(t)) topicToIds.set(t, []);
      topicToIds.get(t).push(b.id);
    });
    if (topicToIds.size === 0) return undefined;
    const topics = Array.from(topicToIds.keys());
    topics.forEach((t) => { try { client.subscribe(t); } catch (_) {} });
    const handler = (topic, payload) => {
      const ids = topicToIds.get(topic);
      if (!ids) return;
      let d;
      try { d = JSON.parse(payload.toString()); } catch (_) { return; }
      if (!d || typeof d !== 'object') return;
      const entry = { ...d, receivedAt: Date.now() };
      setInfo((prev) => {
        const next = { ...prev };
        ids.forEach((id) => { next[id] = entry; });
        return next;
      });
    };
    client.on('message', handler);
    return () => {
      client.off('message', handler);
      topics.forEach((t) => { try { client.unsubscribe(t); } catch (_) {} });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client, connected, key]);

  return info;
}
