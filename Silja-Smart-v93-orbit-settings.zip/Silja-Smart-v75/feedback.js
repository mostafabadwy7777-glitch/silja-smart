// اهتزاز خفيف عند الضغط على المفتاح + تأكيد صوتي اختياري لما الأمر يتبعت،
// عشان تحس إن الأمر اتبعت من غير ما تبص على الشاشة.
// الإعدادين بيتحكموا من: إعدادات المفاتيح > الاهتزاز والصوت.
//   - الاهتزاز: شغال افتراضيًا.
//   - الصوت: مقفول افتراضيًا (بيحترم وضع الصامت في الموبايل).
// أي فشل في الاهتزاز أو الصوت بيتتجاهل بهدوء — مش المفروض يأثر على إرسال الأوامر.
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Haptics from 'expo-haptics';
import { Audio } from 'expo-av';

const KEY = 'iot_feedback_v1';
const DEFAULTS = { haptic: true, sound: false };

let settings = { ...DEFAULTS };
let loadPromise = null;
let sound = null;
let soundLoading = null;

function ensureLoaded() {
  if (!loadPromise) {
    loadPromise = AsyncStorage.getItem(KEY)
      .then((raw) => {
        if (!raw) return;
        const parsed = JSON.parse(raw);
        settings = { haptic: parsed.haptic !== false, sound: parsed.sound === true };
      })
      .catch(() => {});
  }
  return loadPromise;
}
ensureLoaded();

export async function loadFeedbackSettings() {
  await ensureLoaded();
  return { ...settings };
}

export async function saveFeedbackSettings(patch) {
  await ensureLoaded();
  settings = { ...settings, ...patch };
  try { await AsyncStorage.setItem(KEY, JSON.stringify(settings)); } catch (_) {}
  return { ...settings };
}

async function getSound() {
  if (sound) return sound;
  if (!soundLoading) {
    soundLoading = Audio.Sound.createAsync(require('./assets/sounds/sent.wav'), { volume: 0.7 })
      .then(({ sound: s }) => { sound = s; return s; })
      .catch(() => { soundLoading = null; return null; });
  }
  return soundLoading;
}

// لحظة الضغط على المفتاح: اهتزاز خفيف فوري.
export function pressFeedback() {
  if (!settings.haptic) return;
  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light).catch(() => {});
}

// الأمر اتبعت فعلًا (تأكيد النشر من البروكر): صوت تأكيد لو متفعّل.
// (الاهتزاز بيحصل لحظة الضغط بس، عشان ماتحسش باهتزازتين.)
export function sentFeedback() {
  if (settings.sound) {
    getSound()
      .then((s) => (s ? s.replayAsync() : null))
      .catch(() => {});
  }
}

// فشل الإرسال: اهتزاز تحذيري.
export function errorFeedback() {
  if (!settings.haptic) return;
  Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error).catch(() => {});
}

// معاينة للصوت من شاشة الإعدادات.
export function previewSound() {
  getSound()
    .then((s) => (s ? s.replayAsync() : null))
    .catch(() => {});
}
