import React from 'react';
import { SafeAreaView, ScrollView, View, Text, StyleSheet } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useTheme } from '../ThemeContext';
import { FONTS } from '../fonts';
import ScreenBackground from '../components/ScreenBackground';
import ScreenHeader from '../components/ScreenHeader';

const OPACITIES = [
  { value: 0.00, label: '0%', name: 'زجاج كامل' },
  { value: 0.10, label: '10%', name: 'شبه خفي' },
  { value: 0.20, label: '20%', name: 'خفيف جدًا' },
  { value: 0.30, label: '30%', name: 'خفيف' },
  { value: 0.45, label: '45%', name: 'شفاف جدًا' },
  { value: 0.60, label: '60%', name: 'شفاف' },
  { value: 0.75, label: '75%', name: 'متوازن' },
  { value: 0.88, label: '88%', name: 'Glass Premium' },
  { value: 1.00, label: '100%', name: 'أوضح' },
];

const GRADIENTS = [
  { id: 'theme', name: 'مع الثيم (زجاج)', colors: null },
  { id: 'midnight', name: 'ليلي هادئ', colors: ['#101D30', '#263447', '#343047'] },
  { id: 'aurora', name: 'أورورا هادئ', colors: ['#123039', '#1C5559', '#302B46'] },
  { id: 'ocean', name: 'محيط عميق', colors: ['#12283B', '#1B4556', '#302C4B'] },
  { id: 'sunset', name: 'عنابي ناعم', colors: ['#302431', '#593746', '#655044'] },
  { id: 'gold', name: 'فحمي وذهبي', colors: ['#252630', '#454047', '#6B5C43'] },
];

export default function BottomNavSettingsScreen({ onBack }) {
  const { theme, bottomNavOpacity, bottomNavGradient, setBottomNavOpacity, setBottomNavGradient, bottomNavSize = 'compact', bottomNavLift = 12, setBottomNavSize = () => {}, setBottomNavLift = () => {} } = useTheme();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}> 
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <ScreenHeader title="شريط الأيقونات" onBack={onBack} />
        <Text style={[styles.subtitle, { color: theme.textSecondary }]}>تحكم في شفافية الشريط السفلي وتدريج ألوانه. التغيير يظهر فورًا.</Text>

        <View style={[styles.box, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={styles.head}>
            <View style={[styles.iconBox, { backgroundColor: `${theme.accent}18` }]}><MaterialCommunityIcons name="arrow-expand-vertical" size={21} color={theme.accent} /></View>
            <View style={{ flex: 1 }}><Text style={[styles.boxTitle, { color: theme.textPrimary }]}>حجم الشريط وارتفاعه</Text><Text style={[styles.boxSub, { color: theme.textSecondary }]}>صغّر الشريط وارفعه عن حافة الشاشة حسب راحتك.</Text></View>
          </View>
          <View style={styles.row}>
            {[{id:'compact',name:'صغير وأنيق'},{id:'standard',name:'متوسط'},{id:'large',name:'كبير'}].map(opt => { const selected = bottomNavSize === opt.id; return <TouchableOpacity key={opt.id} onPress={() => setBottomNavSize(opt.id)} style={[styles.sizeOption,{backgroundColor:theme.cardAlt,borderColor:selected?theme.accent:theme.border}]}><Text style={[styles.gradientName,{color:theme.textPrimary}]}>{opt.name}</Text><MaterialCommunityIcons name={selected?'check-circle':'circle-outline'} size={17} color={selected?theme.accent:theme.border}/></TouchableOpacity>; })}
          </View>
          <Text style={[styles.boxSub,{color:theme.textSecondary,marginTop:12,marginBottom:8}]}>المسافة من أسفل الشاشة</Text>
          <View style={styles.row}>
            {[{v:0,l:'قريب'},{v:12,l:'مرفوع'},{v:22,l:'مرتفع'}].map(opt => { const selected = bottomNavLift === opt.v; return <TouchableOpacity key={opt.v} onPress={() => setBottomNavLift(opt.v)} style={[styles.liftOption,{backgroundColor:theme.cardAlt,borderColor:selected?theme.accent:theme.border}]}><Text style={[styles.label,{color:theme.textPrimary}]}>{opt.l}</Text><Text style={[styles.name,{color:theme.textSecondary}]}>{opt.v===0?'':`${opt.v}px`}</Text></TouchableOpacity>; })}
          </View>
        </View>

        <View style={[styles.box, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={styles.head}>
            <View style={[styles.iconBox, { backgroundColor: `${theme.accent}18` }]}><MaterialCommunityIcons name="blur" size={21} color={theme.accent} /></View>
            <View style={{ flex: 1 }}><Text style={[styles.boxTitle, { color: theme.textPrimary }]}>شفافية الشريط</Text><Text style={[styles.boxSub, { color: theme.textSecondary }]}>اختار مقدار ظهور الخلفية من خلال الزجاج.</Text></View>
          </View>
          <View style={styles.row}>
            {OPACITIES.map(o => {
              const selected = Math.abs(bottomNavOpacity - o.value) < 0.01;
              return (
                <TouchableOpacity key={o.value} onPress={() => setBottomNavOpacity(o.value)} style={[styles.opacity, { backgroundColor: theme.isLight ? `rgba(250,248,242,${o.value})` : `rgba(12,13,15,${o.value})`, borderColor: selected ? theme.accent : theme.border }, selected && { shadowColor: theme.accent, shadowOpacity: .10, shadowRadius: 5, elevation: 3 }]}>
                  <MaterialCommunityIcons name="glass-mug-variant" size={18} color={selected ? theme.accent : theme.textSecondary} />
                  <Text style={[styles.label, { color: theme.textPrimary }]}>{o.label}</Text>
                  <Text style={[styles.name, { color: theme.textSecondary }]}>{o.name}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        <View style={[styles.box, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={styles.head}>
            <View style={[styles.iconBox, { backgroundColor: `${theme.accent}18` }]}><MaterialCommunityIcons name="gradient-horizontal" size={21} color={theme.accent} /></View>
            <View style={{ flex: 1 }}><Text style={[styles.boxTitle, { color: theme.textPrimary }]}>تدريج ألوان الشريط</Text><Text style={[styles.boxSub, { color: theme.textSecondary }]}>اختار تدرج الألوان اللي يناسب شكل التطبيق.</Text></View>
          </View>
          <View style={styles.gradientGrid}>
            {GRADIENTS.map(g => {
              const selected = bottomNavGradient === g.id;
              return (
                <TouchableOpacity key={g.id} onPress={() => setBottomNavGradient(g.id)} style={[styles.gradientCard, { backgroundColor: theme.cardAlt, borderColor: selected ? theme.accent : theme.border }, selected && { shadowColor: theme.accent, shadowOpacity: .12, shadowRadius: 6, elevation: 4 }]}>
                  <LinearGradient colors={g.colors || [theme.card, theme.cardAlt, theme.card]} start={{x:0,y:0}} end={{x:1,y:0}} style={[styles.preview, !g.colors && { borderWidth: 1, borderColor: theme.accent }]} />
                  <Text style={[styles.gradientName, { color: theme.textPrimary }]}>{g.name}</Text>
                  <MaterialCommunityIcons name={selected ? 'check-circle' : 'circle-outline'} size={18} color={selected ? theme.accent : theme.border} />
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 18, paddingTop: 36 },
  content: { paddingBottom: 130 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  title: { fontSize: 23, fontWeight: '800', fontFamily: FONTS.display },
  back: { fontSize: 15, fontWeight: '800' },
  subtitle: { fontSize: 12, lineHeight: 19, textAlign: 'right', marginBottom: 16 },
  box: { borderRadius: 20, borderWidth: 1, padding: 15, marginBottom: 14 },
  head: { flexDirection: 'row', alignItems: 'center', gap: 11, marginBottom: 14 },
  iconBox: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  boxTitle: { fontSize: 16, fontWeight: '800', textAlign: 'right' },
  boxSub: { fontSize: 11.5, lineHeight: 17, textAlign: 'right', marginTop: 2 },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  opacity: { flex: 1, minWidth: 58, minHeight: 78, borderRadius: 15, borderWidth: 1.2, alignItems: 'center', justifyContent: 'center', paddingVertical: 8 },
  label: { fontSize: 11, fontWeight: '800', marginTop: 3 },
  name: { fontSize: 9, marginTop: 1 },
  gradientGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 9 },
  sizeOption: { flexGrow: 1, minWidth: '30%', borderRadius: 14, borderWidth: 1.2, padding: 11, alignItems: 'center', gap: 6 },
  liftOption: { flex: 1, borderRadius: 14, borderWidth: 1.2, padding: 9, alignItems: 'center', gap: 3 },
  gradientCard: { width: '48%', minWidth: 132, flexGrow: 1, borderRadius: 17, borderWidth: 1.2, padding: 10, alignItems: 'center', gap: 7 },
  preview: { width: '100%', height: 38, borderRadius: 12 },
  gradientName: { fontSize: 12, fontWeight: '800' },
});
