import React, { useEffect, useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, StyleSheet, StatusBar } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { showAlert } from '../components/PremiumAlert';
import PremiumSwitch from '../components/PremiumSwitch';
import ScreenBackground from '../components/ScreenBackground';
import { FONTS } from '../fonts';
import { useTheme } from '../ThemeContext';
import PinSetupModal from '../components/PinSetupModal';
import AppBackgroundModal from '../components/AppBackgroundModal';
import WeatherCityModal from '../components/WeatherCityModal';
import { hasPin, clearPin, loadAutoLockSec, saveAutoLockSec, DEFAULT_AUTO_LOCK_SEC } from '../storage';
import { loadWeatherCity, subscribeWeatherCity, DEFAULT_CITY } from '../weather';
import appJson from '../app.json';

// شاشة الإعدادات الرئيسية (تبويب "الإعدادات" في الشريط السفلي) — قائمة صفوف
// زي أي تطبيق منزل ذكي محترم: كل صف بأيقونته جوه مربع ملوّن، عنوان وسطر
// فرعي، وإما سهم للدخول لصفحة تانية أو سويتش تبديل مباشر.
export default function SettingsHomeScreen({
  connected,
  configured,
  themeName,
  onOpenConnection,
  onOpenTheme,
  onOpenSwitchSettings,
  onOpenBottomNavSettings,
  onOpenHistory,
  onOpenBackup,
  onOpenManualBoard,
  pushEnabled,
  onTogglePush,
  biometricEnabled,
  onToggleBiometric,
}) {
  const { theme, isLight, toggleLightDark } = useTheme();
  const styles = getStyles(theme);
  const version = appJson?.expo?.version || '1.0.0';
  const [pinOn, setPinOn] = useState(false);
  const [pinModal, setPinModal] = useState(false);
  const [bgModal, setBgModal] = useState(false);
  const [cityModal, setCityModal] = useState(false);
  const [cityName, setCityName] = useState(DEFAULT_CITY.name);
  const [autoLock, setAutoLock] = useState(DEFAULT_AUTO_LOCK_SEC);
  useEffect(() => {
    loadWeatherCity().then((c) => setCityName(c.name));
    loadAutoLockSec().then(setAutoLock);
    return subscribeWeatherCity((c) => setCityName(c.name));
  }, []);
  const AUTO_LOCK_OPTIONS = [[30, '30 ثانية'], [60, 'دقيقة'], [300, '5 دقائق'], [-1, 'أبدًا (عند فتح التطبيق من الصفر بس)']];
  const autoLockLabel = (AUTO_LOCK_OPTIONS.find(([v]) => v === autoLock) || AUTO_LOCK_OPTIONS[1])[1].split(' (')[0];
  const chooseAutoLock = () =>
    showAlert('القفل التلقائي', 'التطبيق يتقفل تاني لو قعد في الخلفية أكتر من:', [
      ...AUTO_LOCK_OPTIONS.map(([v, label]) => ({ text: label, onPress: () => { setAutoLock(v); saveAutoLockSec(v); } })),
      { text: 'إلغاء', style: 'cancel' },
    ]);
  useEffect(() => { hasPin().then(setPinOn).catch(() => {}); }, []);
  const onTogglePin = async () => {
    if (pinOn) {
      await clearPin();
      setPinOn(false);
    } else {
      setPinModal(true);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScreenBackground theme={theme} />
      <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} />
      <ScrollView contentContainerStyle={{ paddingBottom: 130 }} showsVerticalScrollIndicator={false}>
        <Text style={styles.pageTitle}>الإعدادات</Text>

        <View style={styles.profileCard}>
          <View style={styles.avatar}>
            <MaterialCommunityIcons name="home-automation" size={26} color="#fff" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={styles.profileName}>Silja Smart</Text>
            <Text style={styles.profileSub}>{configured ? (connected ? 'متصل بالسيرفر' : 'مش متصل حاليًا') : 'لسه محتاج إعداد'}</Text>
          </View>
          <View style={[styles.dot, { backgroundColor: connected ? theme.on : theme.off }]} />
        </View>

        <View style={styles.section}>
          <Row icon="server-network" title="السيرفر و MQTT" subtitle="إعدادات الاتصال بالسيرفر" theme={theme} styles={styles} onPress={onOpenConnection} />
          <Row icon="pencil-plus-outline" title="إضافة بورد يدوي" subtitle="إضافة بورد بدون اكتشاف تلقائي" theme={theme} styles={styles} onPress={onOpenManualBoard} />
          <Row icon="palette-outline" title="المظهر والثيمات" subtitle={themeName} theme={theme} styles={styles} onPress={onOpenTheme} />
          <Row icon="weather-partly-cloudy" title="مدينة الطقس" subtitle={cityName} theme={theme} styles={styles} onPress={() => setCityModal(true)} />
          <Row icon="image-outline" title="خلفية التطبيق" subtitle="اختار صورة من المعرض لكل الشاشات" theme={theme} styles={styles} onPress={() => setBgModal(true)} />
          <Row icon="toggle-switch-outline" title="إعدادات المفاتيح" subtitle="شكل السويتش • شكل الكارت • الحجم • الشفافية" theme={theme} styles={styles} onPress={onOpenSwitchSettings} />
          <Row icon="dock-bottom" title="شريط الأيقونات" subtitle="الشفافية • التدرج • ألوان الشريط الزجاجي" theme={theme} styles={styles} onPress={onOpenBottomNavSettings} />
          <Row icon="bell-outline" title="الإشعارات" subtitle="إدارة تنبيهات التطبيق" theme={theme} styles={styles} trailing={<PremiumSwitch value={pushEnabled} onValueChange={onTogglePush} theme={theme} />} />
          <Row icon={isLight ? 'weather-sunny' : 'weather-night'} title="الوضع الليلي" subtitle={isLight ? 'الوضع الفاتح' : 'الوضع الداكن'} theme={theme} styles={styles} trailing={<PremiumSwitch value={!isLight} onValueChange={toggleLightDark} theme={theme} />} />
          <Row icon="shield-lock-outline" title="الأمان" subtitle="البصمة وحماية التطبيق" theme={theme} styles={styles} trailing={<PremiumSwitch value={biometricEnabled} onValueChange={onToggleBiometric} theme={theme} />} />
          <Row icon="timer-outline" title="القفل التلقائي" subtitle={`بعد ${autoLockLabel} في الخلفية`} theme={theme} styles={styles} onPress={chooseAutoLock} />
          <Row icon="dialpad" title="رمز الدخول (PIN)" subtitle="قفل التطبيق بأربعة أرقام" theme={theme} styles={styles} trailing={<PremiumSwitch value={pinOn} onValueChange={onTogglePin} theme={theme} />} />
          <Row icon="history" title="سجل الأحداث" subtitle="آخر الأحداث والتنبيهات" theme={theme} styles={styles} onPress={onOpenHistory} />
          <Row icon="cloud-upload-outline" title="النسخ الاحتياطي والاستعادة" subtitle="حفظ واستعادة بيانات التطبيق" theme={theme} styles={styles} onPress={onOpenBackup} />
          <Row icon="information-outline" title="حول التطبيق" subtitle={`Silja Smart • الإصدار ${version}`} theme={theme} styles={styles} last onPress={() => showAlert('Silja Smart', `الإصدار ${version}`)} />
        </View>
      </ScrollView>
      <WeatherCityModal visible={cityModal} onClose={() => setCityModal(false)} />
      <AppBackgroundModal visible={bgModal} onClose={() => setBgModal(false)} />
      <PinSetupModal visible={pinModal} onClose={() => setPinModal(false)} onSaved={() => { setPinOn(true); setPinModal(false); }} />
    </SafeAreaView>
  );
}

function SettingsSection({ title, icon, theme, styles, children }) {
  return (
    <View style={styles.sectionBlock}>
      <View style={styles.sectionHeader}>
        <View style={[styles.sectionHeaderIcon, { backgroundColor: theme.cardAlt }]}>
          <MaterialCommunityIcons name={icon} size={18} color={theme.accent} />
        </View>
        <Text style={styles.sectionTitle}>{title}</Text>
      </View>
      <View style={styles.section}>{children}</View>
    </View>
  );
}

function Row({ icon, title, subtitle, trailing, onPress, theme, styles, last }) {
  const Wrapper = trailing ? View : TouchableOpacity;
  const pressable = !trailing && typeof onPress === 'function';
  return (
    <Wrapper
      style={styles.row}
      activeOpacity={0.7}
      onPress={pressable ? onPress : undefined}
      disabled={!pressable && !trailing}
    >
      <View style={styles.rowIconBox}>
        <MaterialCommunityIcons name={(MaterialCommunityIcons.glyphMap || {})[icon] ? icon : 'cog-outline'} size={20} color={theme.accentSoft} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.rowTitle}>{title}</Text>
        <Text style={styles.rowSub}>{subtitle}</Text>
      </View>
      {trailing || <MaterialCommunityIcons name="chevron-left" size={18} color={theme.textMuted} />}
    </Wrapper>
  );
}

const getStyles = (theme) =>
  StyleSheet.create({
    container: { flex: 1, backgroundColor: theme.bg, paddingHorizontal: 20, paddingTop: 18 },
    pageTitle: { fontSize: 27, fontWeight: '800', fontFamily: FONTS.display, color: theme.textPrimary, marginBottom: 14, textAlign: 'right' },
    profileCard: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: theme.card,
      borderRadius: 24,
      padding: 18,
      gap: 12,
      marginBottom: 18,
      borderWidth: 1,
      borderColor: theme.isLight ? theme.border : 'rgba(214,179,106,0.24)',
      shadowColor: '#000', shadowOffset: { width: 0, height: 5 }, shadowOpacity: 0.16, shadowRadius: 12, elevation: 3,
    },
    avatar: {
      width: 52,
      height: 52,
      borderRadius: 26,
      backgroundColor: theme.accent,
      alignItems: 'center',
      justifyContent: 'center',
    },
    profileName: { fontSize: 16, fontWeight: '700', color: theme.textPrimary, textAlign: 'right' },
    profileSub: { fontSize: 12, color: theme.textSecondary, marginTop: 2, textAlign: 'right' },
    dot: { width: 10, height: 10, borderRadius: 5 },
    sectionBlock: { marginBottom: 18 },
    sectionHeader: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 7, paddingHorizontal: 2 },
    sectionHeaderIcon: { width: 32, height: 32, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
    sectionTitle: { fontSize: 13.5, fontWeight: '800', color: theme.textPrimary, textAlign: 'right' },
    // كل صف كارت لوحده بمسافة بينهم (زي التصميم المرجعي) بدل كارت كبير بخطوط فاصلة.
    section: { gap: 10 },
    row: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      paddingHorizontal: 14,
      paddingVertical: 13,
      backgroundColor: theme.card,
      borderRadius: 18,
      borderWidth: 1,
      borderColor: theme.isLight ? theme.border : 'rgba(214,179,106,0.22)',
      shadowColor: '#000', shadowOffset: { width: 0, height: 3 }, shadowOpacity: theme.isLight ? 0.06 : 0.18, shadowRadius: 8, elevation: 2,
    },
    rowIconBox: {
      width: 42,
      height: 42,
      borderRadius: 13,
      backgroundColor: theme.cardAlt,
      borderWidth: 1,
      borderColor: theme.isLight ? theme.border : 'rgba(214,179,106,0.35)',
      alignItems: 'center',
      justifyContent: 'center',
    },
    rowTitle: { fontSize: 14.5, fontWeight: '800', color: theme.textPrimary, textAlign: 'right' },
    rowSub: { fontSize: 11.5, color: theme.textSecondary, marginTop: 2, textAlign: 'right', lineHeight: 17 },
  });
