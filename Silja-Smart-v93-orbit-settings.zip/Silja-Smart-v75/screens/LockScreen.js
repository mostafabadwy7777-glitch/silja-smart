import React, { useEffect, useState } from 'react';
import { SafeAreaView, View, Text, StyleSheet, StatusBar } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as LocalAuthentication from 'expo-local-authentication';
import { FONTS } from '../fonts';
import { useTheme } from '../ThemeContext';
import PinKeypad, { PinDots, PIN_LENGTH } from '../components/PinKeypad';
import { verifyPin, clearPin, getPinLockRemainingMs, registerPinFailure, resetPinFailures } from '../storage';

// شاشة القفل: لو فيه PIN بتعرض لوحة أرقام (مع زرار بصمة لو مفعّلة)، ولو البصمة
// بس مفعّلة بتفضل بالشكل القديم (طلب بصمة مباشر). "نسيت رمز الدخول؟" بتطلب
// تحقق من قفل الموبايل نفسه (بصمة أو نمط/PIN الجهاز)؛ لو نجح بنمسح الرمز.
export default function LockScreen({ onUnlocked, pinEnabled = false, biometricEnabled = false }) {
  const { theme, isLight } = useTheme();
  const styles = getStyles(theme);
  const [status, setStatus] = useState('idle'); // idle | checking | error
  const [errorMsg, setErrorMsg] = useState('');
  const [pin, setPin] = useState('');
  const [pinError, setPinError] = useState(false);
  const [lockMs, setLockMs] = useState(0); // وقت القفل المتبقي بعد محاولات غلط كتير

  const tryBiometric = async () => {
    setStatus('checking');
    setErrorMsg('');

    const hasHardware = await LocalAuthentication.hasHardwareAsync();
    const isEnrolled = await LocalAuthentication.isEnrolledAsync();

    if (!hasHardware || !isEnrolled) {
      // الموبايل مفيهوش بصمة متسجلة — لو مفيش PIN منسمحش بحماية وهمية، ولو فيه PIN
      // المستخدم يكمّل بالـ PIN.
      if (!pinEnabled) onUnlocked();
      else setStatus('idle');
      return;
    }

    const result = await LocalAuthentication.authenticateAsync({
      promptMessage: 'افتح Silja Smart',
      cancelLabel: 'إلغاء',
      disableDeviceFallback: false,
    });

    if (result.success) {
      onUnlocked();
    } else {
      setStatus('error');
      setErrorMsg('مفيش تحقق حصل — جرب تاني');
    }
  };

  // لو كان فيه قفل مؤقت لسه سارى (حتى بعد إغلاق التطبيق) نكمّله
  useEffect(() => { getPinLockRemainingMs().then(setLockMs).catch(() => {}); }, []);
  useEffect(() => {
    if (lockMs <= 0) return undefined;
    const t = setInterval(() => setLockMs((ms) => Math.max(0, ms - 1000)), 1000);
    return () => clearInterval(t);
  }, [lockMs > 0]);

  useEffect(() => {
    if (biometricEnabled) tryBiometric();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const onDigit = (d) => {
    if (lockMs > 0 || pin.length >= PIN_LENGTH || status === 'checking') return;
    const next = pin + d;
    setPin(next);
    setPinError(false);
    setErrorMsg('');
    if (next.length === PIN_LENGTH) {
      setStatus('checking');
      verifyPin(next).then((ok) => {
        if (ok) {
          resetPinFailures().catch(() => {});
          onUnlocked();
        } else {
          registerPinFailure().then(({ remainingMs, triesLeft }) => {
            setStatus('idle');
            setPinError(true);
            if (remainingMs > 0) {
              setLockMs(remainingMs);
              setErrorMsg('');
            } else {
              setErrorMsg(`الرمز غلط — باقي ${triesLeft} محاولات قبل القفل المؤقت`);
            }
            setTimeout(() => { setPin(''); setPinError(false); }, 500);
          });
        }
      });
    }
  };

  const forgotPin = async () => {
    const hasHardware = await LocalAuthentication.hasHardwareAsync();
    const isEnrolled = await LocalAuthentication.isEnrolledAsync();
    if (!hasHardware || !isEnrolled) {
      setErrorMsg('لازم قفل شاشة على الموبايل عشان تقدر تعيد ضبط الرمز. ممكن تمسح بيانات التطبيق من إعدادات الموبايل.');
      return;
    }
    const result = await LocalAuthentication.authenticateAsync({
      promptMessage: 'أكّد هويتك لإعادة ضبط رمز الدخول',
      cancelLabel: 'إلغاء',
      disableDeviceFallback: false,
    });
    if (result.success) {
      await clearPin();
      onUnlocked();
    } else {
      setErrorMsg('لم يتم التحقق من هويتك');
    }
  };

  // ---- بصمة فقط (من غير PIN): الشكل القديم ----
  if (!pinEnabled) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
        <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} />
        <View style={styles.center}>
          <View style={styles.iconCircle}>
            <MaterialCommunityIcons name="shield-lock-outline" size={40} color="#D6B36A" />
          </View>
          <Text style={styles.title}>Silja Smart مقفول</Text>
          <Text style={styles.hint}>افتحه ببصمة إصبعك أو بصمة وجهك</Text>

          {!!errorMsg && <Text style={styles.errorText}>{errorMsg}</Text>}

          <TouchableOpacity
            style={styles.unlockBtn}
            onPress={tryBiometric}
            activeOpacity={0.85}
            disabled={status === 'checking'}
          >
            <MaterialCommunityIcons name="fingerprint" size={20} color="#17140E" />
            <Text style={styles.unlockBtnText}>{status === 'checking' ? 'جاري التحقق…' : 'حاول تاني'}</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // ---- لوحة PIN (تصميم Noir Champagne) ----
  return (
    <View style={styles.pinRoot}>
      <StatusBar barStyle="light-content" />
      <LinearGradient
        pointerEvents="none"
        colors={['#0A0B0D', '#17130B', '#0A0B0D']}
        start={{ x: 0.1, y: 0 }}
        end={{ x: 0.9, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <SafeAreaView style={styles.pinSafe}>
        <View style={styles.pinTop}>
          <MaterialCommunityIcons name="home-variant-outline" size={44} color="#D6B36A" />
          <Text style={styles.pinBrand}>Silja Smart</Text>
          <Text style={styles.pinPrompt}>أدخل رمز الدخول</Text>
          <PinDots length={pin.length} error={pinError} />
          <Text style={[styles.errorText, { minHeight: 34 }]}>
            {lockMs > 0 ? `محاولات غلط كتير — جرب بعد ${lockMs >= 60000 ? `${Math.ceil(lockMs / 60000)} دقيقة` : `${Math.ceil(lockMs / 1000)} ثانية`}` : errorMsg}
          </Text>
        </View>
        <PinKeypad
          onDigit={onDigit}
          onBackspace={() => setPin((p) => p.slice(0, -1))}
          extraKey={biometricEnabled ? { icon: 'fingerprint', onPress: tryBiometric } : null}
        />
        <TouchableOpacity onPress={forgotPin} style={styles.forgot} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Text style={styles.forgotText}>نسيت رمز الدخول؟</Text>
        </TouchableOpacity>
      </SafeAreaView>
    </View>
  );
}

function getStyles(theme) {
  return StyleSheet.create({
    container: { flex: 1 },
    center: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 30 },
    iconCircle: {
      width: 92,
      height: 92,
      borderRadius: 46,
      backgroundColor: 'rgba(214,179,106,0.08)',
      borderWidth: 1.5,
      borderColor: 'rgba(214,179,106,0.55)',
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 18,
    },
    title: { color: theme.textPrimary, fontSize: 19, fontWeight: '800', fontFamily: FONTS.display, marginBottom: 6 },
    hint: { color: theme.textSecondary, fontSize: 13, marginBottom: 20, textAlign: 'center' },
    errorText: { color: '#D96B82', fontSize: 12, marginBottom: 14, textAlign: 'center', paddingHorizontal: 30 },
    unlockBtn: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 8,
      backgroundColor: '#D6B36A',
      borderRadius: 18,
      paddingVertical: 15,
      paddingHorizontal: 30,
    },
    unlockBtnText: { color: '#17140E', fontWeight: '700', fontSize: 14 },
    pinRoot: { flex: 1, backgroundColor: '#0A0B0D' },
    pinSafe: { flex: 1, alignItems: 'center', justifyContent: 'center' },
    pinTop: { alignItems: 'center' },
    pinBrand: { color: '#E8D2A0', fontSize: 26, fontWeight: '800', fontFamily: FONTS.display, marginTop: 8 },
    pinPrompt: { color: '#C8B27A', fontSize: 16, marginTop: 26 },
    forgot: { marginTop: 26 },
    forgotText: { color: '#C8B27A', fontSize: 13 },
  });
}
