import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, TextInput, StyleSheet } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FONTS } from '../fonts';
import { useTheme } from '../ThemeContext';
import ConnectionStatusBanner from '../components/ConnectionStatusBanner';
import ScreenBackground from '../components/ScreenBackground';
import ScreenHeader from '../components/ScreenHeader';
import PremiumSwitch from '../components/PremiumSwitch';
import { flattenSwitchDevices } from '../scenes';
import { getDeviceIcon } from '../deviceIcons';
import { readableOn } from '../colorUtils';
import { isValidTime } from '../presenceSim';
import { presencePlan, deviceLocalOf, formatMinutes } from '../sceneScheduleCore';

export default function PresenceSimScreen({ boards, config, onChange, connected, weatherCity, schedulerServerOnline = false, onBack }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);
  const devices = flattenSwitchDevices(boards).filter((d) => d.controlTopic);
  const lights = devices.filter((d) => getDeviceIcon(d.icon).isLight);
  const [startText, setStartText] = useState(config.startTime);
  const [endText, setEndText] = useState(config.endTime);

  const update = (patch) => onChange({ ...config, ...patch });
  const toggleTarget = (topic) =>
    update({ targets: config.targets.includes(topic) ? config.targets.filter((t) => t !== topic) : [...config.targets, topic] });
  const allLightsOn = lights.length > 0 && lights.every((d) => config.targets.includes(d.controlTopic));
  const toggleLights = () => {
    const topics = lights.map((d) => d.controlTopic);
    update({ targets: allLightsOn ? config.targets.filter((t) => !topics.includes(t)) : Array.from(new Set([...config.targets, ...topics])) });
  };
  const commitTime = (key, text, setText) => {
    if (isValidTime(text)) update({ [key]: text.trim() });
    else setText(config[key]);
  };

  // خطة النهاردة (نفس اللي هيتنفذ فعلًا).
  const plan = presencePlan(config.enabled ? config : { ...config, enabled: true }, deviceLocalOf(Date.now()), weatherCity, deviceLocalOf);
  const nameOf = (topic) => (devices.find((d) => d.controlTopic === topic) || {}).name || 'مفتاح';
  const planByTopic = config.targets
    .map((t) => ({ topic: t, on: plan.find((e) => e.topic === t && e.value === 'ON'), off: plan.find((e) => e.topic === t && e.value === 'OFF') }))
    .filter((p) => p.on && p.off);

  return (
    <SafeAreaView style={styles.safe}>
      <ScreenBackground theme={theme} />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        <ScreenHeader title="محاكاة التواجد" onBack={onBack} />

        <ConnectionStatusBanner
          theme={theme}
          connected={!!connected}
          title={schedulerServerOnline ? 'السيرفر بينفّذ المحاكاة' : 'المحاكاة بتتنفذ من التطبيق'}
          detail={
            !connected
              ? 'مفيش اتصال — الإعدادات محفوظة وهتتنشر لما الاتصال يرجع.'
              : schedulerServerOnline
                ? 'هتشتغل حتى والتطبيق مقفول.'
                : 'سيرفر الجدولة مش شغال، فلازم التطبيق يفضل مفتوح ومتصل وقت التنفيذ.'
          }
        />

        <View style={styles.card}>
          <View style={styles.rowBetween}>
            <PremiumSwitch value={config.enabled} onValueChange={(v) => update({ enabled: v })} theme={theme} size={0.9} />
            <View style={{ flex: 1 }}>
              <Text style={styles.title}>تفعيل المحاكاة</Text>
              <Text style={styles.sub}>كل ليلة تشغيل وإطفاء الكشافات المختارة بأوقات مختلفة شوية. اقفلها لما ترجع.</Text>
            </View>
          </View>
        </View>

        <Text style={styles.sectionLabel}>الوقت</Text>
        <View style={styles.card}>
          <Text style={styles.fieldLabel}>تبدأ من</Text>
          <View style={styles.chipsRow}>
            {[['sunset', 'الغروب'], ['time', 'ساعة محددة']].map(([v, label]) => (
              <TouchableOpacity key={v} style={[styles.chip, config.startMode === v && styles.chipOn]} onPress={() => update({ startMode: v })}>
                <Text style={[styles.chipText, config.startMode === v && styles.chipTextOn]}>{label}</Text>
              </TouchableOpacity>
            ))}
            {config.startMode === 'time' && (
              <TextInput
                value={startText}
                onChangeText={setStartText}
                onEndEditing={() => commitTime('startTime', startText, setStartText)}
                onBlur={() => commitTime('startTime', startText, setStartText)}
                placeholder="18:00"
                placeholderTextColor={theme.textMuted}
                keyboardType="numbers-and-punctuation"
                maxLength={5}
                style={styles.timeInput}
              />
            )}
          </View>
          <Text style={styles.fieldLabel}>تنتهي الساعة (قبل منتصف الليل)</Text>
          <TextInput
            value={endText}
            onChangeText={setEndText}
            onEndEditing={() => commitTime('endTime', endText, setEndText)}
            onBlur={() => commitTime('endTime', endText, setEndText)}
            placeholder="23:30"
            placeholderTextColor={theme.textMuted}
            keyboardType="numbers-and-punctuation"
            maxLength={5}
            style={[styles.timeInput, { alignSelf: 'flex-end' }]}
          />
        </View>

        <Text style={styles.sectionLabel}>الكشافات</Text>
        <View style={styles.card}>
          {devices.length === 0 ? (
            <Text style={styles.sub}>مفيش مفاتيح مضافة لسه.</Text>
          ) : (
            <>
              {lights.length > 0 && (
                <TouchableOpacity style={[styles.chip, styles.lightsChip, allLightsOn && styles.chipOn]} onPress={toggleLights}>
                  <MaterialCommunityIcons name="lightbulb-group-outline" size={16} color={allLightsOn ? readableOn(theme.accent) : theme.accentSoft} />
                  <Text style={[styles.chipText, allLightsOn && styles.chipTextOn]}>كل الإضاءة ({lights.length})</Text>
                </TouchableOpacity>
              )}
              <View style={styles.chipsRow}>
                {devices.map((d) => {
                  const on = config.targets.includes(d.controlTopic);
                  return (
                    <TouchableOpacity key={`${d.boardId}-${d.controlTopic}`} style={[styles.chip, on && styles.chipOn]} onPress={() => toggleTarget(d.controlTopic)}>
                      <Text style={[styles.chipText, on && styles.chipTextOn]} numberOfLines={1}>{d.name || 'مفتاح'}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
            </>
          )}
        </View>

        {planByTopic.length > 0 && (
          <>
            <Text style={styles.sectionLabel}>خطة النهاردة</Text>
            <View style={styles.card}>
              {planByTopic.map((p, i) => (
                <View key={p.topic} style={[styles.planRow, i > 0 && styles.planDivider]}>
                  <Text style={styles.planTimes}>{formatMinutes(p.on.minute)} ← {formatMinutes(p.off.minute)}</Text>
                  <Text style={styles.planName} numberOfLines={1}>{nameOf(p.topic)}</Text>
                </View>
              ))}
              <Text style={[styles.sub, { marginTop: 8 }]}>الأوقات بتتغير كل يوم، وبتتحدد بالغروب حسب المدينة المضبوطة للطقس.</Text>
            </View>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const getStyles = (theme) =>
  StyleSheet.create({
    safe: { flex: 1, backgroundColor: theme.bg },
    content: { paddingHorizontal: 20, paddingTop: 48, paddingBottom: 130 },
    sectionLabel: { fontSize: 13, fontWeight: '800', color: theme.textSecondary, fontFamily: FONTS.bodyBold, marginTop: 6, marginBottom: 10, textAlign: 'right' },
    card: { backgroundColor: theme.card, borderColor: theme.border, borderWidth: 1, borderRadius: 20, padding: 14, marginBottom: 16 },
    rowBetween: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    title: { fontSize: 15, fontWeight: '800', color: theme.textPrimary, textAlign: 'right' },
    sub: { fontSize: 12, color: theme.textMuted, marginTop: 3, lineHeight: 17, textAlign: 'right' },
    fieldLabel: { fontSize: 12.5, fontWeight: '800', color: theme.textSecondary, marginTop: 4, marginBottom: 8, textAlign: 'right' },
    chipsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 8, alignItems: 'center' },
    chip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 14, borderWidth: 1, borderColor: theme.border, backgroundColor: theme.cardAlt, maxWidth: '100%' },
    chipOn: { backgroundColor: theme.accent, borderColor: theme.accent },
    chipText: { fontSize: 13, fontWeight: '700', color: theme.textPrimary },
    chipTextOn: { color: readableOn(theme.accent) },
    lightsChip: { alignSelf: 'flex-end', marginBottom: 10 },
    timeInput: { minWidth: 82, borderRadius: 14, borderWidth: 1, borderColor: theme.border, backgroundColor: theme.cardAlt, paddingHorizontal: 12, paddingVertical: 8, fontSize: 14, fontWeight: '700', color: theme.textPrimary, textAlign: 'center' },
    planRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10, paddingVertical: 8 },
    planDivider: { borderTopWidth: 1, borderTopColor: theme.border },
    planName: { flex: 1, fontSize: 13.5, fontWeight: '800', color: theme.textPrimary, textAlign: 'right' },
    planTimes: { fontSize: 13, fontWeight: '700', color: theme.accentSoft, fontVariant: ['tabular-nums'] },
  });
