import React, { useMemo, useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, StyleSheet, Share } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FONTS } from '../fonts';
import { useTheme } from '../ThemeContext';
import ScreenBackground from '../components/ScreenBackground';
import ScreenHeader from '../components/ScreenHeader';
import EmptyState from '../components/EmptyState';
import { formatDuration, formatRange, formatDate, formatClock } from '../powerOutages';

const DAY = 24 * 60 * 60 * 1000;
const RANGES = [
  { key: '7', label: '7 أيام', ms: 7 * DAY },
  { key: '30', label: '30 يوم', ms: 30 * DAY },
  { key: 'all', label: 'الكل', ms: Infinity },
];
const POWER_COLOR = '#F5A524';

// بيقص فترة على نافذة [from, to] ويرجّع null لو برّاها
function clip(s, e, from, to) {
  const a = Math.max(s, from);
  const b = Math.min(e, to);
  return b > a ? [a, b] : null;
}

export default function PowerReportScreen({ boards = [], outages = {}, stats = {}, onBack }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);
  const [range, setRange] = useState('30');
  const [now] = useState(Date.now());
  const rangeMs = RANGES.find((r) => r.key === range).ms;

  const rows = useMemo(
    () =>
      boards.map((b) => {
        const all = outages[b.id] || [];
        const list = all.filter((o) => now - o.end <= rangeMs);
        const total = list.reduce((a, o) => a + o.dur, 0);
        const longest = list.reduce((m, o) => (!m || o.dur > m.dur ? o : m), null);
        const st = stats[b.id] || {};
        const netDrops = (st.drops || []).filter((t) => now - t <= rangeMs).length;
        return { board: b, list, total, longest, netDrops, periods: st.periods || [] };
      }),
    [boards, outages, stats, rangeMs, now]
  );

  const hasAny = rows.some((r) => r.list.length > 0 || r.netDrops > 0);

  const exportCsv = async () => {
    const lines = ['board,type,start,end,duration_seconds'];
    boards.forEach((b) => {
      (outages[b.id] || []).forEach((o) => {
        lines.push(`"${(b.name || '').replace(/"/g, '""')}",power,${new Date(o.start).toISOString()},${new Date(o.end).toISOString()},${Math.round(o.dur / 1000)}`);
      });
      ((stats[b.id] || {}).periods || []).forEach((p) => {
        if (p.e) lines.push(`"${(b.name || '').replace(/"/g, '""')}",network,${new Date(p.s).toISOString()},${new Date(p.e).toISOString()},${Math.round((p.e - p.s) / 1000)}`);
      });
    });
    try {
      await Share.share({ title: 'سجل الانقطاعات', message: lines.join('\n') });
    } catch (_) {}
  };

  const t0 = now - 7 * DAY;
  const dayLabels = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(t0 + (i + 1) * DAY);
    return ['ح', 'ن', 'ث', 'ر', 'خ', 'ج', 'س'][d.getDay()];
  });

  return (
    <SafeAreaView style={styles.safe}>
      <ScreenBackground theme={theme} />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <ScreenHeader title="تقرير الكهربا" onBack={onBack} />

        <View style={styles.rangeRow}>
          {RANGES.map((r) => (
            <TouchableOpacity key={r.key} style={[styles.rangeBtn, range === r.key && styles.rangeBtnOn]} onPress={() => setRange(r.key)} activeOpacity={0.8}>
              <Text style={[styles.rangeText, range === r.key && styles.rangeTextOn]}>{r.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {boards.length === 0 || !hasAny ? (
          <EmptyState icon="flash-outline" title="مفيش انقطاعات مسجّلة" text="لما الكهربا تقطع ويرجع البورد، هتظهر هنا المدة والوقت." />
        ) : (
          rows.map(({ board, list, total, longest, netDrops, periods }) => (
            <View key={board.id} style={styles.card}>
              <Text style={styles.name} numberOfLines={1}>{board.name || 'بورد بدون اسم'}</Text>

              <View style={styles.statsRow}>
                <View style={styles.stat}>
                  <Text style={styles.statValue}>{list.length}</Text>
                  <Text style={styles.statLabel}>قطع كهربا</Text>
                </View>
                <View style={styles.stat}>
                  <Text style={[styles.statValue, { fontSize: 13 }]} numberOfLines={2}>{list.length ? formatDuration(total) : '—'}</Text>
                  <Text style={styles.statLabel}>إجمالي المدة</Text>
                </View>
                <View style={styles.stat}>
                  <Text style={[styles.statValue, { fontSize: 13 }]} numberOfLines={2}>{longest ? formatDuration(longest.dur) : '—'}</Text>
                  <Text style={styles.statLabel}>أطول قطع</Text>
                </View>
              </View>
              {longest ? <Text style={styles.note}>أطول قطع: {formatRange(longest.start, longest.end)}</Text> : null}
              {netDrops > 0 ? <Text style={styles.note}>انقطاع اتصال (واي فاي/راوتر): {netDrops} مرة</Text> : null}

              <Text style={styles.sub}>آخر 7 أيام</Text>
              <View style={styles.track}>
                {periods.map((p, i) => {
                  const c = clip(p.s, p.e == null ? now : p.e, t0, now);
                  if (!c) return null;
                  return <View key={`n${i}`} style={[styles.seg, { left: `${((c[0] - t0) / (7 * DAY)) * 100}%`, width: `${Math.max(0.6, ((c[1] - c[0]) / (7 * DAY)) * 100)}%`, backgroundColor: theme.off, opacity: 0.55 }]} />;
                })}
                {(outages[board.id] || []).map((o) => {
                  const c = clip(o.start, o.end, t0, now);
                  if (!c) return null;
                  return <View key={`p${o.start}`} style={[styles.seg, { left: `${((c[0] - t0) / (7 * DAY)) * 100}%`, width: `${Math.max(0.8, ((c[1] - c[0]) / (7 * DAY)) * 100)}%`, backgroundColor: POWER_COLOR }]} />;
                })}
              </View>
              <View style={styles.ticks}>
                {dayLabels.map((l, i) => <Text key={i} style={styles.tick}>{l}</Text>)}
              </View>
              <View style={styles.legend}>
                <View style={styles.legendItem}><View style={[styles.dot, { backgroundColor: POWER_COLOR }]} /><Text style={styles.legendText}>كهربا</Text></View>
                <View style={styles.legendItem}><View style={[styles.dot, { backgroundColor: theme.off, opacity: 0.55 }]} /><Text style={styles.legendText}>انقطاع اتصال</Text></View>
              </View>

              {list.slice(0, 10).map((o) => (
                <View key={o.start} style={styles.row}>
                  <Text style={styles.rowDur}>{formatDuration(o.dur)}</Text>
                  <Text style={styles.rowTime}>{formatRange(o.start, o.end)}</Text>
                </View>
              ))}
            </View>
          ))
        )}

        {hasAny && (
          <TouchableOpacity style={styles.exportBtn} onPress={exportCsv} activeOpacity={0.8}>
            <MaterialCommunityIcons name="export-variant" size={18} color={theme.accentSoft} />
            <Text style={styles.exportText}>تصدير السجل (CSV)</Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const getStyles = (theme) =>
  StyleSheet.create({
    safe: { flex: 1, backgroundColor: theme.bg },
    content: { paddingHorizontal: 20, paddingTop: 48, paddingBottom: 130 },
    rangeRow: { flexDirection: 'row', gap: 8, marginBottom: 14 },
    rangeBtn: { flex: 1, paddingVertical: 9, borderRadius: 14, borderWidth: 1, borderColor: theme.border, backgroundColor: theme.card, alignItems: 'center' },
    rangeBtnOn: { borderColor: theme.accentSoft, backgroundColor: theme.cardAlt },
    rangeText: { fontSize: 12.5, fontWeight: '700', color: theme.textMuted },
    rangeTextOn: { color: theme.textPrimary },
    card: { backgroundColor: theme.card, borderColor: theme.border, borderWidth: 1, borderRadius: 20, padding: 14, marginBottom: 12 },
    name: { fontSize: 15, fontWeight: '800', color: theme.textPrimary, fontFamily: FONTS.bodyBold, textAlign: 'right', marginBottom: 12 },
    statsRow: { flexDirection: 'row', gap: 8 },
    stat: { flex: 1, backgroundColor: theme.cardAlt, borderRadius: 14, paddingVertical: 10, paddingHorizontal: 6, alignItems: 'center' },
    statValue: { fontSize: 20, fontWeight: '800', color: theme.textPrimary, textAlign: 'center' },
    statLabel: { fontSize: 10.5, color: theme.textMuted, marginTop: 3, textAlign: 'center' },
    note: { fontSize: 11.5, color: theme.textMuted, textAlign: 'right', marginTop: 8 },
    sub: { fontSize: 12, fontWeight: '800', color: theme.textSecondary, textAlign: 'right', marginTop: 14, marginBottom: 6 },
    track: { height: 14, borderRadius: 7, backgroundColor: theme.cardAlt, overflow: 'hidden' },
    seg: { position: 'absolute', top: 0, bottom: 0, borderRadius: 3 },
    ticks: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 4 },
    tick: { fontSize: 10, color: theme.textMuted, flex: 1, textAlign: 'center' },
    legend: { flexDirection: 'row', gap: 14, marginTop: 8, justifyContent: 'flex-end' },
    legendItem: { flexDirection: 'row', alignItems: 'center', gap: 5 },
    dot: { width: 9, height: 9, borderRadius: 5 },
    legendText: { fontSize: 11, color: theme.textMuted },
    row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8, paddingVertical: 5, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: theme.border, marginTop: 4 },
    rowDur: { fontSize: 12.5, fontWeight: '800', color: POWER_COLOR },
    rowTime: { flex: 1, fontSize: 11.5, color: theme.textMuted, textAlign: 'left' },
    exportBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 13, marginTop: 6, borderRadius: 16, borderWidth: 1, borderColor: theme.border, backgroundColor: theme.card },
    exportText: { fontSize: 13.5, fontWeight: '800', color: theme.textPrimary },
  });
