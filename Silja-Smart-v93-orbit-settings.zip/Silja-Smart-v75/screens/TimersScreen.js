import React, { useEffect, useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, TextInput, StyleSheet } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FONTS } from '../fonts';
import { useTheme } from '../ThemeContext';
import ConnectionStatusBanner from '../components/ConnectionStatusBanner';
import ScreenBackground from '../components/ScreenBackground';
import ScreenHeader from '../components/ScreenHeader';
import EmptyState from '../components/EmptyState';
import { flattenSwitchDevices } from '../scenes';
import { getDeviceIcon } from '../deviceIcons';
import { readableOn } from '../colorUtils';
import { newTimerId, MAX_TIMERS } from '../timers';
import { showToast } from '../components/Toast';

const PRESETS = [15, 30, 60, 120];

function formatRemaining(ms) {
  const total = Math.max(0, Math.ceil(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const pad = (n) => String(n).padStart(2, '0');
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
}

function formatDuration(min) {
  if (min < 60) return `${min} دقيقة`;
  const h = Math.floor(min / 60);
  const m = min % 60;
  return m ? `${h} س و${m} د` : h === 1 ? 'ساعة' : `${h} ساعات`;
}

export default function TimersScreen({ boards, timers = [], onAddTimer, onCancelTimer, connected, onBack }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);
  const devices = flattenSwitchDevices(boards).filter((d) => d.controlTopic);
  const lights = devices.filter((d) => getDeviceIcon(d.icon).isLight);

  const [selected, setSelected] = useState([]); // controlTopics
  const [action, setAction] = useState('OFF');
  const [minutes, setMinutes] = useState(30);
  const [customText, setCustomText] = useState('');
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    if (!timers.length) return undefined;
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, [timers.length]);

  const toggleDevice = (topic) =>
    setSelected((prev) => (prev.includes(topic) ? prev.filter((t) => t !== topic) : [...prev, topic]));

  const allLightsSelected = lights.length > 0 && lights.every((d) => selected.includes(d.controlTopic));
  const toggleLights = () =>
    setSelected((prev) => {
      const topics = lights.map((d) => d.controlTopic);
      return allLightsSelected ? prev.filter((t) => !topics.includes(t)) : Array.from(new Set([...prev, ...topics]));
    });

  const pickPreset = (m) => { setMinutes(m); setCustomText(''); };
  const onCustomChange = (txt) => {
    const clean = txt.replace(/[^0-9]/g, '').slice(0, 4);
    setCustomText(clean);
    const n = parseInt(clean, 10);
    if (n > 0) setMinutes(n);
  };

  const start = () => {
    if (!selected.length) { showToast('اختار مفتاح واحد على الأقل', { type: 'error' }); return; }
    if (!(minutes > 0) || minutes > 1440) { showToast('المدة لازم تكون بين دقيقة و24 ساعة', { type: 'error' }); return; }
    if (timers.length >= MAX_TIMERS) { showToast('وصلت للحد الأقصى من المؤقتات', { type: 'error' }); return; }
    const targets = devices.filter((d) => selected.includes(d.controlTopic)).map((d) => ({ controlTopic: d.controlTopic, name: d.name }));
    const label = targets.length === 1 ? targets[0].name : `${targets.length} مفتاح`;
    onAddTimer({
      id: newTimerId(),
      name: `${action === 'OFF' ? 'إطفاء' : 'تشغيل'} ${label}`,
      value: action,
      targets,
      endsAt: Date.now() + minutes * 60000,
      createdAt: Date.now(),
    });
    setSelected([]);
    showToast(`المؤقت اشتغل: ${formatDuration(minutes)}`, { type: 'success' });
  };

  return (
    <SafeAreaView style={styles.safe}>
      <ScreenBackground theme={theme} />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        <ScreenHeader title="المؤقتات" onBack={onBack} />

        <ConnectionStatusBanner
          theme={theme}
          connected={!!connected}
          detail={connected ? 'المؤقتات بتتنفّذ طول ما التطبيق مفتوح ومتصل.' : 'مفيش اتصال — المؤقت مش هيتنفذ لحد ما الاتصال يرجع.'}
        />

        <Text style={styles.sectionLabel}>مؤقتات شغالة</Text>
        {timers.length === 0 ? (
          <EmptyState icon="timer-outline" title="مفيش مؤقتات" text="اعمل مؤقت من تحت، مثلًا: اطفي الإضاءة بعد 30 دقيقة." />
        ) : (
          timers.map((t) => (
            <View key={t.id} style={styles.timerRow}>
              <View style={styles.timerIcon}>
                <MaterialCommunityIcons name={t.value === 'OFF' ? 'power-plug-off-outline' : 'power-plug-outline'} size={20} color={theme.accentSoft} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.timerTitle} numberOfLines={1}>{t.name}</Text>
                <Text style={styles.timerCount}>{formatRemaining(t.endsAt - now)}</Text>
              </View>
              <TouchableOpacity onPress={() => onCancelTimer(t.id)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }} style={styles.cancelBtn}>
                <MaterialCommunityIcons name="close" size={18} color={theme.off} />
              </TouchableOpacity>
            </View>
          ))
        )}

        <Text style={[styles.sectionLabel, { marginTop: 14 }]}>مؤقت جديد</Text>
        <View style={styles.card}>
          <Text style={styles.fieldLabel}>الإجراء</Text>
          <View style={styles.chipsRow}>
            {[['OFF', 'إطفاء'], ['ON', 'تشغيل']].map(([v, label]) => (
              <TouchableOpacity key={v} style={[styles.chip, action === v && styles.chipOn]} onPress={() => setAction(v)}>
                <Text style={[styles.chipText, action === v && styles.chipTextOn]}>{label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={styles.fieldLabel}>بعد قد إيه</Text>
          <View style={styles.chipsRow}>
            {PRESETS.map((m) => (
              <TouchableOpacity key={m} style={[styles.chip, minutes === m && !customText && styles.chipOn]} onPress={() => pickPreset(m)}>
                <Text style={[styles.chipText, minutes === m && !customText && styles.chipTextOn]}>{formatDuration(m)}</Text>
              </TouchableOpacity>
            ))}
            <View style={[styles.customBox, !!customText && styles.chipOn]}>
              <TextInput
                value={customText}
                onChangeText={onCustomChange}
                placeholder="دقائق"
                placeholderTextColor={theme.textMuted}
                keyboardType="number-pad"
                style={styles.customInput}
                maxLength={4}
              />
            </View>
          </View>

          <Text style={styles.fieldLabel}>المفاتيح</Text>
          {devices.length === 0 ? (
            <Text style={styles.hint}>مفيش مفاتيح مضافة لسه.</Text>
          ) : (
            <>
              {lights.length > 0 && (
                <TouchableOpacity style={[styles.chip, styles.lightsChip, allLightsSelected && styles.chipOn]} onPress={toggleLights}>
                  <MaterialCommunityIcons name="lightbulb-group-outline" size={16} color={allLightsSelected ? readableOn(theme.accent) : theme.accentSoft} />
                  <Text style={[styles.chipText, allLightsSelected && styles.chipTextOn]}>كل الإضاءة ({lights.length})</Text>
                </TouchableOpacity>
              )}
              <View style={styles.chipsRow}>
                {devices.map((d) => {
                  const on = selected.includes(d.controlTopic);
                  return (
                    <TouchableOpacity key={`${d.boardId}-${d.controlTopic}`} style={[styles.chip, on && styles.chipOn]} onPress={() => toggleDevice(d.controlTopic)}>
                      <Text style={[styles.chipText, on && styles.chipTextOn]} numberOfLines={1}>{d.name || 'مفتاح'}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
            </>
          )}

          <TouchableOpacity style={[styles.startBtn, !selected.length && { opacity: 0.5 }]} onPress={start} activeOpacity={0.85}>
            <MaterialCommunityIcons name="timer-play-outline" size={20} color={readableOn(theme.accent)} />
            <Text style={styles.startText}>ابدأ المؤقت</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const getStyles = (theme) =>
  StyleSheet.create({
    safe: { flex: 1, backgroundColor: theme.bg },
    content: { paddingHorizontal: 20, paddingTop: 48, paddingBottom: 130 },
    sectionLabel: { fontSize: 13, fontWeight: '800', color: theme.textSecondary, fontFamily: FONTS.bodyBold, marginTop: 6, marginBottom: 10, textAlign: 'right' },
    card: { backgroundColor: theme.card, borderColor: theme.border, borderWidth: 1, borderRadius: 20, padding: 14, marginBottom: 18 },
    fieldLabel: { fontSize: 12.5, fontWeight: '800', color: theme.textSecondary, marginTop: 6, marginBottom: 8, textAlign: 'right' },
    chipsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 8 },
    chip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 14, borderWidth: 1, borderColor: theme.border, backgroundColor: theme.cardAlt, maxWidth: '100%' },
    chipOn: { backgroundColor: theme.accent, borderColor: theme.accent },
    chipText: { fontSize: 13, fontWeight: '700', color: theme.textPrimary },
    chipTextOn: { color: readableOn(theme.accent) },
    lightsChip: { alignSelf: 'flex-end', marginBottom: 10 },
    customBox: { minWidth: 78, borderRadius: 14, borderWidth: 1, borderColor: theme.border, backgroundColor: theme.cardAlt, paddingHorizontal: 10, justifyContent: 'center' },
    customInput: { fontSize: 13, fontWeight: '700', color: theme.textPrimary, textAlign: 'center', paddingVertical: 8 },
    hint: { fontSize: 12, color: theme.textMuted, textAlign: 'right' },
    startBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, backgroundColor: theme.accent, borderRadius: 16, paddingVertical: 13, marginTop: 10 },
    startText: { fontSize: 15, fontWeight: '800', color: readableOn(theme.accent) },
    timerRow: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: theme.card, borderColor: theme.border, borderWidth: 1, borderRadius: 18, padding: 13, marginBottom: 10 },
    timerIcon: { width: 40, height: 40, borderRadius: 14, backgroundColor: theme.cardAlt, alignItems: 'center', justifyContent: 'center' },
    timerTitle: { fontSize: 13.5, fontWeight: '800', color: theme.textPrimary, textAlign: 'right' },
    timerCount: { fontSize: 18, fontWeight: '800', color: theme.accentSoft, marginTop: 2, textAlign: 'right', fontVariant: ['tabular-nums'] },
    cancelBtn: { width: 34, height: 34, borderRadius: 12, backgroundColor: theme.cardAlt, alignItems: 'center', justifyContent: 'center' },
  });
