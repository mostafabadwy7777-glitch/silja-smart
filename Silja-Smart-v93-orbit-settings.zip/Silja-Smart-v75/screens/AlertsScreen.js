import React, { useEffect } from 'react';
import { SafeAreaView, ScrollView, View, Text, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import TouchableOpacity from '../components/AnimatedTouchable';
import PremiumSwitch from '../components/PremiumSwitch';
import ScreenBackground from '../components/ScreenBackground';
import ScreenHeader from '../components/ScreenHeader';
import ConnectionStatusBanner from '../components/ConnectionStatusBanner';
import EmptyState from '../components/EmptyState';
import { useTheme } from '../ThemeContext';
import { FONTS } from '../fonts';
import { shortDateTime } from '../numfmt';

const KIND_META = {
  offline: { icon: 'access-point-off', tone: 'off' },
  online: { icon: 'access-point-check', tone: 'on' },
  offline_long: { icon: 'clock-alert-outline', tone: 'off' },
  switch_on: { icon: 'toggle-switch', tone: 'on' },
  switch_off: { icon: 'toggle-switch-off-outline', tone: 'muted' },
};

const OPTIONS = [
  { key: 'boardOffline', icon: 'access-point-off', title: 'انقطاع بورد', sub: 'تنبيه لما بورد يفصل عن الشبكة' },
  { key: 'boardOnline', icon: 'access-point-check', title: 'رجوع بورد', sub: 'تنبيه لما بورد يرجع متصل' },
  { key: 'longOffline', icon: 'clock-alert-outline', title: 'بورد مقطوع من فترة', sub: 'تنبيه لو بورد فضل مقطوع أكتر من 30 دقيقة' },
  { key: 'switchChange', icon: 'toggle-switch-outline', title: 'تغيّر حالة المفاتيح', sub: 'كل مرة مفتاح يتشغل أو يتقفل (ممكن يكون كتير)' },
  { key: 'phoneNotify', icon: 'bell-ring-outline', title: 'إشعار على الموبايل', sub: 'يظهر تنبيه انقطاع البورد كإشعار (محتاج إذن الإشعارات)' },
];

function formatTime(ts) {
  try {
    return shortDateTime(ts);
  } catch (_) {
    return '';
  }
}

export default function AlertsScreen({ alerts = [], settings, connected, onChangeSettings, onMarkAllRead, onClear, onOpenHealth, onBack }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);

  // أول ما الشاشة تتفتح (وكل ما يوصل تنبيه جديد وهي مفتوحة) نعتبره مقروء
  const unread = alerts.filter((a) => !a.read).length;
  useEffect(() => {
    if (unread > 0) onMarkAllRead && onMarkAllRead();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [unread]);

  const toneColor = (tone) => (tone === 'on' ? theme.on : tone === 'off' ? theme.off : theme.textSecondary);

  return (
    <SafeAreaView style={styles.safe}>
      <ScreenBackground theme={theme} />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <ScreenHeader title="التنبيهات" onBack={onBack} />

        <ConnectionStatusBanner
          theme={theme}
          connected={!!connected}
          detail={connected ? 'التنبيهات بتتسجّل طول ما التطبيق مفتوح ومتصل.' : 'مفيش اتصال — مش هتتسجل تنبيهات جديدة لحد ما الاتصال يرجع.'}
        />

        {!!onOpenHealth && (
          <TouchableOpacity style={styles.healthLink} onPress={onOpenHealth} activeOpacity={0.8}>
            <View style={styles.optIcon}>
              <MaterialCommunityIcons name="heart-pulse" size={19} color={theme.accentSoft} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.optTitle}>صحة البوردات</Text>
              <Text style={styles.optSub}>آخر ظهور وعدد مرات الانقطاع لكل بورد</Text>
            </View>
            <MaterialCommunityIcons name="chevron-left" size={22} color={theme.textMuted} />
          </TouchableOpacity>
        )}

        <Text style={styles.sectionLabel}>إعدادات التنبيهات</Text>
        <View style={styles.card}>
          {OPTIONS.map((opt, i) => (
            <View key={opt.key} style={[styles.optRow, i > 0 && styles.optDivider]}>
              <View style={styles.optIcon}>
                <MaterialCommunityIcons name={opt.icon} size={19} color={theme.accentSoft} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.optTitle}>{opt.title}</Text>
                <Text style={styles.optSub}>{opt.sub}</Text>
              </View>
              <PremiumSwitch
                value={!!settings[opt.key]}
                onValueChange={(v) => onChangeSettings({ ...settings, [opt.key]: v })}
                theme={theme}
                size={0.85}
              />
            </View>
          ))}
        </View>

        <View style={styles.listHeader}>
          <Text style={styles.sectionLabel}>آخر التنبيهات</Text>
          {alerts.length > 0 && (
            <TouchableOpacity onPress={onClear} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
              <Text style={styles.clearText}>مسح الكل</Text>
            </TouchableOpacity>
          )}
        </View>

        {alerts.length === 0 ? (
          <EmptyState icon="bell-outline" title="مفيش تنبيهات" text="أي انقطاع أو رجوع لبورد هيظهر هنا." />
        ) : (
          alerts.map((a) => {
            const meta = KIND_META[a.kind] || { icon: 'bell-outline', tone: 'muted' };
            const color = toneColor(meta.tone);
            return (
              <View key={a.id} style={styles.alertRow}>
                <View style={[styles.alertIcon, { borderColor: color }]}>
                  <MaterialCommunityIcons name={meta.icon} size={20} color={color} />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.alertTitle}>{a.title}</Text>
                  <Text style={styles.alertBody} numberOfLines={4}>{a.body}</Text>
                </View>
                <Text style={styles.alertTime}>{formatTime(a.ts)}</Text>
              </View>
            );
          })
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const getStyles = (theme) =>
  StyleSheet.create({
    safe: { flex: 1, backgroundColor: theme.bg },
    content: { paddingHorizontal: 20, paddingTop: 48, paddingBottom: 130 },
    sectionLabel: { fontSize: 13, fontWeight: '800', color: theme.textSecondary, fontFamily: FONTS.bodyBold, marginTop: 6, marginBottom: 10, textAlign: 'right' },
    card: { backgroundColor: theme.card, borderColor: theme.border, borderWidth: 1, borderRadius: 20, paddingHorizontal: 14, marginBottom: 18 },
    healthLink: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: theme.card, borderColor: theme.border, borderWidth: 1, borderRadius: 20, padding: 14, marginBottom: 18 },
    optRow: { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 13 },
    optDivider: { borderTopWidth: 1, borderTopColor: theme.border },
    optIcon: { width: 38, height: 38, borderRadius: 13, backgroundColor: theme.cardAlt, alignItems: 'center', justifyContent: 'center' },
    optTitle: { fontSize: 14, fontWeight: '800', color: theme.textPrimary, textAlign: 'right' },
    optSub: { fontSize: 11, color: theme.textMuted, marginTop: 2, lineHeight: 16, textAlign: 'right' },
    listHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
    clearText: { fontSize: 12, fontWeight: '800', color: theme.accentSoft },
    alertRow: { flexDirection: 'row', alignItems: 'center', gap: 12, backgroundColor: theme.card, borderColor: theme.border, borderWidth: 1, borderRadius: 18, padding: 13, marginBottom: 10 },
    alertIcon: { width: 40, height: 40, borderRadius: 14, borderWidth: 1, backgroundColor: theme.cardAlt, alignItems: 'center', justifyContent: 'center' },
    alertTitle: { fontSize: 13.5, fontWeight: '800', color: theme.textPrimary, textAlign: 'right' },
    alertBody: { fontSize: 12, color: theme.textSecondary, marginTop: 2, textAlign: 'right' },
    alertTime: { fontSize: 10.5, color: theme.textMuted },
  });
