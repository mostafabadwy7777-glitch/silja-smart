// منطق جدولة المشاهد المشترك بين التطبيق والسيرفر (نفس الملف متنسخ في server/).
// مكتوب CommonJS عشان يشتغل في Node مباشرة وفي Metro/Expo من غير تعديل.
//
// شكل الجدولة المحفوظة جوه المشهد (scene.schedule):
//   { enabled: true,
//     mode: 'time' | 'sunrise' | 'sunset',
//     time: 'HH:MM',        // لو mode = 'time' (24 ساعة)
//     offsetMin: 0,          // لو شروق/غروب: دقايق بعد (+) أو قبل (−)
//     days: [0..6] }         // 0 = الأحد ... 6 = السبت (فاضية = كل يوم)
//
// الشروق/الغروب بيتحسبوا محليًا بالإحداثيات (من موقع الطقس المتخزن) من غير إنترنت.

const RAD = Math.PI / 180;
const DEG = 180 / Math.PI;
const mod = (a, n) => ((a % n) + n) % n;

// وقت الشروق/الغروب بالـ UTC ms ليوم (y, m, d) محلي عند (lat, lon). null لو الشمس مش بتشرق/تغرب.
// خوارزمية \"Sunrise/Sunset Algorithm\" (Almanac for Computers) بزاوية 90.833° — دقتها في حدود دقايق قليلة.
function sunEventMs(y, m, d, lat, lon, rising) {
  const dayOfYear = Math.floor((Date.UTC(y, m - 1, d) - Date.UTC(y, 0, 0)) / 86400000);
  const lngHour = lon / 15;
  const t = dayOfYear + ((rising ? 6 : 18) - lngHour) / 24;
  const M = 0.9856 * t - 3.289;
  const L = mod(M + 1.916 * Math.sin(M * RAD) + 0.02 * Math.sin(2 * M * RAD) + 282.634, 360);
  let RA = mod(DEG * Math.atan(0.91764 * Math.tan(L * RAD)), 360);
  RA += Math.floor(L / 90) * 90 - Math.floor(RA / 90) * 90;
  RA /= 15;
  const sinDec = 0.39782 * Math.sin(L * RAD);
  const cosDec = Math.cos(Math.asin(sinDec));
  const cosH = (Math.cos(90.833 * RAD) - sinDec * Math.sin(lat * RAD)) / (cosDec * Math.cos(lat * RAD));
  if (cosH > 1 || cosH < -1) return null;
  const H = (rising ? 360 - DEG * Math.acos(cosH) : DEG * Math.acos(cosH)) / 15;
  const T = H + RA - 0.06571 * t - 6.622;
  const UT = mod(T - lngHour, 24);
  let ms = Date.UTC(y, m - 1, d) + UT * 3600000;
  // صحّح اليوم (لمناطق بعيدة عن UTC) بحيث الحدث يبقى حوالين الظهر الشمسي بتاع نفس اليوم المحلي.
  const solarNoon = Date.UTC(y, m - 1, d, 12) - lngHour * 3600000;
  const expected = solarNoon + (rising ? -6 : 6) * 3600000;
  ms += Math.round((expected - ms) / 86400000) * 86400000;
  return ms;
}

// localOf(ms) => { y, m, d, minutes, weekday } بالتوقيت المحلي (جهاز الموبايل أو منطقة السيرفر المضبوطة).
// بيرجّع دقيقة التنفيذ المستهدفة (من منتصف الليل) في اليوم المحلي ده، أو null.
function scheduleTargetMinutes(schedule, day, city, localOf) {
  if (!schedule) return null;
  if (schedule.mode === 'sunrise' || schedule.mode === 'sunset') {
    if (!city || !Number.isFinite(city.lat) || !Number.isFinite(city.lon)) return null;
    const ms = sunEventMs(day.y, day.m, day.d, city.lat, city.lon, schedule.mode === 'sunrise');
    if (ms == null) return null;
    const at = localOf(ms + (Number(schedule.offsetMin) || 0) * 60000);
    if (at.y !== day.y || at.m !== day.m || at.d !== day.d) return null; // الإزاحة عدّت منتصف الليل
    return at.minutes;
  }
  const match = /^(\d{1,2}):(\d{2})$/.exec(String(schedule.time || '').trim());
  if (!match) return null;
  const h = Number(match[1]);
  const mi = Number(match[2]);
  if (h > 23 || mi > 59) return null;
  return h * 60 + mi;
}

// هل المشهد مستحق دلوقتي؟ بيرجّع مفتاح تنفيذ فريد (للمنع من التكرار) أو null.
// الاستحقاق = دقيقة التنفيذ هي الدقيقة الحالية أو اللي قبلها (عشان فحص كل 15–30 ثانية مايفوتش).
function dueKey(schedule, now, city, localOf) {
  if (!schedule || !schedule.enabled) return null;
  const days = Array.isArray(schedule.days) ? schedule.days : [];
  if (days.length > 0 && !days.includes(now.weekday)) return null;
  const target = scheduleTargetMinutes(schedule, now, city, localOf);
  if (target == null) return null;
  const diff = now.minutes - target;
  if (diff < 0 || diff > 1) return null;
  return `${now.y}-${now.m}-${now.d}T${target}`;
}

// تحويل ms لأجزاء بتوقيت الجهاز المحلي (للتطبيق).
function deviceLocalOf(ms) {
  const dt = new Date(ms);
  return { y: dt.getFullYear(), m: dt.getMonth() + 1, d: dt.getDate(), minutes: dt.getHours() * 60 + dt.getMinutes(), weekday: dt.getDay() };
}

// تحويل ms لأجزاء بتوقيت منطقة زمنية IANA (للسيرفر).
const WEEKDAYS = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
function makeZonedLocalOf(timeZone) {
  const fmt = new Intl.DateTimeFormat('en-US', {
    timeZone, year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', weekday: 'short', hourCycle: 'h23',
  });
  return (ms) => {
    const p = {};
    fmt.formatToParts(new Date(ms)).forEach((x) => { p[x.type] = x.value; });
    return { y: Number(p.year), m: Number(p.month), d: Number(p.day), minutes: (Number(p.hour) % 24) * 60 + Number(p.minute), weekday: WEEKDAYS[p.weekday] };
  };
}

const pad2 = (n) => String(n).padStart(2, '0');
function formatMinutes(min) {
  return `${pad2(Math.floor(min / 60))}:${pad2(min % 60)}`;
}

// ---------- محاكاة التواجد ----------
// بتولّد خطة اليوم: لكل مفتاح مختار وقت تشغيل عشوائي قريب من البداية ووقت إطفاء عشوائي قريب من النهاية.
// العشوائية "مزروعة" بتاريخ اليوم واسم المفتاح، فالتطبيق والسيرفر بيطلعوا نفس الخطة بالظبط
// وإعادة تشغيل أي منهم مبتغيّرش الأوقات. الأوقات بتتغير من يوم للتاني.
//   cfg = { enabled, startMode: 'sunset' | 'time', startTime: 'HH:MM', endTime: 'HH:MM', targets: [controlTopic...] }
// بترجع [{ topic, value: 'ON'|'OFF', minute, key }] — النهاية لازم تكون في نفس اليوم (قبل 23:59).
function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function hashStr(str) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}
function presencePlan(cfg, day, city, localOf) {
  if (!cfg || !cfg.enabled || !Array.isArray(cfg.targets) || cfg.targets.length === 0) return [];
  const start = scheduleTargetMinutes(
    { mode: cfg.startMode === 'time' ? 'time' : 'sunset', time: cfg.startTime, offsetMin: 0 }, day, city, localOf
  );
  const end = scheduleTargetMinutes({ mode: 'time', time: cfg.endTime }, day, city, localOf);
  if (start == null || end == null || end - start < 30) return [];
  const onSpread = Math.min(45, Math.floor((end - start) / 3));
  const offSpread = Math.min(90, Math.floor((end - start) / 2));
  const base = `${day.y}-${day.m}-${day.d}`;
  const plan = [];
  cfg.targets.forEach((topic) => {
    if (typeof topic !== 'string' || !topic) return;
    const rnd = mulberry32(hashStr(`${base}|${topic}`));
    const on = start + Math.floor(rnd() * (onSpread + 1));
    const off = Math.max(on + 10, end - Math.floor(rnd() * (offSpread + 1)));
    plan.push({ topic, value: 'ON', minute: on, key: `${base}|${topic}|ON` });
    plan.push({ topic, value: 'OFF', minute: Math.min(off, 23 * 60 + 59), key: `${base}|${topic}|OFF` });
  });
  return plan;
}

module.exports = { sunEventMs, scheduleTargetMinutes, dueKey, deviceLocalOf, makeZonedLocalOf, formatMinutes, presencePlan };
