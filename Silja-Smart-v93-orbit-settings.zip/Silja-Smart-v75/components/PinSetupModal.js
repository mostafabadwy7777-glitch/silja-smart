import React, { useEffect, useState } from 'react';
import { Modal, View, Text, StyleSheet } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { LinearGradient } from 'expo-linear-gradient';
import { FONTS } from '../fonts';
import PinKeypad, { PinDots, PIN_LENGTH } from './PinKeypad';
import { savePin } from '../storage';

// نافذة ضبط رمز الدخول: إدخال الرمز مرتين للتأكيد ثم الحفظ.
export default function PinSetupModal({ visible, onClose, onSaved }) {
  const [first, setFirst] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    if (visible) { setFirst(''); setPin(''); setError(''); }
  }, [visible]);

  const onDigit = (d) => {
    if (pin.length >= PIN_LENGTH) return;
    const next = pin + d;
    setPin(next);
    setError('');
    if (next.length !== PIN_LENGTH) return;
    if (!first) {
      setTimeout(() => { setFirst(next); setPin(''); }, 200);
    } else if (next === first) {
      savePin(next).then(() => onSaved && onSaved());
    } else {
      setError('الرمزين مش متطابقين — ابدأ من الأول');
      setTimeout(() => { setFirst(''); setPin(''); }, 600);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <View style={styles.root}>
        <LinearGradient colors={['#0A0B0D', '#17130B', '#0A0B0D']} start={{ x: 0.1, y: 0 }} end={{ x: 0.9, y: 1 }} style={StyleSheet.absoluteFill} />
        <View style={styles.inner}>
          <Text style={styles.title}>{first ? 'أكّد رمز الدخول' : 'اختار رمز دخول من 4 أرقام'}</Text>
          <PinDots length={pin.length} error={!!error} />
          <Text style={styles.error}>{error}</Text>
          <PinKeypad onDigit={onDigit} onBackspace={() => setPin((p) => p.slice(0, -1))} />
          <TouchableOpacity onPress={onClose} style={styles.cancel}>
            <Text style={styles.cancelText}>إلغاء</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0A0B0D' },
  inner: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  title: { color: '#E8D2A0', fontSize: 20, fontFamily: FONTS.display, fontWeight: '800' },
  error: { color: '#D96B82', fontSize: 12, minHeight: 30, marginBottom: 8, textAlign: 'center' },
  cancel: { marginTop: 26 },
  cancelText: { color: '#C8B27A', fontSize: 14 },
});
