import React, { useMemo } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import TouchableOpacity from './AnimatedTouchable';
import { useTheme } from '../ThemeContext';

const KIND_ICON = {
  offline: 'access-point-off',
  online: 'access-point',
  switch_on: 'toggle-switch',
  switch_off: 'toggle-switch-off-outline',
};

const pad = (n) => String(n).padStart(2, '0');
const timeOf = (ts) => {
  const d = new Date(ts);
  return `${d.getHours()}:${pad(d.getMinutes())}`;
};

// شريط صغير بآخر 3 أحداث، من نفس سجل التنبيهات الموجود (alerts.js) — مفيش مصدر بيانات جديد.
// ملحوظة: أحداث المفاتيح بتتسجل بس لو خيار "تغيّر حالة المفاتيح" مفعّل في شاشة التنبيهات.
export default function HomeRecentActivity({ alerts = [], onOpen }) {
  const { theme } = useTheme();
  const styles = useMemo(() => getStyles(theme), [theme]);
  const items = alerts.slice(0, 3);
  if (!items.length) return null;

  return (
    <View style={styles.wrap}>
      <View style={styles.head}>
        {!!onOpen && (
          <TouchableOpacity onPress={onOpen} hitSlop={{ top: 6, bottom: 6, left: 6, right: 6 }}>
            <Text style={styles.link}>عرض الكل</Text>
          </TouchableOpacity>
        )}
        <Text style={styles.title}>آخر نشاط</Text>
      </View>
      {items.map((a) => {
        const bad = a.kind === 'offline';
        return (
          <View key={a.id} style={styles.row}>
            <Text style={styles.time}>{timeOf(a.ts)}</Text>
            <Text numberOfLines={1} style={styles.text}>{a.body || a.title}</Text>
            <MaterialCommunityIcons
              name={KIND_ICON[a.kind] || 'bell-outline'}
              size={18}
              color={bad ? (theme.off || '#E5484D') : a.kind === 'switch_off' ? theme.textMuted : theme.on}
            />
          </View>
        );
      })}
    </View>
  );
}

function getStyles(theme) {
  return StyleSheet.create({
    wrap: { backgroundColor: theme.card, borderRadius: 18, borderWidth: 1, borderColor: theme.border, padding: 12, marginBottom: 14 },
    head: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
    title: { color: theme.textPrimary, fontSize: 15, fontWeight: '800' },
    link: { color: theme.accentSoft, fontSize: 12.5, fontWeight: '700' },
    row: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 6 },
    time: { color: theme.textMuted, fontSize: 12, minWidth: 40, textAlign: 'left' },
    text: { flex: 1, color: theme.textSecondary, fontSize: 13, textAlign: 'right' },
  });
}
