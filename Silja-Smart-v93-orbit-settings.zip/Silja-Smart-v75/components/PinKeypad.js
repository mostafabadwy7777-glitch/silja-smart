import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';

// لوحة أرقام + نقاط الإدخال بتصميم Noir Champagne. مستخدمة في شاشة القفل
// وفي نافذة ضبط الرمز في الإعدادات. ألوانها ثابتة (شامبين) زي شاشة التحميل.
export const PIN_LENGTH = 4;
const GOLD = '#D6B36A';

export function PinDots({ length, error }) {
  return (
    <View style={styles.dots}>
      {Array.from({ length: PIN_LENGTH }).map((_, i) => (
        <View
          key={i}
          style={[styles.dot, i < length && styles.dotFilled, error && styles.dotError]}
        />
      ))}
    </View>
  );
}

export default function PinKeypad({ onDigit, onBackspace, extraKey }) {
  const rows = [['1', '2', '3'], ['4', '5', '6'], ['7', '8', '9']];
  return (
    <View style={styles.pad}>
      {rows.map((row) => (
        <View key={row.join('')} style={styles.row}>
          {row.map((d) => (
            <Key key={d} label={d} onPress={() => onDigit(d)} />
          ))}
        </View>
      ))}
      <View style={styles.row}>
        {extraKey ? (
          <TouchableOpacity style={[styles.key, styles.keyGhost]} onPress={extraKey.onPress} activeOpacity={0.7}>
            <MaterialCommunityIcons name={extraKey.icon} size={26} color={GOLD} />
          </TouchableOpacity>
        ) : (
          <View style={styles.key} />
        )}
        <Key label="0" onPress={() => onDigit('0')} />
        <TouchableOpacity style={[styles.key, styles.keyGhost]} onPress={onBackspace} activeOpacity={0.7}>
          <MaterialCommunityIcons name="backspace-outline" size={26} color={GOLD} />
        </TouchableOpacity>
      </View>
    </View>
  );
}

function Key({ label, onPress }) {
  return (
    <TouchableOpacity style={styles.key} onPress={onPress} activeOpacity={0.7}>
      <Text style={styles.keyText}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  dots: { flexDirection: 'row', justifyContent: 'center', gap: 18, marginVertical: 26 },
  dot: { width: 14, height: 14, borderRadius: 7, borderWidth: 1.5, borderColor: 'rgba(214,179,106,0.6)' },
  dotFilled: { backgroundColor: GOLD, borderColor: GOLD },
  dotError: { borderColor: '#D96B82', backgroundColor: 'rgba(217,107,130,0.5)' },
  pad: { alignItems: 'center', gap: 14 },
  row: { flexDirection: 'row', gap: 22 },
  key: {
    width: 72, height: 72, borderRadius: 36, alignItems: 'center', justifyContent: 'center',
    borderWidth: 1.5, borderColor: 'rgba(214,179,106,0.55)', backgroundColor: 'rgba(214,179,106,0.05)',
  },
  keyGhost: { borderWidth: 0, backgroundColor: 'transparent' },
  keyText: { color: '#E8D2A0', fontSize: 28, fontWeight: '500' },
});
