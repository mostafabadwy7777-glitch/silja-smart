import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, StyleSheet, Modal, ScrollView, Animated, Easing } from 'react-native';
import * as Haptics from 'expo-haptics';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import TouchableOpacity from './AnimatedTouchable';
import OrbitRing from './OrbitRing';
import { showAlert } from './PremiumAlert';
import { useTheme } from '../ThemeContext';
import { getDeviceIcon } from '../deviceIcons';
import { loadHomeModes, saveHomeModes } from '../storage';
import { runScene } from '../scenes';
import FadeInView from './FadeInView';

// away = يطفي ويوقف الستائر، arrive = يشغّل المفاتيح اللي المستخدم يختارها (عكس الخروج).
const MODES = {
  away: { title: 'وضع الخروج', icon: 'exit-run', hint: 'يطفي الإضاءة ويوقف الستائر' },
  arrive: { title: 'وضع الوصول', icon: 'home-import-outline', hint: 'يشغّل الإضاءة اللي تختارها' },
};

// موجة سريعة بتطلع من أيقونة الوضع لما تدوس عليه.
function Burst({ color }) {
  const p = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    Animated.timing(p, { toValue: 1, duration: 650, easing: Easing.out(Easing.quad), useNativeDriver: true }).start();
  }, [p]);
  return (
    <Animated.View
      pointerEvents="none"
      style={{
        position: 'absolute', width: 38, height: 38, borderRadius: 19, borderWidth: 2, borderColor: color,
        opacity: p.interpolate({ inputRange: [0, 1], outputRange: [0.75, 0] }),
        transform: [{ scale: p.interpolate({ inputRange: [0, 1], outputRange: [1, 2.4] }) }],
      }}
    />
  );
}

const keyOf = (board, device) => `${board.id}|${device.controlTopic}`;

// زرارين في الرئيسية: "خروج" (OFF للمفاتيح العادية و STOP للستائر، الافتراضي: كل الإضاءة + كل الستائر)
// و"وصول" (ON للمفاتيح العادية اللي المستخدم يختارها). بنفس أوامر MQTT العادية.
export default function HomeModesBar({ boards = [], client, connected }) {
  const { theme } = useTheme();
  const styles = useMemo(() => getStyles(theme), [theme]);
  const [modes, setModes] = useState({ away: null, arrive: null });
  const [picking, setPicking] = useState(null); // 'away' | 'arrive' | null
  const [burst, setBurst] = useState(null); // { mode, n }

  useEffect(() => {
    loadHomeModes().then(setModes).catch(() => {});
  }, []);

  const all = useMemo(
    () => boards
      .filter((b) => b.type !== 'irrigation')
      .flatMap((b) => (b.devices || [])
        .filter((d) => d.controlTopic)
        .map((d) => ({ board: b, device: d, key: keyOf(b, d), updown: d.controlType === 'updown' }))),
    [boards]
  );

  const defaultKeys = useMemo(
    () => all.filter((x) => x.updown || getDeviceIcon(x.device.icon).isLight).map((x) => x.key),
    [all]
  );
  // وضع الوصول بيشغّل بس (مفيش ستائر)، فالستائر مش بتظهر في اختياره.
  const poolFor = (mode) => (mode === 'arrive' ? all.filter((x) => !x.updown) : all);
  const selectedFor = (mode) => (modes[mode] || (mode === 'arrive' ? [] : defaultKeys));
  // نتجاهل مفاتيح اتحذفت من البوردات
  const targetsFor = (mode) => {
    const set = new Set(selectedFor(mode));
    return poolFor(mode).filter((x) => set.has(x.key));
  };

  const run = (mode) => {
    try { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); } catch (_) {}
    setBurst({ mode, n: Date.now() });
    if (!connected || !client) { showAlert('غير متصل', 'لسه مش متصل بالسيرفر، استنى ثانية وحاول تاني'); return; }
    const targets = targetsFor(mode);
    if (!targets.length) {
      showAlert(MODES[mode].title, 'مفيش مفاتيح متحددة للوضع ده. اضغط على الترس واختار اللي يتأثر.');
      return;
    }
    showAlert(MODES[mode].title, `هيتم ${mode === 'arrive' ? 'تشغيل' : 'إطفاء/إيقاف'} ${targets.length} مفتاح. متأكد؟`, [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'تنفيذ',
        onPress: async () => {
          const scene = { actions: targets.map((x) => ({ controlTopic: x.device.controlTopic, value: mode === 'arrive' ? 'ON' : (x.updown ? 'STOP' : 'OFF') })) };
          const res = await runScene(scene, client);
          if (!res.ok) showAlert(MODES[mode].title, res.error || 'تعذر التنفيذ');
        },
      },
    ]);
  };

  const toggleKey = (mode, k) => {
    const cur = selectedFor(mode);
    const next = cur.includes(k) ? cur.filter((x) => x !== k) : [...cur, k];
    const updated = { ...modes, [mode]: next };
    setModes(updated);
    saveHomeModes(updated).catch(() => {});
  };

  if (!all.length) return null;

  return (
    <View style={styles.row}>
      {Object.keys(MODES).map((mode, idx) => (
        <FadeInView key={mode} delay={560 + idx * 90} style={styles.cardWrap}>
        <View style={styles.card}>
          <TouchableOpacity style={styles.main} onPress={() => run(mode)}>
            {theme.orbit ? (
              <OrbitRing
                size={42} thickness={2.2} colors={theme.orbit.colors} innerColor={theme.card}
                tint={theme.cardAlt} duration={theme.orbit.duration} phase={idx * 0.5}
              >
                {burst && burst.mode === mode ? <Burst key={burst.n} color={theme.accentSoft} /> : null}
                <MaterialCommunityIcons name={MODES[mode].icon} size={20} color={theme.accentSoft} />
              </OrbitRing>
            ) : (
            <View style={styles.iconCircle}>
              {burst && burst.mode === mode ? <Burst key={burst.n} color={theme.accentSoft} /> : null}
              <MaterialCommunityIcons name={MODES[mode].icon} size={20} color={theme.accentSoft} />
            </View>
            )}
            <View style={{ flex: 1 }}>
              <Text numberOfLines={1} style={styles.title}>{MODES[mode].title}</Text>
              <Text numberOfLines={1} style={styles.sub}>{selectedFor(mode).length ? `${targetsFor(mode).length} مفتاح` : 'غير محدد'}</Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setPicking(mode)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <MaterialCommunityIcons name="cog-outline" size={17} color={theme.textMuted} />
          </TouchableOpacity>
        </View>
        </FadeInView>
      ))}

      <Modal visible={!!picking} transparent animationType="fade" onRequestClose={() => setPicking(null)}>
        <View style={styles.backdrop}>
          <View style={styles.sheet}>
            <Text style={styles.sheetTitle}>{picking ? `اختار اللي يتأثر — ${MODES[picking].title}` : ''}</Text>
            <ScrollView style={{ maxHeight: 420 }}>
              {picking && poolFor(picking).map((x) => {
                const on = selectedFor(picking).includes(x.key);
                return (
                  <TouchableOpacity key={x.key} style={styles.pickRow} onPress={() => toggleKey(picking, x.key)}>
                    <MaterialCommunityIcons name={on ? 'checkbox-marked' : 'checkbox-blank-outline'} size={22} color={on ? theme.accentSoft : theme.textMuted} />
                    <View style={{ flex: 1 }}>
                      <Text numberOfLines={1} style={styles.pickName}>{x.device.name}</Text>
                      <Text numberOfLines={1} style={styles.pickSub}>{x.board.name}{picking === 'arrive' ? ' • تشغيل' : (x.updown ? ' • إيقاف' : ' • إطفاء')}</Text>
                    </View>
                    <MaterialCommunityIcons name={getDeviceIcon(x.device.icon).icon} size={20} color={theme.textSecondary} />
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
            <TouchableOpacity style={styles.doneBtn} onPress={() => setPicking(null)}>
              <Text style={styles.doneText}>تم</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

function getStyles(theme) {
  return StyleSheet.create({
    row: { flexDirection: 'row', gap: 10, marginBottom: 14 },
    cardWrap: { flex: 1 },
    card: { height: 62, flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: theme.card, borderRadius: 18, borderWidth: 1, borderColor: theme.border, paddingHorizontal: 10 },
    iconCircle: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', backgroundColor: theme.cardAlt || theme.card, borderWidth: 1, borderColor: theme.border },
    main: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 },
    title: { color: theme.textPrimary, fontSize: 13, fontWeight: '800', textAlign: 'right' },
    sub: { color: theme.textMuted, fontSize: 11, textAlign: 'right', marginTop: 1 },
    backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.55)', justifyContent: 'center', padding: 20 },
    sheet: { backgroundColor: theme.card, borderRadius: 22, padding: 16, borderWidth: 1, borderColor: theme.border },
    sheetTitle: { color: theme.textPrimary, fontSize: 16, fontWeight: '800', textAlign: 'center', marginBottom: 12 },
    pickRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: theme.border },
    pickName: { color: theme.textPrimary, fontSize: 14, fontWeight: '700', textAlign: 'right' },
    pickSub: { color: theme.textMuted, fontSize: 11.5, textAlign: 'right', marginTop: 1 },
    doneBtn: { marginTop: 12, backgroundColor: theme.accent, borderRadius: 14, paddingVertical: 12, alignItems: 'center' },
    doneText: { color: '#17140E', fontWeight: '800', fontSize: 15 },
  });
}
