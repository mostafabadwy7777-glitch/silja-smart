import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Animated, Easing } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';
import { FONTS } from '../fonts';
import { withAlpha } from '../colorUtils';

// ============================================================================
// توست صغير "تم الإرسال" — بيظهر لحظات بعد أي أمر (مفتاح، مشهد، ري، تايمر...)
// بدل ما المستخدم يعتمد على تغيّر الكارت بس.
//
// الاستخدام من أي مكان:
//   showToast('تم الإرسال');
//   showToast('تم تشغيل المشهد', { type: 'success' });
//   showToast('تعذر الإرسال', { type: 'error' });
//
// <ToastHost /> بيتركّب مرة واحدة في App.js (جوه ThemeProvider).
// أي توست جديد بيحلّ محل القديم فورًا (مفيش طابور)، فلو اتبعتت أوامر كتير
// ورا بعض مش هيتراكم على الشاشة.
// ============================================================================

// ارتفاع تقريبي للشريط السفلي حسب الحجم المختار، عشان التوست يفضل فوقه دايمًا
const NAV_HEIGHT = { compact: 58, standard: 66, large: 74 };

let _trigger = null;

export function showToast(message = 'تم الإرسال', options = {}) {
  if (_trigger) _trigger({ message, type: options.type || 'success', duration: options.duration || 1700 });
}

export default function ToastHost() {
  const { theme, bottomNavSize = 'compact', bottomNavLift = 12 } = useTheme();
  const [toast, setToast] = useState(null);
  const anim = useRef(new Animated.Value(0)).current;
  const hideTimer = useRef(null);

  useEffect(() => {
    _trigger = (cfg) => {
      clearTimeout(hideTimer.current);
      setToast({ ...cfg, key: Date.now() });
    };
    return () => {
      _trigger = null;
      clearTimeout(hideTimer.current);
    };
  }, []);

  useEffect(() => {
    if (!toast) return undefined;
    anim.setValue(0);
    Animated.timing(anim, { toValue: 1, duration: 180, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
    hideTimer.current = setTimeout(() => {
      Animated.timing(anim, { toValue: 0, duration: 200, easing: Easing.in(Easing.cubic), useNativeDriver: true }).start(({ finished }) => {
        if (finished) setToast(null);
      });
    }, toast.duration);
    return () => clearTimeout(hideTimer.current);
  }, [toast, anim]);

  if (!toast || !theme) return null;

  const isError = toast.type === 'error';
  const tint = isError ? theme.danger : theme.on;
  const translateY = anim.interpolate({ inputRange: [0, 1], outputRange: [14, 0] });

  return (
    <View style={[styles.wrap, { bottom: 22 + bottomNavLift + NAV_HEIGHT[bottomNavSize] + 12 }]} pointerEvents="none">
      <Animated.View
        style={[
          styles.pill,
          {
            backgroundColor: theme.card,
            borderColor: withAlpha(tint, 0.55),
            shadowColor: theme.isLight ? '#1b2330' : '#000',
            opacity: anim,
            transform: [{ translateY }],
          },
        ]}
      >
        <View style={[styles.iconWrap, { backgroundColor: withAlpha(tint, 0.16) }]}>
          <MaterialCommunityIcons name={isError ? 'alert-circle-outline' : 'check'} size={16} color={tint} />
        </View>
        <Text style={[styles.text, { color: theme.textPrimary }]} numberOfLines={1}>{toast.message}</Text>
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  // فوق شريط التنقل السفلي مباشرة
  wrap: { position: 'absolute', left: 0, right: 0, alignItems: 'center', zIndex: 9999, elevation: 30 },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    borderWidth: 1,
    borderRadius: 22,
    paddingVertical: 8,
    paddingHorizontal: 14,
    maxWidth: '86%',
    shadowOpacity: 0.22,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 8,
  },
  iconWrap: { width: 22, height: 22, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  text: { fontSize: 13, fontWeight: '700', fontFamily: FONTS.body },
});
