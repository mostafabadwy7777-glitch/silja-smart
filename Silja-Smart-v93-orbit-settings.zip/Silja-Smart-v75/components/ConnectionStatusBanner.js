import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';

/** A compact, theme-aware status banner. `connected` means the MQTT client is
 * connected to the broker; it does not claim that every board is online. */
export default function ConnectionStatusBanner({ theme, connected, title, detail, style }) {
  const color = connected ? theme.on : theme.off;
  const defaultTitle = connected ? 'متصل بالسيرفر' : 'غير متصل بالسيرفر';
  const defaultDetail = connected
    ? 'الأوامر متاحة؛ حالة كل بورد تُعرض بشكل منفصل.'
    : 'أوامر التحكم متوقفة حتى يرجع الاتصال. الحالات المعروضة قد تكون قديمة.';
  return (
    <View accessibilityRole="summary" style={[styles.wrap, { backgroundColor: `${color}12`, borderColor: `${color}45` }, style]}>
      <View style={[styles.iconWrap, { backgroundColor: `${color}18` }]}>
        <MaterialCommunityIcons name={connected ? 'lan-connect' : 'lan-disconnect'} size={17} color={color} />
      </View>
      <View style={styles.copy}>
        <Text style={[styles.title, { color }]}>{title || defaultTitle}</Text>
        {!!(detail || defaultDetail) && <Text style={[styles.detail, { color: theme.textSecondary }]}>{detail || defaultDetail}</Text>}
      </View>
      <View style={[styles.dot, { backgroundColor: color }]} />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1, borderRadius: 17, paddingHorizontal: 13, paddingVertical: 11, marginBottom: 14 },
  iconWrap: { width: 34, height: 34, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  copy: { flex: 1 },
  title: { fontSize: 12.5, fontWeight: '900', textAlign: 'right' },
  detail: { fontSize: 11, lineHeight: 16, textAlign: 'right', marginTop: 2 },
  dot: { width: 7, height: 7, borderRadius: 4 },
});
