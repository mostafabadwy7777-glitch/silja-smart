// خط ملوّن بيلف حوالين حواف أيقونة دايرية (ثيم "Orbit Neon").
// من غير أي مكتبة جديدة: دايرة فيها مربع متدرّج بيلف (native driver)،
// وقرص داخلي معتم بيغطي النص ويسيب بس سمك الخط على الحافة.
// الأيقونة (children) بتتحط فوق ومش بتتقص، فأي badge برا الدايرة يفضل ظاهر.
import React, { useEffect, useRef } from 'react';
import { View, Animated, Easing, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { withAlpha } from '../colorUtils';

export default function OrbitRing({
  size = 38,
  thickness = 2,
  colors = ['#2DE0A8', '#3B9DFF'],
  innerColor = '#0F1E36',
  tint,                 // لون شفاف خفيف فوق القرص الداخلي (اختياري)
  duration = 3600,      // زمن لفة كاملة بالمللي ثانية
  phase = 0,            // 0..1 — نقطة بداية مختلفة لكل دايرة عشان مايلفّوش متزامنين
  active = true,
  style,
  children,
}) {
  const spin = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!active) { spin.stopAnimation(); return undefined; }
    spin.setValue(0);
    const loop = Animated.loop(
      Animated.timing(spin, { toValue: 1, duration, easing: Easing.linear, useNativeDriver: true })
    );
    loop.start();
    return () => loop.stop();
  }, [active, duration, spin]);

  const rotate = spin.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const [c1, c2] = [colors[0], colors[1] || colors[0]];
  const inner = size - thickness * 2;

  return (
    <View style={[{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }, style]}>
      <View
        pointerEvents="none"
        style={[StyleSheet.absoluteFill, { borderRadius: size / 2, overflow: 'hidden', backgroundColor: withAlpha(c1, 0.18) }]}
      >
        <View style={{ width: size, height: size, transform: [{ rotate: `${Math.round(phase * 360)}deg` }] }}>
          <Animated.View style={{ width: size, height: size, transform: [{ rotate }] }}>
            <LinearGradient
              colors={[c2, withAlpha(c2, 0), withAlpha(c1, 0), c1]}
              locations={[0, 0.38, 0.62, 1]}
              start={{ x: 0, y: 0.5 }}
              end={{ x: 1, y: 0.5 }}
              style={StyleSheet.absoluteFill}
            />
          </Animated.View>
        </View>
        <View
          style={{
            position: 'absolute', left: thickness, top: thickness, width: inner, height: inner,
            borderRadius: inner / 2, backgroundColor: innerColor, overflow: 'hidden',
          }}
        >
          {!!tint && <View style={[StyleSheet.absoluteFill, { backgroundColor: tint }]} />}
        </View>
      </View>
      {children}
    </View>
  );
}
