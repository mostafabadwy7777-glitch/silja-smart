import React, { useEffect, useRef, useState } from 'react';
import {
  Modal, View, Text, TextInput, ActivityIndicator, ScrollView, StyleSheet, KeyboardAvoidingView, Platform, Pressable,
} from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';
import { FONTS } from '../fonts';
import { DEFAULT_CITY, detectCurrentCity, loadWeatherCity, saveWeatherCity, searchCities } from '../weather';
import { readableOn, withAlpha } from '../colorUtils';

// اختيار منطقة الطقس: زرار "موقعي الحالي" (GPS ثم اسم المنطقة بالعربي) + بحث بالاسم
// بيشتغل تلقائيًا وانت بتكتب، بنتايج من OpenStreetMap وOpen-Meteo.
export default function WeatherCityModal({ visible, onClose }) {
  const { theme } = useTheme();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [locating, setLocating] = useState(false);
  const [msg, setMsg] = useState('');
  const [current, setCurrent] = useState(null);
  const reqId = useRef(0);

  useEffect(() => {
    if (!visible) return;
    setQuery('');
    setResults([]);
    setMsg('');
    loadWeatherCity().then(setCurrent);
  }, [visible]);

  const runSearch = async (text) => {
    const q = text.trim();
    if (q.length < 2) {
      reqId.current += 1;
      setResults([]);
      setMsg('');
      setLoading(false);
      return;
    }
    const id = ++reqId.current;
    setLoading(true);
    setMsg('');
    try {
      const r = await searchCities(q);
      if (id !== reqId.current) return;
      setResults(r);
      if (!r.length) setMsg('مفيش نتائج — جرّب اسم تاني أو اكتب اسم المدينة مع المنطقة');
    } catch (_) {
      if (id !== reqId.current) return;
      setResults([]);
      setMsg('تعذر البحث. اتأكد من الإنترنت وجرّب تاني.');
    } finally {
      if (id === reqId.current) setLoading(false);
    }
  };

  // بحث تلقائي بعد ما تقف عن الكتابة نص ثانية تقريبًا
  useEffect(() => {
    if (!visible) return undefined;
    const t = setTimeout(() => runSearch(query), 550);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query, visible]);

  const choose = async (city) => {
    await saveWeatherCity({ name: city.name, lat: city.lat, lon: city.lon });
    onClose();
  };

  const useMyLocation = async () => {
    setLocating(true);
    setMsg('');
    try {
      const { city, source } = await detectCurrentCity();
      await saveWeatherCity({ name: city.name, lat: city.lat, lon: city.lon });
      setCurrent(city);
      if (source === 'ip') {
        setMsg(`تم تحديد "${city.name}" بالتقريب. فعّل إذن الموقع لدقة أعلى.`);
      }
      onClose();
    } catch (e) {
      setMsg(
        e && e.code === 'permission'
          ? 'إذن الموقع مرفوض. فعّله من إعدادات التطبيق أو ابحث بالاسم.'
          : 'تعذر تحديد موقعك. تأكد من تشغيل الموقع والإنترنت، أو ابحث بالاسم.'
      );
    } finally {
      setLocating(false);
    }
  };

  const accent = theme.accentSoft || theme.accent;
  const onAccent = readableOn(accent);

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose} statusBarTranslucent>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <Pressable style={styles.overlay} onPress={onClose}>
          <Pressable onPress={() => {}} style={[styles.box, { borderColor: withAlpha(accent, 0.28) }]}>
            <LinearGradient
              colors={[withAlpha(accent, 0.14), theme.card, theme.card]}
              locations={[0, 0.35, 1]}
              start={{ x: 0.5, y: 0 }}
              end={{ x: 0.5, y: 1 }}
              style={styles.boxInner}
            >
              <View style={styles.headerRow}>
                <View style={styles.titleWrap}>
                  <View style={[styles.titleIcon, { backgroundColor: withAlpha(accent, 0.16) }]}>
                    <MaterialCommunityIcons name="weather-partly-cloudy" size={20} color={accent} />
                  </View>
                  <View>
                    <Text style={[styles.title, { color: theme.textPrimary }]}>منطقة الطقس</Text>
                    {!!current && <Text style={[styles.subtitle, { color: theme.textMuted }]}>الحالية: {current.name}</Text>}
                  </View>
                </View>
                <TouchableOpacity onPress={onClose} style={[styles.closeBtn, { backgroundColor: withAlpha(theme.textMuted, 0.14) }]} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
                  <MaterialCommunityIcons name="close" size={18} color={theme.textSecondary || theme.textMuted} />
                </TouchableOpacity>
              </View>

              <TouchableOpacity
                style={[styles.locateBtn, { backgroundColor: accent }]}
                onPress={useMyLocation}
                disabled={locating}
                activeOpacity={0.85}
              >
                {locating ? (
                  <ActivityIndicator color={onAccent} />
                ) : (
                  <MaterialCommunityIcons name="crosshairs-gps" size={20} color={onAccent} />
                )}
                <Text style={[styles.locateText, { color: onAccent }]}>{locating ? 'بحدد موقعك…' : 'استخدم موقعي الحالي'}</Text>
              </TouchableOpacity>

              <View style={styles.dividerRow}>
                <View style={[styles.dividerLine, { backgroundColor: theme.border }]} />
                <Text style={[styles.dividerText, { color: theme.textMuted }]}>أو ابحث بالاسم</Text>
                <View style={[styles.dividerLine, { backgroundColor: theme.border }]} />
              </View>

              <View style={[styles.searchBox, { backgroundColor: theme.cardAlt, borderColor: theme.border }]}>
                <MaterialCommunityIcons name="magnify" size={20} color={theme.textMuted} />
                <TextInput
                  style={[styles.input, { color: theme.textPrimary }]}
                  value={query}
                  onChangeText={setQuery}
                  placeholder="اسم المدينة أو الحي…"
                  placeholderTextColor={theme.textMuted}
                  textAlign="right"
                  returnKeyType="search"
                  onSubmitEditing={() => runSearch(query)}
                  autoCorrect={false}
                />
                {loading ? (
                  <ActivityIndicator size="small" color={accent} />
                ) : !!query ? (
                  <TouchableOpacity onPress={() => setQuery('')} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
                    <MaterialCommunityIcons name="close-circle" size={18} color={theme.textMuted} />
                  </TouchableOpacity>
                ) : null}
              </View>

              {!!msg && <Text style={[styles.msg, { color: theme.textMuted }]}>{msg}</Text>}

              {results.length > 0 && (
                <ScrollView style={styles.list} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
                  {results.map((c, i) => (
                    <TouchableOpacity
                      key={`${c.lat}-${c.lon}-${i}`}
                      style={[styles.result, { borderColor: theme.border, backgroundColor: withAlpha(theme.cardAlt, 0.7) }]}
                      onPress={() => choose(c)}
                    >
                      <MaterialCommunityIcons name="map-marker-outline" size={20} color={accent} />
                      <View style={{ flex: 1 }}>
                        <Text style={[styles.resName, { color: theme.textPrimary }]} numberOfLines={1}>{c.name}</Text>
                        {!!c.region && <Text style={[styles.resRegion, { color: theme.textMuted }]} numberOfLines={1}>{c.region}</Text>}
                      </View>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
              )}

              <TouchableOpacity style={styles.reset} onPress={() => choose(DEFAULT_CITY)}>
                <Text style={[styles.resetText, { color: accent }]}>الرجوع للقاهرة (الافتراضي)</Text>
              </TouchableOpacity>
            </LinearGradient>
          </Pressable>
        </Pressable>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(4,7,12,0.78)', justifyContent: 'center', padding: 20 },
  box: { borderRadius: 28, borderWidth: 1, overflow: 'hidden', maxHeight: '88%' },
  boxInner: { padding: 18 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  titleWrap: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  titleIcon: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  title: { fontSize: 17, fontWeight: '800', fontFamily: FONTS.display },
  subtitle: { fontSize: 11.5, marginTop: 1 },
  closeBtn: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  locateBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9, borderRadius: 16, paddingVertical: 14 },
  locateText: { fontSize: 15, fontWeight: '800' },
  dividerRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginVertical: 14 },
  dividerLine: { flex: 1, height: StyleSheet.hairlineWidth },
  dividerText: { fontSize: 11.5 },
  searchBox: { flexDirection: 'row', alignItems: 'center', gap: 8, borderWidth: 1, borderRadius: 16, paddingHorizontal: 12 },
  input: { flex: 1, paddingVertical: 12, fontSize: 14.5 },
  msg: { fontSize: 12.5, textAlign: 'center', marginTop: 12, lineHeight: 19 },
  list: { marginTop: 12, maxHeight: 250 },
  result: { flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1, borderRadius: 14, paddingVertical: 11, paddingHorizontal: 13, marginBottom: 8 },
  resName: { fontSize: 14.5, fontWeight: '700', textAlign: 'right' },
  resRegion: { fontSize: 11.5, marginTop: 2, textAlign: 'right' },
  reset: { alignItems: 'center', marginTop: 12, paddingVertical: 4 },
  resetText: { fontSize: 13, fontWeight: '700' },
});
