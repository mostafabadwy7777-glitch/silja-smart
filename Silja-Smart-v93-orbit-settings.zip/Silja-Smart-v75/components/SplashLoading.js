import React, { useEffect, useRef, useState } from 'react';
import { View, Text, Image, StyleSheet, Animated, Easing, StatusBar } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { loadAppBg, loadAppBgDim } from '../storage';
import PulseRings from './PulseRings';

// شاشة التحميل بتصميم Noir Champagne: خلفية سوداء متدرجة، لوجو شامبين،
// وشريط تحميل بيتحرك. ألوانها ثابتة (مش من الثيم) لأنها بتظهر قبل ما الثيم
// والخطوط يتحمّلوا. fontsReady بس بيقرر نستخدم خط التطبيق ولا خط النظام.
const TRACK_W = 190;
const BAR_W = 76;

export default function SplashLoading({ fontsReady = false }) {
  const slide = useRef(new Animated.Value(0)).current;
  const float = useRef(new Animated.Value(0)).current;
  const fade = useRef(new Animated.Value(0)).current;
  const [bg, setBg] = useState(null);
  useEffect(() => {
    Promise.all([loadAppBg(), loadAppBgDim()]).then(([uri, dim]) => { if (uri) setBg({ uri, dim }); }).catch(() => {});
  }, []);

  useEffect(() => {
    const loop = Animated.loop(
      Animated.timing(slide, { toValue: 1, duration: 1400, easing: Easing.inOut(Easing.ease), useNativeDriver: true })
    );
    loop.start();
    return () => loop.stop();
  }, [slide]);

  useEffect(() => {
    Animated.timing(fade, { toValue: 1, duration: 900, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(float, { toValue: 1, duration: 2200, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(float, { toValue: 0, duration: 2200, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [float, fade]);

  const floatY = float.interpolate({ inputRange: [0, 1], outputRange: [0, -6] });
  const translateX = slide.interpolate({ inputRange: [0, 1], outputRange: [-BAR_W, TRACK_W] });
  const titleFont = fontsReady ? { fontFamily: 'ElMessiri_700Bold' } : null;

  return (
    <View style={styles.root}>
      <StatusBar barStyle="light-content" />
      {!!bg && (
        <>
          <Image source={{ uri: bg.uri }} style={StyleSheet.absoluteFill} resizeMode="cover" />
          <View pointerEvents="none" style={[StyleSheet.absoluteFill, { backgroundColor: `rgba(10,11,13,${Math.min(0.9, bg.dim + 0.15)})` }]} />
        </>
      )}
      <LinearGradient
        pointerEvents="none"
        colors={bg ? ['rgba(10,11,13,0)', 'rgba(23,19,11,0.35)', 'rgba(10,11,13,0)'] : ['#0A0B0D', '#17130B', '#0A0B0D']}
        start={{ x: 0.1, y: 0 }}
        end={{ x: 0.9, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <View pointerEvents="none" style={styles.glow} />
      <LinearGradient pointerEvents="none" colors={['rgba(214,179,106,0)', 'rgba(214,179,106,0.35)', 'rgba(214,179,106,0)']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.streakA} />
      <LinearGradient pointerEvents="none" colors={['rgba(214,179,106,0)', 'rgba(214,179,106,0.22)', 'rgba(214,179,106,0)']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.streakB} />

      <Animated.View style={[styles.center, { opacity: fade }]}>
        <View style={styles.logoWrap}>
          <PulseRings color="#D6B36A" size={104} rings={3} duration={3000} maxScale={1.9} />
          <Animated.View style={[styles.logoBox, { transform: [{ translateY: floatY }] }]}>
            <MaterialCommunityIcons name="home-variant-outline" size={58} color="#D6B36A" />
          </Animated.View>
        </View>
        <Text style={[styles.title, titleFont]}>Silja Smart</Text>
        <Text style={styles.tagline}>Your Smart Home</Text>
      </Animated.View>

      <View style={styles.footer}>
        <Text style={styles.loadingText}>جاري التحميل...</Text>
        <View style={styles.track}>
          <Animated.View style={[styles.bar, { transform: [{ translateX }] }]} />
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0A0B0D', alignItems: 'center', justifyContent: 'center' },
  glow: { position: 'absolute', top: '22%', width: 280, height: 280, borderRadius: 140, backgroundColor: '#D6B36A', opacity: 0.07 },
  center: { alignItems: 'center' },
  logoWrap: { width: 104, height: 104, alignItems: 'center', justifyContent: 'center', marginBottom: 18 },
  streakA: { position: 'absolute', top: '10%', left: '-30%', width: '160%', height: 1.5, transform: [{ rotate: '-24deg' }] },
  streakB: { position: 'absolute', top: '78%', left: '-30%', width: '160%', height: 1.5, transform: [{ rotate: '-24deg' }] },
  logoBox: {
    width: 104, height: 104, borderRadius: 32, alignItems: 'center', justifyContent: 'center',
    backgroundColor: 'rgba(214,179,106,0.08)', borderWidth: 1.5, borderColor: 'rgba(214,179,106,0.55)',
  },
  title: { color: '#E8D2A0', fontSize: 34, fontWeight: '800', letterSpacing: 0.4 },
  tagline: { color: '#C8B27A', fontSize: 14, marginTop: 6, letterSpacing: 0.8 },
  footer: { position: 'absolute', bottom: 70, alignItems: 'center' },
  loadingText: { color: '#A7A196', fontSize: 13, marginBottom: 12 },
  track: { width: TRACK_W, height: 4, borderRadius: 2, overflow: 'hidden', backgroundColor: 'rgba(214,179,106,0.16)' },
  bar: { width: BAR_W, height: 4, borderRadius: 2, backgroundColor: '#D6B36A' },
});
