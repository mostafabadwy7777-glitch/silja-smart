import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FONTS } from '../fonts';
import { useTheme } from '../ThemeContext';

// هيدر موحّد لكل الشاشات الفرعية زي التصميم: سهم رجوع في البداية، العنوان في
// النص، وخانة اختيارية في النهاية (زرار إضافة/إعدادات/تحديث).
// ملحوظة: التطبيق RTL، فسهم الرجوع هو chevron-right (زي شاشة الأجهزة).
export default function ScreenHeader({ title, onBack, right, style }) {
  const { theme } = useTheme();
  return (
    <View style={[styles.row, style]}>
      <View style={styles.side}>
        {onBack ? (
          <TouchableOpacity onPress={onBack} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }} style={styles.backBtn}>
            <MaterialCommunityIcons name="chevron-right" size={28} color={theme.accentSoft} />
          </TouchableOpacity>
        ) : null}
      </View>
      <Text style={[styles.title, { color: theme.textPrimary }]} numberOfLines={1}>{title}</Text>
      <View style={[styles.side, styles.sideEnd]}>{right || null}</View>
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', minHeight: 48, paddingBottom: 12, marginBottom: 14 },
  side: { width: 44, justifyContent: 'center' },
  sideEnd: { alignItems: 'flex-end' },
  backBtn: { paddingVertical: 4 },
  title: { flex: 1, textAlign: 'center', fontSize: 20, fontWeight: '800', fontFamily: FONTS.bodyBold },
});
