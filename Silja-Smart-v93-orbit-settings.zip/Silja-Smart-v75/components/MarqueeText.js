import React, { useEffect, useRef, useState } from 'react';
import { Animated, Easing, I18nManager, Text, View } from 'react-native';

// نص بيتحرك أفقيًا (ذهاب وإياب) لو أطول من المساحة المتاحة، عشان الاسم يظهر كله.
// لو الاسم داخل المساحة بيتعرض عادي من غير حركة.
const RTL = !!I18nManager.isRTL;
const physLeft = (px) => (RTL ? { end: px } : { start: px });
const physRight = (px) => (RTL ? { start: px } : { end: px });
const ARABIC = /[\u0600-\u06FF]/;

export default function MarqueeText({ text, style, maxWidth = 110 }) {
  const [textW, setTextW] = useState(null);
  const x = useRef(new Animated.Value(0)).current;
  const str = String(text ?? '');
  const startsRight = ARABIC.test(str);
  const overflow = textW ? Math.ceil(textW) - maxWidth + 4 : 0;
  const scrolls = overflow > 0;

  useEffect(() => {
    x.setValue(0);
    if (!scrolls) return undefined;
    const target = startsRight ? overflow : -overflow;
    const dur = Math.max(1400, overflow * 38);
    const loop = Animated.loop(
      Animated.sequence([
        Animated.delay(1200),
        Animated.timing(x, { toValue: target, duration: dur, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
        Animated.delay(900),
        Animated.timing(x, { toValue: 0, duration: dur, easing: Easing.inOut(Easing.quad), useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [scrolls, overflow, startsRight, x, str]);

  const measurer = (
    <Text
      style={[style, { position: 'absolute', opacity: 0, width: 3000 }, physLeft(0)]}
      onTextLayout={(e) => {
        const w = e.nativeEvent.lines?.[0]?.width;
        if (w && Math.abs(w - (textW || 0)) > 0.5) setTextW(w);
      }}
      pointerEvents="none"
    >
      {str}
    </Text>
  );

  if (!scrolls) {
    return (
      <View style={{ maxWidth, overflow: 'hidden' }}>
        {measurer}
        <Text numberOfLines={1} style={style}>{str}</Text>
      </View>
    );
  }

  return (
    <View style={{ width: maxWidth, height: (style?.fontSize || 12) * 1.5, overflow: 'hidden' }}>
      <Animated.View
        style={[
          { position: 'absolute', top: 0, width: Math.ceil(textW) + 2, transform: [{ translateX: x }] },
          startsRight ? physRight(0) : physLeft(0),
        ]}
      >
        <Text numberOfLines={1} style={[style, { width: Math.ceil(textW) + 2 }]}>{str}</Text>
      </Animated.View>
    </View>
  );
}
