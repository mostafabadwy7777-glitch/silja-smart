import React, { useEffect, useRef, useState } from 'react';
import { Text, Animated, Easing } from 'react-native';

// نص فيه أرقام ("3/20" أو "7") — الأرقام بتعدّ بسرعة من القيمة القديمة للجديدة لما تتغير
// (وأول ظهور بيعدّ من صفر). باقي الحروف والرموز بتفضل زي ما هي.
export default function AnimatedNumber({ value, style, duration = 700, ...rest }) {
  const text = String(value);
  const nums = (text.match(/\d+/g) || []).map(Number);
  const prev = useRef(nums.map(() => 0));
  const p = useRef(new Animated.Value(0)).current;
  const [shown, setShown] = useState(prev.current);
  const key = nums.join(',');

  useEffect(() => {
    const from = prev.current.length === nums.length ? prev.current : nums.map(() => 0);
    p.setValue(0);
    const id = p.addListener(({ value: v }) => {
      setShown(nums.map((n, i) => Math.round(from[i] + (n - from[i]) * v)));
    });
    Animated.timing(p, { toValue: 1, duration, easing: Easing.out(Easing.cubic), useNativeDriver: false }).start(({ finished }) => {
      if (finished) prev.current = nums;
    });
    return () => { p.removeListener(id); p.stopAnimation(); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  let i = 0;
  const out = text.replace(/\d+/g, () => String(shown[i++] ?? 0));
  return <Text style={style} {...rest}>{out}</Text>;
}
