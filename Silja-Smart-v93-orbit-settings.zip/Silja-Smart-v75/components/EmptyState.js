// حالة فاضية بشكل أنيق: أيقونة في دايرة ذهبية بموجات هادية، عنوان، شرح، وزرار اختياري.
import React from 'react';
import { View, Text } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import TouchableOpacity from './AnimatedTouchable';
import PulseRings from './PulseRings';
import { useTheme } from '../ThemeContext';
import { withAlpha, readableOn } from '../colorUtils';

export default function EmptyState({ icon = 'inbox-outline', title, text, actionLabel, onAction }) {
  const { theme } = useTheme();
  const c = theme.accentSoft || '#D6B36A';
  return (
    <View style={{ alignItems: 'center', paddingVertical: 48, paddingHorizontal: 24 }}>
      <View style={{ width: 130, height: 130, alignItems: 'center', justifyContent: 'center' }}>
        <PulseRings color={c} size={90} rings={2} duration={3400} maxScale={1.5} />
        <LinearGradient
          colors={[withAlpha(c, 0.3), withAlpha(c, 0.06)]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{ width: 90, height: 90, borderRadius: 45, alignItems: 'center', justifyContent: 'center', borderWidth: 1.4, borderColor: withAlpha(c, 0.55) }}
        >
          <MaterialCommunityIcons name={icon} size={40} color={c} />
        </LinearGradient>
      </View>
      {!!title && <Text style={{ color: theme.textPrimary, fontSize: 17, fontWeight: '800', marginTop: 8, textAlign: 'center' }}>{title}</Text>}
      {!!text && <Text style={{ color: theme.textMuted, fontSize: 12.5, lineHeight: 19, marginTop: 6, textAlign: 'center', maxWidth: 280 }}>{text}</Text>}
      {!!actionLabel && (
        <TouchableOpacity
          onPress={onAction}
          style={{ marginTop: 18, paddingVertical: 12, paddingHorizontal: 26, borderRadius: 16, backgroundColor: theme.accent, shadowColor: theme.accent, shadowOpacity: 0.4, shadowRadius: 10, shadowOffset: { width: 0, height: 4 }, elevation: 4 }}
        >
          <Text style={{ color: readableOn(theme.accent), fontWeight: '800', fontSize: 13.5 }}>{actionLabel}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}
