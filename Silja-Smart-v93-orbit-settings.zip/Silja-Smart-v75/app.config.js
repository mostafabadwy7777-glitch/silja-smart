// بيقرأ app.json زي ما هو، وبيضيف ملف Firebase (للإشعارات على أندرويد) تلقائيًا
// لو google-services.json موجود في جذر المشروع. من غيره البناء بيشتغل عادي بدون إشعارات push.
const fs = require('fs');
const path = require('path');

module.exports = ({ config }) => {
  const file = path.join(__dirname, 'google-services.json');
  if (fs.existsSync(file)) {
    return { ...config, android: { ...config.android, googleServicesFile: './google-services.json' } };
  }
  return config;
};
