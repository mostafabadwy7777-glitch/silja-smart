// تنسيق التاريخ والوقت بأرقام إنجليزية (0-9) على أي جهاز — يدويًا من غير Intl.
const AR_MONTHS = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
const p2 = (n) => String(n).padStart(2, '0');

// "1:12 م"
export function clock12(ms) {
  const d = new Date(ms);
  const h = d.getHours();
  return `${h % 12 || 12}:${p2(d.getMinutes())} ${h < 12 ? 'ص' : 'م'}`;
}
// "28/10 • 1:12 م"
export function shortDateTime(ms) {
  const d = new Date(ms);
  return `${p2(d.getDate())}/${p2(d.getMonth() + 1)} • ${clock12(ms)}`;
}
// "28 أكتوبر • 1:12 م"
export function dayMonthTime(ms) {
  const d = new Date(ms);
  return `${d.getDate()} ${AR_MONTHS[d.getMonth()]} • ${clock12(ms)}`;
}
// "28 أكتوبر"
export function dayMonth(ms) {
  const d = new Date(ms);
  return `${d.getDate()} ${AR_MONTHS[d.getMonth()]}`;
}
