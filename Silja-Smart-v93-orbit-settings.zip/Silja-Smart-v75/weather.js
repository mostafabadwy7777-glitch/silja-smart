import AsyncStorage from '@react-native-async-storage/async-storage';

// مدينة/منطقة الطقس المختارة (الافتراضي القاهرة) + اشتراك بسيط عشان الشارة تتحدّث فورًا
// لما المستخدم يغيّر المنطقة من الإعدادات.
const KEY = 'iot_weather_city_v1';
const AUTO_KEY = 'iot_weather_autoloc_v1';
export const DEFAULT_CITY = { name: 'القاهرة', lat: 30.0444, lon: 31.2357 };
const listeners = new Set();

export async function loadWeatherCity() {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    const c = raw ? JSON.parse(raw) : null;
    if (c && Number.isFinite(c.lat) && Number.isFinite(c.lon)) return c;
  } catch (_) {}
  return DEFAULT_CITY;
}

export async function hasSavedWeatherCity() {
  try {
    return !!(await AsyncStorage.getItem(KEY));
  } catch (_) {
    return false;
  }
}

export async function saveWeatherCity(city) {
  await AsyncStorage.setItem(KEY, JSON.stringify(city));
  listeners.forEach((fn) => fn(city));
}

export function subscribeWeatherCity(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

// ---------------------------------------------------------------------------
// أدوات شبكة: مهلة زمنية عشان البحث ما يعلقش، وقراءة JSON بأمان.
// ---------------------------------------------------------------------------
async function getJson(url, headers, timeoutMs = 9000) {
  const ctrl = typeof AbortController !== 'undefined' ? new AbortController() : null;
  const timer = ctrl ? setTimeout(() => ctrl.abort(), timeoutMs) : null;
  try {
    const res = await fetch(url, { headers: { Accept: 'application/json', ...(headers || {}) }, signal: ctrl ? ctrl.signal : undefined });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    if (timer) clearTimeout(timer);
  }
}

const NOMINATIM_HEADERS = { 'User-Agent': 'SiljaSmart/1.0 (home automation app)' };

// توحيد الحروف العربية (أ/إ/آ → ا، ة → ه، ى → ي، وشيل التشكيل) لتحسين نتيجة البحث.
export function normalizeArabic(text) {
  return String(text || '')
    .replace(/[ً-ٰٟـ]/g, '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ى/g, 'ي')
    .trim();
}

// ---------------------------------------------------------------------------
// البحث: OpenStreetMap (Nominatim) بيجيب الأحياء والمناطق بالعربي كويس،
// وOpen-Meteo احتياطي للمدن. بنجمع النتيجتين ونشيل المكرر.
// ---------------------------------------------------------------------------
function placeTitle(a, fallback) {
  return (
    a.suburb || a.neighbourhood || a.quarter || a.city_district || a.district ||
    a.village || a.town || a.city || a.municipality || a.county || fallback || ''
  );
}

function placeRegion(a) {
  const parts = [a.city || a.town || a.village, a.state || a.governorate || a.region, a.country].filter(Boolean);
  const title = placeTitle(a);
  return parts.filter((p, i) => p !== title && parts.indexOf(p) === i).join('، ');
}

async function searchNominatim(query) {
  const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query)}&format=jsonv2&addressdetails=1&limit=8&accept-language=ar`;
  const data = await getJson(url, NOMINATIM_HEADERS);
  return (Array.isArray(data) ? data : [])
    .map((r) => {
      const lat = parseFloat(r.lat);
      const lon = parseFloat(r.lon);
      const a = r.address || {};
      const name = placeTitle(a, r.name || (r.display_name || '').split('،')[0]);
      if (!name || !Number.isFinite(lat) || !Number.isFinite(lon)) return null;
      return { name, region: placeRegion(a), lat, lon };
    })
    .filter(Boolean);
}

async function searchOpenMeteo(query) {
  const out = [];
  for (const lang of ['ar', 'en']) {
    const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=8&language=${lang}&format=json`;
    const data = await getJson(url);
    (data.results || []).forEach((r) =>
      out.push({
        name: r.name,
        region: [r.admin2, r.admin1, r.country].filter(Boolean).join('، '),
        lat: r.latitude,
        lon: r.longitude,
      })
    );
    if (out.length) break;
  }
  return out;
}

export async function searchCities(query) {
  const q = normalizeArabic(query);
  const settled = await Promise.allSettled([searchNominatim(q), searchOpenMeteo(q)]);
  const lists = settled.filter((r) => r.status === 'fulfilled').map((r) => r.value);
  if (!lists.length) throw new Error('search failed'); // الاتنين فشلوا = غالبًا مفيش إنترنت
  const seen = new Set();
  const merged = [];
  lists.flat().forEach((c) => {
    const key = `${c.lat.toFixed(2)},${c.lon.toFixed(2)}`;
    if (seen.has(key)) return;
    seen.add(key);
    merged.push(c);
  });
  return merged.slice(0, 10);
}

// ---------------------------------------------------------------------------
// "موقعي الحالي": GPS ثم تحويل الإحداثيات لاسم المنطقة بالعربي.
// ---------------------------------------------------------------------------
export async function reverseGeocode(lat, lon) {
  // 1) Nominatim (أدق في الأحياء)
  try {
    const url = `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lon}&format=jsonv2&zoom=14&addressdetails=1&accept-language=ar`;
    const data = await getJson(url, NOMINATIM_HEADERS);
    const a = (data && data.address) || {};
    const name = placeTitle(a);
    if (name) return { name, region: placeRegion(a), lat, lon };
  } catch (_) {}
  // 2) BigDataCloud (بدون مفتاح) احتياطي
  try {
    const url = `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lon}&localityLanguage=ar`;
    const d = await getJson(url);
    const name = d.locality || d.city || d.principalSubdivision;
    if (name) return { name, region: [d.principalSubdivision, d.countryName].filter(Boolean).join('، '), lat, lon };
  } catch (_) {}
  return null;
}

// تقريب بالـ IP لو الـ GPS مش متاح أو الإذن مرفوض (دقته على مستوى المدينة).
async function locateByIp() {
  try {
    const d = await getJson('https://api.bigdatacloud.net/data/reverse-geocode-client?localityLanguage=ar');
    if (Number.isFinite(d.latitude) && Number.isFinite(d.longitude)) {
      const name = d.locality || d.city || d.principalSubdivision;
      if (name) return { name, region: [d.principalSubdivision, d.countryName].filter(Boolean).join('، '), lat: d.latitude, lon: d.longitude };
    }
  } catch (_) {}
  return null;
}

// بيرجع { city, source } أو يرمي خطأ برسالة مفهومة.
export async function detectCurrentCity() {
  let permissionDenied = false;
  try {
    const Location = require('expo-location');
    const perm = await Location.requestForegroundPermissionsAsync();
    if (perm.status === 'granted') {
      let pos = null;
      try {
        pos = await Promise.race([
          Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced }),
          new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 12000)),
        ]);
      } catch (_) {
        pos = await Location.getLastKnownPositionAsync().catch(() => null);
      }
      if (pos && pos.coords) {
        const city = await reverseGeocode(pos.coords.latitude, pos.coords.longitude);
        if (city) return { city, source: 'gps' };
        return { city: { name: 'موقعي الحالي', region: '', lat: pos.coords.latitude, lon: pos.coords.longitude }, source: 'gps' };
      }
    } else {
      permissionDenied = true;
    }
  } catch (_) {
    // expo-location مش متاحة (مثلًا نسخة قديمة من التطبيق) — نكمل بالتقريب بالـ IP
  }
  const ipCity = await locateByIp();
  if (ipCity) return { city: ipCity, source: 'ip', permissionDenied };
  const err = new Error(permissionDenied ? 'permission' : 'unavailable');
  err.code = permissionDenied ? 'permission' : 'unavailable';
  throw err;
}

// أول تشغيل للتطبيق: نحاول نجيب منطقة المستخدم تلقائيًا مرة واحدة بس.
export async function autoDetectOnFirstRun() {
  try {
    if (await AsyncStorage.getItem(AUTO_KEY)) return;
    await AsyncStorage.setItem(AUTO_KEY, '1');
    if (await hasSavedWeatherCity()) return;
    const { city } = await detectCurrentCity();
    if (city) await saveWeatherCity({ name: city.name, lat: city.lat, lon: city.lon });
  } catch (_) {
    // صامت: لو فشل بيفضل الافتراضي (القاهرة) والمستخدم يقدر يختار يدويًا
  }
}
