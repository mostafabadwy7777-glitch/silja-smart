// ============================================================================
// مؤقتات العدّ التنازلي — "اطفي الإضاءة بعد 30 دقيقة" / "شغّل بعد ساعة".
// ============================================================================
// المؤقتات بتتخزن محليًا (AsyncStorage) بوقت الانتهاء المطلق (endsAt)، فتفضل
// صحيحة لو التطبيق اتقفل وفتح تاني. التنفيذ بيحصل من التطبيق نفسه (أوامر MQTT
// عادية QoS 1) — يعني لازم التطبيق يكون مفتوح ومتصل وقت الانتهاء.
// لو التطبيق اتفتح بعد الميعاد بأكتر من GRACE_MS، المؤقت بيتلغي من غير تنفيذ
// عشان مانطفيش/نشغّل حاجة متأخر بكتير بدون ما المستخدم يتوقعها.
// ============================================================================
import { useCallback, useEffect, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { showToast } from './components/Toast';

const TIMERS_KEY = 'silja_timers_v1';
const TICK_MS = 1000;
const GRACE_MS = 10 * 60 * 1000;
export const MAX_TIMERS = 20;

export function newTimerId() {
  return `t_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
}

async function loadTimers() {
  try {
    const raw = await AsyncStorage.getItem(TIMERS_KEY);
    const list = raw ? JSON.parse(raw) : [];
    return Array.isArray(list)
      ? list.filter((t) => t && t.id && Number.isFinite(t.endsAt) && Array.isArray(t.targets) && t.targets.length > 0)
      : [];
  } catch (_) {
    return [];
  }
}

function saveTimers(list) {
  return AsyncStorage.setItem(TIMERS_KEY, JSON.stringify(list)).catch(() => {});
}

// بيرجّع { timers, addTimer, cancelTimer }
export function useTimers({ client, connected }) {
  const [timers, setTimers] = useState([]);
  const timersRef = useRef([]);
  const loadedRef = useRef(false);
  const clientRef = useRef(client);
  const connectedRef = useRef(connected);
  clientRef.current = client;
  connectedRef.current = connected;

  const commit = useCallback((next) => {
    timersRef.current = next;
    setTimers(next);
    saveTimers(next);
  }, []);

  useEffect(() => {
    let alive = true;
    loadTimers().then((list) => {
      if (!alive) return;
      loadedRef.current = true;
      // أي مؤقت اتضاف قبل ما التحميل يخلص بنحافظ عليه.
      const merged = [...list, ...timersRef.current.filter((t) => !list.some((x) => x.id === t.id))];
      timersRef.current = merged;
      setTimers(merged);
    });
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    const id = setInterval(() => {
      if (!loadedRef.current) return;
      const now = Date.now();
      const current = timersRef.current;
      if (!current.some((t) => t.endsAt <= now)) return;
      const c = clientRef.current;
      const canSend = !!(c && c.connected && connectedRef.current);
      const remaining = [];
      current.forEach((t) => {
        if (t.endsAt > now) { remaining.push(t); return; }
        if (now - t.endsAt > GRACE_MS) {
          showToast(`المؤقت "${t.name}" فات ميعاده وتم إلغاؤه`, { type: 'error' });
          return;
        }
        if (!canSend) { remaining.push(t); return; } // نستنى الاتصال (لحد GRACE_MS)
        t.targets.forEach((d) => {
          try { c.publish(d.controlTopic, t.value, { qos: 1 }); } catch (_) {}
        });
        showToast(`خلص المؤقت: ${t.name}`, { type: 'success' });
      });
      if (remaining.length !== current.length) commit(remaining);
    }, TICK_MS);
    return () => clearInterval(id);
  }, [commit]);

  const addTimer = useCallback((timer) => {
    commit([...timersRef.current, timer].sort((a, b) => a.endsAt - b.endsAt));
  }, [commit]);

  const cancelTimer = useCallback((id) => {
    commit(timersRef.current.filter((t) => t.id !== id));
  }, [commit]);

  return { timers, addTimer, cancelTimer };
}
