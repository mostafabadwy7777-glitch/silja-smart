// ============================================================================
// قوة إشارة الواي فاي للبوردات (RSSI).
// ============================================================================
// البورد بينشر `<device_id|prefix>/rssi` (رقم dBm، Retained). الهوك ده بيشترك في
// توبيك كل بورد ويرجّع { [boardId]: dBm }. العرض (اللون/الأيقونة/الوصف) في rssiInfo.
// ============================================================================
import { useEffect, useState } from 'react';
import { boardRssiTopic, parseRssi } from './discovery';

// نفس حدود الفيرموير (rssiQuality): -55 / -70 / -80
export function rssiInfo(rssi, theme) {
  if (typeof rssi !== 'number') return null;
  if (rssi >= -55) return { level: 4, label: 'ممتازة', icon: 'wifi-strength-4', color: theme.on };
  if (rssi >= -70) return { level: 3, label: 'جيدة', icon: 'wifi-strength-3', color: theme.on };
  if (rssi >= -80) return { level: 2, label: 'ضعيفة', icon: 'wifi-strength-2', color: '#F5A524' };
  return { level: 1, label: 'ضعيفة جدًا', icon: 'wifi-strength-1', color: '#F2784B' };
}

export function useBoardRssi(client, connected, boards = []) {
  const [rssi, setRssi] = useState({}); // { [boardId]: dBm }
  const key = boards.map((b) => `${b.id}:${boardRssiTopic(b)}`).join(',');

  useEffect(() => {
    if (!client || !connected) { setRssi({}); return undefined; }
    const topicToIds = new Map();
    boards.forEach((b) => {
      const t = boardRssiTopic(b);
      if (!t) return;
      if (!topicToIds.has(t)) topicToIds.set(t, []);
      topicToIds.get(t).push(b.id);
    });
    if (topicToIds.size === 0) return undefined;

    const topics = Array.from(topicToIds.keys());
    topics.forEach((t) => { try { client.subscribe(t); } catch (_) {} });
    const handler = (topic, payload) => {
      const ids = topicToIds.get(topic);
      if (!ids) return;
      const v = parseRssi(payload.toString());
      if (v === null) return;
      setRssi((prev) => {
        if (ids.every((id) => prev[id] === v)) return prev;
        const next = { ...prev };
        ids.forEach((id) => { next[id] = v; });
        return next;
      });
    };
    client.on('message', handler);
    return () => {
      client.off('message', handler);
      topics.forEach((t) => { try { client.unsubscribe(t); } catch (_) {} });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client, connected, key]);

  return rssi;
}
