// معاينة حيّة مصغّرة لمشهد الطقس جوه إعدادات الخلفية: بتتغيّر فورًا وانت بتسحب الشرائط.
// بتستخدم صورة خلفية كارت الرئيسية لو موجودة (نفس شكل الكارت الحقيقي)، وإلا سماء ملوّنة.
import React, { useEffect, useState } from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { HeroWeatherScene } from './HeroWeatherScene';
import { useWeatherNow, skyPhase } from '../weatherNow';
import { loadHeroBackground } from '../storage';
import { useTheme } from '../ThemeContext';

const SAMPLES = {
  night: { label: 'ليل', w: { code: 2, isDay: false, temp: 24, city: '' } },
  day: { label: 'نهار', w: { code: 2, isDay: true, temp: 30, city: '' } },
  rain: { label: 'مطر', w: { code: 61, isDay: true, temp: 18, city: '' } },
  snow: { label: 'ثلج', w: { code: 73, isDay: false, temp: -1, city: '' } },
  storm: { label: 'عاصفة', w: { code: 95, isDay: false, temp: 16, city: '' } },
};

export default function WeatherFxPreview({ theme, cloudAlpha, starAlpha, rainAlpha, bodyAlpha, boltAlpha = 1, shootingStars = true }) {
  const { motionActive } = useTheme();
  const live = useWeatherNow(true);
  const [bg, setBg] = useState(null);
  const [pick, setPick] = useState(null);
  useEffect(() => { loadHeroBackground().then(setBg).catch(() => {}); }, []);
  const sel = pick || (live ? 'live' : 'night');
  const weather = sel === 'live' ? live : SAMPLES[sel].w;
  const chips = [...(live ? [['live', 'الحالي']] : []), ...Object.keys(SAMPLES).map((k) => [k, SAMPLES[k].label])];
  return (
    <View style={{ marginBottom: 8 }}>
      <View style={[styles.box, { borderColor: theme.border, backgroundColor: '#0B1220' }]}>
        {!!bg && <Image source={{ uri: bg }} style={StyleSheet.absoluteFillObject} resizeMode="cover" />}
        {!!weather && (
          <HeroWeatherScene weather={weather} motion={motionActive !== false} hour={new Date().getHours()} overlay={!!bg} cloudAlpha={cloudAlpha} starAlpha={starAlpha} rainAlpha={rainAlpha} bodyAlpha={bodyAlpha} boltAlpha={boltAlpha} shootingStars={shootingStars} sky={sel === 'live' ? skyPhase(weather) : null} />
        )}
      </View>
      <View style={styles.chips}>
        {chips.map(([id, label]) => {
          const on = sel === id;
          return (
            <TouchableOpacity key={id} onPress={() => setPick(id)} style={[styles.chip, { borderColor: on ? theme.accent : theme.border, backgroundColor: on ? theme.accent : 'transparent' }]}>
              <Text style={{ color: on ? (theme.isLight ? '#fff' : '#10161C') : theme.textSecondary, fontSize: 12, fontWeight: '800' }}>{label}</Text>
            </TouchableOpacity>
          );
        })}
      </View>
      <Text style={{ color: theme.textMuted, fontSize: 11, marginTop: 6, textAlign: 'right' }}>
        {bg ? 'المعاينة فوق صورة كارت الرئيسية بتاعتك.' : 'المعاينة على سماء الكارت الافتراضية.'}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  box: { height: 120, borderRadius: 16, overflow: 'hidden', borderWidth: 1 },
  chips: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 8, justifyContent: 'flex-end' },
  chip: { paddingHorizontal: 14, paddingVertical: 6, borderRadius: 12, borderWidth: 1 },
});
