import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Image, StyleSheet, Animated, Easing, Dimensions } from 'react-native';
import { usePaneActive } from '../ThemeContext';
import { useTheme } from '../ThemeContext';
import { LinearGradient } from 'expo-linear-gradient';
import PresetLayers, { isPresetId } from './BgPresets';
import { LightsGlow, WeatherLayer } from './BgEffects';
import { useLightsOn } from '../lightsGlow';
import { useWeatherNow } from '../weatherNow';
import { useTilt } from '../tilt';

// ============================================================================
// خلفية زخرفية "حية" لكل شاشة — نفس فكرة النسخة اللي قبل كده (هالات ضوء +
// أرضية شبكية بمنظور 3D)، لكن دلوقتي كل حاجة بتتحرك ببطء وبشكل لا نهائي:
//
// الطبقات الزخرفية اختيارية؛ التصميم الافتراضي يفضل هادئًا ونظيفًا،
// ويمكن تفعيل الهالات أو الشبكة أو الجزيئات في الشاشات التي تحتاجها فقط.
//
// كل الحركات بتستخدم Animated + useNativeDriver (scale/translateY/opacity
// بس) عشان تفضل ناعمة وخفيفة على الأداء حتى مع أكتر من طبقة شغالة في نفس
// الوقت. الطبقة كلها لسه pointerEvents="none" فمش بتأثر على أي تفاعل.
// ============================================================================

const GRID_ROWS = 10;
const ROW_HEIGHT = 30;
const GRID_COLS = 9;
const PARTICLE_COUNT = 6;

// ألوان سماء الوقت (أعلى → أسفل) حسب ساعة الجهاز: فجر 5-8، نهار 8-16، غروب 16-19، ليل بعد كده.
function skyForHour(h) {
  if (h >= 5 && h < 8) return ['#FF9A76', '#FFD1A1'];
  if (h >= 8 && h < 16) return ['#5BB5FF', '#CDEBFF'];
  if (h >= 16 && h < 19) return ['#FF7A59', '#8E5BD6'];
  return ['#1B2A6B', '#4A2C8C'];
}

// #rrggbb → rgba(...) بشفافية معينة
function withAlpha(hex, a) {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
  if (!m) return `rgba(214,179,106,${a})`;
  const n = parseInt(m[1], 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
}

// تجميع الشاشات في 4 مجموعات عشان نقدر نخصّص خلفية لكل مجموعة (الإعدادات في خلفية التطبيق).
const SCREEN_GROUP = {
  home: 'home',
  boards: 'home',
  switches: 'switches',
  devices: 'switches',
  scenes: 'scenes',
  presence: 'scenes',
  autoLights: 'scenes',
  timers: 'scenes',
};
export const groupOfScreen = (screen) => SCREEN_GROUP[screen] || 'other';
const BLUR_RADIUS = [0, 3, 8, 16];
const PARALLAX_PX = 14;

export default function ScreenBackground({ theme, grid = false, glows = false, particles = false, ambient = true, screen }) {
  const { appBg, appBgDim, timeSky, bgPrefs, motionActive } = useTheme();
  const win = Dimensions.get('window');
  const dark = !(theme && theme.isLight);
  // أي خلفية تتطبق على الشاشة دي: اختيار المجموعة، أو العام (خلفية جاهزة > صورة > ثيم عادي).
  const choice = (bgPrefs && bgPrefs.perScreen && bgPrefs.perScreen[groupOfScreen(screen)]) || 'global';
  let mode = choice === 'global' ? (bgPrefs && bgPrefs.preset && isPresetId(bgPrefs.preset) ? bgPrefs.preset : appBg ? 'photo' : 'plain') : choice;
  if (mode === 'photo' && !appBg) mode = 'plain';
  if (mode !== 'photo' && mode !== 'plain' && !isPresetId(mode)) mode = 'plain';
  const blur = BLUR_RADIUS[(bgPrefs && bgPrefs.blur) || 0] || 0;

  // ظهور تدريجي: عند فتح الشاشة وعند تغيير الخلفية.
  const fade = useRef(new Animated.Value(0.35)).current;
  const bgKey = `${mode}|${appBg || ''}|${blur}`;
  useEffect(() => {
    fade.setValue(0.35);
    const a = Animated.timing(fade, { toValue: 1, duration: 420, easing: Easing.out(Easing.quad), useNativeDriver: true });
    a.start();
    return () => a.stop();
  }, [bgKey, fade]);

  // تفاعل الإضاءة / الطقس / العمق (كلها بتقف لو الشاشة متخفية أو "حركة أقل").
  const lightsOn = useLightsOn();
  const paneActiveFx = usePaneActive();
  const weather = useWeatherNow(!!(bgPrefs && bgPrefs.weather) && paneActiveFx);
  const parallaxOn = !!(bgPrefs && bgPrefs.parallax) && motionActive !== false && paneActiveFx;
  const tilt = useTilt(parallaxOn);
  const [hour, setHour] = useState(new Date().getHours());
  const pulse = useRef(new Animated.Value(0)).current;
  const scroll = useRef(new Animated.Value(0)).current;
  const floatAnims = useRef(
    Array.from({ length: PARTICLE_COUNT }).map(() => new Animated.Value(0))
  ).current;

  const paneActive = usePaneActive(); // التبويب المخفي بيوقّف الحركة
  useEffect(() => {
    if (!paneActive) return undefined; // التبويب مخفي: بنوقّف الحركة
    if (!theme) return undefined;

    const pulseLoop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, {
          toValue: 1,
          duration: 2600,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
        Animated.timing(pulse, {
          toValue: 0,
          duration: 2600,
          easing: Easing.inOut(Easing.sin),
          useNativeDriver: true,
        }),
      ])
    );
    if (glows) pulseLoop.start();

    const scrollLoop = Animated.loop(
      Animated.timing(scroll, {
        toValue: 1,
        duration: 3200,
        easing: Easing.linear,
        useNativeDriver: true,
      })
    );
    if (grid) scrollLoop.start();

    const particleTimeouts = [];
    const particleLoops = floatAnims.map((v, i) => {
      v.setValue(0);
      const loop = Animated.loop(
        Animated.timing(v, {
          toValue: 1,
          duration: 4200 + (i % 5) * 700,
          easing: Easing.linear,
          useNativeDriver: true,
        })
      );
      if (particles) {
        const t = setTimeout(() => loop.start(), i * 260);
        particleTimeouts.push(t);
      }
      return loop;
    });

    return () => {
      pulseLoop.stop();
      scrollLoop.stop();
      particleLoops.forEach((l) => l.stop());
      particleTimeouts.forEach((t) => clearTimeout(t));
    };
  }, [theme, grid, glows, particles, paneActive]);

  const particleSeeds = useMemo(
    () =>
      Array.from({ length: PARTICLE_COUNT }).map((_, i) => ({
        left: `${(i * 37 + 8) % 92}%`,
        size: 3 + (i % 3),
      })),
    []
  );

  // الساعة بتتحدّث كل 10 دقايق، وبس لما الشاشة ظاهرة وسماء الوقت شغالة.
  useEffect(() => {
    if (!timeSky || !paneActive) return undefined;
    setHour(new Date().getHours());
    const t = setInterval(() => setHour(new Date().getHours()), 600000);
    return () => clearInterval(t);
  }, [timeSky, paneActive]);

  if (!theme) return null;
  const lineColor = theme.accent;

  const glowScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.92, 1.14] });
  const gridTranslateY = scroll.interpolate({ inputRange: [0, 1], outputRange: [0, ROW_HEIGHT] });

  return (
    <View pointerEvents="none" style={[StyleSheet.absoluteFillObject, { overflow: 'hidden' }]}>
      <Animated.View
        pointerEvents="none"
        style={[
          StyleSheet.absoluteFillObject,
          { opacity: fade },
          parallaxOn && {
            transform: [
              { translateX: tilt.x.interpolate({ inputRange: [-1, 1], outputRange: [-PARALLAX_PX, PARALLAX_PX] }) },
              { translateY: tilt.y.interpolate({ inputRange: [-1, 1], outputRange: [-PARALLAX_PX, PARALLAX_PX] }) },
              { scale: 1.12 },
            ],
          },
        ]}
      >
        {mode === 'plain' && !!theme.bgGradient && (
          <LinearGradient colors={theme.bgGradient} start={{ x: 0.15, y: 0 }} end={{ x: 0.85, y: 1 }} style={StyleSheet.absoluteFillObject} />
        )}
        {mode === 'photo' && (
          <>
            <Image source={{ uri: appBg }} style={StyleSheet.absoluteFillObject} resizeMode="cover" blurRadius={blur} />
            {/* طبقة بلون الثيم فوق الصورة عشان النصوص تفضل مقروءة */}
            <View style={[StyleSheet.absoluteFillObject, { backgroundColor: withAlpha(theme.bg, appBgDim) }]} />
          </>
        )}
        {isPresetId(mode) && <PresetLayers id={mode} w={win.width} h={win.height} dark={dark} />}
      </Animated.View>
      {!!bgPrefs && bgPrefs.reactive && <LightsGlow count={lightsOn} dark={dark} />}
      {!!weather && <WeatherLayer weather={weather} motion={motionActive !== false && paneActiveFx} dark={dark} cloudAlpha={bgPrefs && bgPrefs.cloudAlpha != null ? bgPrefs.cloudAlpha : 1} starAlpha={bgPrefs && bgPrefs.starAlpha != null ? bgPrefs.starAlpha : 1} rainAlpha={bgPrefs && bgPrefs.rainAlpha != null ? bgPrefs.rainAlpha : 1} bodyAlpha={bgPrefs && bgPrefs.bodyAlpha != null ? bgPrefs.bodyAlpha : 1} />}
      {timeSky && (
        <LinearGradient
          colors={skyForHour(hour).map((c) => withAlpha(c, theme.isLight ? 0.16 : 0.22))}
          start={{ x: 0.5, y: 0 }}
          end={{ x: 0.5, y: 1 }}
          style={StyleSheet.absoluteFillObject}
        />
      )}
      {ambient && !isPresetId(mode) && (
        <>
          {/* تدرج مائل بلمعة دهبية هادية (زي خلفية التصميم) + شعاعين ضوء رفيعين على الجنبين */}
          <LinearGradient
            colors={[withAlpha(theme.accentSoft, 0), withAlpha(theme.accentSoft, theme.isLight ? 0.07 : 0.10), withAlpha(theme.accentSoft, 0)]}
            start={{ x: 0.05, y: 0 }}
            end={{ x: 0.95, y: 1 }}
            style={StyleSheet.absoluteFillObject}
          />
          <LinearGradient
            colors={[withAlpha(theme.accentSoft, 0), withAlpha(theme.accentSoft, theme.isLight ? 0.18 : 0.30), withAlpha(theme.accentSoft, 0)]}
            style={styles.beamRight}
          />
          <LinearGradient
            colors={[withAlpha(theme.accentSoft, 0), withAlpha(theme.accentSoft, theme.isLight ? 0.10 : 0.18), withAlpha(theme.accentSoft, 0)]}
            style={styles.beamLeft}
          />
        </>
      )}
      {glows && (
        <>
          <Animated.View
            style={[
              styles.glow,
              styles.glowTopRight,
              { backgroundColor: theme.accent, shadowColor: theme.accent, transform: [{ scale: glowScale }] },
            ]}
          />
          <Animated.View
            style={[
              styles.glow,
              styles.glowBottomLeft,
              { backgroundColor: theme.accentSoft, shadowColor: theme.accentSoft, transform: [{ scale: glowScale }] },
            ]}
          />
          <Animated.View
            style={[
              styles.glow,
              styles.glowCenter,
              { backgroundColor: theme.on, shadowColor: theme.on, transform: [{ scale: glowScale }] },
            ]}
          />
        </>
      )}

      {particles && (
        <View style={StyleSheet.absoluteFillObject}>
          {particleSeeds.map((p, i) => {
            const v = floatAnims[i];
            const translateY = v.interpolate({ inputRange: [0, 1], outputRange: [0, -70] });
            const opacity = v.interpolate({
              inputRange: [0, 0.15, 0.8, 1],
              outputRange: [0, 0.55, 0.3, 0],
            });
            return (
              <Animated.View
                key={'particle-' + i}
                style={{
                  position: 'absolute',
                  bottom: 40,
                  left: p.left,
                  width: p.size,
                  height: p.size,
                  borderRadius: p.size,
                  backgroundColor: theme.accentSoft,
                  opacity,
                  transform: [{ translateY }],
                }}
              />
            );
          })}
        </View>
      )}

      {grid && (
        <View style={styles.gridWrap}>
          <View style={styles.gridPlane}>
            <Animated.View style={{ transform: [{ translateY: gridTranslateY }] }}>
              {Array.from({ length: GRID_ROWS + 1 }).map((_, i) => (
                <View key={'r' + i} style={[styles.gridRow, { borderBottomColor: lineColor }]} />
              ))}
            </Animated.View>
            <View style={styles.gridColsWrap}>
              {Array.from({ length: GRID_COLS }).map((_, i) => (
                <View key={'c' + i} style={[styles.gridCol, { backgroundColor: lineColor }]} />
              ))}
            </View>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  beamRight: { position: 'absolute', right: 14, top: '8%', width: 2, height: '52%', borderRadius: 1 },
  beamLeft: { position: 'absolute', left: 8, top: '30%', width: 2, height: '40%', borderRadius: 1 },
  glow: {
    position: 'absolute',
    borderRadius: 999,
    opacity: 0.035,
    shadowOpacity: 0.10,
    shadowRadius: 70,
    shadowOffset: { width: 0, height: 0 },
  },
  glowTopRight: { top: -100, right: -100, width: 190, height: 190 },
  glowBottomLeft: { bottom: -70, left: -90, width: 210, height: 210, opacity: 0.025 },
  glowCenter: { top: '36%', left: '20%', width: 130, height: 130, opacity: 0.018 },

  gridWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: 230,
    overflow: 'hidden',
    opacity: 0.07,
  },
  gridPlane: {
    position: 'absolute',
    left: '-20%',
    width: '140%',
    height: GRID_ROWS * ROW_HEIGHT,
    bottom: 0,
    transform: [{ perspective: 700 }, { rotateX: '68deg' }],
  },
  gridRow: { height: ROW_HEIGHT, borderBottomWidth: 1 },
  gridColsWrap: {
    ...StyleSheet.absoluteFillObject,
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  gridCol: { width: 1, height: '100%' },
});
