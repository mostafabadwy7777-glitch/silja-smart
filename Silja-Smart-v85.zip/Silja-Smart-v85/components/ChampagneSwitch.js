// مفتاح "شامبين" فاخر لكارت Noir Champagne.
// مسار عريض غامق بإطار ذهبي رفيع، وزرار دائري معدني (تدرج شامبين) عليه أيقونة power.
// لما يشتغل: المسار بيتملّي بتدرج لون الجهاز، والزرار بيتحرك للجهة التانية، وكلمة ON بتظهر.
// مفيش حركة مستمرة (توفير بطارية) — حركة الانزلاق بس عند التبديل.
import React, { useEffect, useRef } from 'react';
import { Animated, Easing, I18nManager, TouchableWithoutFeedback, View, Text } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { mixHex, withAlpha, readableOn } from '../colorUtils';

// التطبيق RTL: نثبّت الاتجاه الفعلي (ON = يمين، OFF = شمال) من غير الاعتماد على left/right.
const RTL = !!I18nManager.isRTL;
const physLeft = (px) => (RTL ? { end: px } : { start: px });
const physRight = (px) => (RTL ? { start: px } : { end: px });

export default function ChampagneSwitch({
  value,
  onValueChange,
  theme,
  activeColor,
  width = 116,
  height = 40,
  disabled = false,
}) {
  const anim = useRef(new Animated.Value(value ? 1 : 0)).current;
  const gold = activeColor || theme?.accentSoft || '#D6B36A';
  const isLight = !!theme?.isLight;

  useEffect(() => {
    Animated.timing(anim, { toValue: value ? 1 : 0, duration: 280, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  }, [value, anim]);

  const pad = 4;
  const thumb = height - pad * 2;
  const travel = width - thumb - pad * 2;

  const trackOff = isLight ? mixHex(theme.cardAlt, theme.border, 0.5) : '#12151A';
  const rimOff = isLight ? withAlpha(theme.textMuted, 0.4) : 'rgba(214,179,106,0.28)';
  const rimOn = withAlpha(mixHex(gold, '#FFFFFF', 0.25), 0.9);
  const fill = [mixHex(gold, '#000000', 0.25), gold, mixHex(gold, '#FFFFFF', 0.3)];
  const thumbOff = isLight ? ['#FFFFFF', '#D8D2C4'] : ['#4A4D54', '#2A2D33'];
  const thumbOn = [mixHex(gold, '#FFFFFF', 0.7), mixHex(gold, '#FFFFFF', 0.25)];
  const textOn = readableOn(gold);
  const textOff = isLight ? theme.textMuted : 'rgba(255,255,255,0.38)';

  const x = anim.interpolate({ inputRange: [0, 1], outputRange: [0, travel] });
  const fillOpacity = anim;
  const thumbOnOpacity = anim;

  return (
    <TouchableWithoutFeedback onPress={() => !disabled && onValueChange && onValueChange(!value)} disabled={disabled}>
      <View style={{ width, height: height + 8, alignItems: 'center', justifyContent: 'center', opacity: disabled ? 0.45 : 1 }}>
        <View
          style={{
            width, height, borderRadius: height / 2, overflow: 'hidden', borderWidth: 1.2,
            borderColor: value ? rimOn : rimOff, backgroundColor: trackOff,
          }}
        >
          {/* تعبئة المسار وقت التشغيل */}
          <Animated.View pointerEvents="none" style={{ position: 'absolute', top: 0, bottom: 0, left: 0, right: 0, opacity: fillOpacity }}>
            <LinearGradient colors={fill} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ flex: 1 }} />
          </Animated.View>
          {/* خط لمعة رفيع على الحافة العلوية */}
          <LinearGradient
            pointerEvents="none"
            colors={['rgba(255,255,255,0.22)', 'rgba(255,255,255,0)']}
            start={{ x: 0.5, y: 0 }}
            end={{ x: 0.5, y: 0.6 }}
            style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
          />
          {/* الكلمة في الجهة المقابلة للزرار */}
          <Text
            style={[
              { position: 'absolute', top: '50%', marginTop: -7, lineHeight: 14, fontSize: 10.5, fontWeight: '800', letterSpacing: 1.4, color: value ? textOn : textOff },
              value ? physLeft(thumb * 0.5 + 2) : physRight(thumb * 0.5 + 2),
            ]}
          >
            {value ? 'ON' : 'OFF'}
          </Text>
          {/* الزرار الدائري المعدني */}
          <Animated.View
            style={{
              position: 'absolute', top: pad - 1.2, ...physLeft(pad - 1.2), width: thumb, height: thumb, borderRadius: thumb / 2,
              overflow: 'hidden', borderWidth: 1, borderColor: value ? 'rgba(255,255,255,0.65)' : 'rgba(255,255,255,0.14)',
              alignItems: 'center', justifyContent: 'center',
              transform: [{ translateX: x }],
            }}
          >
            <LinearGradient colors={thumbOff} start={{ x: 0.2, y: 0 }} end={{ x: 0.8, y: 1 }} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
            <Animated.View pointerEvents="none" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, opacity: thumbOnOpacity }}>
              <LinearGradient colors={thumbOn} start={{ x: 0.2, y: 0 }} end={{ x: 0.8, y: 1 }} style={{ flex: 1 }} />
            </Animated.View>
            <MaterialCommunityIcons name="power" size={Math.round(thumb * 0.5)} color={value ? mixHex(gold, '#000000', 0.55) : textOff} />
          </Animated.View>
        </View>
      </View>
    </TouchableWithoutFeedback>
  );
}
