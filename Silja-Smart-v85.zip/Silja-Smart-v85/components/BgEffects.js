// تأثيرات الخلفية الحية: وهج دافي بيتفاعل مع الإضاءة، وطقس (مطر / سحاب / ضباب / نجوم).
// كل الحركات native-driven (opacity/translate) وبتقف مع "حركة أقل" أو لما الشاشة تتخفي.
import React, { useEffect, useMemo, useRef } from 'react';
import { Animated, Dimensions, Easing, StyleSheet, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Glow } from './BgPresets';
import { kindForCode, skyPhase } from '../weatherNow';

const AMBER = '255,184,90';
// ثوابت (مرجع واحد) عشان useLoop مايعيدش تشغيل الحركة مع كل إعادة رسم.
const SIN_IN_OUT = Easing.inOut(Easing.sin);

// وهج دافي لما الإضاءة تشتغل: كل ما عدد الإضاءة الشغالة يزيد الوهج يقوى (لحد 5)، ويتدرّج بنعومة.
export function LightsGlow({ count, dark }) {
  const { width: w, height: h } = Dimensions.get('window');
  const level = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const target = count <= 0 ? 0 : 0.4 + 0.6 * (Math.min(count, 5) / 5);
    Animated.timing(level, { toValue: target, duration: 900, easing: Easing.inOut(Easing.quad), useNativeDriver: true }).start();
  }, [count, level]);
  return (
    <Animated.View pointerEvents="none" style={[StyleSheet.absoluteFillObject, { opacity: level }]}>
      <LinearGradient
        colors={['rgba(255,184,90,0)', `rgba(${AMBER},${dark ? 0.16 : 0.12})`]}
        start={{ x: 0.5, y: 0.35 }}
        end={{ x: 0.5, y: 1 }}
        style={StyleSheet.absoluteFillObject}
      />
      <Glow x={w * 0.88} y={h * 0.06} r={Math.max(w, h) * 0.42} rgb={AMBER} alpha={dark ? 0.12 : 0.10} />
    </Animated.View>
  );
}

function useLoop(value, { from = 0, to = 1, duration, delay = 0, alternate = false, easing = Easing.linear, enabled }) {
  useEffect(() => {
    if (!enabled) { value.setValue(from); return undefined; }
    const step = (a, b) => Animated.timing(value, { toValue: b, duration, easing, useNativeDriver: true });
    const anim = Animated.loop(alternate ? Animated.sequence([step(from, to), step(to, from)]) : Animated.sequence([step(from, to), Animated.timing(value, { toValue: from, duration: 0, useNativeDriver: true })]));
    const t = setTimeout(() => anim.start(), delay);
    return () => { clearTimeout(t); anim.stop(); };
  }, [enabled, value, from, to, duration, delay, alternate, easing]);
}

function Streak({ left, delay, duration, h, enabled, alpha }) {
  const v = useRef(new Animated.Value(0)).current;
  useLoop(v, { duration, delay, enabled });
  return (
    <Animated.View
      style={{
        position: 'absolute', left, top: -50, width: 1.4, height: 34, borderRadius: 1,
        backgroundColor: `rgba(190,212,255,${alpha})`,
        opacity: v.interpolate({ inputRange: [0, 0.1, 0.9, 1], outputRange: [0, 1, 1, 0] }),
        transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [0, h + 90] }) }, { rotate: '10deg' }],
      }}
    />
  );
}

function Cloud({ top, size, alpha, duration, delay, enabled, startX, travel }) {
  const v = useRef(new Animated.Value(0)).current;
  useLoop(v, { duration, delay, enabled, alternate: true, easing: SIN_IN_OUT });
  return (
    <Animated.View
      pointerEvents="none"
      style={{ position: 'absolute', top, left: startX, width: size * 2.4, height: size, transform: [{ translateX: v.interpolate({ inputRange: [0, 1], outputRange: [0, travel] }) }] }}
    >
      {[0, 1, 2, 3].map((i) => {
        const s = size * (0.55 + (i % 2) * 0.25 + (i === 1 ? 0.15 : 0));
        return (
          <View
            key={i}
            style={{ position: 'absolute', left: i * size * 0.5, top: size - s - (i % 2) * size * 0.1, width: s, height: s, borderRadius: s / 2, backgroundColor: `rgba(210,220,235,${alpha})` }}
          />
        );
      })}
    </Animated.View>
  );
}

function Flake({ left, delay, duration, h, size, enabled, alpha }) {
  const v = useRef(new Animated.Value(0)).current;
  useLoop(v, { duration, delay, enabled });
  return (
    <Animated.View
      style={{
        position: 'absolute', left, top: -10, width: size, height: size, borderRadius: size, backgroundColor: `rgba(240,246,255,${alpha})`,
        opacity: v.interpolate({ inputRange: [0, 0.1, 0.9, 1], outputRange: [0, 1, 1, 0] }),
        transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [0, h + 20] }) }, { translateX: v.interpolate({ inputRange: [0, 1], outputRange: [0, 18] }) }],
      }}
    />
  );
}

function Star({ left, top, size, delay, duration, enabled, mult = 1 }) {
  const v = useRef(new Animated.Value(0)).current;
  useLoop(v, { duration, delay, enabled, alternate: true, easing: SIN_IN_OUT });
  return (
    <Animated.View
      style={{ position: 'absolute', left, top, width: size, height: size, borderRadius: size, backgroundColor: 'rgba(255,248,225,0.9)', opacity: enabled ? Animated.multiply(v.interpolate({ inputRange: [0, 1], outputRange: [0.15, 0.85] }), mult) : 0.5 * mult }}
    />
  );
}

// cloudAlpha / starAlpha (0..1) من الإعدادات: السحاب بيتضرب في 3 (عشان يبان فوق الصور)، والنجوم 1 = الشكل الأصلي.
export function WeatherLayer({ weather, motion, dark, cloudAlpha = 1, starAlpha = 1, rainAlpha = 1, bodyAlpha = 1 }) {
  const { width: w, height: h } = Dimensions.get('window');
  const sky = weather ? skyPhase(weather) : null;
  const kind = weather ? kindForCode(weather.code, sky ? sky.isDay : weather.isDay) : 'none';
  const rain = kind === 'rain' || kind === 'heavyRain' || kind === 'storm';
  const rainCount = Math.max(1, Math.round((kind === 'rain' ? 10 : 18) * (0.3 + 0.7 * rainAlpha)));
  const streaks = useMemo(
    () => Array.from({ length: rainCount }).map((_, i) => ({ left: ((i * 53 + 11) % 97) / 97 * w, delay: (i * 137) % 1100, duration: 900 + ((i * 71) % 600) })),
    [rainCount, w]
  );
  const stars = useMemo(
    () => Array.from({ length: 11 }).map((_, i) => ({ left: ((i * 61 + 7) % 93) / 93 * w, top: ((i * 37 + 13) % 55) / 100 * h, size: 1.6 + (i % 3) * 0.7, delay: i * 240, duration: 1500 + (i % 4) * 500 })),
    [w, h]
  );
  const flakes = useMemo(
    () => Array.from({ length: Math.max(1, Math.round(14 * (0.3 + 0.7 * rainAlpha))) }).map((_, i) => ({ left: ((i * 47 + 5) % 97) / 97 * w, delay: (i * 311) % 4500, duration: 6500 + ((i * 417) % 4500), size: 2 + (i % 3) }))
    , [w, rainAlpha]
  );
  if (kind === 'none') return null;
  const cloudy = kind === 'cloud' || kind === 'fog' || kind === 'snow' || rain;
  const cloudA = (kind === 'fog' ? 0.07 : rain ? 0.06 : 0.05) * (dark ? 1 : 0.8) * cloudAlpha * 3;
  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFillObject}>
      {cloudy && cloudAlpha > 0.01 && (
        <>
          <Cloud top={h * 0.06} size={h * 0.11} alpha={cloudA} duration={16000} delay={0} enabled={motion} startX={-w * 0.2} travel={w * 0.35} />
          <Cloud top={h * 0.22} size={h * 0.09} alpha={cloudA * 0.8} duration={21000} delay={1500} enabled={motion} startX={w * 0.35} travel={-w * 0.4} />
          <Cloud top={h * 0.42} size={h * 0.12} alpha={cloudA * 0.7} duration={26000} delay={800} enabled={motion} startX={-w * 0.1} travel={w * 0.3} />
        </>
      )}
      {rain && motion && rainAlpha > 0.01 && streaks.map((s, i) => (
        <Streak key={i} left={s.left} delay={s.delay} duration={s.duration} h={h} enabled alpha={(kind === 'rain' ? 0.16 : 0.24) * rainAlpha} />
      ))}
      {kind === 'snow' && motion && rainAlpha > 0.01 && flakes.map((f, i) => <Flake key={i} {...f} h={h} enabled alpha={0.75} />)}
      {kind === 'clearNight' && starAlpha > 0.01 && stars.map((s, i) => <Star key={i} {...s} enabled={motion} mult={starAlpha} />)}
      {kind === 'clearDay' && <Glow x={w * 0.9} y={h * 0.05} r={Math.max(w, h) * 0.4} rgb="255,214,120" alpha={(dark ? 0.09 : 0.14) * bodyAlpha} />}
    </View>
  );
}
