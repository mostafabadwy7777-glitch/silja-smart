// مشهد طقس واقعي جوه كارت الرئيسية (بدل المربع الصغير): سماء متدرجة حسب الحالة والوقت، شمس أو قمر بهالة،
// سحب واقعية نازلة من فوق الكارت (صور مولّدة بإضاءة وظل وحواف ناعمة)، مطر، نجوم بالليل، وبرق خفيف في العواصف.
// الحركة بطيئة وnative (translate/opacity) وبتقف مع "حركة أقل" أو لما الشاشة تتخفي.
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Animated, Easing, Image, StyleSheet, Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import TouchableOpacity from './AnimatedTouchable';
import { kindForCode, weatherLabel } from '../weatherNow';

const CLOUDS = {
  day: { a: require('../assets/weather/cloud_day_a.png'), b: require('../assets/weather/cloud_day_b.png'), bank: require('../assets/weather/cloud_day_bank.png') },
  night: { a: require('../assets/weather/cloud_night_a.png'), b: require('../assets/weather/cloud_night_b.png'), bank: require('../assets/weather/cloud_night_bank.png') },
  storm: { a: require('../assets/weather/cloud_storm_a.png'), b: require('../assets/weather/cloud_storm_b.png'), bank: require('../assets/weather/cloud_storm_bank.png') },
};
const SUN = require('../assets/weather/sun.png');
const MOON = require('../assets/weather/moon.png');
// أبعاد الصور (عرض / ارتفاع) عشان نحسب الارتفاع من العرض.
const RATIO = { a: 462 / 163, b: 405 / 159, bank: 960 / 300 };

const SIN = Easing.inOut(Easing.sin);

// ألوان السماء (أعلى → أسفل) حسب الحالة. phase ('dawn'|'dusk'|...) من شروق/غروب مدينتك الحقيقي؛ من غيره بنقدّر بالساعة.
function skyColors(kind, isDay, hour, code, phase) {
  const dawn = phase === 'dawn';
  const twi = phase ? phase === 'dusk' || phase === 'dawn' : false;
  const warm = dawn ? ['#41568F', '#D58E94', '#F8CC93'] : ['#34478A', '#B4647A', '#F4B075'];
  if (kind === 'snow') return isDay ? ['#6E7F92', '#92A2B3', '#BCC8D3'] : ['#151B27', '#232D40', '#36445C'];
  if (!isDay) {
    if (kind === 'storm' || kind === 'heavyRain' || kind === 'rain') return ['#0E131C', '#1A222F', '#283243'];
    if (twi && kind !== 'fog') return dawn ? ['#2A3768', '#8A5C86', '#D98C86'] : ['#1B2152', '#5F3B78', '#B9626F'];
    if (kind === 'cloud' || kind === 'fog') return ['#101626', '#1C2540', '#2A3556'];
    return ['#050B22', '#0F1C48', '#1F3166'];
  }
  if (kind === 'storm') return ['#262C36', '#3A4351', '#525E6F'];
  if (kind === 'heavyRain') return ['#34404F', '#4B596B', '#66768A'];
  if (kind === 'rain') return ['#46576B', '#62758B', '#8397AB'];
  if (kind === 'fog') return ['#8A97A5', '#AAB5C0', '#C8D0D8'];
  const dusk = phase ? twi : hour >= 17 && hour < 19;
  if (kind === 'cloud') return code === 3 ? ['#5F7C9A', '#86A0B8', '#AFC2D3'] : dusk ? warm : ['#2F78C2', '#5FA3E0', '#9CC9EE'];
  return dusk ? warm : ['#1F6FC0', '#4F9BE0', '#8EC3EE'];
}

function useDrift(value, amplitudePx, durationMs, delay, enabled) {
  useEffect(() => {
    if (!enabled) { value.setValue(0); return undefined; }
    const a = Animated.loop(Animated.sequence([
      Animated.timing(value, { toValue: 1, duration: durationMs, easing: SIN, useNativeDriver: true }),
      Animated.timing(value, { toValue: 0, duration: durationMs, easing: SIN, useNativeDriver: true }),
    ]));
    const t = setTimeout(() => a.start(), delay);
    return () => { clearTimeout(t); a.stop(); };
  }, [value, durationMs, delay, enabled]);
  return value.interpolate({ inputRange: [0, 1], outputRange: [-amplitudePx, amplitudePx] });
}

function Cloud({ src, ratio, width, top, startX, alpha = 1, mult = 1, amp, duration, delay, motion }) {
  const v = useRef(new Animated.Value(0)).current;
  const tx = useDrift(v, amp, duration, delay, motion);
  return (
    <Animated.Image
      source={src}
      resizeMode="stretch"
      style={{ position: 'absolute', top, left: startX, width, height: width / ratio, opacity: alpha * mult, transform: [{ translateX: tx }] }}
    />
  );
}

function Streak({ left, delay, duration, h, alpha }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const a = Animated.loop(Animated.timing(v, { toValue: 1, duration, easing: Easing.linear, useNativeDriver: true }));
    const t = setTimeout(() => a.start(), delay);
    return () => { clearTimeout(t); a.stop(); };
  }, [v, duration, delay]);
  return (
    <Animated.View
      style={{
        position: 'absolute', left, top: -40, width: 1.3, height: 30, borderRadius: 1, backgroundColor: `rgba(205,222,255,${alpha})`,
        opacity: v.interpolate({ inputRange: [0, 0.08, 0.92, 1], outputRange: [0, 1, 1, 0] }),
        transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [0, h + 80] }) }, { rotate: '9deg' }],
      }}
    />
  );
}

function Star({ left, top, size, delay, duration, motion, mult = 1 }) {
  const v = useRef(new Animated.Value(0)).current;
  const o = useDrift(v, 0.35, duration, delay, motion);
  return <Animated.View style={{ position: 'absolute', left, top, width: size, height: size, borderRadius: size, backgroundColor: '#FFF8E1', opacity: motion ? Animated.multiply(Animated.add(o, 0.55), mult) : 0.6 * mult }} />;
}

// ثلج: ندف بتنزل ببطء وبتميل شوية.
function Flake({ left, delay, duration, h, size, alpha }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    const a = Animated.loop(Animated.timing(v, { toValue: 1, duration, easing: Easing.linear, useNativeDriver: true }));
    const t = setTimeout(() => a.start(), delay);
    return () => { clearTimeout(t); a.stop(); };
  }, [v, duration, delay]);
  return (
    <Animated.View
      style={{
        position: 'absolute', left, top: -8, width: size, height: size, borderRadius: size, backgroundColor: `rgba(244,248,255,${alpha})`,
        opacity: v.interpolate({ inputRange: [0, 0.08, 0.92, 1], outputRange: [0, 1, 1, 0] }),
        transform: [{ translateY: v.interpolate({ inputRange: [0, 1], outputRange: [0, h + 16] }) }, { translateX: v.interpolate({ inputRange: [0, 0.5, 1], outputRange: [0, 9, -3] }) }],
      }}
    />
  );
}

// شهاب نادر: خط رفيع بيعدّي في السماء مرة كل نص دقيقة تقريبًا.
function ShootingStar({ w, h, motion, mult }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!motion) { v.setValue(0); return undefined; }
    const a = Animated.loop(Animated.sequence([
      Animated.delay(14000),
      Animated.timing(v, { toValue: 1, duration: 900, easing: Easing.out(Easing.quad), useNativeDriver: true }),
      Animated.timing(v, { toValue: 0, duration: 0, useNativeDriver: true }),
      Animated.delay(22000),
    ]));
    a.start();
    return () => a.stop();
  }, [motion, v]);
  const dx = -w * 0.35;
  const dy = h * 0.45;
  const ang = (Math.atan2(dy, dx) * 180) / Math.PI;
  return (
    <Animated.View
      pointerEvents="none"
      style={{
        position: 'absolute', left: w * 0.6, top: h * 0.05, width: 46, height: 1.6, borderRadius: 1, backgroundColor: 'rgba(255,248,225,0.95)',
        opacity: v.interpolate({ inputRange: [0, 0.1, 0.8, 1], outputRange: [0, mult, mult * 0.6, 0] }),
        transform: [{ translateX: v.interpolate({ inputRange: [0, 1], outputRange: [0, dx] }) }, { translateY: v.interpolate({ inputRange: [0, 1], outputRange: [0, dy] }) }, { rotate: `${ang}deg` }],
      }}
    />
  );
}

function Flash({ motion, mult = 1 }) {
  const v = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!motion) return undefined;
    const a = Animated.loop(Animated.sequence([
      Animated.delay(5200),
      Animated.timing(v, { toValue: 1, duration: 70, useNativeDriver: true }),
      Animated.timing(v, { toValue: 0.15, duration: 90, useNativeDriver: true }),
      Animated.timing(v, { toValue: 0.8, duration: 60, useNativeDriver: true }),
      Animated.timing(v, { toValue: 0, duration: 380, useNativeDriver: true }),
    ]));
    a.start();
    return () => a.stop();
  }, [motion, v]);
  return <Animated.View pointerEvents="none" style={[StyleSheet.absoluteFillObject, { backgroundColor: 'rgba(230,238,255,0.35)', opacity: Animated.multiply(v, mult) }]} />;
}

// الخلفية نفسها: بتتحط absoluteFill جوه كارت الرئيسية (الكارت overflow hidden).
// cloudAlpha / starAlpha / rainAlpha / bodyAlpha / boltAlpha: وضوح السحاب والنجوم والمطر-الثلج والشمس-القمر وشدة البرق (0..1).
// sky: ناتج skyPhase(weather) (مرحلة السماء من شروق/غروب مدينتك). shootingStars: شهاب نادر بالليل. overlay: فوق صورة خلفية الكارت (من غير سماء ملوّنة).
export function HeroWeatherScene({ weather, motion = true, hour = 12, cloudAlpha = 1, starAlpha = 1, rainAlpha = 1, bodyAlpha = 1, boltAlpha = 1, shootingStars = true, sky = null, overlay = false }) {
  const [size, setSize] = useState({ w: 0, h: 0 });
  const isDay = sky ? sky.isDay : !weather || weather.isDay !== false;
  const kind = weather ? kindForCode(weather.code, isDay) : 'none';
  const { w, h } = size;
  const stars = useMemo(
    () => Array.from({ length: 16 }).map((_, i) => ({ left: ((i * 61 + 7) % 93) / 93 * w, top: ((i * 37 + 11) % 60) / 100 * h, size: 1.4 + (i % 3) * 0.7, delay: i * 210, duration: 1400 + (i % 4) * 450 })),
    [w, h]
  );
  const streaks = useMemo(() => {
    const n = Math.round((kind === 'rain' ? 12 : 22) * (0.3 + 0.7 * rainAlpha));
    return Array.from({ length: n }).map((_, i) => ({ left: ((i * 53 + 9) % 97) / 97 * w, delay: (i * 131) % 1000, duration: 850 + ((i * 67) % 550) }));
  }, [kind, w, rainAlpha]);

  const flakes = useMemo(() => {
    const n = Math.round(26 * (0.3 + 0.7 * rainAlpha));
    return Array.from({ length: n }).map((_, i) => ({ left: ((i * 47 + 13) % 97) / 97 * w, delay: (i * 223) % 4000, duration: 5200 + ((i * 379) % 4200), size: 2 + (i % 3) * 1.2, alpha: 0.7 + (i % 3) * 0.1 }));
  }, [w, rainAlpha]);

  if (kind === 'none') return null;
  const code = weather.code;
  const rainy = kind === 'rain' || kind === 'heavyRain' || kind === 'storm';
  const pal = !isDay ? 'night' : rainy ? 'storm' : 'day';
  const C = CLOUDS[pal];
  const colors = skyColors(kind, isDay, hour, code, sky ? sky.phase : null);
  const partly = code === 1 || code === 2;
  const overcast = kind === 'cloud' && code === 3;
  const snowy = kind === 'snow';

  // مقاسات نسبية لعرض الكارت.
  const bankW = w * 1.35;
  const bank = (extra = {}) => (
    <Cloud src={C.bank} ratio={RATIO.bank} width={bankW} top={-bankW / RATIO.bank * 0.38} startX={-w * 0.17} amp={w * 0.02} duration={30000} delay={0} motion={motion} mult={cloudAlpha} {...extra} />
  );
  const cumulus = (key, which, wf, topf, xf, alpha, amp, dur, delay) => (
    <Cloud key={key} src={C[which]} ratio={RATIO[which]} width={w * wf} top={h * topf} startX={w * xf} alpha={alpha} mult={cloudAlpha} amp={amp * w} duration={dur} delay={delay} motion={motion} />
  );

  return (
    <View pointerEvents="none" style={StyleSheet.absoluteFillObject} onLayout={(e) => setSize({ w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height })}>
      {!overlay && <LinearGradient colors={colors} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={StyleSheet.absoluteFillObject} />}
      {w > 0 && (
        <>
          {/* نجوم الليل الصافي */}
          {!isDay && (kind === 'clearNight' || partly) && starAlpha > 0.01 && stars.map((s, i) => <Star key={i} {...s} motion={motion} mult={starAlpha} />)}
          {!isDay && (kind === 'clearNight' || partly) && shootingStars && starAlpha > 0.05 && <ShootingStar w={w} h={h} motion={motion} mult={starAlpha} />}
          {/* الشمس / القمر (ورا السحاب) */}
          {isDay && (kind === 'clearDay' || partly) && (
            <Image source={SUN} style={{ position: 'absolute', top: -h * 0.62, end: -w * 0.02, width: h * 1.75, height: h * 1.75, opacity: (partly ? 0.92 : 1) * bodyAlpha }} />
          )}
          {!isDay && (kind === 'clearNight' || partly) && (
            <Image source={MOON} style={{ position: 'absolute', top: -h * 0.18, end: w * 0.03, width: h * 1.05, height: h * 1.05, opacity: bodyAlpha }} />
          )}
          {/* ضباب: غشاوة فاتحة */}
          {kind === 'fog' && <LinearGradient colors={['rgba(235,240,245,0.10)', 'rgba(235,240,245,0.38)']} style={StyleSheet.absoluteFillObject} />}

          {/* سحب خلفية بعيدة */}
          {(kind === 'clearDay' || kind === 'clearNight') && cumulus('c1', 'b', 0.42, 0.40, 0.08, isDay ? 0.78 : 0.4, 0.04, 26000, 0)}
          {kind === 'clearDay' && cumulus('c2', 'a', 0.36, 0.52, 0.58, 0.7, 0.05, 32000, 2000)}
          {partly && (
            <>
              {cumulus('p1', 'a', 0.5, 0.18, -0.05, 0.95, 0.05, 24000, 0)}
              {cumulus('p2', 'b', 0.4, 0.46, 0.55, 0.9, 0.04, 28000, 1500)}
            </>
          )}
          {/* غطاء سحاب نازل من فوق */}
          {(overcast || kind === 'fog' || rainy || snowy) && bank({ alpha: kind === 'fog' ? 0.85 : 1 })}
          {(overcast || rainy || snowy) && (
            <>
              {cumulus('o1', 'b', 0.5, 0.12, -0.08, 1, 0.05, 22000, 0)}
              {cumulus('o2', 'a', 0.52, 0.2, 0.52, 0.98, 0.045, 27000, 1200)}
              {kind !== 'rain' && cumulus('o3', 'b', 0.4, 0.34, 0.28, 0.95, 0.04, 31000, 600)}
            </>
          )}
          {kind === 'fog' && (
            <>
              {cumulus('f1', 'a', 0.6, 0.3, -0.1, 0.55, 0.05, 30000, 0)}
              {cumulus('f2', 'b', 0.55, 0.44, 0.5, 0.5, 0.05, 36000, 900)}
            </>
          )}

          {/* مطر */}
          {rainy && motion && rainAlpha > 0.01 && streaks.map((s, i) => <Streak key={i} left={s.left} delay={s.delay} duration={s.duration} h={h} alpha={(kind === 'rain' ? 0.2 : 0.3) * rainAlpha} />)}
          {kind === 'storm' && boltAlpha > 0.01 && <Flash motion={motion} mult={boltAlpha} />}
          {snowy && motion && rainAlpha > 0.01 && flakes.map((f, i) => <Flake key={i} {...f} h={h} />)}

          {/* فوق صورة: تعتيم تلقائي خفيف بيزيد مع وضوح السحاب عشان الكلام الأبيض ما يضيعش */}
          {overlay && cloudAlpha > 0.05 && (
            <LinearGradient pointerEvents="none" colors={[`rgba(0,0,0,${(0.04 + 0.12 * cloudAlpha).toFixed(2)})`, `rgba(0,0,0,${(0.10 + 0.20 * cloudAlpha).toFixed(2)})`]} style={StyleSheet.absoluteFillObject} />
          )}
          {/* تعتيم سفلي خفيف عشان الكلام يبان */}
          <LinearGradient pointerEvents="none" colors={['rgba(0,0,0,0)', isDay ? 'rgba(6,16,30,0.42)' : 'rgba(0,0,0,0.30)']} start={{ x: 0.5, y: 0.35 }} end={{ x: 0.5, y: 1 }} style={StyleSheet.absoluteFillObject} />
        </>
      )}
    </View>
  );
}

export const weatherIconName = (code, isDay) => {
  if (code === 0) return isDay ? 'weather-sunny' : 'weather-night';
  if (code <= 2) return isDay ? 'weather-partly-cloudy' : 'weather-night-partly-cloudy';
  if (code === 3) return 'weather-cloudy';
  if (code === 45 || code === 48) return 'weather-fog';
  if (code >= 51 && code <= 67) return 'weather-rainy';
  if ((code >= 71 && code <= 77) || code === 85 || code === 86) return 'weather-snowy';
  if (code >= 80 && code <= 82) return 'weather-pouring';
  if (code >= 95) return 'weather-lightning-rainy';
  return 'weather-partly-cloudy';
};

// نص الطقس من غير مربع: درجة الحرارة كبيرة + الوصف والمدينة + سطر تفاصيل (الإحساس/الرطوبة/الرياح)،
// بنفس لون نص الكارت وظل خفيف. onPress بيفتح التفاصيل وتوقع الساعات الجاية.
export function HeroWeatherText({ weather, color, mutedColor, shadow, onPress }) {
  if (!weather || weather.temp == null) return null;
  const parts = [];
  if (weather.feels != null && weather.feels !== weather.temp) parts.push(`الإحساس ${weather.feels}°`);
  if (weather.humidity != null) parts.push(`رطوبة ${weather.humidity}%`);
  if (weather.wind != null) parts.push(`رياح ${weather.wind} كم/س`);
  const body = (
    <View style={{ alignItems: 'flex-start', flexShrink: 1, minWidth: 0 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
        <MaterialCommunityIcons name={weatherIconName(weather.code, weather.isDay)} size={30} color={color} style={shadow} />
        <Text style={[{ fontSize: 34, fontWeight: '800', color }, shadow]} numberOfLines={1}>{weather.temp}°</Text>
        {!!onPress && <MaterialCommunityIcons name="chevron-down" size={16} color={mutedColor} style={shadow} />}
      </View>
      <Text style={[{ fontSize: 12, marginTop: 1, color: mutedColor }, shadow]} numberOfLines={1} ellipsizeMode="tail">
        {weatherLabel(weather.code)}{weather.city ? ` • ${weather.city}` : ''}{weather.stale ? ' • آخر قراءة' : ''}
      </Text>
      {parts.length > 0 && (
        <Text style={[{ fontSize: 11, marginTop: 1, color: mutedColor }, shadow]} numberOfLines={1} ellipsizeMode="tail">{parts.join(' • ')}</Text>
      )}
    </View>
  );
  if (!onPress) return body;
  return (
    <TouchableOpacity activeOpacity={0.8} onPress={onPress} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }} style={{ flexShrink: 1, minWidth: 0, alignItems: 'flex-start' }}>
      {body}
    </TouchableOpacity>
  );
}
