// قائمة ترتيب المفاتيح بالسحب: كل صف فيه مقبض (☰) تمسكه وتسحب لفوق/تحت، والصفوف التانية
// بتفسح مكان لحظيًا. وكمان سهمين ▲▼ لكل صف (مفيد مع القوائم الطويلة اللي مش بتتسحب لآخرها).
// الصفوف كلها بنفس الارتفاع فحساب مكان الإفلات بسيط وثابت. بتستخدم PanResponder الجاهز في React Native
// (من غير مكتبات إضافية).
import React, { useRef, useState } from 'react';
import { Animated, PanResponder, View, Text, TouchableOpacity } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { getDeviceIcon } from '../deviceIcons';
import { withAlpha } from '../colorUtils';

const ROW_H = 62;
const GAP = 8;
const STEP = ROW_H + GAP;

function arrayMove(list, from, to) {
  const next = list.slice();
  const [it] = next.splice(from, 1);
  next.splice(to, 0, it);
  return next;
}

function Row({ item, index, count, theme, drag, dy, api }) {
  const idxRef = useRef(index);
  idxRef.current = index;
  const pan = useRef(PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: () => true,
    onPanResponderTerminationRequest: () => false,
    onPanResponderGrant: () => api.current.start(idxRef.current),
    onPanResponderMove: (_, g) => api.current.move(g.dy),
    onPanResponderRelease: () => api.current.end(),
    onPanResponderTerminate: () => api.current.end(),
  })).current;

  const def = getDeviceIcon(item.icon);
  const dragging = !!drag && drag.from === index;
  let shift = 0;
  if (drag && !dragging) {
    if (drag.from < drag.to && index > drag.from && index <= drag.to) shift = -STEP;
    else if (drag.from > drag.to && index >= drag.to && index < drag.from) shift = STEP;
  }
  const accent = theme.accent;
  const dark = !theme.isLight;

  return (
    <Animated.View
      style={{
        height: ROW_H, marginBottom: GAP, flexDirection: 'row', alignItems: 'center', gap: 10,
        paddingHorizontal: 10, borderRadius: 18, borderWidth: 1.2,
        borderColor: dragging ? withAlpha(accent, 0.95) : (dark ? 'rgba(255,255,255,0.14)' : theme.border),
        backgroundColor: dragging ? withAlpha(theme.card, 0.98) : withAlpha(theme.card, dark ? 0.7 : 0.9),
        zIndex: dragging ? 20 : 1,
        elevation: dragging ? 8 : 0,
        shadowColor: '#000', shadowOpacity: dragging ? 0.35 : 0, shadowRadius: 10, shadowOffset: { width: 0, height: 4 },
        transform: dragging ? [{ translateY: dy }, { scale: 1.03 }] : [{ translateY: shift }],
      }}
    >
      {/* مقبض السحب — منطقة لمس واسعة */}
      <View {...pan.panHandlers} style={{ width: 44, height: ROW_H - 8, alignItems: 'center', justifyContent: 'center' }} hitSlop={{ top: 4, bottom: 4, left: 4, right: 4 }}>
        <MaterialCommunityIcons name="drag-horizontal-variant" size={26} color={dragging ? accent : theme.textMuted} />
      </View>
      <View style={{ width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', backgroundColor: withAlpha(accent, 0.14) }}>
        <MaterialCommunityIcons name={def.icon} size={20} color={theme.accentSoft || accent} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ color: theme.textPrimary, fontSize: 14, fontWeight: '800', textAlign: 'right' }} numberOfLines={1}>{item.name || 'مفتاح بدون اسم'}</Text>
        {!!item.room && <Text style={{ color: theme.textMuted, fontSize: 11, textAlign: 'right' }} numberOfLines={1}>{item.room}</Text>}
      </View>
      <View style={{ flexDirection: 'row', gap: 2 }}>
        <TouchableOpacity disabled={index === 0} onPress={() => api.current.step(index, -1)} hitSlop={{ top: 6, bottom: 6, left: 4, right: 4 }} style={{ padding: 6, opacity: index === 0 ? 0.25 : 1 }}>
          <MaterialCommunityIcons name="chevron-up" size={22} color={theme.textSecondary} />
        </TouchableOpacity>
        <TouchableOpacity disabled={index === count - 1} onPress={() => api.current.step(index, 1)} hitSlop={{ top: 6, bottom: 6, left: 4, right: 4 }} style={{ padding: 6, opacity: index === count - 1 ? 0.25 : 1 }}>
          <MaterialCommunityIcons name="chevron-down" size={22} color={theme.textSecondary} />
        </TouchableOpacity>
      </View>
    </Animated.View>
  );
}

// items: مصفوفة المفاتيح بالترتيب الحالي. onChange(newItems) بتتنادى بعد كل تغيير ترتيب.
// onDragging(bool) بتقفل/تفتح تمرير الشاشة أثناء السحب.
export default function ReorderList({ items, theme, onChange, onDragging }) {
  const [drag, setDrag] = useState(null); // { from, to }
  const dy = useRef(new Animated.Value(0)).current;
  const dragRef = useRef(null);
  const api = useRef({});

  api.current = {
    start: (i) => {
      dragRef.current = { from: i, to: i };
      dy.setValue(0);
      setDrag({ from: i, to: i });
      onDragging && onDragging(true);
    },
    move: (d) => {
      const cur = dragRef.current;
      if (!cur) return;
      dy.setValue(d);
      const to = Math.max(0, Math.min(items.length - 1, Math.round(cur.from + d / STEP)));
      if (to !== cur.to) {
        dragRef.current = { from: cur.from, to };
        setDrag({ from: cur.from, to });
      }
    },
    end: () => {
      const cur = dragRef.current;
      dragRef.current = null;
      dy.setValue(0);
      setDrag(null);
      onDragging && onDragging(false);
      if (cur && cur.from !== cur.to) onChange(arrayMove(items, cur.from, cur.to));
    },
    step: (i, dir) => {
      const to = i + dir;
      if (to < 0 || to >= items.length) return;
      onChange(arrayMove(items, i, to));
    },
  };

  return (
    <View>
      {items.map((item, index) => (
        <Row key={item.id} item={item} index={index} count={items.length} theme={theme} drag={drag} dy={dy} api={api} />
      ))}
    </View>
  );
}
