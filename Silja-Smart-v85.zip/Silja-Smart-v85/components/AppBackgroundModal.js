import React, { useState } from 'react';
import { Modal, View, Text, Image, ScrollView, StyleSheet } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import { showAlert } from './PremiumAlert';
import PremiumSwitch from './PremiumSwitch';
import OpacitySlider from './OpacitySlider';
import WeatherFxPreview from './WeatherFxPreview';
import PresetLayers, { BG_PRESETS, isPresetId, presetName } from './BgPresets';
import { useTheme } from '../ThemeContext';
import { FONTS } from '../fonts';

const APP_BG_FILE = FileSystem.documentDirectory + 'app-images/app-bg.jpg';

const SCREEN_ROWS = [
  { key: 'home', label: 'الرئيسية' },
  { key: 'switches', label: 'المفاتيح والأجهزة' },
  { key: 'scenes', label: 'المشاهد والجداول' },
  { key: 'other', label: 'باقي الشاشات' },
];
const BLUR_LEVELS = ['بدون', 'خفيف', 'متوسط', 'قوي'];
// أوضاع جاهزة لشرائط الطقس بدوسة واحدة ("درامي" = كل حاجة 100% = الشكل الافتراضي).
const FX_KEYS = ['cloudAlpha', 'starAlpha', 'rainAlpha', 'bodyAlpha', 'boltAlpha'];
const FX_PRESETS = [
  { id: 'calm', label: 'هادي', v: { cloudAlpha: 0.45, starAlpha: 0.5, rainAlpha: 0.4, bodyAlpha: 0.7, boltAlpha: 0.4 } },
  { id: 'mid', label: 'متوسط', v: { cloudAlpha: 0.75, starAlpha: 0.8, rainAlpha: 0.7, bodyAlpha: 0.9, boltAlpha: 0.7 } },
  { id: 'drama', label: 'درامي', v: { cloudAlpha: 1, starAlpha: 1, rainAlpha: 1, bodyAlpha: 1, boltAlpha: 1 } },
];
const THUMB_W = 96;
const THUMB_H = 128;

// نافذة خلفية التطبيق: خلفيات جاهزة، صورتك مع تمويه وتعتيم، خلفية مختلفة لكل مجموعة شاشات،
// وتأثيرات حية (تتفاعل مع الإضاءة، الطقس، عمق مع ميلان الموبايل).
export default function AppBackgroundModal({ visible, onClose }) {
  const { theme, appBg, appBgDim, setAppBg, setAppBgDim, bgPrefs, setBgPrefs } = useTheme();
  const [busy, setBusy] = useState(false);
  // سحب شريط السحاب/النجوم: قيمة مؤقتة أثناء السحب (من غير كتابة على التخزين)، وتتحفظ عند الإفلات.
  const [fxDraft, setFxDraft] = useState({});
  const [sliding, setSliding] = useState(false);
  const dark = !theme.isLight;

  const persist = async (sourceUri) => {
    await FileSystem.makeDirectoryAsync(FileSystem.documentDirectory + 'app-images/', { intermediates: true }).catch(() => {});
    await FileSystem.deleteAsync(APP_BG_FILE, { idempotent: true }).catch(() => {});
    await FileSystem.copyAsync({ from: sourceUri, to: APP_BG_FILE });
    // باراميتر الوقت بيخلّي الصورة تتحدّث فورًا لو اتغيّرت على نفس المسار
    return `${APP_BG_FILE}?t=${Date.now()}`;
  };

  const handle = async (launcher, permFn, permMsg) => {
    const perm = await permFn();
    if (!perm.granted) {
      showAlert('مفيش صلاحية', permMsg);
      return;
    }
    const result = await launcher();
    if (result.canceled || !result.assets?.[0]?.uri) return;
    setBusy(true);
    try {
      await setAppBg(await persist(result.assets[0].uri));
      await setBgPrefs({ preset: null }); // الصورة الجديدة هي الخلفية العامة
    } catch (e) {
      showAlert('خطأ', 'مقدرناش نحفظ الصورة، جرب تاني');
    } finally {
      setBusy(false);
    }
  };

  const pickFromLibrary = () =>
    handle(
      () => ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, aspect: [9, 19], quality: 0.8 }),
      ImagePicker.requestMediaLibraryPermissionsAsync,
      'لازم تسمح للتطبيق بالدخول على الصور من إعدادات الموبايل الأول'
    );
  const takePhoto = () =>
    handle(
      () => ImagePicker.launchCameraAsync({ allowsEditing: true, aspect: [9, 19], quality: 0.8 }),
      ImagePicker.requestCameraPermissionsAsync,
      'لازم تسمح للتطبيق باستخدام الكاميرا من إعدادات الموبايل الأول'
    );

  const pct = Math.round(appBgDim * 100);
  const step = (d) => setAppBgDim(Math.round((appBgDim + d) * 10) / 10);

  // الخلفية العامة الحالية: خلفية جاهزة > صورة > ثيم عادي.
  const activeGlobal = bgPrefs.preset && isPresetId(bgPrefs.preset) ? bgPrefs.preset : appBg ? 'photo' : 'plain';
  const chooseGlobal = (id) => {
    if (id === 'plain') { setBgPrefs({ preset: null }); setAppBg(null); return; }
    if (id === 'photo') { setBgPrefs({ preset: null }); return; }
    setBgPrefs({ preset: id });
  };

  // اختيارات خلفية كل مجموعة شاشات (بتتبدّل بالدوس).
  const perOptions = ['global', 'plain', ...BG_PRESETS.map((p) => p.id), ...(appBg ? ['photo'] : [])];
  const labelOf = (v) => (v === 'global' ? 'نفس العامة' : v === 'plain' ? 'ثيم عادي' : v === 'photo' ? 'صورتي' : presetName(v) || 'نفس العامة');
  const cyclePer = (key) => {
    const cur = bgPrefs.perScreen[key] || 'global';
    const idx = perOptions.indexOf(cur);
    setBgPrefs({ perScreen: { [key]: perOptions[(idx + 1) % perOptions.length] } });
  };

  const Tile = ({ id, label, children }) => {
    const on = activeGlobal === id;
    return (
      <TouchableOpacity activeOpacity={0.85} onPress={() => chooseGlobal(id)} style={styles.tileWrap}>
        <View style={[styles.tile, { borderColor: on ? theme.accent : theme.border, borderWidth: on ? 2 : 1 }]}>
          {children}
          {on && (
            <View style={[styles.tick, { backgroundColor: theme.accent }]}>
              <MaterialCommunityIcons name="check" size={13} color={theme.isLight ? '#fff' : '#10161C'} />
            </View>
          )}
        </View>
        <Text style={[styles.tileLabel, { color: on ? theme.textPrimary : theme.textSecondary }]} numberOfLines={1}>{label}</Text>
      </TouchableOpacity>
    );
  };

  const Toggle = ({ icon, title, sub, value, onChange }) => (
    <View style={[styles.toggleRow, { borderColor: theme.border, backgroundColor: theme.cardAlt }]}>
      <PremiumSwitch value={value} onValueChange={onChange} theme={theme} size={0.8} />
      <View style={{ flex: 1 }}>
        <Text style={[styles.toggleTitle, { color: theme.textPrimary }]}>{title}</Text>
        <Text style={[styles.toggleSub, { color: theme.textMuted }]}>{sub}</Text>
      </View>
      <MaterialCommunityIcons name={icon} size={22} color={theme.accentSoft} />
    </View>
  );

  // بنادي الدالة دي مباشرة (مش كمكوّن) عشان الشريط ماينعملوش remount وسط السحب.
  const fxVal = (key) => (fxDraft[key] != null ? fxDraft[key] : bgPrefs[key] != null ? bgPrefs[key] : 1);
  const clearDraft = (key) => setFxDraft((d) => { const n = { ...d }; delete n[key]; return n; });
  const fxRow = (key, icon, title) => {
    const val = fxVal(key);
    return (
      <View key={key} style={[styles.toggleRow, { flexDirection: 'column', alignItems: 'stretch', gap: 0, paddingVertical: 8, borderColor: theme.border, backgroundColor: theme.cardAlt }]}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
          <MaterialCommunityIcons name={icon} size={20} color={theme.accentSoft} />
          <Text style={[styles.toggleTitle, { color: theme.textPrimary, flex: 1 }]}>{title}</Text>
          <TouchableOpacity hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }} onPress={() => { clearDraft(key); setBgPrefs({ [key]: 1 }); }}>
            <Text style={{ color: theme.accent, fontSize: 11.5, fontWeight: '700' }}>افتراضي</Text>
          </TouchableOpacity>
          <Text style={{ color: theme.accent, fontSize: 15, fontWeight: '800', minWidth: 46, textAlign: 'center' }}>{Math.round(val * 100)}%</Text>
        </View>
        <OpacitySlider
          theme={theme}
          value={val}
          onChange={(v) => setFxDraft((d) => ({ ...d, [key]: v }))}
          onCommit={(v) => { setBgPrefs({ [key]: v }); clearDraft(key); }}
          onDragState={setSliding}
        />
      </View>
    );
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={[styles.box, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={styles.headerRow}>
            <Text style={[styles.title, { color: theme.textPrimary }]}>خلفية التطبيق</Text>
            <TouchableOpacity onPress={onClose} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <MaterialCommunityIcons name="close" size={20} color={theme.textMuted} />
            </TouchableOpacity>
          </View>

          <ScrollView scrollEnabled={!sliding} showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 6 }}>
            <Text style={[styles.section, { color: theme.textPrimary }]}>خلفيات جاهزة</Text>
            <View style={styles.tiles}>
              <Tile id="plain" label="ثيم عادي">
                {theme.bgGradient
                  ? <LinearGradient colors={theme.bgGradient} start={{ x: 0.15, y: 0 }} end={{ x: 0.85, y: 1 }} style={StyleSheet.absoluteFillObject} />
                  : <View style={[StyleSheet.absoluteFillObject, { backgroundColor: theme.bg }]} />}
              </Tile>
              {BG_PRESETS.map((p) => (
                <Tile key={p.id} id={p.id} label={p.name}>
                  <PresetLayers id={p.id} w={THUMB_W} h={THUMB_H} dark={dark} />
                </Tile>
              ))}
              {!!appBg && (
                <Tile id="photo" label="صورتي">
                  <Image source={{ uri: appBg }} style={StyleSheet.absoluteFillObject} resizeMode="cover" />
                </Tile>
              )}
            </View>

            <Text style={[styles.section, { color: theme.textPrimary }]}>صورتك</Text>
            <View style={styles.actions}>
              <TouchableOpacity style={[styles.btn, { backgroundColor: theme.cardAlt, borderColor: theme.border }]} onPress={pickFromLibrary} disabled={busy}>
                <MaterialCommunityIcons name="image-outline" size={17} color={theme.accentSoft} />
                <Text style={[styles.btnText, { color: theme.textSecondary }]}>صورة</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.btn, { backgroundColor: theme.cardAlt, borderColor: theme.border }]} onPress={takePhoto} disabled={busy}>
                <MaterialCommunityIcons name="camera-outline" size={17} color={theme.accentSoft} />
                <Text style={[styles.btnText, { color: theme.textSecondary }]}>كاميرا</Text>
              </TouchableOpacity>
            </View>

            {!!appBg && (
              <>
                <Text style={[styles.label, { color: theme.textPrimary }]}>درجة التعتيم — {pct}%</Text>
                <View style={styles.dimRow}>
                  <TouchableOpacity style={[styles.stepBtn, { backgroundColor: theme.cardAlt, borderColor: theme.border }]} onPress={() => step(-0.1)}>
                    <MaterialCommunityIcons name="minus" size={18} color={theme.accentSoft} />
                  </TouchableOpacity>
                  <View style={[styles.track, { backgroundColor: theme.cardAlt }]}>
                    <View style={[styles.fill, { width: `${pct}%`, backgroundColor: theme.accentSoft }]} />
                  </View>
                  <TouchableOpacity style={[styles.stepBtn, { backgroundColor: theme.cardAlt, borderColor: theme.border }]} onPress={() => step(0.1)}>
                    <MaterialCommunityIcons name="plus" size={18} color={theme.accentSoft} />
                  </TouchableOpacity>
                </View>

                <Text style={[styles.label, { color: theme.textPrimary }]}>تمويه الصورة (الكروت تبان أوضح)</Text>
                <View style={styles.chips}>
                  {BLUR_LEVELS.map((name, i) => {
                    const on = (bgPrefs.blur || 0) === i;
                    return (
                      <TouchableOpacity key={name} onPress={() => setBgPrefs({ blur: i })} style={[styles.chip, { backgroundColor: on ? theme.accent : theme.cardAlt, borderColor: on ? theme.accent : theme.border }]}>
                        <Text style={{ color: on ? (theme.isLight ? '#fff' : '#10161C') : theme.textSecondary, fontSize: 12.5, fontWeight: '800' }}>{name}</Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>

                <TouchableOpacity style={styles.remove} onPress={() => { setAppBg(null); setBgPrefs({ blur: 0 }); }}>
                  <MaterialCommunityIcons name="trash-can-outline" size={16} color={theme.danger} />
                  <Text style={[styles.removeText, { color: theme.danger }]}>إزالة الصورة</Text>
                </TouchableOpacity>
              </>
            )}

            <Text style={[styles.section, { color: theme.textPrimary }]}>خلفية لكل شاشة</Text>
            <Text style={[styles.hint, { color: theme.textMuted }]}>دوس على الخلفية عشان تبدّل بينها لكل مجموعة شاشات.</Text>
            {SCREEN_ROWS.map((r) => {
              const v = bgPrefs.perScreen[r.key] || 'global';
              return (
                <TouchableOpacity key={r.key} activeOpacity={0.8} onPress={() => cyclePer(r.key)} style={[styles.perRow, { borderColor: theme.border, backgroundColor: theme.cardAlt }]}>
                  <View style={[styles.perPill, { backgroundColor: v === 'global' ? theme.card : theme.accent }]}>
                    <Text style={{ color: v === 'global' ? theme.textSecondary : (theme.isLight ? '#fff' : '#10161C'), fontSize: 12, fontWeight: '800' }}>{labelOf(v)}</Text>
                  </View>
                  <Text style={[styles.perLabel, { color: theme.textPrimary }]}>{r.label}</Text>
                </TouchableOpacity>
              );
            })}

            <Text style={[styles.section, { color: theme.textPrimary }]}>تأثيرات حية</Text>
            <Toggle icon="weather-sunny" title="طقس واقعي في كارت الرئيسية" sub="كارت الرئيسية بيتحول لسماء حقيقية: شمس أو قمر، وسحب نازلة من فوق، ومطر حسب الجو." value={bgPrefs.heroWeather !== false} onChange={(v) => setBgPrefs({ heroWeather: v })} />
            <Toggle icon="lightbulb-on-outline" title="تتفاعل مع الإضاءة" sub="الخلفية بتدفّى بلون الإضاءة لما إضاءة تشتغل، وتقوى كل ما تزيد." value={!!bgPrefs.reactive} onChange={(v) => setBgPrefs({ reactive: v })} />
            <Toggle icon="weather-partly-rainy" title="خلفية بالطقس" sub="مطر خفيف أو سحب أو نجوم حسب الجو في مدينتك (محتاجة نت، وبتقف مع حركة أقل)." value={!!bgPrefs.weather} onChange={(v) => setBgPrefs({ weather: v })} />
            <Text style={[styles.section, { color: theme.textPrimary }]}>ضبط شكل الطقس</Text>
            <View style={{ flexDirection: 'row', gap: 8, marginBottom: 10 }}>
              {FX_PRESETS.map((pr) => {
                const on = FX_KEYS.every((k) => Math.abs(fxVal(k) - pr.v[k]) < 0.015);
                return (
                  <TouchableOpacity key={pr.id} onPress={() => { setFxDraft({}); setBgPrefs(pr.v); }} style={[styles.chip, { borderColor: on ? theme.accent : theme.border, backgroundColor: on ? theme.accent : 'transparent' }]}>
                    <Text style={{ color: on ? (theme.isLight ? '#fff' : '#10161C') : theme.textSecondary, fontSize: 13, fontWeight: '800' }}>{pr.label}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>
            <WeatherFxPreview theme={theme} cloudAlpha={fxVal('cloudAlpha')} starAlpha={fxVal('starAlpha')} rainAlpha={fxVal('rainAlpha')} bodyAlpha={fxVal('bodyAlpha')} boltAlpha={fxVal('boltAlpha')} shootingStars={bgPrefs.shootingStars !== false} />
            {fxRow('cloudAlpha', 'weather-cloudy', 'السحاب')}
            {fxRow('starAlpha', 'star-four-points', 'النجوم')}
            {fxRow('rainAlpha', 'weather-pouring', 'المطر والثلج')}
            {fxRow('bodyAlpha', 'white-balance-sunny', 'الشمس والقمر')}
            {fxRow('boltAlpha', 'weather-lightning', 'شدة البرق')}
            <Toggle icon="creation" title="شهاب نادر بالليل" sub="خط شهاب بيعدّي في سماء الكارت مرة كل نص دقيقة تقريبًا (في الليالي الصافية)." value={bgPrefs.shootingStars !== false} onChange={(v) => setBgPrefs({ shootingStars: v })} />
            <Toggle icon="rotate-3d-variant" title="تأثير العمق" sub="الخلفية بتتحرك شوية مع ميلان الموبايل. بتحتاج حساس الحركة." value={!!bgPrefs.parallax} onChange={(v) => setBgPrefs({ parallax: v })} />
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', padding: 18 },
  box: { borderRadius: 24, borderWidth: 1, padding: 18, maxHeight: '90%' },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  title: { fontSize: 17, fontWeight: '800', fontFamily: FONTS.display },
  section: { fontSize: 14, fontWeight: '800', marginTop: 16, marginBottom: 10, textAlign: 'right' },
  hint: { fontSize: 12, marginTop: -4, marginBottom: 10, textAlign: 'right' },
  tiles: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, justifyContent: 'flex-end' },
  tileWrap: { width: THUMB_W, alignItems: 'center' },
  tile: { width: THUMB_W, height: THUMB_H, borderRadius: 16, overflow: 'hidden' },
  tileLabel: { fontSize: 11.5, fontWeight: '700', marginTop: 5, textAlign: 'center' },
  tick: { position: 'absolute', top: 6, right: 6, width: 20, height: 20, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  actions: { flexDirection: 'row', gap: 10 },
  btn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, borderWidth: 1, borderRadius: 14, paddingVertical: 12 },
  btnText: { fontSize: 13.5, fontWeight: '700' },
  label: { fontSize: 13, fontWeight: '700', marginTop: 16, marginBottom: 8, textAlign: 'right' },
  dimRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  stepBtn: { width: 36, height: 36, borderRadius: 12, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  track: { flex: 1, height: 8, borderRadius: 4, overflow: 'hidden' },
  fill: { height: 8, borderRadius: 4 },
  chips: { flexDirection: 'row', gap: 8 },
  chip: { flex: 1, borderWidth: 1, borderRadius: 12, paddingVertical: 9, alignItems: 'center' },
  remove: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 16 },
  removeText: { fontSize: 13, fontWeight: '700' },
  perRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', borderWidth: 1, borderRadius: 14, paddingVertical: 10, paddingHorizontal: 12, marginBottom: 8 },
  perLabel: { fontSize: 13.5, fontWeight: '800', textAlign: 'right' },
  perPill: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 10 },
  toggleRow: { flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1, borderRadius: 16, padding: 12, marginBottom: 8 },
  toggleTitle: { fontSize: 13.5, fontWeight: '800', textAlign: 'right' },
  toggleSub: { fontSize: 11.5, marginTop: 2, lineHeight: 16, textAlign: 'right' },
});
