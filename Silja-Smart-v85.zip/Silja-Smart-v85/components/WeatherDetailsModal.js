// تفاصيل الطقس: الإحساس والرطوبة والرياح وشروق/غروب مدينتك، وتوقع الـ 12 ساعة الجاية (اضغط على الطقس في الرئيسية).
import React from 'react';
import { Modal, View, Text, ScrollView, StyleSheet } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';
import { FONTS } from '../fonts';
import { weatherLabel } from '../weatherNow';
import { weatherIconName } from './HeroWeatherScene';

const p2 = (n) => String(n).padStart(2, '0');
const fmtMin = (m) => { const h = Math.floor(m / 60); return `${h % 12 || 12}:${p2(m % 60)} ${h < 12 ? 'ص' : 'م'}`; };
const fmtHour = (h) => `${h % 12 || 12} ${h < 12 ? 'ص' : 'م'}`;

export default function WeatherDetailsModal({ visible, onClose, weather }) {
  const { theme } = useTheme();
  if (!weather) return null;
  const hasSun = Number.isFinite(weather.rise) && Number.isFinite(weather.set);
  const dayAt = (h) => (hasSun ? h * 60 + 30 >= weather.rise && h * 60 + 30 < weather.set : h >= 6 && h < 18);
  const hours = Array.isArray(weather.hours) ? weather.hours : [];
  const maxPop = hours.reduce((m, x) => Math.max(m, x.pop || 0), 0);
  const stats = [
    weather.feels != null && { icon: 'thermometer', label: 'الإحساس', value: `${weather.feels}°` },
    weather.humidity != null && { icon: 'water-percent', label: 'الرطوبة', value: `${weather.humidity}%` },
    weather.wind != null && { icon: 'weather-windy', label: 'الرياح', value: `${weather.wind} كم/س` },
    hours.length > 0 && { icon: 'umbrella-outline', label: 'احتمال المطر', value: `${Math.round(maxPop)}%` },
    hasSun && { icon: 'weather-sunset-up', label: 'الشروق', value: fmtMin(weather.rise) },
    hasSun && { icon: 'weather-sunset-down', label: 'الغروب', value: fmtMin(weather.set) },
  ].filter(Boolean);
  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={[styles.box, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={styles.headerRow}>
            <Text style={[styles.title, { color: theme.textPrimary }]}>{`الطقس${weather.city ? ` • ${weather.city}` : ''}`}</Text>
            <TouchableOpacity onPress={onClose} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <MaterialCommunityIcons name="close" size={22} color={theme.textSecondary} />
            </TouchableOpacity>
          </View>
          <ScrollView showsVerticalScrollIndicator={false}>
            <View style={styles.nowRow}>
              <MaterialCommunityIcons name={weatherIconName(weather.code, weather.isDay)} size={44} color={theme.accent} />
              <View>
                <Text style={{ color: theme.textPrimary, fontSize: 36, fontWeight: '800' }}>{weather.temp != null ? `${weather.temp}°` : ''}</Text>
                <Text style={{ color: theme.textSecondary, fontSize: 13 }}>{weatherLabel(weather.code)}</Text>
              </View>
            </View>
            {weather.stale && <Text style={{ color: theme.textMuted, fontSize: 11.5, textAlign: 'right', marginBottom: 8 }}>آخر قراءة محفوظة (مفيش اتصال بالنت دلوقتي).</Text>}

            {hours.length > 0 && (
              <>
                <Text style={[styles.section, { color: theme.textPrimary }]}>الساعات الجاية</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingVertical: 2 }}>
                  {hours.map((x, i) => (
                    <View key={i} style={[styles.hourCard, { borderColor: theme.border, backgroundColor: theme.cardAlt }]}>
                      <Text style={{ color: theme.textSecondary, fontSize: 12, fontWeight: '700' }}>{i === 0 ? 'الآن' : fmtHour(x.h)}</Text>
                      <MaterialCommunityIcons name={weatherIconName(x.code, dayAt(x.h))} size={24} color={theme.accentSoft} style={{ marginVertical: 6 }} />
                      <Text style={{ color: theme.textPrimary, fontSize: 15, fontWeight: '800' }}>{x.temp != null ? `${x.temp}°` : '—'}</Text>
                      <Text style={{ color: x.pop >= 30 ? theme.accent : theme.textMuted, fontSize: 11, marginTop: 3, fontWeight: '700' }}>{x.pop >= 10 ? `${Math.round(x.pop)}%` : ' '}</Text>
                    </View>
                  ))}
                </ScrollView>
              </>
            )}

            {stats.length > 0 && (
              <>
                <Text style={[styles.section, { color: theme.textPrimary }]}>تفاصيل</Text>
                <View style={styles.grid}>
                  {stats.map((st) => (
                    <View key={st.label} style={[styles.stat, { borderColor: theme.border, backgroundColor: theme.cardAlt }]}>
                      <MaterialCommunityIcons name={st.icon} size={20} color={theme.accentSoft} />
                      <Text style={{ color: theme.textPrimary, fontSize: 15, fontWeight: '800', marginTop: 4 }}>{st.value}</Text>
                      <Text style={{ color: theme.textMuted, fontSize: 11.5, marginTop: 1 }}>{st.label}</Text>
                    </View>
                  ))}
                </View>
              </>
            )}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', padding: 18 },
  box: { borderRadius: 24, borderWidth: 1, padding: 18, maxHeight: '85%' },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  title: { fontSize: 17, fontWeight: '800', fontFamily: FONTS.display },
  nowRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 14, marginVertical: 6 },
  section: { fontSize: 14, fontWeight: '800', marginTop: 14, marginBottom: 8, textAlign: 'right' },
  hourCard: { width: 64, alignItems: 'center', borderWidth: 1, borderRadius: 16, paddingVertical: 10 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  stat: { width: '31%', flexGrow: 1, alignItems: 'center', borderWidth: 1, borderRadius: 14, paddingVertical: 10 },
});
