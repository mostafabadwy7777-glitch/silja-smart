// شريط فلاتر زجاجي: كبسولات في سطر واحد قابل للتمرير أفقيًا. الكبسولة المختارة بتتلوّن بلون الثيم
// وبتتوهج حدودها. options = [{ key, label, icon? }]، ومعاها اختياري "extra" (زرار أو مصفوفة أزرار) لتبديلات منفصلة (زي الترتيب).
import React from 'react';
import { ScrollView, View, Text, StyleSheet } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { withAlpha, readableOn } from '../colorUtils';

function Chip({ theme, label, icon, active, onPress }) {
  const dark = !theme.isLight;
  const accent = theme.accent;
  return (
    <TouchableOpacity
      onPress={onPress}
      activeOpacity={0.85}
      style={{
        height: 40, borderRadius: 20, overflow: 'hidden', justifyContent: 'center', paddingHorizontal: 16,
        borderWidth: 1.2, borderColor: active ? withAlpha(accent, 0.95) : (dark ? 'rgba(255,255,255,0.16)' : withAlpha(accent, 0.25)),
        backgroundColor: active ? withAlpha(accent, 0.9) : withAlpha(theme.card, dark ? 0.55 : 0.75),
        shadowColor: accent, shadowOpacity: active ? 0.4 : 0, shadowRadius: 10, shadowOffset: { width: 0, height: 2 }, elevation: active ? 4 : 0,
      }}
    >
      <LinearGradient pointerEvents="none" colors={[`rgba(255,255,255,${active ? 0.35 : dark ? 0.16 : 0.45})`, 'rgba(255,255,255,0)']} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 0.7 }} style={StyleSheet.absoluteFill} />
      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
        {!!icon && <MaterialCommunityIcons name={icon} size={16} color={active ? readableOn(accent) : theme.textSecondary} />}
        <Text style={{ color: active ? readableOn(accent) : theme.textSecondary, fontSize: 13, fontWeight: active ? '800' : '700' }}>{label}</Text>
      </View>
    </TouchableOpacity>
  );
}

export default function GlassChips({ theme, options, value, onChange, extra, style }) {
  return (
    <View style={[{ marginBottom: 14 }, style]}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8, paddingHorizontal: 2, paddingVertical: 4, flexGrow: 1 }}>
        {options.map((o) => <Chip key={o.key} theme={theme} label={o.label} icon={o.icon} active={value === o.key} onPress={() => onChange(o.key)} />)}
        {(Array.isArray(extra) ? extra : extra ? [extra] : []).map((x) => (
          <Chip key={x.label} theme={theme} label={x.label} icon={x.icon} active={!!x.active} onPress={x.onPress} />
        ))}
      </ScrollView>
    </View>
  );
}
