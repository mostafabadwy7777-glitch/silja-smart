// خلفيات جاهزة مرسومة بالكود (تدرجات وطبقات شفافة) — من غير أي صور، فمفيش وزن زيادة على التطبيق.
// كل خلفية بتتكيّف مع الثيم: غامقة في الثيمات الغامقة وبدرجات فاتحة هادية في الثيمات النهارية.
// PresetLayers بيرسم الخلفية بحجم (w × h) فنستخدمه للشاشة كلها وللمعاينات الصغيرة.
import React from 'react';
import { View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export const BG_PRESETS = [
  { id: 'champagne', name: 'شامبين فاخر', icon: 'diamond-stone' },
  { id: 'marble', name: 'رخام أسود', icon: 'texture-box' },
  { id: 'glass', name: 'زجاج أزرق', icon: 'window-closed-variant' },
  { id: 'fabric', name: 'نسيج ذهبي', icon: 'checkerboard' },
];

export const isPresetId = (id) => BG_PRESETS.some((p) => p.id === id);
export const presetName = (id) => (BG_PRESETS.find((p) => p.id === id) || {}).name || '';

// وهج ناعم: دواير متداخلة كل واحدة بشفافية خفيفة (مفيش RadialGradient في المكتبة).
export function Glow({ x, y, r, rgb, alpha, layers = 7 }) {
  return (
    <View pointerEvents="none" style={{ position: 'absolute', left: x - r, top: y - r, width: r * 2, height: r * 2 }}>
      {Array.from({ length: layers }).map((_, i) => {
        const rr = r * (1 - (i / layers) * 0.9);
        return (
          <View
            key={i}
            style={{ position: 'absolute', left: r - rr, top: r - rr, width: rr * 2, height: rr * 2, borderRadius: rr, backgroundColor: `rgba(${rgb},${(alpha / layers).toFixed(4)})` }}
          />
        );
      })}
    </View>
  );
}

// خطوط عروق الرخام: [x%, y%, طول%, زاوية, سمك, شفافية]
const VEINS = [
  [0.10, 0.08, 0.95, 62, 1.2, 0.20], [0.38, 0.02, 0.80, 58, 0.8, 0.12], [0.78, 0.10, 0.70, 66, 1.6, 0.16],
  [0.05, 0.42, 0.85, 54, 0.8, 0.10], [0.55, 0.38, 0.90, 60, 1.0, 0.14], [0.92, 0.50, 0.60, 70, 0.8, 0.10],
  [0.20, 0.72, 0.80, 57, 1.4, 0.16], [0.62, 0.70, 0.75, 63, 0.8, 0.10], [0.45, 0.90, 0.55, 52, 1.0, 0.12],
];

function Champagne({ w, h, dark }) {
  return (
    <>
      <LinearGradient colors={dark ? ['#0B0A09', '#17120D', '#2A1F12'] : ['#FBF6EA', '#F3E7CC', '#E9D6A9']} start={{ x: 0.1, y: 0 }} end={{ x: 0.9, y: 1 }} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
      <Glow x={w * 0.9} y={h * 0.08} r={Math.max(w, h) * 0.55} rgb={dark ? '214,179,106' : '214,170,90'} alpha={dark ? 0.22 : 0.28} />
      <Glow x={w * 0.05} y={h * 0.95} r={Math.max(w, h) * 0.5} rgb={dark ? '176,128,60' : '200,150,70'} alpha={dark ? 0.14 : 0.18} />
      {/* شريط لمعة قطري رفيع */}
      <LinearGradient
        colors={['rgba(255,255,255,0)', dark ? 'rgba(240,215,160,0.07)' : 'rgba(255,255,255,0.35)', 'rgba(255,255,255,0)']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0.35 }}
        style={{ position: 'absolute', top: h * 0.18, left: -w * 0.1, width: w * 1.2, height: h * 0.14, transform: [{ rotate: '-12deg' }] }}
      />
    </>
  );
}

function Marble({ w, h, dark }) {
  const base = dark ? ['#0A0A0B', '#151517', '#0C0C0E'] : ['#F7F7F5', '#EAEAE6', '#F3F3F0'];
  const vein = dark ? '214,190,140' : '110,110,105';
  const white = dark ? '255,255,255' : '90,90,90';
  const len = Math.hypot(w, h);
  return (
    <>
      <LinearGradient colors={base} start={{ x: 0.2, y: 0 }} end={{ x: 0.8, y: 1 }} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
      <Glow x={w * 0.3} y={h * 0.25} r={Math.max(w, h) * 0.5} rgb={white} alpha={dark ? 0.05 : 0.10} />
      {VEINS.map(([x, y, l, a, th, al], i) => (
        <View
          key={i}
          style={{
            position: 'absolute', left: w * x, top: h * y, width: len * l * 0.55, height: Math.max(0.6, th * (w / 400)),
            backgroundColor: `rgba(${i % 3 === 0 ? vein : white},${al})`, transform: [{ rotate: `${a}deg` }],
          }}
        />
      ))}
    </>
  );
}

function GlassBlue({ w, h, dark }) {
  const panes = [
    { l: -0.15, t: 0.06, pw: 0.7, ph: 0.34, r: -14 },
    { l: 0.35, t: 0.36, pw: 0.85, ph: 0.30, r: -14 },
    { l: -0.2, t: 0.66, pw: 0.8, ph: 0.30, r: -14 },
  ];
  return (
    <>
      <LinearGradient colors={dark ? ['#06132A', '#0A2748', '#0D4A5C'] : ['#E6F2FF', '#CFE6FA', '#BEE4EE']} start={{ x: 0.1, y: 0 }} end={{ x: 0.9, y: 1 }} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
      <Glow x={w * 0.85} y={h * 0.15} r={Math.max(w, h) * 0.45} rgb={dark ? '70,170,230' : '90,170,230'} alpha={dark ? 0.20 : 0.25} />
      {panes.map((p, i) => (
        <LinearGradient
          key={i}
          colors={dark ? ['rgba(255,255,255,0.075)', 'rgba(255,255,255,0.012)'] : ['rgba(255,255,255,0.55)', 'rgba(255,255,255,0.10)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{
            position: 'absolute', left: w * p.l, top: h * p.t, width: w * p.pw, height: h * p.ph, borderRadius: Math.max(10, w * 0.06),
            borderWidth: 1, borderColor: dark ? 'rgba(255,255,255,0.10)' : 'rgba(255,255,255,0.7)', transform: [{ rotate: `${p.r}deg` }],
          }}
        />
      ))}
    </>
  );
}

function GoldFabric({ w, h, dark }) {
  const diag = Math.hypot(w, h);
  const gap = Math.max(10, diag / 62);
  const n = Math.ceil(diag / gap);
  const line = dark ? 'rgba(214,179,106,' : 'rgba(150,110,40,';
  return (
    <>
      <LinearGradient colors={dark ? ['#0D0B08', '#17120B', '#0F0C08'] : ['#FAF3E3', '#F1E4C3', '#F7EDD3']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
      {/* نسيج: خطوط قطرية في اتجاهين، الاتجاه التاني أخف */}
      <View pointerEvents="none" style={{ position: 'absolute', left: (w - diag) / 2, top: (h - diag) / 2, width: diag, height: diag, transform: [{ rotate: '45deg' }] }}>
        {Array.from({ length: n }).map((_, i) => (
          <View key={`a${i}`} style={{ position: 'absolute', top: i * gap, left: 0, right: 0, height: 1, backgroundColor: `${line}${dark ? 0.07 : 0.10})` }} />
        ))}
        {Array.from({ length: Math.ceil(n / 2) }).map((_, i) => (
          <View key={`b${i}`} style={{ position: 'absolute', left: i * gap * 2, top: 0, bottom: 0, width: 1, backgroundColor: `${line}${dark ? 0.04 : 0.06})` }} />
        ))}
      </View>
      <Glow x={w * 0.5} y={h * 0.1} r={Math.max(w, h) * 0.5} rgb={dark ? '214,179,106' : '220,180,100'} alpha={dark ? 0.12 : 0.18} />
    </>
  );
}

export default function PresetLayers({ id, w, h, dark }) {
  switch (id) {
    case 'champagne': return <Champagne w={w} h={h} dark={dark} />;
    case 'marble': return <Marble w={w} h={h} dark={dark} />;
    case 'glass': return <GlassBlue w={w} h={h} dark={dark} />;
    case 'fabric': return <GoldFabric w={w} h={h} dark={dark} />;
    default: return null;
  }
}
