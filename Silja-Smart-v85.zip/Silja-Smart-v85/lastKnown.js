// آخر حالة معروفة لكل مفتاح — بتتخزن على الجهاز كل ما توصل رسالة حالة من البورد،
// وبتتعرض (بعلامة "قديمة" + الوقت اللي فات) لما الإنترنت/السيرفر يقطع أو لما التطبيق يتفتح
// وحالة المفتاح لسه ماوصلتش، بدل ما الكروت تفضل فاضية أو تقول "متوقف" من غير ما نكون عارفين.
//
// الحالة الحية (اللي وصلت فعلًا من البورد) بتفضل هي المرجع لما الاتصال شغال؛ دي بس شبكة أمان للعرض.
import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = 'iot_last_known_v1';
const MAX_ENTRIES = 400;
const SAVE_DEBOUNCE_MS = 3000;
const NOTIFY_THROTTLE_MS = 1000;

let known = {}; // { [topic]: { on: boolean, ts: ms } }
let loaded = false;
let loadPromise = null;
let saveTimer = null;
let notifyTimer = null;
const listeners = new Set();

function notifySoon() {
  if (notifyTimer) return;
  notifyTimer = setTimeout(() => {
    notifyTimer = null;
    listeners.forEach((fn) => { try { fn(); } catch (_) {} });
  }, NOTIFY_THROTTLE_MS);
}

function scheduleSave() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    let entries = Object.entries(known);
    if (entries.length > MAX_ENTRIES) {
      entries = entries.sort((a, b) => b[1].ts - a[1].ts).slice(0, MAX_ENTRIES);
      known = Object.fromEntries(entries);
    }
    AsyncStorage.setItem(KEY, JSON.stringify(known)).catch(() => {});
  }, SAVE_DEBOUNCE_MS);
}

export function initLastKnown() {
  if (!loadPromise) {
    loadPromise = AsyncStorage.getItem(KEY)
      .then((raw) => {
        if (!raw) return;
        const parsed = JSON.parse(raw);
        if (parsed && typeof parsed === 'object') {
          // الحالة الحية اللي وصلت قبل ما التحميل يخلص ليها الأولوية.
          known = { ...parsed, ...known };
        }
      })
      .catch(() => {})
      .then(() => { loaded = true; notifySoon(); });
  }
  return loadPromise;
}

function parseOnOff(payload) {
  const raw = String(payload).trim();
  let value = raw.toUpperCase();
  try {
    const data = JSON.parse(raw);
    if (data && typeof data === 'object') value = String(data.state ?? data.status ?? data.value ?? data.on ?? '').toUpperCase();
  } catch (_) {}
  if (value === 'ON' || value === '1' || value === 'TRUE') return true;
  if (value === 'OFF' || value === '0' || value === 'FALSE') return false;
  return null;
}

function statusTopicsFor(boards = []) {
  const set = new Set();
  boards.forEach((b) => {
    if (b.type === 'irrigation') return;
    (b.devices || []).forEach((d) => {
      if (d.controlType === 'updown') return;
      const t = d.statusTopic || d.controlTopic;
      if (t) set.add(t);
    });
  });
  return Array.from(set);
}
export { statusTopicsFor as lastKnownTopicsFor };

// بتتنادى من App.js: بتسجّل كل رسالة حالة ON/OFF بتوصل (والاشتراكات refcounted فمفيش تعارض مع الشاشات).
export function attachLastKnown(client, boards) {
  if (!client) return () => {};
  const topics = statusTopicsFor(boards);
  const set = new Set(topics);
  topics.forEach((t) => { try { client.subscribe(t); } catch (_) {} });
  const handler = (topic, payload) => {
    if (!set.has(topic)) return;
    const on = parseOnOff(payload);
    if (on === null) return;
    const prev = known[topic];
    known[topic] = { on, ts: Date.now() };
    if (!prev || prev.on !== on) { scheduleSave(); notifySoon(); } else scheduleSave();
  };
  client.on('message', handler);
  return () => {
    client.off('message', handler);
    topics.forEach((t) => { try { client.unsubscribe(t); } catch (_) {} });
  };
}

export function getLastKnown(topic) {
  return topic ? known[topic] : undefined;
}

// "قبل 5د" / "قبل 3س" / "قبل يومين" — للعرض جنب علامة "قديمة".
export function formatAge(ts, now = Date.now()) {
  const sec = Math.max(0, Math.round((now - ts) / 1000));
  if (sec < 60) return 'من لحظات';
  const min = Math.floor(sec / 60);
  if (min < 60) return `قبل ${min} د`;
  const h = Math.floor(min / 60);
  if (h < 24) return `قبل ${h} س`;
  const d = Math.floor(h / 24);
  return d === 1 ? 'قبل يوم' : d === 2 ? 'قبل يومين' : `قبل ${d} أيام`;
}

// اشتراك مباشر (من غير هوك) في تغيّر الحالات — بنستخدمه لوهج الخلفية اللي بيتفاعل مع الإضاءة.
export function subscribeLastKnown(fn) {
  initLastKnown();
  listeners.add(fn);
  return () => { listeners.delete(fn); };
}

// هوك: بيرجّع دالة (topic) => { on, ts } | undefined، ويعيد رسم الشاشة لما التخزين يتحمّل أو الحالة تتغيّر.
export function useLastKnown() {
  const [, setTick] = useState(0);
  useEffect(() => {
    initLastKnown();
    const fn = () => setTick((n) => n + 1);
    listeners.add(fn);
    if (loaded) fn();
    return () => { listeners.delete(fn); };
  }, []);
  return getLastKnown;
}
