// الطقس الحالي لخلفية التطبيق وكارت الرئيسية. مخزن مشترك واحد بيجيب من Open-Meteo كل 30 دقيقة
// وبس لما فيه مشترك فعلًا، وبنحتفظ بآخر قراءة محفوظة لو مفيش نت (بتظهر فورًا أول ما التطبيق يفتح).
// القراءة فيها: الحالة والدرجة والإحساس والرطوبة والرياح، شروق/غروب مدينتك الحقيقي، وتوقع 12 ساعة جاية.
import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { DEFAULT_CITY, loadWeatherCity, subscribeWeatherCity } from './weather';

const REFRESH_MS = 30 * 60 * 1000;
let current = null; // { code, isDay, temp, feels, humidity, wind, nowRain, rise, set, utc, hours, next, city, at, stale }
let city = DEFAULT_CITY;
let timer = null;
let unsubCity = null;
const listeners = new Set();

const cacheKey = (c) => `iot_weather_bg_${c.lat.toFixed(2)}_${c.lon.toFixed(2)}`;

const isSnowCode = (code) => (code >= 71 && code <= 77) || code === 85 || code === 86;
export const isRainyCode = (code) => code != null && ((code >= 51 && code <= 67) || (code >= 80 && code <= 82) || code >= 95);

// وصف عربي وأيقونة للحالة (نفس المستخدم في الشارة القديمة).
export function weatherLabel(code) {
  if (code === 0) return 'صافي';
  if (code <= 2) return 'غائم جزئيًا';
  if (code === 3) return 'غائم';
  if (code === 45 || code === 48) return 'ضباب';
  if (code >= 51 && code <= 67) return 'أمطار';
  if (isSnowCode(code)) return 'ثلوج';
  if (code >= 80 && code <= 82) return 'زخات';
  if (code >= 95) return 'عاصفة';
  return 'معتدل';
}

export function kindForCode(code, isDay) {
  if (code == null) return 'none';
  if (code >= 95) return 'storm';
  if ((code >= 80 && code <= 82) || (code >= 61 && code <= 67)) return 'heavyRain';
  if (code >= 51 && code <= 60) return 'rain';
  if (isSnowCode(code)) return 'snow';
  if (code === 45 || code === 48) return 'fog';
  if (code === 3 || code === 2) return 'cloud';
  if (code === 0 || code === 1) return isDay ? 'clearDay' : 'clearNight';
  return 'cloud'; // أي كود مش معروف: سماء غائمة عادية بدل ما المشهد يختفي
}

// مرحلة السماء حسب شروق/غروب مدينتك الحقيقي (بتوقيت المدينة مش توقيت الموبايل).
// phase: 'dawn' | 'day' | 'dusk' | 'night' — الفجر والغروب نافذة 40 دقيقة حوالين الشروق/الغروب. null لو مفيش بيانات.
export function skyPhase(w, nowMs = Date.now()) {
  if (!w || !Number.isFinite(w.rise) || !Number.isFinite(w.set) || !Number.isFinite(w.utc)) return null;
  const m = (((Math.floor(nowMs / 60000) + Math.round(w.utc / 60)) % 1440) + 1440) % 1440;
  const W = 40;
  const isDay = m >= w.rise && m < w.set;
  let phase = isDay ? 'day' : 'night';
  if (m >= w.set - W && m < w.set + W) phase = 'dusk';
  else if (m >= w.rise - W && m < w.rise + W) phase = 'dawn';
  return { phase, isDay };
}

// مطر متوقع؟ بيبص على الساعتين الجايين (احتمال >= threshold أو كود مطر). now:true لو بتمطر دلوقتي.
// القراءة القديمة (من الكاش) مابتتحسبش عشان ماننبّهش على حاجة قديمة.
export function rainSoonInfo(w, threshold = 60) {
  if (!w || w.stale) return null;
  if (w.nowRain) return { now: true };
  const next = Array.isArray(w.next) ? w.next : [];
  for (let i = 0; i < Math.min(2, next.length); i++) {
    const n = next[i];
    if (n && ((Number(n.pop) || 0) >= threshold || isRainyCode(n.code))) return { now: false, hours: i + 1, prob: Math.round(Number(n.pop) || 0) };
  }
  return null;
}

function emit() { listeners.forEach((fn) => { try { fn(current); } catch (_) {} }); }

const STALE_DAY_MS = 3 * 60 * 60 * 1000;
async function loadCached(c) {
  try {
    const raw = await AsyncStorage.getItem(cacheKey(c));
    const cached = raw ? JSON.parse(raw) : null;
    if (cached && Number.isFinite(cached.code) && !current) {
      const age = cached.at ? Date.now() - cached.at : Infinity;
      const sky = skyPhase(cached);
      const h = new Date().getHours();
      const isDay = sky ? sky.isDay : age > STALE_DAY_MS ? h >= 6 && h < 18 : cached.isDay;
      current = { ...cached, isDay, stale: true };
      emit();
    }
  } catch (_) {}
}

const num = (x) => (Number.isFinite(x) ? Math.round(x) : null);
const minOfDay = (iso) => (typeof iso === 'string' && iso.length >= 16 ? parseInt(iso.slice(11, 13), 10) * 60 + parseInt(iso.slice(14, 16), 10) : null);

function parse(d, c) {
  const cu = d.current;
  const hr = d.hourly || {};
  const times = Array.isArray(hr.time) ? hr.time : [];
  const curHour = typeof cu.time === 'string' ? cu.time.slice(0, 13) : '';
  const idx = curHour ? times.findIndex((t) => String(t).slice(0, 13) >= curHour) : -1;
  const hours = [];
  if (idx >= 0) {
    for (let i = idx; i < Math.min(times.length, idx + 12); i++) {
      const code = hr.weather_code ? hr.weather_code[i] : null;
      if (!Number.isFinite(code)) continue;
      hours.push({ h: parseInt(String(times[i]).slice(11, 13), 10), temp: hr.temperature_2m ? num(hr.temperature_2m[i]) : null, code, pop: hr.precipitation_probability ? Number(hr.precipitation_probability[i]) || 0 : 0 });
    }
  }
  const daily = d.daily || {};
  return {
    code: cu.weather_code,
    isDay: cu.is_day === 1,
    temp: num(cu.temperature_2m),
    feels: num(cu.apparent_temperature),
    humidity: num(cu.relative_humidity_2m),
    wind: num(cu.wind_speed_10m),
    nowRain: Number(cu.precipitation) > 0 || isRainyCode(cu.weather_code),
    rise: daily.sunrise ? minOfDay(daily.sunrise[0]) : null,
    set: daily.sunset ? minOfDay(daily.sunset[0]) : null,
    utc: Number.isFinite(d.utc_offset_seconds) ? d.utc_offset_seconds : null,
    hours,
    next: hours.slice(1, 4).map((x) => ({ pop: x.pop, code: x.code })),
    city: c.name || '',
    at: Date.now(),
    stale: false,
  };
}

async function load() {
  const c = city;
  if (!current) loadCached(c);
  try {
    const ctrl = typeof AbortController === 'function' ? new AbortController() : null;
    const to = ctrl ? setTimeout(() => ctrl.abort(), 8000) : null;
    let res;
    try {
      res = await fetch(
        `https://api.open-meteo.com/v1/forecast?latitude=${c.lat}&longitude=${c.lon}`
        + '&current=temperature_2m,apparent_temperature,relative_humidity_2m,wind_speed_10m,precipitation,weather_code,is_day'
        + '&hourly=temperature_2m,weather_code,precipitation_probability&daily=sunrise,sunset&timezone=auto&forecast_days=2',
        ctrl ? { signal: ctrl.signal } : undefined
      );
    } finally { if (to) clearTimeout(to); }
    if (!res.ok) throw new Error('http');
    const d = await res.json();
    if (d && d.current && Number.isFinite(d.current.weather_code)) {
      current = parse(d, c);
      AsyncStorage.setItem(cacheKey(c), JSON.stringify({ ...current, stale: undefined })).catch(() => {});
      emit();
      return;
    }
  } catch (_) {}
  await loadCached(c);
}

function start() {
  if (timer) return;
  loadWeatherCity().then((c) => { city = c || DEFAULT_CITY; load(); }).catch(() => load());
  timer = setInterval(load, REFRESH_MS);
  unsubCity = subscribeWeatherCity((c) => { if (c) { city = c; current = null; emit(); load(); } });
}
function stop() {
  if (timer) clearInterval(timer);
  timer = null;
  if (typeof unsubCity === 'function') unsubCity();
  unsubCity = null;
}

// enabled=false بيرجّع null من غير أي طلب شبكة.
export function useWeatherNow(enabled) {
  const [w, setW] = useState(current);
  useEffect(() => {
    if (!enabled) return undefined;
    listeners.add(setW);
    setW(current);
    start();
    return () => {
      listeners.delete(setW);
      if (listeners.size === 0) stop();
    };
  }, [enabled]);
  return enabled ? w : null;
}
