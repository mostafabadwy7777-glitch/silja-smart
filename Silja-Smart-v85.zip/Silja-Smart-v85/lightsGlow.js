// عدد الإضاءة الشغالة دلوقتي (من آخر حالة معروفة) — الخلفية بتدفّى بلون الإضاءة بقدره.
// App.js بينادي startLightsGlow(boards) ويحدّثها لما البوردات تتغيّر؛ ScreenBackground بيقرا useLightsOn().
import { useEffect, useState } from 'react';
import { getDeviceIcon } from './deviceIcons';
import { getLastKnown, subscribeLastKnown } from './lastKnown';

let count = 0;
const listeners = new Set();

function set(n) {
  if (n === count) return;
  count = n;
  listeners.forEach((fn) => { try { fn(n); } catch (_) {} });
}

export function lightTopicsFor(boards = []) {
  const out = new Set();
  (boards || []).forEach((b) => {
    if (!b || b.type === 'irrigation') return;
    (b.devices || []).forEach((d) => {
      if (!d || d.controlType === 'updown') return;
      if (!getDeviceIcon(d.icon).isLight) return;
      const t = d.statusTopic || d.controlTopic;
      if (t) out.add(t);
    });
  });
  return Array.from(out);
}

export function startLightsGlow(boards) {
  const topics = lightTopicsFor(boards);
  const recompute = () => set(topics.filter((t) => { const k = getLastKnown(t); return !!(k && k.on); }).length);
  recompute();
  return subscribeLastKnown(recompute);
}

export function getLightsOn() { return count; }

export function useLightsOn() {
  const [n, setN] = useState(count);
  useEffect(() => {
    listeners.add(setN);
    setN(count);
    return () => { listeners.delete(setN); };
  }, []);
  return n;
}
