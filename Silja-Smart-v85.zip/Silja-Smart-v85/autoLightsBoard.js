// تخزين جدول "الإضاءة الخارجية التلقائية" جوه البورد نفسه.
//
// الفيرموير بيدعم جدول يومي لكل مفتاح (شغّل HH:MM / اطفي HH:MM) ويحسبه جواه، فبيشتغل حتى لو الموبايل
// والسيرفر مقفولين أو الإنترنت قاطع. المشكلة إن الغروب بيتغير كل يوم حوالي دقيقة، والبورد بيكرر نفس الميعاد.
// فالتطبيق بيحسب غروب/شروق النهارده (مع الفرق اللي اخترته) ويبعته للبورد، ويجدّده:
//   - فورًا لما تغيّر الإعدادات،
//   - مرة كل يوم لما التطبيق يتفتح ومتصل (والسيرفر كمان لو شغال، شوف server/index.js).
// لو مفتحتش التطبيق ولا شغّلت السيرفر لأيام، الميعاد في البورد بيفضل على آخر قيمة (فرق دقيقة تقريبًا في اليوم).
//
// قيد: جدول البورد يومي (كل يوم) بس، فلو اخترت أيام محددة الجدولة في البورد بتتعطّل وبيفضل الجدول عن طريق
// التطبيق/السيرفر. وبيستبدل أي جدول/مؤقت كان مضبوط على نفس المفتاح من المؤقت العادي.
import { useEffect, useRef } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { scheduleTargetMinutes, deviceLocalOf, formatMinutes } from './sceneScheduleCore';
import { showToast } from './components/Toast';

export const AUTO_ON_ID = 'auto-outdoor-on';
export const AUTO_OFF_ID = 'auto-outdoor-off';
const STATE_KEY = 'silja_autolights_board_v1';

function findPair(scenes) {
  const on = (scenes || []).find((s) => s && s.id === AUTO_ON_ID);
  const off = (scenes || []).find((s) => s && s.id === AUTO_OFF_ID);
  return on && off ? { on, off } : null;
}

const everyDay = (schedule) => {
  const d = schedule && Array.isArray(schedule.days) ? schedule.days : [];
  return d.length === 0 || d.length === 7;
};

// أوقات النهارده (HH:MM) للتشغيل والإطفاء، أو null لو مقدرناش نحسب (مفيش موقع طقس مثلًا).
export function computeBoardTimes(onScene, offScene, city, nowMs = Date.now()) {
  const day = deviceLocalOf(nowMs);
  const on = scheduleTargetMinutes(onScene.schedule, day, city, deviceLocalOf);
  const off = scheduleTargetMinutes(offScene.schedule, day, city, deviceLocalOf);
  if (on == null || off == null) return null;
  return { on: formatMinutes(on), off: formatMinutes(off) };
}

const topicsOf = (scene) => Array.from(new Set((scene.actions || []).map((a) => a && a.controlTopic).filter(Boolean)));

function sendTimer(client, topic, payload) {
  try { client.publish(`${topic}/timer/set`, JSON.stringify(payload), { qos: 1 }); } catch (_) {}
}

async function loadState() {
  try { return JSON.parse((await AsyncStorage.getItem(STATE_KEY)) || 'null') || { date: '', sig: '', topics: [] }; } catch (_) { return { date: '', sig: '', topics: [] }; }
}
function saveState(state) {
  return AsyncStorage.setItem(STATE_KEY, JSON.stringify(state)).catch(() => {});
}

// بيبعت (أو يعطّل) الجدول في البورد حسب الإعدادات. بيرجّع { sent, reason? }.
export async function syncAutoLightsToBoards({ client, scenes, city, silent = true }) {
  if (!client || !client.connected) return { sent: false, reason: 'offline' };
  const pair = findPair(scenes);
  const state = await loadState();
  const wanted = !!(pair && pair.on.boardSync && pair.on.schedule && pair.on.schedule.enabled && everyDay(pair.on.schedule) && everyDay(pair.off.schedule));

  if (!wanted) {
    // اتقفل أو اتشال: نعطّل الجدول اللي إحنا بعتناه قبل كده بس، ومنلمسش جداول المستخدم التانية.
    if (state.topics.length) {
      state.topics.forEach((t) => sendTimer(client, t, { mode: 'schedule', enabled: false, on: '00:00', off: '00:00' }));
      await saveState({ date: '', sig: '', topics: [] });
      if (!silent) showToast('اتلغى جدول البورد');
      return { sent: true, reason: 'disabled' };
    }
    return { sent: false, reason: 'not-wanted' };
  }

  const times = computeBoardTimes(pair.on, pair.off, city);
  if (!times) return { sent: false, reason: 'no-city' };
  const topics = topicsOf(pair.on);
  const day = deviceLocalOf(Date.now());
  const today = `${day.y}-${day.m}-${day.d}`;
  const sig = JSON.stringify({ times, topics });
  if (state.date === today && state.sig === sig) return { sent: false, reason: 'up-to-date' };

  // مفاتيح اتشالت من الاختيار: نعطّل جدولها.
  state.topics.filter((t) => !topics.includes(t)).forEach((t) => sendTimer(client, t, { mode: 'schedule', enabled: false, on: '00:00', off: '00:00' }));
  topics.forEach((t) => sendTimer(client, t, { mode: 'schedule', enabled: true, on: times.on, off: times.off }));
  const changed = state.sig !== sig;
  await saveState({ date: today, sig, topics });
  if (!silent && changed) showToast(`اتبعت الجدول للبورد: ${times.on} ← ${times.off}`);
  return { sent: true, times };
}

// بيشغّل المزامنة: لما الاتصال يرجع، ولما الإعدادات/الموقع يتغيروا (مع رسالة تأكيد)، وكل ساعة عشان
// لو التطبيق فضل مفتوح عدّى منتصف الليل (التاريخ اتغيّر) يجدّد.
export function useAutoLightsBoardSync({ client, connected, scenes, city }) {
  const sceneSig = JSON.stringify(
    (scenes || []).filter((s) => s && (s.id === AUTO_ON_ID || s.id === AUTO_OFF_ID)).map((s) => [s.id, s.boardSync, s.schedule, (s.actions || []).map((a) => a.controlTopic)])
  );
  const ref = useRef({});
  ref.current = { client, scenes, city };
  const firstRef = useRef(true);

  useEffect(() => {
    if (!connected || !client) return undefined;
    const silent = firstRef.current; // أول مرة بعد الاتصال: من غير رسالة
    firstRef.current = false;
    syncAutoLightsToBoards({ client, scenes: ref.current.scenes, city: ref.current.city, silent }).catch(() => {});
    return undefined;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connected, client, sceneSig, city && city.lat, city && city.lon]);

  useEffect(() => {
    if (!connected || !client) return undefined;
    const id = setInterval(() => {
      const r = ref.current;
      syncAutoLightsToBoards({ client: r.client, scenes: r.scenes, city: r.city, silent: true }).catch(() => {});
    }, 60 * 60 * 1000);
    return () => clearInterval(id);
  }, [connected, client]);
}
