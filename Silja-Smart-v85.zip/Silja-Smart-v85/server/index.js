// سيرفر إشعارات Silja Smart — شغّله على أي جهاز شغال طول الوقت (VPS / Raspberry Pi / PC).
// بيعمل 4 حاجات:
//  1) بيقرأ توكنات الموبايلات اللي التطبيق بينشرها على silja/app/push_tokens/<installId> (Retained).
//  2) بيقرأ رسائل الاكتشاف +/discovery عشان يعرف أسماء المفاتيح وتوبيكات حالتها.
//  3) لما حالة مفتاح تتغيّر، أو بورد يقطع/يرجع، بيبعت إشعار لكل الموبايلات عن طريق Expo Push.
//  4) بينفّذ جدولة المشاهد (وقت محدد / شروق / غروب) حتى والتطبيق مقفول: التطبيق بينشر الجداول
//     Retained على silja/app/scene_schedule والسيرفر بيبعت أوامر المشهد في ميعادها، وبينشر حالته على
//     silja/app/scheduler/status (online/offline) عشان التطبيق ما ينفّذش نفس المشهد مرتين.
//
// التشغيل:
//   cd server && npm install
//   MQTT_URL=mqtt://broker.example.com:1883 MQTT_USER=user MQTT_PASS=pass node index.js
// متغيرات اختيارية: NOTIFY_SWITCHES=0 (يوقف إشعارات التشغيل/الإيقاف)، NOTIFY_BOARDS=0 (يوقف إشعارات قطع البورد)،
//   SCHEDULER=0 (يوقف تنفيذ جدولة المشاهد)، SCHEDULE_TZ=Africa/Cairo (منطقة زمنية ثابتة بدل اللي التطبيق بيبعتها).
const mqtt = require('mqtt');
const { dueKey, makeZonedLocalOf, presencePlan, scheduleTargetMinutes, formatMinutes } = require('./sceneScheduleCore');
const { Expo } = require('expo-server-sdk');

const MQTT_URL = process.env.MQTT_URL;
if (!MQTT_URL) {
  console.error('لازم تحدد MQTT_URL، مثال: MQTT_URL=mqtt://host:1883');
  process.exit(1);
}
const NOTIFY_SWITCHES = process.env.NOTIFY_SWITCHES !== '0';
const NOTIFY_BOARDS = process.env.NOTIFY_BOARDS !== '0';
const SCHEDULER = process.env.SCHEDULER !== '0';
const SCHEDULER_STATUS_TOPIC = 'silja/app/scheduler/status';
const SCHEDULE_CONFIG_TOPIC = 'silja/app/scene_schedule';
const PRESENCE_CONFIG_TOPIC = 'silja/app/presence_sim';
const SCHEDULER_TICK_MS = 15000;

const expo = new Expo();
const tokens = new Map();      // installId -> expo push token
const statusTopics = new Map(); // status topic -> { name, board }
const lastState = new Map();   // status topic -> true/false
const boardNames = new Map();  // availability topic -> board name
const lastAvail = new Map();   // availability topic -> online/offline
const startedAt = Date.now();
const seenOutage = new Map();  // outage topic -> آخر start اتبعت عنه إشعار (لمنع التكرار)
const OUTAGE_TZ = process.env.SCHEDULE_TZ || 'Africa/Cairo';
const fmtClock = (ms) => new Intl.DateTimeFormat('ar-EG-u-nu-latn', { hour: 'numeric', minute: '2-digit', hour12: true, timeZone: OUTAGE_TZ }).format(ms);
const fmtDate = (ms) => new Intl.DateTimeFormat('ar-EG-u-nu-latn', { weekday: 'long', day: 'numeric', month: 'numeric', year: 'numeric', timeZone: OUTAGE_TZ }).format(ms);
function fmtDur(sec) {
  const d = Math.floor(sec / 86400), h = Math.floor((sec % 86400) / 3600), m = Math.floor((sec % 3600) / 60), s = sec % 60;
  const p = [];
  if (d) p.push(`${d} يوم`);
  if (h) p.push(`${h} ساعة`);
  if (m && !d) p.push(`${m} دقيقة`);
  if (s && !d && !h) p.push(`${s} ثانية`);
  return p.length ? p.join(' و') : '0 ثانية';
}
const WARMUP_MS = 8000;        // نتجاهل رسائل Retained القديمة أول ما نتصل

let scheduleConfig = { scenes: [], city: null, tz: null };
let presenceConfig = null; // محاكاة التواجد (retained على silja/app/presence_sim)
const presenceRan = new Set(); // مفاتيح أحداث المحاكاة اللي اتنفذت (لمنع التكرار)
let boardSyncKey = '';         // آخر جدول إضاءة خارجية اتبعت للبورد (تاريخ + أوقات)
const scheduleRan = new Map(); // sceneId -> آخر مفتاح تنفيذ (لمنع التكرار)

const client = mqtt.connect(MQTT_URL, {
  username: process.env.MQTT_USER || undefined,
  password: process.env.MQTT_PASS || undefined,
  clientId: `silja-push-${Math.random().toString(16).slice(2, 8)}`,
  reconnectPeriod: 3000,
  // لو السيرفر وقع فجأة، البروكر بيعلن إنه offline والتطبيق يرجع ينفّذ الجداول بنفسه.
  will: SCHEDULER ? { topic: SCHEDULER_STATUS_TOPIC, payload: 'offline', qos: 1, retain: true } : undefined,
});

client.on('connect', () => {
  console.log('متصل بالبروكر');
  client.subscribe(['silja/app/push_tokens/+', '+/discovery', '+/availability', '+/outage']);
  statusTopics.forEach((_, t) => client.subscribe(t));
  if (SCHEDULER) {
    client.subscribe(SCHEDULE_CONFIG_TOPIC);
    client.subscribe(PRESENCE_CONFIG_TOPIC);
    client.publish(SCHEDULER_STATUS_TOPIC, 'online', { qos: 1, retain: true });
  }
});
client.on('error', (e) => console.error('MQTT error:', e.message));

async function broadcast(title, body) {
  const messages = [...tokens.values()]
    .filter((t) => Expo.isExpoPushToken(t))
    .map((to) => ({ to, title, body, sound: 'default', channelId: 'silja-default', priority: 'high' }));
  for (const chunk of expo.chunkPushNotifications(messages)) {
    try {
      const receipts = await expo.sendPushNotificationsAsync(chunk);
      receipts.forEach((r, i) => {
        if (r.status === 'error') {
          console.error('فشل إرسال إشعار:', r.message);
          if (r.details && r.details.error === 'DeviceNotRegistered') {
            for (const [id, tk] of tokens) if (tk === chunk[i].to) tokens.delete(id);
          }
        }
      });
    } catch (e) {
      console.error('Expo push error:', e.message);
    }
  }
}

function parseState(raw) {
  const v = raw.trim().toUpperCase();
  if (['ON', '1', 'TRUE'].includes(v)) return true;
  if (['OFF', '0', 'FALSE'].includes(v)) return false;
  try {
    const d = JSON.parse(raw);
    const c = d.state ?? d.status ?? d.value ?? d.on;
    if (typeof c === 'boolean') return c;
    const s = String(c ?? '').trim().toUpperCase();
    if (['ON', '1', 'TRUE'].includes(s)) return true;
    if (['OFF', '0', 'FALSE'].includes(s)) return false;
  } catch (_) {}
  return null;
}

// ---------- تنفيذ جدولة المشاهد ----------
function resolveZone() {
  const wanted = process.env.SCHEDULE_TZ || scheduleConfig.tz;
  if (wanted) {
    try { return makeZonedLocalOf(wanted); } catch (_) { console.error('منطقة زمنية غير صالحة:', wanted); }
  }
  return makeZonedLocalOf(Intl.DateTimeFormat().resolvedOptions().timeZone);
}

function schedulerTick() {
  if (!client.connected || !scheduleConfig.scenes.length) return;
  const localOf = resolveZone();
  const now = localOf(Date.now());
  scheduleConfig.scenes.forEach((scene) => {
    const key = dueKey(scene.schedule, now, scheduleConfig.city, localOf);
    if (!key || scheduleRan.get(scene.id) === key) return;
    scheduleRan.set(scene.id, key);
    const actions = (scene.actions || []).filter((a) => a && a.controlTopic && a.value);
    console.log(`تشغيل مجدول: «${scene.name}» (${actions.length} أمر)`);
    actions.forEach((a) => client.publish(a.controlTopic, String(a.value), { qos: 1 }));
  });
}
if (SCHEDULER) setInterval(schedulerTick, SCHEDULER_TICK_MS);

// ---------- جدول الإضاءة الخارجية جوه البورد ----------
// الفيرموير بينفّذ جدول يومي ثابت (HH:MM)، والغروب بيتغير كل يوم، فالسيرفر بيحسب أوقات النهارده ويبعتها
// للبورد على <control_topic>/timer/set مرة كل يوم (وأول ما يشتغل)، فالميعاد يفضل مظبوط حتى لو التطبيق مقفول.
// بيشتغل بس لو المستخدم فعّل "تخزين الجدول في البورد" في التطبيق وكان الجدول كل يوم.
function boardSyncTick() {
  if (!client.connected) return;
  const onS = scheduleConfig.scenes.find((s) => s.id === 'auto-outdoor-on');
  const offS = scheduleConfig.scenes.find((s) => s.id === 'auto-outdoor-off');
  if (!onS || !offS || !onS.boardSync || !onS.schedule || !onS.schedule.enabled) return;
  const everyDay = (sch) => !Array.isArray(sch.days) || sch.days.length === 0 || sch.days.length === 7;
  if (!everyDay(onS.schedule) || !everyDay(offS.schedule)) return;
  const localOf = resolveZone();
  const now = localOf(Date.now());
  const on = scheduleTargetMinutes(onS.schedule, now, scheduleConfig.city, localOf);
  const off = scheduleTargetMinutes(offS.schedule, now, scheduleConfig.city, localOf);
  if (on == null || off == null) return;
  const topics = Array.from(new Set((onS.actions || []).map((a) => a && a.controlTopic).filter(Boolean)));
  const key = `${now.y}-${now.m}-${now.d}|${on}|${off}|${topics.join(',')}`;
  if (key === boardSyncKey) return;
  boardSyncKey = key;
  console.log(`جدول الإضاءة الخارجية للبورد: ${formatMinutes(on)} ← ${formatMinutes(off)} (${topics.length} مفتاح)`);
  topics.forEach((t) => client.publish(`${t}/timer/set`, JSON.stringify({ mode: 'schedule', enabled: true, on: formatMinutes(on), off: formatMinutes(off) }), { qos: 1 }));
}
if (SCHEDULER) setInterval(boardSyncTick, 60000);

// ---------- محاكاة التواجد ----------
function presenceTick() {
  if (!client.connected || !presenceConfig || !presenceConfig.enabled) return;
  let localOf;
  const wanted = process.env.SCHEDULE_TZ || presenceConfig.tz || scheduleConfig.tz;
  try { localOf = makeZonedLocalOf(wanted || Intl.DateTimeFormat().resolvedOptions().timeZone); } catch (_) { localOf = resolveZone(); }
  const now = localOf(Date.now());
  const city = presenceConfig.city || scheduleConfig.city;
  presencePlan(presenceConfig, now, city, localOf).forEach((ev) => {
    const diff = now.minutes - ev.minute;
    if (diff < 0 || diff > 1 || presenceRan.has(ev.key)) return;
    if (presenceRan.size > 500) presenceRan.clear();
    presenceRan.add(ev.key);
    console.log(`محاكاة تواجد: ${ev.value} ${ev.topic}`);
    client.publish(ev.topic, ev.value, { qos: 1 });
  });
}
if (SCHEDULER) setInterval(presenceTick, SCHEDULER_TICK_MS);

client.on('message', (topic, payload) => {
  const raw = payload.toString();

  if (topic === PRESENCE_CONFIG_TOPIC) {
    try {
      const cfg = raw ? JSON.parse(raw) : null;
      presenceConfig = cfg && typeof cfg === 'object' ? cfg : null;
      console.log(`محاكاة التواجد: ${presenceConfig && presenceConfig.enabled ? 'مفعّلة' : 'متوقفة'}`);
    } catch (_) {
      console.error('إعدادات محاكاة تواجد غير صالحة');
    }
    return;
  }

  if (topic === SCHEDULE_CONFIG_TOPIC) {
    try {
      const cfg = JSON.parse(raw);
      scheduleConfig = {
        scenes: Array.isArray(cfg.scenes) ? cfg.scenes : [],
        city: cfg.city || null,
        tz: typeof cfg.tz === 'string' ? cfg.tz : null,
      };
      console.log(`جداول المشاهد: ${scheduleConfig.scenes.length} مشهد`);
    } catch (_) {
      console.error('جدول مشاهد غير صالح');
    }
    return;
  }

  if (topic.startsWith('silja/app/push_tokens/')) {
    const id = topic.split('/').pop();
    if (!raw) { tokens.delete(id); return; }
    try {
      const { token } = JSON.parse(raw);
      if (token) tokens.set(id, token);
      console.log(`توكن مسجّل (${tokens.size} جهاز)`);
    } catch (_) {}
    return;
  }

  if (topic.endsWith('/discovery')) {
    try {
      const d = JSON.parse(raw);
      const boardName = d.name || d.device_id || topic;
      if (d.device_id) boardNames.set(`${d.device_id}/availability`, boardName);
      if (d.prefix) boardNames.set(`${d.prefix}/availability`, boardName);
      (d.switches || []).forEach((sw) => {
        const t = sw.status_topic || sw.state_topic || sw.control_topic || sw.topic;
        if (!t || sw.control_type === 'updown') return;
        const isNew = !statusTopics.has(t);
        statusTopics.set(t, { name: sw.name || 'مفتاح', board: boardName });
        if (isNew && client.connected) client.subscribe(t);
      });
    } catch (_) {}
    return;
  }

  if (topic.endsWith('/outage')) {
    // الفيرموير بيحسب قطع الكهربا وينشره Retained: {start,end,dur} (epoch ثواني)
    try {
      const d = JSON.parse(raw);
      const start = Number(d.start), end = Number(d.end);
      if (!Number.isFinite(start) || !Number.isFinite(end) || end < start) return;
      if (seenOutage.get(topic) === start) return;
      seenOutage.set(topic, start);
      // أول رسالة بعد تشغيل السيرفر = مجرد Retained قديمة، منبعتش عنها إشعار
      if (!NOTIFY_BOARDS || Date.now() - startedAt < WARMUP_MS) return;
      const name = boardNames.get(`${topic.replace('/outage', '')}/availability`) || topic.replace('/outage', '');
      const a = start * 1000, b = end * 1000;
      const when = fmtDate(a) === fmtDate(b)
        ? `من ${fmtClock(a)} إلى ${fmtClock(b)} — ${fmtDate(a)}`
        : `من ${fmtClock(a)} (${fmtDate(a)}) إلى ${fmtClock(b)} (${fmtDate(b)})`;
      broadcast('⚡ الكهربا كانت قاطعة', `${name}: ${fmtDur(end - start)}\n${when}`);
    } catch (_) {}
    return;
  }

  if (topic.endsWith('/availability')) {
    const v = raw.trim().toLowerCase();
    if (v !== 'online' && v !== 'offline') return;
    const prev = lastAvail.get(topic);
    lastAvail.set(topic, v);
    if (!NOTIFY_BOARDS || prev === undefined || prev === v) return;
    if (Date.now() - startedAt < WARMUP_MS) return;
    const name = boardNames.get(topic) || topic.replace('/availability', '');
    broadcast(v === 'offline' ? '⚠️ البورد مقطوع' : '✅ البورد رجع', name);
    return;
  }

  const info = statusTopics.get(topic);
  if (!info) return;
  const state = parseState(raw);
  if (state === null) return;
  const prev = lastState.get(topic);
  lastState.set(topic, state);
  if (!NOTIFY_SWITCHES || prev === undefined || prev === state) return; // أول قراءة = مجرد معرفة الحالة الحالية
  if (Date.now() - startedAt < WARMUP_MS) return;
  broadcast(info.name, `${state ? 'اتشغّل' : 'اتقفل'} — ${info.board}`);
});
