// ميلان الموبايل لتأثير العمق (Parallax). مصدر واحد مشترك (Accelerometer) بيشتغل بس وفيه مشترك فعلًا،
// والقيم بتتنعّم (low-pass) وتتقيّد بين -1 و 1. لو مكتبة expo-sensors مش متاحة بنرجّع قيم ثابتة (صفر) من غير ما نكسر حاجة.
import { useEffect, useRef } from 'react';
import { Animated } from 'react-native';

const x = new Animated.Value(0);
const y = new Animated.Value(0);
let subs = 0;
let sensorSub = null;
let fx = 0;
let fy = 0;

function startSensor() {
  if (sensorSub) return;
  try {
    // eslint-disable-next-line global-require
    const { Accelerometer } = require('expo-sensors');
    Accelerometer.setUpdateInterval(60);
    sensorSub = Accelerometer.addListener(({ x: ax, y: ay }) => {
      // ax: ميل يمين/شمال، ay: ميل لقدام/ورا (الجهاز ماسكه عمودي ≈ 0 على x و -1 على y)
      const tx = Math.max(-1, Math.min(1, ax * 2.2));
      const ty = Math.max(-1, Math.min(1, (ay + 0.7) * 2.2));
      fx += (tx - fx) * 0.18;
      fy += (ty - fy) * 0.18;
      x.setValue(fx);
      y.setValue(fy);
    });
  } catch (_) {
    sensorSub = null;
  }
}
function stopSensor() {
  if (sensorSub && typeof sensorSub.remove === 'function') sensorSub.remove();
  sensorSub = null;
  fx = 0; fy = 0;
  x.setValue(0); y.setValue(0);
}

// بيرجّع { x, y } Animated.Value (-1..1). enabled=false = من غير حساسات.
export function useTilt(enabled) {
  const ref = useRef({ x, y });
  useEffect(() => {
    if (!enabled) return undefined;
    subs += 1;
    if (subs === 1) startSensor();
    return () => {
      subs -= 1;
      if (subs <= 0) { subs = 0; stopSensor(); }
    };
  }, [enabled]);
  return ref.current;
}
