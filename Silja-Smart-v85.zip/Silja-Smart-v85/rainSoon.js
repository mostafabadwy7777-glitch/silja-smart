// ربط توقع المطر بالتطبيق: بيقرا الساعتين الجايين من الطقس المشترك (weatherNow) وبيقارنهم بحد «حماية المطر»
// المحفوظ في شاشة الري. useRainSoon() لبانر الرئيسية، و useRainSoonAlert() لتنبيه + إشعار محلي (مرة كل 3 ساعات).
import { useEffect, useMemo, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useWeatherNow, rainSoonInfo } from './weatherNow';
import { loadRainGuard, DEFAULT_RAIN_GUARD } from './storage';
import { notifyLocal } from './notifications';

const LAST_KEY = 'silja:rainSoonLastAlert';
const COOLDOWN_MS = 3 * 60 * 60 * 1000;

// { now:true } | { now:false, hours, prob } | null (null كمان لو الحماية متقفلة)
export function useRainSoon() {
  const weather = useWeatherNow(true);
  const [guard, setGuard] = useState(DEFAULT_RAIN_GUARD);
  useEffect(() => { loadRainGuard().then(setGuard).catch(() => {}); }, [weather]);
  return useMemo(() => (guard && guard.enabled ? rainSoonInfo(weather, Number(guard.threshold) || 60) : null), [weather, guard]);
}

export function useRainSoonAlert({ settings, onAlert }) {
  const info = useRainSoon();
  const onAlertRef = useRef(onAlert);
  onAlertRef.current = onAlert;
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const key = info ? (info.now ? 'now' : `s${info.hours}`) : null;
  useEffect(() => {
    if (!info || !settingsRef.current || !settingsRef.current.rainSoon) return undefined;
    let cancelled = false;
    (async () => {
      try {
        const raw = await AsyncStorage.getItem(LAST_KEY);
        if (Date.now() - (raw ? Number(raw) : 0) < COOLDOWN_MS) return;
        if (cancelled) return;
        await AsyncStorage.setItem(LAST_KEY, String(Date.now()));
        const title = info.now ? 'بتمطر دلوقتي 🌧' : `مطر متوقع ${info.hours === 1 ? 'خلال ساعة' : 'خلال ساعتين'} 🌧`;
        const body = info.now ? 'لو الري شغال ممكن تقفله من الرئيسية.' : `احتمال المطر حوالي ${info.prob}%. ممكن توقف الري قبل ما تمطر.`;
        const ts = Date.now();
        onAlertRef.current({ id: `${ts}-rain`, ts, kind: 'rain', title, body, read: false });
        if (settingsRef.current.phoneNotify) notifyLocal(title, body);
      } catch (_) {}
    })();
    return () => { cancelled = true; };
  }, [key]); // eslint-disable-line react-hooks/exhaustive-deps
}
