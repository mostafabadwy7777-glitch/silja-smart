// جدولة المشاهد (تشغيل مشهد تلقائيًا في وقت وأيام معينة، أو مع الشروق/الغروب).
//
// إزاي بتشتغل:
// 1) التطبيق بينشر الجداول المفعّلة (Retained) على silja/app/scene_schedule.
//    لو سيرفر Silja (مجلد server/) شغال، هو اللي بينفّذ الجداول حتى والتطبيق مقفول،
//    وبينشر حالته على silja/app/scheduler/status (online/offline).
// 2) لو السيرفر مش شغال، التطبيق بينفّذ الجداول بنفسه — بس وهو مفتوح ومتصل.
//    ولما السيرفر يبقى online التطبيق بيبطّل ينفّذ عشان ماينفّذش المشهد مرتين.
import { useEffect, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { runScene } from './scenes';
import { showToast } from './components/Toast';
import { dueKey, deviceLocalOf, presencePlan } from './sceneScheduleCore';
import { PRESENCE_CONFIG_TOPIC, buildPresenceConfig } from './presenceSim';

export const SCHEDULER_STATUS_TOPIC = 'silja/app/scheduler/status';
export const SCHEDULE_CONFIG_TOPIC = 'silja/app/scene_schedule';
const LAST_RUN_KEY = 'silja_scene_lastrun_v1';
const TICK_MS = 15000;
const PUBLISH_DEBOUNCE_MS = 1500;

function deviceTimeZone() {
  try { return Intl.DateTimeFormat().resolvedOptions().timeZone || null; } catch (_) { return null; }
}

// الجداول المفعّلة بس، بالحد الأدنى من البيانات اللي السيرفر محتاجها للتنفيذ.
export function buildScheduleConfig(scenes, city) {
  const list = (scenes || [])
    .filter((s) => s && s.schedule && s.schedule.enabled && Array.isArray(s.actions) && s.actions.length > 0)
    .map((s) => ({
      id: s.id,
      name: s.name,
      boardSync: !!s.boardSync,
      actions: s.actions
        .filter((a) => a && a.controlTopic && a.value)
        .map((a) => ({ controlTopic: a.controlTopic, value: a.value })),
      schedule: {
        enabled: true,
        mode: s.schedule.mode || 'time',
        time: s.schedule.time,
        offsetMin: Number(s.schedule.offsetMin) || 0,
        days: Array.isArray(s.schedule.days) ? s.schedule.days : [],
      },
    }));
  return {
    v: 1,
    tz: deviceTimeZone(),
    city: city && Number.isFinite(city.lat) && Number.isFinite(city.lon) ? { name: city.name, lat: city.lat, lon: city.lon } : null,
    scenes: list,
  };
}

// بيرجّع { serverOnline } — true لو سيرفر الجدولة شغال دلوقتي.
export function useSceneScheduler({ client, connected, scenes, city, presence }) {
  const [serverOnline, setServerOnline] = useState(false);
  const scenesRef = useRef(scenes);
  const cityRef = useRef(city);
  const serverOnlineRef = useRef(false);
  const lastRunRef = useRef(null); // { [sceneId]: key } — بيتحمّل من التخزين أول مرة
  const lastPublishedRef = useRef('');
  scenesRef.current = scenes;
  cityRef.current = city;
  const presenceRef = useRef(presence);
  presenceRef.current = presence;
  const presenceRanRef = useRef(new Set());
  const lastPresencePublishedRef = useRef('');

  // متابعة حالة سيرفر الجدولة.
  useEffect(() => {
    if (!client || !connected) { serverOnlineRef.current = false; setServerOnline(false); return undefined; }
    const handler = (topic, payload) => {
      if (topic !== SCHEDULER_STATUS_TOPIC) return;
      const on = String(payload).trim().toLowerCase() === 'online';
      serverOnlineRef.current = on;
      setServerOnline(on);
    };
    client.on('message', handler);
    client.subscribe(SCHEDULER_STATUS_TOPIC);
    return () => { client.off('message', handler); client.unsubscribe(SCHEDULER_STATUS_TOPIC); };
  }, [client, connected]);

  // نشر الجداول للسيرفر (Retained) كل ما تتغير، أو أول ما نتصل.
  const configJson = JSON.stringify(buildScheduleConfig(scenes, city));
  useEffect(() => {
    if (!client || !connected) { lastPublishedRef.current = ''; return undefined; }
    if (lastPublishedRef.current === configJson) return undefined;
    const id = setTimeout(() => {
      try {
        client.publish(SCHEDULE_CONFIG_TOPIC, configJson, { qos: 1, retain: true }, (error) => {
          if (!error) lastPublishedRef.current = configJson;
        });
      } catch (_) {}
    }, PUBLISH_DEBOUNCE_MS);
    return () => clearTimeout(id);
  }, [client, connected, configJson]);

  // نشر إعدادات محاكاة التواجد (Retained) كل ما تتغير.
  const presenceJson = JSON.stringify(buildPresenceConfig(presence, city));
  useEffect(() => {
    if (!client || !connected) { lastPresencePublishedRef.current = ''; return undefined; }
    if (lastPresencePublishedRef.current === presenceJson) return undefined;
    const id = setTimeout(() => {
      try {
        client.publish(PRESENCE_CONFIG_TOPIC, presenceJson, { qos: 1, retain: true }, (error) => {
          if (!error) lastPresencePublishedRef.current = presenceJson;
        });
      } catch (_) {}
    }, PUBLISH_DEBOUNCE_MS);
    return () => clearTimeout(id);
  }, [client, connected, presenceJson]);

  // التنفيذ من التطبيق (بس لو السيرفر مش شغال).
  useEffect(() => {
    if (!client || !connected) return undefined;
    let cancelled = false;
    const loadLastRun = async () => {
      if (lastRunRef.current) return;
      try {
        const raw = await AsyncStorage.getItem(LAST_RUN_KEY);
        lastRunRef.current = raw ? JSON.parse(raw) || {} : {};
      } catch (_) { lastRunRef.current = {}; }
    };
    const tick = async () => {
      if (serverOnlineRef.current) return;
      await loadLastRun();
      if (cancelled) return;
      const now = deviceLocalOf(Date.now());
      for (const scene of scenesRef.current || []) {
        const key = dueKey(scene.schedule, now, cityRef.current, deviceLocalOf);
        if (!key || lastRunRef.current[scene.id] === key) continue;
        lastRunRef.current[scene.id] = key;
        AsyncStorage.setItem(LAST_RUN_KEY, JSON.stringify(lastRunRef.current)).catch(() => {});
        // eslint-disable-next-line no-await-in-loop
        const res = await runScene(scene, client);
        if (res.ok) showToast(`تم تشغيل «${scene.name}» تلقائيًا`);
        else showToast(`تعذر تشغيل «${scene.name}» تلقائيًا`);
      }
      // محاكاة التواجد: نفس الخطة اللي السيرفر بيولّدها.
      const pcfg = presenceRef.current;
      if (pcfg && pcfg.enabled) {
        const ran = presenceRanRef.current;
        presencePlan(pcfg, now, cityRef.current, deviceLocalOf).forEach((ev) => {
          const diff = now.minutes - ev.minute;
          if (diff < 0 || diff > 1 || ran.has(ev.key)) return;
          if (ran.size > 500) ran.clear();
          ran.add(ev.key);
          try { client.publish(ev.topic, ev.value, { qos: 1 }); } catch (_) {}
        });
      }
    };
    tick();
    const id = setInterval(tick, TICK_MS);
    return () => { cancelled = true; clearInterval(id); };
  }, [client, connected]);

  return { serverOnline };
}
