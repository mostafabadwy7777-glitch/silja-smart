// إضاءة خارجية تلقائية: تشغيل مجموعة مفاتيح (حديقة / واجهة / مدخل...) عند الغروب، وإطفاؤها عند الشروق أو
// في ساعة محددة، مع فرق بالدقايق وأيام محددة. بنبنيها فوق نظام جدولة المشاهد الموجود: الشاشة بتولّد مشهدين
// ثابتين (id: auto-outdoor-on / auto-outdoor-off) بجدولة غروب/شروق، فالتنفيذ بيحصل من سيرفر Silja (حتى والتطبيق
// مقفول) أو من التطبيق نفسه لو السيرفر مش شغال — من غير أي منطق تنفيذ جديد.
import React, { useMemo, useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, TextInput, StyleSheet } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FONTS } from '../fonts';
import { useTheme } from '../ThemeContext';
import ConnectionStatusBanner from '../components/ConnectionStatusBanner';
import ScreenBackground from '../components/ScreenBackground';
import ScreenHeader from '../components/ScreenHeader';
import PremiumSwitch from '../components/PremiumSwitch';
import { flattenSwitchDevices } from '../scenes';
import { getDeviceIcon } from '../deviceIcons';
import { readableOn } from '../colorUtils';
import { sunEventMs, deviceLocalOf, formatMinutes } from '../sceneScheduleCore';
import { gc, gb } from '../glassTokens';

import { AUTO_ON_ID, AUTO_OFF_ID } from '../autoLightsBoard';

const WEEK_DAYS = [
  { v: 6, label: 'سبت' }, { v: 0, label: 'أحد' }, { v: 1, label: 'اثنين' }, { v: 2, label: 'ثلاثاء' },
  { v: 3, label: 'أربعاء' }, { v: 4, label: 'خميس' }, { v: 5, label: 'جمعة' },
];
const toLatin = (s) => String(s || '').replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
const clampOff = (n) => Math.max(-300, Math.min(300, Number.isFinite(n) ? n : 0));

function normalizeTime(str) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(toLatin(str).trim());
  if (!m) return null;
  const h = Number(m[1]);
  const mi = Number(m[2]);
  if (h > 23 || mi > 59) return null;
  return `${String(h).padStart(2, '0')}:${String(mi).padStart(2, '0')}`;
}

const DEFAULT_CFG = { enabled: false, onBoard: true, targets: [], onOffset: 0, offMode: 'time', offTime: '00:30', offOffset: 0, days: [] };

// قراءة الإعدادات من المشهدين المحفوظين (لو موجودين).
function readCfg(scenes) {
  const on = (scenes || []).find((s) => s.id === AUTO_ON_ID);
  const off = (scenes || []).find((s) => s.id === AUTO_OFF_ID);
  if (!on && !off) return DEFAULT_CFG;
  const topics = new Set();
  [on, off].forEach((s) => (s && s.actions ? s.actions : []).forEach((a) => a && a.controlTopic && topics.add(a.controlTopic)));
  const so = (on && on.schedule) || {};
  const sf = (off && off.schedule) || {};
  return {
    enabled: !!(so.enabled || sf.enabled),
    onBoard: on ? !!on.boardSync : true,
    targets: [...topics],
    onOffset: Number(so.offsetMin) || 0,
    offMode: sf.mode === 'sunrise' ? 'sunrise' : 'time',
    offTime: normalizeTime(sf.time) || DEFAULT_CFG.offTime,
    offOffset: Number(sf.offsetMin) || 0,
    days: Array.isArray(so.days) ? so.days : [],
  };
}

// بناء المشهدين من الإعدادات. لو مفيش مفاتيح مختارة بنشيل المشهدين خالص.
export function buildAutoScenes(cfg, devices) {
  if (!cfg.targets.length) return [];
  const info = (topic) => devices.find((d) => d.controlTopic === topic) || {};
  const actions = (value) =>
    cfg.targets.map((topic) => {
      const d = info(topic);
      return { controlTopic: topic, boardName: d.boardName, name: d.name, icon: d.icon, controlType: d.controlType || 'toggle', value };
    });
  const enabled = !!cfg.enabled;
  return [
    {
      id: AUTO_ON_ID, name: 'إضاءة خارجية — تشغيل', kind: 'home', icon: 'weather-sunset-down', auto: 'outdoor', boardSync: !!cfg.onBoard,
      actions: actions('ON'),
      schedule: { enabled, mode: 'sunset', time: '18:00', offsetMin: cfg.onOffset, days: cfg.days },
    },
    {
      id: AUTO_OFF_ID, name: 'إضاءة خارجية — إطفاء', kind: 'home', icon: 'weather-sunset-up', auto: 'outdoor', boardSync: !!cfg.onBoard,
      actions: actions('OFF'),
      schedule: { enabled, mode: cfg.offMode, time: cfg.offTime, offsetMin: cfg.offMode === 'sunrise' ? cfg.offOffset : 0, days: cfg.days },
    },
  ];
}

export default function AutoLightsScreen({ boards, scenes, onSaveScenes, connected, weatherCity, schedulerServerOnline = false, onBack }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);
  const devices = useMemo(() => flattenSwitchDevices(boards).filter((d) => d.controlTopic && d.controlType !== 'updown'), [boards]);
  const lights = devices.filter((d) => getDeviceIcon(d.icon).isLight);

  const [cfg, setCfg] = useState(() => readCfg(scenes));
  const [onOffText, setOnOffText] = useState(() => String(readCfg(scenes).onOffset));
  const [offOffText, setOffOffText] = useState(() => String(readCfg(scenes).offOffset));
  const [offTimeText, setOffTimeText] = useState(() => readCfg(scenes).offTime);

  // أي تغيير بيتحفظ فورًا: بنشيل المشهدين القدام ونحط الجداد مكانهم.
  const commit = (patch) => {
    const next = { ...cfg, ...patch };
    setCfg(next);
    const rest = (scenes || []).filter((s) => s.id !== AUTO_ON_ID && s.id !== AUTO_OFF_ID);
    onSaveScenes([...rest, ...buildAutoScenes(next, devices)]);
  };

  const toggleTarget = (topic) =>
    commit({ targets: cfg.targets.includes(topic) ? cfg.targets.filter((t) => t !== topic) : [...cfg.targets, topic] });
  const allLightsOn = lights.length > 0 && lights.every((d) => cfg.targets.includes(d.controlTopic));
  const toggleLights = () => {
    const topics = lights.map((d) => d.controlTopic);
    commit({ targets: allLightsOn ? cfg.targets.filter((t) => !topics.includes(t)) : Array.from(new Set([...cfg.targets, ...topics])) });
  };
  const toggleDay = (v) => commit({ days: cfg.days.includes(v) ? cfg.days.filter((x) => x !== v) : [...cfg.days, v] });
  const parseOffset = (text, setText, key) => {
    const clean = toLatin(text).replace(/[^0-9-]/g, '').replace(/(?!^)-/g, '').slice(0, 4);
    setText(clean);
    const n = parseInt(clean, 10);
    commit({ [key]: clampOff(n) });
  };

  const sunAt = (rising, offsetMin) => {
    if (!weatherCity || !Number.isFinite(weatherCity.lat) || !Number.isFinite(weatherCity.lon)) return null;
    const now = deviceLocalOf(Date.now());
    const ms = sunEventMs(now.y, now.m, now.d, weatherCity.lat, weatherCity.lon, rising);
    if (ms == null) return null;
    return formatMinutes(deviceLocalOf(ms + (Number(offsetMin) || 0) * 60000).minutes);
  };
  const onTime = sunAt(false, cfg.onOffset);
  const offTimePreview = cfg.offMode === 'sunrise' ? sunAt(true, cfg.offOffset) : cfg.offTime;
  const allDays = cfg.days.length === 0 || cfg.days.length === 7;
  const ready = cfg.targets.length > 0;

  const offsetHelp = (base) => `فرق بالدقايق عن ${base} (موجب = بعد، سالب = قبل، 0 = بالظبط)`;

  return (
    <SafeAreaView style={styles.safe}>
      <ScreenBackground theme={theme} screen="autoLights" />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        <ScreenHeader title="إضاءة خارجية تلقائية" onBack={onBack} />

        <ConnectionStatusBanner
          theme={theme}
          connected={!!connected}
          title={schedulerServerOnline ? 'السيرفر بينفّذ الجدول' : 'الجدول بيتنفذ من التطبيق'}
          detail={
            !connected
              ? 'مفيش اتصال — الإعدادات محفوظة وهتتنشر لما الاتصال يرجع.'
              : schedulerServerOnline
                ? 'هتشتغل حتى والتطبيق مقفول.'
                : 'سيرفر الجدولة مش شغال، فلازم التطبيق يفضل مفتوح ومتصل وقت التنفيذ.'
          }
        />

        <View style={styles.card}>
          <View style={styles.rowBetween}>
            <PremiumSwitch value={cfg.enabled && ready} onValueChange={(v) => commit({ enabled: v })} theme={theme} size={0.9} disabled={!ready} />
            <View style={{ flex: 1 }}>
              <Text style={styles.title}>تفعيل التشغيل التلقائي</Text>
              <Text style={styles.sub}>
                {ready ? 'الإضاءة تشتغل مع الغروب وتطفي في الميعاد اللي تحدده، كل يوم من نفسها.' : 'اختار المفاتيح الأول من تحت، وبعدين فعّل.'}
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.card}>
          <View style={styles.rowBetween}>
            <PremiumSwitch value={cfg.onBoard} onValueChange={(v) => commit({ onBoard: v })} theme={theme} size={0.9} />
            <View style={{ flex: 1 }}>
              <Text style={styles.title}>تخزين الجدول في البورد</Text>
              <Text style={styles.sub}>
                {cfg.onBoard
                  ? (allDays
                    ? 'التطبيق بيبعت للبورد ميعاد التشغيل والإطفاء، والبورد بينفّذه بنفسه حتى لو الموبايل والسيرفر مقفولين أو النت قاطع. بيتجدد كل يوم لما التطبيق يتفتح أو السيرفر يشتغل (الغروب بيتأخر حوالي دقيقة كل يوم).'
                    : 'جدول البورد يومي بس، ومع أيام محددة بيتعطّل. الجدول بيتنفذ من التطبيق/السيرفر بدله.')
                  : 'متوقف: الجدول بيتنفذ من سيرفر Silja أو من التطبيق وهو مفتوح.'}
              </Text>
              {cfg.onBoard && allDays && <Text style={[styles.sub, { color: theme.textSecondary }]}>تنبيه: بيستبدل أي جدول أو مؤقت مضبوط على نفس المفاتيح.</Text>}
            </View>
          </View>
        </View>

        <Text style={styles.sectionLabel}>المفاتيح</Text>
        <View style={styles.card}>
          {devices.length === 0 ? (
            <Text style={styles.sub}>مفيش مفاتيح مضافة لسه.</Text>
          ) : (
            <>
              {lights.length > 0 && (
                <TouchableOpacity style={[styles.chip, styles.lightsChip, allLightsOn && styles.chipOn]} onPress={toggleLights}>
                  <MaterialCommunityIcons name="lightbulb-group-outline" size={16} color={allLightsOn ? readableOn(theme.accent) : theme.accentSoft} />
                  <Text style={[styles.chipText, allLightsOn && styles.chipTextOn]}>كل الإضاءة ({lights.length})</Text>
                </TouchableOpacity>
              )}
              <View style={styles.chipsRow}>
                {devices.map((d) => {
                  const on = cfg.targets.includes(d.controlTopic);
                  return (
                    <TouchableOpacity key={`${d.boardId}-${d.controlTopic}`} style={[styles.chip, on && styles.chipOn]} onPress={() => toggleTarget(d.controlTopic)}>
                      <Text style={[styles.chipText, on && styles.chipTextOn]} numberOfLines={1}>{d.name || 'مفتاح'}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
            </>
          )}
        </View>

        <Text style={styles.sectionLabel}>التشغيل (الغروب)</Text>
        <View style={styles.card}>
          <Text style={styles.fieldLabel}>{offsetHelp('الغروب')}</Text>
          <TextInput
            value={onOffText}
            onChangeText={(t) => parseOffset(t, setOnOffText, 'onOffset')}
            placeholder="0"
            placeholderTextColor={theme.textMuted}
            keyboardType="numbers-and-punctuation"
            maxLength={4}
            style={styles.bigInput}
          />
          <Text style={[styles.sub, { color: onTime ? theme.accentSoft : theme.danger }]}>
            {onTime ? `النهارده حوالين الساعة ${onTime} (حسب موقع الطقس: ${weatherCity?.name || ''})` : 'مقدرش أحسب الغروب — راجع موقع الطقس.'}
          </Text>
        </View>

        <Text style={styles.sectionLabel}>الإطفاء</Text>
        <View style={styles.card}>
          <View style={styles.chipsRow}>
            {[['time', 'ساعة محددة'], ['sunrise', 'الشروق']].map(([v, label]) => (
              <TouchableOpacity key={v} style={[styles.chip, cfg.offMode === v && styles.chipOn]} onPress={() => commit({ offMode: v })}>
                <Text style={[styles.chipText, cfg.offMode === v && styles.chipTextOn]}>{label}</Text>
              </TouchableOpacity>
            ))}
          </View>
          {cfg.offMode === 'time' ? (
            <>
              <Text style={styles.fieldLabel}>الساعة (24 ساعة)، مثلًا 00:30 يعني بعد منتصف الليل</Text>
              <TextInput
                value={offTimeText}
                onChangeText={(t) => {
                  const v = toLatin(t).replace(/[^0-9:]/g, '').slice(0, 5);
                  setOffTimeText(v);
                  const ok = normalizeTime(v);
                  if (ok) commit({ offTime: ok });
                }}
                onBlur={() => setOffTimeText(cfg.offTime)}
                placeholder="00:30"
                placeholderTextColor={theme.textMuted}
                keyboardType="numbers-and-punctuation"
                maxLength={5}
                style={styles.bigInput}
              />
            </>
          ) : (
            <>
              <Text style={styles.fieldLabel}>{offsetHelp('الشروق')}</Text>
              <TextInput
                value={offOffText}
                onChangeText={(t) => parseOffset(t, setOffOffText, 'offOffset')}
                placeholder="0"
                placeholderTextColor={theme.textMuted}
                keyboardType="numbers-and-punctuation"
                maxLength={4}
                style={styles.bigInput}
              />
              <Text style={[styles.sub, { color: offTimePreview ? theme.accentSoft : theme.danger }]}>
                {offTimePreview ? `النهارده حوالين الساعة ${offTimePreview}` : 'مقدرش أحسب الشروق — راجع موقع الطقس.'}
              </Text>
            </>
          )}
        </View>

        <Text style={styles.sectionLabel}>الأيام {allDays ? '(كل يوم)' : ''}</Text>
        <View style={styles.card}>
          <View style={styles.daysRow}>
            {WEEK_DAYS.map((d) => {
              const active = cfg.days.includes(d.v);
              return (
                <TouchableOpacity key={d.v} onPress={() => toggleDay(d.v)} style={[styles.dayChip, active && styles.chipOn]}>
                  <Text style={[styles.dayText, active && styles.chipTextOn]}>{d.label}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
          <Text style={[styles.sub, { marginTop: 8 }]}>من غير ما تختار أيام بيشتغل كل يوم.</Text>
        </View>

        {ready && (
          <View style={styles.summary}>
            <MaterialCommunityIcons name="weather-sunset" size={20} color={theme.accentSoft} />
            <Text style={styles.summaryText}>
              {cfg.enabled
                ? `النهارده: تشغيل ${onTime || '—'} ← إطفاء ${offTimePreview || '—'} (${cfg.targets.length} مفتاح)`
                : 'متوقف. فعّله من فوق لما تكون جاهز.'}
            </Text>
          </View>
        )}
        <Text style={[styles.sub, { marginHorizontal: 4 }]}>
          الشاشة دي بتعمل مشهدين («إضاءة خارجية — تشغيل/إطفاء») بتلاقيهم في المشاهد، وتقدر تشغّلهم يدوي في أي وقت.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

const getStyles = (theme) =>
  StyleSheet.create({
    safe: { flex: 1, backgroundColor: theme.bg },
    content: { paddingHorizontal: 20, paddingTop: 48, paddingBottom: 130 },
    sectionLabel: { fontSize: 13, fontWeight: '800', color: theme.textSecondary, fontFamily: FONTS.bodyBold, marginTop: 6, marginBottom: 10, textAlign: 'right' },
    card: { backgroundColor: gc(theme), borderColor: gb(theme), borderWidth: 1, borderRadius: 20, padding: 14, marginBottom: 16 },
    rowBetween: { flexDirection: 'row', alignItems: 'center', gap: 12 },
    title: { fontSize: 15, fontWeight: '800', color: theme.textPrimary, textAlign: 'right' },
    sub: { fontSize: 12, color: theme.textMuted, marginTop: 3, lineHeight: 17, textAlign: 'right' },
    fieldLabel: { fontSize: 12.5, fontWeight: '800', color: theme.textSecondary, marginTop: 4, marginBottom: 8, textAlign: 'right' },
    chipsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 8, alignItems: 'center' },
    chip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 14, borderWidth: 1, borderColor: gb(theme), backgroundColor: theme.cardAlt, maxWidth: '100%' },
    chipOn: { backgroundColor: theme.accent, borderColor: theme.accent },
    chipText: { fontSize: 13, fontWeight: '700', color: theme.textPrimary },
    chipTextOn: { color: readableOn(theme.accent) },
    lightsChip: { alignSelf: 'flex-end', marginBottom: 10 },
    bigInput: { borderRadius: 14, borderWidth: 1, borderColor: gb(theme), backgroundColor: theme.cardAlt, paddingHorizontal: 12, paddingVertical: 10, fontSize: 18, fontWeight: '800', color: theme.textPrimary, textAlign: 'center', marginBottom: 6 },
    daysRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, justifyContent: 'center' },
    dayChip: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 12, borderWidth: 1, borderColor: gb(theme), backgroundColor: theme.cardAlt },
    dayText: { fontSize: 12, fontWeight: '800', color: theme.textSecondary },
    summary: { flexDirection: 'row', alignItems: 'center', gap: 10, padding: 14, borderRadius: 18, borderWidth: 1, borderColor: theme.accentSoft, backgroundColor: theme.cardAlt, marginBottom: 12 },
    summaryText: { flex: 1, fontSize: 13, fontWeight: '800', color: theme.textPrimary, textAlign: 'right', lineHeight: 19 },
  });
