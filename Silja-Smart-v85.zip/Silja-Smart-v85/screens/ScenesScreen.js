import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, TextInput, StyleSheet, Animated } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { showAlert } from '../components/PremiumAlert';
import { showToast } from '../components/Toast';
import { useTheme } from '../ThemeContext';
import { getDeviceIcon } from '../deviceIcons';
import { flattenSwitchDevices, runScene } from '../scenes';
import { newId } from '../storage';
import ConnectionStatusBanner from '../components/ConnectionStatusBanner';
import ScreenBackground from '../components/ScreenBackground';
import ScreenHeader from '../components/ScreenHeader';
import EmptyState from '../components/EmptyState';
import { readableOn, withAlpha } from '../colorUtils';
import { LinearGradient } from 'expo-linear-gradient';
import PremiumSwitch from '../components/PremiumSwitch';
import { sunEventMs, deviceLocalOf, formatMinutes } from '../sceneScheduleCore';
import { pressFeedback, sentFeedback, errorFeedback } from '../feedback';
import FadeInView from '../components/FadeInView';
import SceneGlassCard from '../components/SceneGlassCard';

// أفعال ممكنة لكل نوع مفتاح
const TOGGLE_ACTIONS = [
  { value: 'ON', label: 'شغّل', icon: 'power-plug' },
  { value: 'OFF', label: 'اقفل', icon: 'power-plug-off' },
];
const UPDOWN_ACTIONS = [
  { value: 'UP', label: 'طلوع', icon: 'arrow-up-bold' },
  { value: 'DOWN', label: 'نزول', icon: 'arrow-down-bold' },
  { value: 'STOP', label: 'وقف', icon: 'stop' },
];

// ---------- جدولة المشهد ----------
const DEFAULT_SCHEDULE = { enabled: false, mode: 'time', time: '07:00', offsetMin: 0, days: [] };
const SCHEDULE_MODES = [
  { id: 'time', label: 'وقت محدد' },
  { id: 'sunrise', label: 'الشروق' },
  { id: 'sunset', label: 'الغروب' },
];
// ترتيب أيام الأسبوع في الشاشة (السبت الأول) — القيمة 0=الأحد ... 6=السبت.
const WEEK_DAYS = [
  { v: 6, label: 'سبت' }, { v: 0, label: 'أحد' }, { v: 1, label: 'اثنين' }, { v: 2, label: 'ثلاثاء' },
  { v: 3, label: 'أربعاء' }, { v: 4, label: 'خميس' }, { v: 5, label: 'جمعة' },
];
const toLatinDigits = (str) => String(str || '').replace(/[٠-٩]/g, (d) => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));

function normalizeTime(str) {
  const m = /^(\d{1,2}):(\d{2})$/.exec(toLatinDigits(str).trim());
  if (!m) return null;
  const h = Number(m[1]);
  const mi = Number(m[2]);
  if (h > 23 || mi > 59) return null;
  return `${String(h).padStart(2, '0')}:${String(mi).padStart(2, '0')}`;
}

function describeDays(days) {
  if (!Array.isArray(days) || days.length === 0 || days.length === 7) return 'كل يوم';
  return WEEK_DAYS.filter((d) => days.includes(d.v)).map((d) => d.label).join('، ');
}

function describeSchedule(schedule) {
  if (!schedule || !schedule.enabled) return '';
  const off = Number(schedule.offsetMin) || 0;
  let when;
  if (schedule.mode === 'sunrise' || schedule.mode === 'sunset') {
    const base = schedule.mode === 'sunrise' ? 'الشروق' : 'الغروب';
    when = off === 0 ? `عند ${base}` : `${Math.abs(off)} د ${off > 0 ? 'بعد' : 'قبل'} ${base}`;
  } else {
    when = `الساعة ${schedule.time || '--:--'}`;
  }
  return `${describeDays(schedule.days)} • ${when}`;
}

const SCENE_TABS = [
  { id: 'all', label: 'الكل' },
  { id: 'home', label: 'المنزل' },
  { id: 'away', label: 'الخروج' },
  { id: 'sleep', label: 'النوم' },
];

// تصنيف المشهد من اسمه (مفيش حقل نوع محفوظ في بيانات المشهد).
// بنفضّل النوع المحفوظ في المشهد (kind)؛ والمشاهد القديمة اللي ملهاش نوع بتتصنّف من اسمها.
function sceneKind(name = '', kind) {
  if (kind === 'home' || kind === 'away' || kind === 'sleep') return kind;
  const n = String(name);
  if (/خروج|سفر|مغادر|بره|برا|خارج/.test(n)) return 'away';
  if (/نوم|ليل|نايم|راحة/.test(n)) return 'sleep';
  return 'home';
}

// أيقونة مناسبة لاسم المشهد؛ لو المشهد ملهوش اسم معروف بنرجع للنجمة.
function sceneIcon(scene) {
  const n = String(scene?.name || '');
  if (/استقبال|ضيوف|ضيف/.test(n)) return 'account-group-outline';
  if (/نوم|ليل|نايم/.test(n)) return 'weather-night';
  if (/خروج|سفر|مغادر|بره|برا/.test(n)) return 'exit-run';
  if (/عودة|وصول|رجوع|دخول/.test(n)) return 'home-import-outline';
  if (/صباح|فجر|استيقاظ|صحيان/.test(n)) return 'weather-sunset-up';
  if (/سينما|فيلم|مشاهدة|تلفزيون/.test(n)) return 'movie-open-outline';
  if (/عشاء|غداء|سفرة|أكل|فطار/.test(n)) return 'silverware-fork-knife';
  if (/سهر|حفلة|احتفال/.test(n)) return 'party-popper';
  if (/ري|حديقة/.test(n)) return 'sprinkler-variant';
  return 'star-four-points';
}

export default function ScenesScreen({ boards, scenes, onSaveScenes, client, connected, weatherCity, schedulerServerOnline = false, onOpenPresence, onOpenAutoLights, onBack }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);
  const devices = flattenSwitchDevices(boards);

  const [editing, setEditing] = useState(null); // null | scene draft object
  const [running, setRunning] = useState(null);
  const [tab, setTab] = useState('all');
  const [ranId, setRanId] = useState(null);
  const [offsetText, setOffsetText] = useState('0'); // نص خانة الفرق بالدقايق (عشان نقدر نكتب "-" قبل الرقم)
  const pop = React.useRef(new Animated.Value(1)).current;
  const lastSceneRunRef = React.useRef({});

  const startNew = () => { setOffsetText('0'); setEditing({ id: newId(), name: '', kind: 'home', icon: 'star-four-points', actions: [], schedule: { ...DEFAULT_SCHEDULE } }); };
  const startEdit = (scene) => { setOffsetText(String(Number(scene.schedule && scene.schedule.offsetMin) || 0)); setEditing({ ...scene, kind: sceneKind(scene.name, scene.kind), actions: scene.actions.map((a) => ({ ...a })), schedule: { ...DEFAULT_SCHEDULE, ...(scene.schedule || {}), days: [...((scene.schedule && scene.schedule.days) || [])] } }); };

  const persist = (list) => onSaveScenes(list);

  const deleteScene = (id) => {
    showAlert('مسح المشهد', 'متأكد؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'مسح', style: 'destructive', onPress: () => persist(scenes.filter((s) => s.id !== id)) },
    ]);
  };

  const trigger = async (scene) => {
    if (!connected || !client) { showAlert('الاتصال غير متاح', 'اتصل بالسيرفر قبل تشغيل المشهد.'); return; }
    if (running) return;
    const lastRunAt = lastSceneRunRef.current[scene.id] || 0;
    if (Date.now() - lastRunAt < 900) return;
    lastSceneRunRef.current[scene.id] = Date.now();
    pressFeedback();
    setRunning(scene.id);
    try {
      const res = await runScene(scene, client);
      if (!res.ok) {
        errorFeedback();
        showAlert('تعذر التشغيل', res.error || 'مقدرش أشغّل المشهد');
      } else {
        sentFeedback();
        setRanId(scene.id);
        showToast(`تم تشغيل «${scene.name}»`);
        pop.setValue(0.8);
        Animated.spring(pop, { toValue: 1, friction: 3, tension: 120, useNativeDriver: true }).start();
        setTimeout(() => setRanId(null), 1300);
      }
    } catch (error) {
      showAlert('فشل تشغيل المشهد', error?.message || 'تعذر إرسال أوامر المشهد.');
    } finally {
      setRunning(null);
    }
  };

  const toggleActionInDraft = (device, value) => {
    setEditing((prev) => {
      const idx = prev.actions.findIndex((a) => a.controlTopic === device.controlTopic);
      const actions = [...prev.actions];
      if (idx >= 0 && actions[idx].value === value) {
        // نفس القيمة تاني = شيل الفعل ده من المشهد
        actions.splice(idx, 1);
      } else if (idx >= 0) {
        actions[idx] = { ...actions[idx], value };
      } else {
        actions.push({
          controlTopic: device.controlTopic,
          boardName: device.boardName,
          name: device.name,
          icon: device.icon,
          controlType: device.controlType,
          value,
        });
      }
      return { ...prev, actions };
    });
  };

  const saveDraft = () => {
    if (!editing.name.trim()) {
      showAlert('خطأ', 'لازم تحط اسم للمشهد');
      return;
    }
    if (editing.actions.length === 0) {
      showAlert('خطأ', 'لازم تختار مفتاح واحد على الأقل وحالته');
      return;
    }
    let draft = editing;
    const sch = editing.schedule;
    if (sch && sch.enabled) {
      if (sch.mode === 'time') {
        const t = normalizeTime(sch.time);
        if (!t) {
          showAlert('خطأ في الجدولة', 'اكتب الوقت بصيغة صحيحة 24 ساعة، مثلاً 07:30 أو 22:00.');
          return;
        }
        draft = { ...editing, schedule: { ...sch, time: t } };
      }
    }
    const exists = scenes.some((s) => s.id === editing.id);
    const list = exists ? scenes.map((s) => (s.id === editing.id ? draft : s)) : [...scenes, draft];
    persist(list);
    setEditing(null);
  };

  const setSchedule = (patch) => setEditing((prev) => ({ ...prev, schedule: { ...DEFAULT_SCHEDULE, ...(prev.schedule || {}), ...patch } }));

  // وقت الشروق/الغروب النهارده بتوقيت الجهاز (معاينة بس).
  const sunPreview = (mode, offsetMin) => {
    const city = weatherCity;
    if (!city || !Number.isFinite(city.lat) || !Number.isFinite(city.lon)) return null;
    const now = deviceLocalOf(Date.now());
    const ms = sunEventMs(now.y, now.m, now.d, city.lat, city.lon, mode === 'sunrise');
    if (ms == null) return null;
    const at = deviceLocalOf(ms + (Number(offsetMin) || 0) * 60000);
    return { time: formatMinutes(at.minutes), city: city.name };
  };

  function renderSchedulePanel() {
    const sch = { ...DEFAULT_SCHEDULE, ...(editing.schedule || {}) };
    const sun = sch.mode === 'sunrise' || sch.mode === 'sunset';
    const preview = sch.enabled && sun ? sunPreview(sch.mode, sch.offsetMin) : null;
    const allDays = sch.days.length === 0 || sch.days.length === 7;
    return (
      <View style={[styles.schedCard, { backgroundColor: theme.card, borderColor: sch.enabled ? theme.accent : theme.border }]}>
        <View style={styles.schedHead}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.deviceName, { color: theme.textPrimary }]}>تشغيل تلقائي بجدول</Text>
            <Text style={[styles.boardName, { color: theme.textMuted }]}>شغّل المشهد في وقت محدد أو مع الشروق/الغروب</Text>
          </View>
          <PremiumSwitch value={!!sch.enabled} onValueChange={(v) => setSchedule({ enabled: v })} theme={theme} size={0.9} />
        </View>

        {sch.enabled && (
          <>
            <View style={[styles.tabsWrap, { backgroundColor: theme.cardAlt, borderColor: theme.border, marginTop: 12, marginBottom: 12 }]}>
              {SCHEDULE_MODES.map((m) => {
                const active = sch.mode === m.id;
                return (
                  <TouchableOpacity key={m.id} onPress={() => setSchedule({ mode: m.id })} style={[styles.tabBtn, active && { backgroundColor: theme.accent }]}>
                    <Text style={{ color: active ? readableOn(theme.accent) : theme.textSecondary, fontSize: 12.5, fontWeight: '800' }}>{m.label}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            {sch.mode === 'time' ? (
              <View>
                <Text style={[styles.boardName, { color: theme.textSecondary, marginBottom: 6 }]}>الوقت (24 ساعة)</Text>
                <TextInput
                  style={[styles.input, { backgroundColor: theme.cardAlt, color: theme.textPrimary, marginBottom: 6, textAlign: 'center', fontSize: 18, fontWeight: '800' }]}
                  value={String(sch.time || '')}
                  onChangeText={(v) => setSchedule({ time: toLatinDigits(v).replace(/[^0-9:]/g, '').slice(0, 5) })}
                  placeholder="07:00"
                  placeholderTextColor={theme.textMuted}
                  keyboardType="numbers-and-punctuation"
                  maxLength={5}
                />
              </View>
            ) : (
              <View>
                <Text style={[styles.boardName, { color: theme.textSecondary, marginBottom: 6 }]}>
                  فرق بالدقايق عن {sch.mode === 'sunrise' ? 'الشروق' : 'الغروب'} (موجب = بعد، سالب = قبل، 0 = بالظبط)
                </Text>
                <TextInput
                  style={[styles.input, { backgroundColor: theme.cardAlt, color: theme.textPrimary, marginBottom: 6, textAlign: 'center', fontSize: 18, fontWeight: '800' }]}
                  value={offsetText}
                  onChangeText={(v) => {
                    const clean = toLatinDigits(v).replace(/[^0-9-]/g, '').replace(/(?!^)-/g, '').slice(0, 4);
                    const n = parseInt(clean, 10);
                    setOffsetText(clean);
                    setSchedule({ offsetMin: Number.isFinite(n) ? Math.max(-300, Math.min(300, n)) : 0 });
                  }}
                  placeholder="0"
                  placeholderTextColor={theme.textMuted}
                  keyboardType="numbers-and-punctuation"
                  maxLength={4}
                />
                {preview ? (
                  <Text style={[styles.boardName, { color: theme.accentSoft }]}>
                    النهارده حوالين الساعة {preview.time} (حسب موقع الطقس: {preview.city})
                  </Text>
                ) : (
                  <Text style={[styles.boardName, { color: theme.danger }]}>مقدرش أحسب الشروق/الغروب — راجع موقع الطقس.</Text>
                )}
              </View>
            )}

            <Text style={[styles.boardName, { color: theme.textSecondary, marginTop: 12, marginBottom: 8 }]}>الأيام {allDays ? '(كل يوم)' : ''}</Text>
            <View style={styles.daysRow}>
              {WEEK_DAYS.map((d) => {
                const active = sch.days.includes(d.v);
                return (
                  <TouchableOpacity
                    key={d.v}
                    onPress={() => setSchedule({ days: active ? sch.days.filter((x) => x !== d.v) : [...sch.days, d.v] })}
                    style={[styles.dayChip, { backgroundColor: active ? theme.accent : theme.cardAlt, borderColor: active ? theme.accent : theme.border }]}
                  >
                    <Text style={{ color: active ? readableOn(theme.accent) : theme.textSecondary, fontSize: 11.5, fontWeight: '800' }}>{d.label}</Text>
                  </TouchableOpacity>
                );
              })}
            </View>

            <View style={[styles.schedNote, { backgroundColor: theme.cardAlt, borderColor: schedulerServerOnline ? theme.on : theme.border }]}>
              <MaterialCommunityIcons name={schedulerServerOnline ? 'server-network' : 'cellphone-information'} size={16} color={schedulerServerOnline ? theme.on : theme.textMuted} />
              <Text style={[styles.schedNoteText, { color: theme.textSecondary }]}>
                {schedulerServerOnline
                  ? 'سيرفر Silja شغال: الجدول بيتنفّذ حتى والتطبيق مقفول.'
                  : 'سيرفر Silja (مجلد server/) مش شغال: الجدول هيتنفّذ بس والتطبيق مفتوح ومتصل. شغّل السيرفر عشان يشتغل والتطبيق مقفول.'}
              </Text>
            </View>
          </>
        )}
      </View>
    );
  }

  // ---------- شاشة تعديل/إنشاء مشهد ----------
  if (editing) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <ScreenBackground theme={theme} screen="scenes" />
        <ScreenHeader title={scenes.some((s) => s.id === editing.id) ? 'تعديل المشهد' : 'مشهد جديد'} onBack={() => setEditing(null)} />

        <TextInput
          style={[styles.input, { backgroundColor: theme.cardAlt, color: theme.textPrimary }]}
          value={editing.name}
          onChangeText={(v) => setEditing({ ...editing, name: v })}
          placeholder="اسم المشهد (مثلاً: وضع النوم)"
          placeholderTextColor={theme.textMuted}
        />

        <View style={[styles.tabsWrap, { backgroundColor: theme.card, borderColor: theme.border, marginBottom: 12 }]}>
          {SCENE_TABS.filter((t) => t.id !== 'all').map((t) => {
            const active = (editing.kind || 'home') === t.id;
            return (
              <TouchableOpacity key={t.id} onPress={() => setEditing({ ...editing, kind: t.id })} style={[styles.tabBtn, active && { backgroundColor: theme.accent }]}>
                <Text style={{ color: active ? readableOn(theme.accent) : theme.textSecondary, fontSize: 12.5, fontWeight: '800' }}>{t.label}</Text>
              </TouchableOpacity>
            );
          })}
        </View>

        <Text style={[styles.hint, { color: theme.textSecondary }]}>
          اختار حالة كل مفتاح عايزه يتغيّر لما المشهد يشتغل. المفاتيح اللي مش هتلمسها هتفضل زي ما هي.
        </Text>

        <ScrollView contentContainerStyle={{ paddingBottom: 40 }} keyboardShouldPersistTaps="handled">
          {renderSchedulePanel()}
          {devices.length === 0 && (
            <Text style={[styles.emptyText, { color: theme.textMuted }]}>مفيش مفاتيح متاحة — ضيف بوردات الأول.</Text>
          )}
          {devices.map((device) => {
            const current = editing.actions.find((a) => a.controlTopic === device.controlTopic);
            const actionsList = device.controlType === 'updown' ? UPDOWN_ACTIONS : TOGGLE_ACTIONS;
            const meta = getDeviceIcon(device.icon);
            return (
              <View key={device.controlTopic} style={[styles.deviceRow, { backgroundColor: theme.card, borderColor: current ? theme.accent : theme.border }]}>
                <View style={styles.deviceInfo}>
                  <MaterialCommunityIcons name={meta.icon} size={20} color={theme.textSecondary} />
                  <View style={{ marginRight: 8 }}>
                    <Text style={[styles.deviceName, { color: theme.textPrimary }]}>{device.name}</Text>
                    <Text style={[styles.boardName, { color: theme.textMuted }]}>{device.boardName}</Text>
                  </View>
                </View>
                <View style={styles.actionsRow}>
                  {actionsList.map((a) => {
                    const selected = current?.value === a.value;
                    return (
                      <TouchableOpacity
                        key={a.value}
                        onPress={() => toggleActionInDraft(device, a.value)}
                        style={[
                          styles.actionChip,
                          {
                            backgroundColor: selected ? theme.accent : theme.cardAlt,
                            borderColor: selected ? theme.accent : theme.border,
                          },
                        ]}
                      >
                        <Text style={{ color: selected ? readableOn(theme.accent) : theme.textSecondary, fontSize: 11, fontWeight: '700' }}>
                          {a.label}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </View>
            );
          })}
        </ScrollView>

        <TouchableOpacity style={[styles.primaryBtn, { backgroundColor: theme.accent }]} onPress={saveDraft}>
          <Text style={[styles.btnText, { color: readableOn(theme.accent) }]}>{`حفظ المشهد${editing.actions.length ? ` (${editing.actions.length})` : ''}`}</Text>
        </TouchableOpacity>
      </SafeAreaView>
    );
  }

  // ---------- قائمة المشاهد ----------
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <ScreenBackground theme={theme} screen="scenes" />
      <ScreenHeader title="المشاهد" onBack={onBack} right={
        <TouchableOpacity onPress={startNew}><MaterialCommunityIcons name="plus-circle" size={26} color={theme.accentSoft} /></TouchableOpacity>
      } />

      <Text style={[styles.hint, { color: theme.textSecondary }]}>
        جمّع مفاتيح من أي بورد في مشهد واحد وشغّلهم كلهم بدوسة واحدة (مثلاً "وضع النوم" يقفل كل حاجة إلا الإنذار).
      </Text>
      <View style={{ marginHorizontal: 16 }}><ConnectionStatusBanner theme={theme} connected={connected} title={connected ? 'جاهز لتشغيل المشاهد' : 'المشاهد محفوظة — التشغيل متوقف'} detail={connected ? 'التشغيل يرسل الأوامر المحفوظة للبوردات.' : 'ارجع الاتصال قبل تشغيل أي مشهد.'} /></View>

      <ScrollView contentContainerStyle={{ paddingBottom: 130 }}>
        {!!onOpenAutoLights && (
          <TouchableOpacity
            onPress={onOpenAutoLights}
            activeOpacity={0.8}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginHorizontal: 16, marginBottom: 12, padding: 14, borderRadius: 20, borderWidth: 1, backgroundColor: theme.card, borderColor: theme.border }}
          >
            <View style={{ width: 38, height: 38, borderRadius: 13, backgroundColor: theme.cardAlt, alignItems: 'center', justifyContent: 'center' }}>
              <MaterialCommunityIcons name="weather-sunset" size={20} color={theme.accentSoft} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 14, fontWeight: '800', color: theme.textPrimary, textAlign: 'right' }}>إضاءة خارجية تلقائية</Text>
              <Text style={{ fontSize: 11, color: theme.textMuted, marginTop: 2, textAlign: 'right' }}>حديقة وواجهة وبوابة: تشتغل مع الغروب وتطفي في ميعادها</Text>
            </View>
            <MaterialCommunityIcons name="chevron-left" size={22} color={theme.textMuted} />
          </TouchableOpacity>
        )}
        {!!onOpenPresence && (
          <TouchableOpacity
            onPress={onOpenPresence}
            activeOpacity={0.8}
            style={{ flexDirection: 'row', alignItems: 'center', gap: 12, marginHorizontal: 16, marginBottom: 12, padding: 14, borderRadius: 20, borderWidth: 1, backgroundColor: theme.card, borderColor: theme.border }}
          >
            <View style={{ width: 38, height: 38, borderRadius: 13, backgroundColor: theme.cardAlt, alignItems: 'center', justifyContent: 'center' }}>
              <MaterialCommunityIcons name="home-account" size={20} color={theme.accentSoft} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 14, fontWeight: '800', color: theme.textPrimary, textAlign: 'right' }}>محاكاة التواجد</Text>
              <Text style={{ fontSize: 11, color: theme.textMuted, marginTop: 2, textAlign: 'right' }}>كشافات بتشتغل وتطفي بأوقات مختلفة وانت مسافر</Text>
            </View>
            <MaterialCommunityIcons name="chevron-left" size={22} color={theme.textMuted} />
          </TouchableOpacity>
        )}
        {scenes.length === 0 && (
          <EmptyState icon="movie-open-outline" title="مفيش مشاهد لسه" text="اجمع مفاتيح كتير في مشهد واحد وشغّلهم بدوسة." actionLabel="مشهد جديد" onAction={startNew} />
        )}
        {scenes.length > 0 && (
          <View style={[styles.tabsWrap, { backgroundColor: theme.card, borderColor: theme.border }]}>
            {SCENE_TABS.map((t) => {
              const active = tab === t.id;
              return (
                <TouchableOpacity key={t.id} onPress={() => setTab(t.id)} style={[styles.tabBtn, active && { backgroundColor: theme.accent }]}>
                  <Text style={{ color: active ? readableOn(theme.accent) : theme.textSecondary, fontSize: 12.5, fontWeight: '800' }}>{t.label}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        )}
        {scenes.length > 0 && scenes.filter((sc) => tab === 'all' || sceneKind(sc.name, sc.kind) === tab).length === 0 && (
          <Text style={[styles.emptyText, { color: theme.textMuted }]}>مفيش مشاهد في التصنيف ده.</Text>
        )}
        {scenes.filter((sc) => tab === 'all' || sceneKind(sc.name, sc.kind) === tab).map((scene, si) => (
          <FadeInView key={scene.id} delay={Math.min(si, 8) * 70} distance={14}>
          <SceneGlassCard
            theme={theme}
            name={scene.name}
            icon={sceneIcon(scene)}
            meta={`${scene.actions.length === 1 ? 'إجراء واحد' : scene.actions.length === 2 ? 'إجراءان' : `${scene.actions.length} إجراءات`}${scene.actions.length ? ` • ${scene.actions.slice(0, 2).map((a) => a.name).filter(Boolean).join('، ')}${scene.actions.length > 2 ? '…' : ''}` : ''}`}
            schedule={describeSchedule(scene.schedule)}
            connected={connected}
            running={running === scene.id}
            ran={ranId === scene.id}
            onPress={() => trigger(scene)}
            onEdit={() => startEdit(scene)}
            onDelete={() => deleteScene(scene.id)}
          />
          </FadeInView>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const getStyles = (theme) =>
  StyleSheet.create({
    container: { flex: 1, paddingHorizontal: 20, paddingTop: 50, backgroundColor: theme.bg },
    hint: { fontSize: 12, marginBottom: 16, lineHeight: 18 },
    emptyText: { fontSize: 13, textAlign: 'center', marginTop: 40 },
    input: { borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12, marginBottom: 14, fontSize: 14, borderWidth: 1 },
    deviceRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      borderWidth: 1,
      borderRadius: 18,
      padding: 14,
      marginBottom: 12,
    },
    deviceInfo: { flexDirection: 'row', alignItems: 'center', flex: 1 },
    deviceName: { fontSize: 13, fontWeight: '700' },
    boardName: { fontSize: 11, marginTop: 2 },
    actionsRow: { flexDirection: 'row', gap: 6 },
    actionChip: { borderWidth: 1, borderRadius: 11, paddingVertical: 8, paddingHorizontal: 12 },
    primaryBtn: { borderRadius: 15, paddingVertical: 15, alignItems: 'center', marginTop: 4 },
    btnText: { color: '#fff', fontWeight: '600', fontSize: 13 },
    sceneCard: { borderWidth: 1, borderRadius: 22, marginBottom: 15, overflow: 'hidden', shadowColor: '#000', shadowOpacity: 0.14, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 3 },
    sceneMain: { flexDirection: 'row', alignItems: 'center', padding: 15, gap: 12 },
    sceneIconWrap: {
      width: 52,
      height: 52,
      borderRadius: 17,
      borderWidth: 1.5,
      alignItems: 'center',
      justifyContent: 'center',
    },
    playCircle: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
    sceneName: { fontSize: 15, fontWeight: '700' },
    sceneMeta: { fontSize: 11, marginTop: 2 },
    schedCard: { borderWidth: 1, borderRadius: 18, padding: 14, marginBottom: 14 },
    schedHead: { flexDirection: 'row', alignItems: 'center', gap: 10 },
    daysRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
    dayChip: { borderWidth: 1, borderRadius: 11, paddingVertical: 8, paddingHorizontal: 11 },
    schedNote: { flexDirection: 'row', alignItems: 'flex-start', gap: 8, borderWidth: 1, borderRadius: 12, padding: 10, marginTop: 14 },
    schedNoteText: { flex: 1, fontSize: 11, lineHeight: 17 },
    sceneFooter: { flexDirection: 'row', paddingBottom: 4, paddingHorizontal: 8 },
    tabsWrap: { flexDirection: 'row', borderRadius: 18, borderWidth: 1, padding: 4, gap: 4, marginBottom: 16 },
    tabBtn: { flex: 1, borderRadius: 14, paddingVertical: 10, alignItems: 'center' },
    footerBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 10, gap: 6 },
    footerBtnText: { fontSize: 12, fontWeight: '600' },
  });
