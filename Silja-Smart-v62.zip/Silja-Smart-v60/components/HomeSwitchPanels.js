import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, StyleSheet, Modal, ScrollView } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import TouchableOpacity from './AnimatedTouchable';
import { useTheme } from '../ThemeContext';
import { getDeviceIcon } from '../deviceIcons';
import { loadHomeFavorites, saveHomeFavorites } from '../storage';

const keyOf = (board, device) => `${board.id}|${device.controlTopic}`;

// لوحتين في الرئيسية: "المفضلة" (تحكم سريع بمفاتيح اخترتها) و"شغال دلوقتي"
// (المفاتيح اللي حالتها ON فعلًا، وعليها زرار إطفاء). كله من حالة MQTT الحقيقية.
export default function HomeSwitchPanels({ boards = [], switchStates = {}, client, connected }) {
  const { theme } = useTheme();
  const styles = useMemo(() => getStyles(theme), [theme]);
  const [favs, setFavs] = useState([]);
  const [picker, setPicker] = useState(false);

  useEffect(() => {
    loadHomeFavorites().then(setFavs).catch(() => {});
  }, []);

  // كل المفاتيح العادية (من غير الري والستائر) مع البورد بتاعها.
  const all = useMemo(
    () => boards
      .filter((b) => b.type !== 'irrigation')
      .flatMap((b) => (b.devices || [])
        .filter((d) => d.controlTopic && d.controlType !== 'updown')
        .map((d) => ({ board: b, device: d, key: keyOf(b, d) }))),
    [boards]
  );
  const byKey = useMemo(() => new Map(all.map((x) => [x.key, x])), [all]);
  const isOn = (x) => switchStates[x.device.statusTopic || x.device.controlTopic] === true;

  const favItems = favs.map((k) => byKey.get(k)).filter(Boolean);
  const activeItems = all.filter(isOn);

  const send = (x, cmd) => {
    if (!connected || !client) return;
    client.publish(x.device.controlTopic, cmd, { qos: 1 });
  };
  const toggleFav = (k) => {
    const next = favs.includes(k) ? favs.filter((f) => f !== k) : [...favs, k];
    setFavs(next);
    saveHomeFavorites(next).catch(() => {});
  };

  if (!all.length) return null;

  return (
    <View>
      {/* ---------- المفضلة ---------- */}
      <View style={styles.headRow}>
        <TouchableOpacity onPress={() => setPicker(true)} style={styles.editBtn}>
          <MaterialCommunityIcons name="star-plus-outline" size={16} color={theme.accentSoft} />
          <Text style={styles.editText}>تعديل</Text>
        </TouchableOpacity>
        <Text style={styles.title}>المفضلة</Text>
      </View>
      {favItems.length === 0 ? (
        <Text style={styles.hint}>اضغط "تعديل" واختار المفاتيح اللي بتستخدمها كتير عشان تتحكم فيها من هنا.</Text>
      ) : (
        <View style={styles.grid}>
          {favItems.map((x) => {
            const on = isOn(x);
            return (
              <TouchableOpacity
                key={x.key}
                style={[styles.favTile, { borderColor: on ? theme.on : theme.border }]}
                onPress={() => send(x, on ? 'OFF' : 'ON')}
              >
                <MaterialCommunityIcons name={getDeviceIcon(x.device.icon).icon} size={24} color={on ? theme.on : theme.textSecondary} />
                <Text numberOfLines={1} style={styles.favName}>{x.device.name}</Text>
                <Text style={[styles.favState, { color: on ? theme.on : theme.textMuted }]}>{on ? 'شغال' : 'مطفي'}</Text>
              </TouchableOpacity>
            );
          })}
        </View>
      )}

      {/* ---------- شغال دلوقتي ---------- */}
      {activeItems.length > 0 && (
        <View style={{ marginTop: 6 }}>
          <View style={styles.headRow}>
            <Text style={styles.count}>{activeItems.length}</Text>
            <Text style={styles.title}>شغال دلوقتي</Text>
          </View>
          {activeItems.map((x) => (
            <View key={x.key} style={styles.activeRow}>
              <TouchableOpacity onPress={() => send(x, 'OFF')} style={styles.offBtn}>
                <MaterialCommunityIcons name="power" size={16} color={theme.off || '#E5484D'} />
                <Text style={[styles.offText, { color: theme.off || '#E5484D' }]}>إطفاء</Text>
              </TouchableOpacity>
              <View style={{ flex: 1 }}>
                <Text numberOfLines={1} style={styles.activeName}>{x.device.name}</Text>
                <Text numberOfLines={1} style={styles.activeBoard}>{x.board.name}</Text>
              </View>
              <MaterialCommunityIcons name={getDeviceIcon(x.device.icon).icon} size={22} color={theme.on} />
            </View>
          ))}
        </View>
      )}

      {/* ---------- اختيار المفضلة ---------- */}
      <Modal visible={picker} transparent animationType="fade" onRequestClose={() => setPicker(false)}>
        <View style={styles.backdrop}>
          <View style={styles.sheet}>
            <Text style={styles.sheetTitle}>اختار المفاتيح المفضلة</Text>
            <ScrollView style={{ maxHeight: 420 }}>
              {all.map((x) => {
                const on = favs.includes(x.key);
                return (
                  <TouchableOpacity key={x.key} style={styles.pickRow} onPress={() => toggleFav(x.key)}>
                    <MaterialCommunityIcons name={on ? 'star' : 'star-outline'} size={22} color={on ? theme.accentSoft : theme.textMuted} />
                    <View style={{ flex: 1 }}>
                      <Text numberOfLines={1} style={styles.activeName}>{x.device.name}</Text>
                      <Text numberOfLines={1} style={styles.activeBoard}>{x.board.name}</Text>
                    </View>
                    <MaterialCommunityIcons name={getDeviceIcon(x.device.icon).icon} size={20} color={theme.textSecondary} />
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
            <TouchableOpacity style={styles.doneBtn} onPress={() => setPicker(false)}>
              <Text style={styles.doneText}>تم</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

function getStyles(theme) {
  return StyleSheet.create({
    headRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
    title: { color: theme.textPrimary, fontSize: 16, fontWeight: '800' },
    count: { color: theme.on, fontSize: 14, fontWeight: '800' },
    editBtn: { flexDirection: 'row', alignItems: 'center', gap: 4 },
    editText: { color: theme.accentSoft, fontSize: 13, fontWeight: '700' },
    hint: { color: theme.textMuted, fontSize: 12.5, textAlign: 'right', marginBottom: 12 },
    grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 12 },
    favTile: { width: '31%', borderRadius: 18, borderWidth: 1, paddingVertical: 12, paddingHorizontal: 6, alignItems: 'center', backgroundColor: theme.card },
    favName: { color: theme.textPrimary, fontSize: 12.5, fontWeight: '700', marginTop: 6, maxWidth: '100%' },
    favState: { fontSize: 11, marginTop: 2 },
    activeRow: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: theme.card, borderRadius: 16, borderWidth: 1, borderColor: theme.border, padding: 12, marginBottom: 8 },
    activeName: { color: theme.textPrimary, fontSize: 14, fontWeight: '700', textAlign: 'right' },
    activeBoard: { color: theme.textMuted, fontSize: 11.5, textAlign: 'right', marginTop: 1 },
    offBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingVertical: 6, paddingHorizontal: 10, borderRadius: 12, borderWidth: 1, borderColor: theme.border },
    offText: { fontSize: 12, fontWeight: '700' },
    backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.55)', justifyContent: 'center', padding: 20 },
    sheet: { backgroundColor: theme.card, borderRadius: 22, padding: 16, borderWidth: 1, borderColor: theme.border },
    sheetTitle: { color: theme.textPrimary, fontSize: 16, fontWeight: '800', textAlign: 'center', marginBottom: 12 },
    pickRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: theme.border },
    doneBtn: { marginTop: 12, backgroundColor: theme.accent, borderRadius: 14, paddingVertical: 12, alignItems: 'center' },
    doneText: { color: '#17140E', fontWeight: '800', fontSize: 15 },
  });
}
