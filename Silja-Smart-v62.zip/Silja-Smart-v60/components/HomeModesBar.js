import React, { useEffect, useMemo, useState } from 'react';
import { View, Text, StyleSheet, Modal, ScrollView } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import TouchableOpacity from './AnimatedTouchable';
import { showAlert } from './PremiumAlert';
import { useTheme } from '../ThemeContext';
import { getDeviceIcon } from '../deviceIcons';
import { loadHomeModes, saveHomeModes } from '../storage';
import { runScene } from '../scenes';

const MODES = {
  away: { title: 'وضع الخروج', icon: 'exit-run', hint: 'يطفي الإضاءة ويوقف الستائر' },
  sleep: { title: 'وضع النوم', icon: 'weather-night', hint: 'يطفي الإضاءة ويوقف الستائر' },
};

const keyOf = (board, device) => `${board.id}|${device.controlTopic}`;

// زرارين في الرئيسية: "خروج" و"نوم". كل وضع بيبعت OFF للمفاتيح العادية و STOP للستائر
// اللي المستخدم اختارها (الافتراضي: كل الإضاءة + كل الستائر). بنفس أوامر MQTT العادية.
export default function HomeModesBar({ boards = [], client, connected }) {
  const { theme } = useTheme();
  const styles = useMemo(() => getStyles(theme), [theme]);
  const [modes, setModes] = useState({ away: null, sleep: null });
  const [picking, setPicking] = useState(null); // 'away' | 'sleep' | null

  useEffect(() => {
    loadHomeModes().then(setModes).catch(() => {});
  }, []);

  const all = useMemo(
    () => boards
      .filter((b) => b.type !== 'irrigation')
      .flatMap((b) => (b.devices || [])
        .filter((d) => d.controlTopic)
        .map((d) => ({ board: b, device: d, key: keyOf(b, d), updown: d.controlType === 'updown' }))),
    [boards]
  );

  const defaultKeys = useMemo(
    () => all.filter((x) => x.updown || getDeviceIcon(x.device.icon).isLight).map((x) => x.key),
    [all]
  );
  const selectedFor = (mode) => (modes[mode] || defaultKeys);
  // نتجاهل مفاتيح اتحذفت من البوردات
  const targetsFor = (mode) => {
    const set = new Set(selectedFor(mode));
    return all.filter((x) => set.has(x.key));
  };

  const run = (mode) => {
    if (!connected || !client) { showAlert('غير متصل', 'لسه مش متصل بالسيرفر، استنى ثانية وحاول تاني'); return; }
    const targets = targetsFor(mode);
    if (!targets.length) {
      showAlert(MODES[mode].title, 'مفيش مفاتيح متحددة للوضع ده. اضغط على الترس واختار اللي يتأثر.');
      return;
    }
    showAlert(MODES[mode].title, `هيتم إطفاء/إيقاف ${targets.length} مفتاح. متأكد؟`, [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'تنفيذ',
        onPress: async () => {
          const scene = { actions: targets.map((x) => ({ controlTopic: x.device.controlTopic, value: x.updown ? 'STOP' : 'OFF' })) };
          const res = await runScene(scene, client);
          if (!res.ok) showAlert(MODES[mode].title, res.error || 'تعذر التنفيذ');
        },
      },
    ]);
  };

  const toggleKey = (mode, k) => {
    const cur = selectedFor(mode);
    const next = cur.includes(k) ? cur.filter((x) => x !== k) : [...cur, k];
    const updated = { ...modes, [mode]: next };
    setModes(updated);
    saveHomeModes(updated).catch(() => {});
  };

  if (!all.length) return null;

  return (
    <View style={styles.row}>
      {Object.keys(MODES).map((mode) => (
        <View key={mode} style={styles.card}>
          <TouchableOpacity style={styles.main} onPress={() => run(mode)}>
            <MaterialCommunityIcons name={MODES[mode].icon} size={24} color={theme.accentSoft} />
            <View style={{ flex: 1 }}>
              <Text style={styles.title}>{MODES[mode].title}</Text>
              <Text numberOfLines={1} style={styles.sub}>{selectedFor(mode).length ? `${targetsFor(mode).length} مفتاح` : 'غير محدد'}</Text>
            </View>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => setPicking(mode)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <MaterialCommunityIcons name="cog-outline" size={18} color={theme.textMuted} />
          </TouchableOpacity>
        </View>
      ))}

      <Modal visible={!!picking} transparent animationType="fade" onRequestClose={() => setPicking(null)}>
        <View style={styles.backdrop}>
          <View style={styles.sheet}>
            <Text style={styles.sheetTitle}>{picking ? `اختار اللي يتأثر — ${MODES[picking].title}` : ''}</Text>
            <ScrollView style={{ maxHeight: 420 }}>
              {picking && all.map((x) => {
                const on = selectedFor(picking).includes(x.key);
                return (
                  <TouchableOpacity key={x.key} style={styles.pickRow} onPress={() => toggleKey(picking, x.key)}>
                    <MaterialCommunityIcons name={on ? 'checkbox-marked' : 'checkbox-blank-outline'} size={22} color={on ? theme.accentSoft : theme.textMuted} />
                    <View style={{ flex: 1 }}>
                      <Text numberOfLines={1} style={styles.pickName}>{x.device.name}</Text>
                      <Text numberOfLines={1} style={styles.pickSub}>{x.board.name}{x.updown ? ' • إيقاف' : ' • إطفاء'}</Text>
                    </View>
                    <MaterialCommunityIcons name={getDeviceIcon(x.device.icon).icon} size={20} color={theme.textSecondary} />
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
            <TouchableOpacity style={styles.doneBtn} onPress={() => setPicking(null)}>
              <Text style={styles.doneText}>تم</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

function getStyles(theme) {
  return StyleSheet.create({
    row: { flexDirection: 'row', gap: 10, marginBottom: 14 },
    card: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: theme.card, borderRadius: 18, borderWidth: 1, borderColor: theme.border, paddingVertical: 12, paddingHorizontal: 12 },
    main: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 8 },
    title: { color: theme.textPrimary, fontSize: 13.5, fontWeight: '800', textAlign: 'right' },
    sub: { color: theme.textMuted, fontSize: 11, textAlign: 'right', marginTop: 1 },
    backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.55)', justifyContent: 'center', padding: 20 },
    sheet: { backgroundColor: theme.card, borderRadius: 22, padding: 16, borderWidth: 1, borderColor: theme.border },
    sheetTitle: { color: theme.textPrimary, fontSize: 16, fontWeight: '800', textAlign: 'center', marginBottom: 12 },
    pickRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: theme.border },
    pickName: { color: theme.textPrimary, fontSize: 14, fontWeight: '700', textAlign: 'right' },
    pickSub: { color: theme.textMuted, fontSize: 11.5, textAlign: 'right', marginTop: 1 },
    doneBtn: { marginTop: 12, backgroundColor: theme.accent, borderRadius: 14, paddingVertical: 12, alignItems: 'center' },
    doneText: { color: '#17140E', fontWeight: '800', fontSize: 15 },
  });
}
