import React, { useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { useTheme } from '../ThemeContext';

// نقط ملونة صغيرة: أخضر = متصل، أحمر = مقطوع، رمادي = لسه مش معروف. نقطة لكل بورد في صف واحد.
export default function BoardStatusDots({ boards = [], statusOf, onOpen }) {
  const { theme } = useTheme();
  const styles = useMemo(() => getStyles(theme), [theme]);
  if (!boards.length) return null;
  const colorOf = (s) => (s === 'online' ? theme.on : s === 'offline' ? (theme.off || '#E5484D') : theme.textMuted);

  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.row} style={styles.scroll}>
      {boards.map((b) => (
        <TouchableOpacity key={b.id} style={styles.item} onPress={() => onOpen && onOpen(b)} activeOpacity={0.8}>
          <View style={[styles.dot, { backgroundColor: colorOf(statusOf(b.id)) }]} />
          <Text numberOfLines={1} style={styles.name}>{b.name || 'بورد'}</Text>
        </TouchableOpacity>
      ))}
    </ScrollView>
  );
}

function getStyles(theme) {
  return StyleSheet.create({
    scroll: { marginBottom: 14 },
    row: { flexDirection: 'row', gap: 14, paddingHorizontal: 4 },
    item: { flexDirection: 'row', alignItems: 'center', gap: 6 },
    dot: { width: 9, height: 9, borderRadius: 5 },
    name: { color: theme.textSecondary, fontSize: 12, maxWidth: 90 },
  });
}
