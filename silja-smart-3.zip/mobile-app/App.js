// لازم يتحط أول سطر في الملف - قبل أي استيراد تاني، خصوصًا قبل "mqtt" -
// عشان يجهز Buffer/process قبل ما مكتبة mqtt تحاول تستخدمهم (شوف الشرح
// بالتفصيل جوه polyfills.js). من غيره التطبيق بيعمل crash فوري.
import './polyfills';

import React, { useEffect, useRef, useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, TextInput, TouchableOpacity, StyleSheet, StatusBar, Alert, Switch } from 'react-native';
import mqtt from 'mqtt/dist/mqtt';
import * as LocalAuthentication from 'expo-local-authentication';
import {
  DEFAULT_SETTINGS,
  loadSettings,
  saveSettings,
  loadBoards,
  saveBoards,
  loadPairingKey,
  savePairingKey,
  loadScenes,
  saveScenes,
  loadPushEnabled,
  savePushEnabled,
  loadBiometricEnabled,
  saveBiometricEnabled,
  newId,
} from './storage';
import { ThemeProvider, useTheme } from './ThemeContext';
import { registerForPushNotificationsAsync, unregisterPushNotifications } from './notifications';
import BoardsListScreen from './screens/BoardsListScreen';
import SwitchesScreen from './screens/SwitchesScreen';
import IrrigationScreen from './screens/IrrigationScreen';
import ThemeScreen from './screens/ThemeScreen';
import ScenesScreen from './screens/ScenesScreen';
import HistoryScreen from './screens/HistoryScreen';
import BackupScreen from './screens/BackupScreen';
import LockScreen from './screens/LockScreen';

export default function App() {
  return (
    <ThemeProvider>
      <AppInner />
    </ThemeProvider>
  );
}

function AppInner() {
  const { theme } = useTheme();
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [pairingKey, setPairingKey] = useState('');
  const [boards, setBoards] = useState([]);
  const [scenes, setScenes] = useState([]);
  const [pushEnabled, setPushEnabled] = useState(false);
  const [biometricEnabled, setBiometricEnabled] = useState(false);
  const [unlocked, setUnlocked] = useState(false);
  const [ready, setReady] = useState(false);
  const [screen, setScreen] = useState('boards'); // settings | boards | board | theme | scenes | history | backup
  const [activeBoard, setActiveBoard] = useState(null);
  const [connected, setConnected] = useState(false);

  const clientRef = useRef(null);

  // ---------- تحميل البيانات المحفوظة ----------
  // بيرجع true لو فيه إعدادات سيرفر + مفتاح ربط محفوظين (يعني التطبيق "مظبوط").
  const loadAllFromStorage = async () => {
    const savedSettings = await loadSettings();
    const savedBoards = await loadBoards();
    const savedPairingKey = await loadPairingKey();
    const savedScenes = await loadScenes();
    const savedPushEnabled = await loadPushEnabled();
    const savedBiometricEnabled = await loadBiometricEnabled();
    const configured = !!(savedSettings && savedPairingKey);
    if (savedSettings) setSettings(savedSettings);
    setPairingKey(savedPairingKey);
    setBoards(savedBoards);
    setScenes(savedScenes);
    setPushEnabled(savedPushEnabled);
    setBiometricEnabled(savedBiometricEnabled);
    return configured;
  };

  useEffect(() => {
    (async () => {
      await loadAllFromStorage();
      setReady(true);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // التطبيق دايمًا بيفتح على صفحة البوردات (الشاشة الرئيسية)، سواء السيرفر
  // متظبط أو لسه لأ. لو لسه مفيش سيرفر محفوظ، الصفحة نفسها بتوضح كده وبتوجّه
  // المستخدم لأيقونة الترس (⚙️) فوق عشان يدخل الإعدادات.
  const isConfigured = !!(settings.host && pairingKey);

  // بعد استيراد نسخة احتياطية، نعيد تحميل كل حاجة من التخزين المحلي على طول
  // (بدل ما نستنى إعادة تشغيل التطبيق) ونرجع لشاشة البوردات أو الإعدادات
  // حسب لو فيه سيرفر ومفتاح ربط اتحفظوا في النسخة اللي اتستوردت.
  const handleBackupImported = async () => {
    await loadAllFromStorage();
    setActiveBoard(null);
    setScreen('boards');
  };

  // ---------- اتصال MQTT واحد مشترك لكل البوردات ----------
  useEffect(() => {
    if (!ready || screen === 'settings' || !settings.host) return undefined;

    const url = `${settings.protocol}://${settings.host}:${settings.port}${settings.path}`;
    const client = mqtt.connect(url, {
      clientId: 'iot-app-' + Math.random().toString(16).slice(2, 10),
      username: settings.username || undefined,
      password: settings.password || undefined,
      reconnectPeriod: 3000,
      connectTimeout: 8000,
    });
    clientRef.current = client;

    client.on('connect', () => {
      setConnected(true);
      // كل ما نتصل (أو نعيد الاتصال)، لو الإشعارات مفعّلة نعيد نشر التوكن Retained
      // عشان سيرفر الإشعارات يفضل عارفه حتى لو البروكر أعاد تشغيل أو مسح الحالة.
      if (pushEnabled) registerForPushNotificationsAsync(client);
    });
    client.on('reconnect', () => setConnected(false));
    client.on('close', () => setConnected(false));
    client.on('error', (err) => console.log('MQTT error:', err.message));

    return () => client.end(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [ready, screen, settings]);

  const persistSettings = async (s) => {
    setSettings(s);
    await saveSettings(s);
  };

  const persistPairingKey = async (k) => {
    setPairingKey(k);
    await savePairingKey(k);
  };

  const persistBoards = async (list) => {
    setBoards(list);
    await saveBoards(list);
  };

  const persistScenes = async (list) => {
    setScenes(list);
    await saveScenes(list);
  };

  const togglePush = async () => {
    if (pushEnabled) {
      await unregisterPushNotifications(clientRef.current);
      setPushEnabled(false);
      await savePushEnabled(false);
      return;
    }
    const res = await registerForPushNotificationsAsync(clientRef.current);
    if (!res.ok) {
      Alert.alert('الإشعارات', res.error || 'حصل خطأ');
      return;
    }
    setPushEnabled(true);
    await savePushEnabled(true);
    Alert.alert(
      'اتفعّلت',
      'التوكن اتنشر على البروكر. لازم سيرفر الإشعارات (server/) يكون شغال عشان الإشعارات توصلك فعليًا وقت التطبيق مقفول.'
    );
  };

  // تفعيل/تعطيل حماية فتح التطبيق بالبصمة (إصبع أو وجه). قبل ما نفعّلها بنتأكد
  // إن الموبايل فيه حساس بصمة أصلاً وإن فيه بصمة متسجلة عليه، وإلا التفعيل
  // مش هيبقى له أي معنى (ولا هيقدر يتحقق منه أبدًا).
  const toggleBiometric = async () => {
    if (biometricEnabled) {
      setBiometricEnabled(false);
      await saveBiometricEnabled(false);
      return;
    }
    const hasHardware = await LocalAuthentication.hasHardwareAsync();
    if (!hasHardware) {
      Alert.alert('غير متاح', 'الموبايل ده مفيهوش حساس بصمة إصبع أو بصمة وجه');
      return;
    }
    const isEnrolled = await LocalAuthentication.isEnrolledAsync();
    if (!isEnrolled) {
      Alert.alert('لازم تسجّل بصمة الأول', 'روح إعدادات الموبايل وسجّل بصمة إصبع أو بصمة وجه، وبعدين رجع فعّل الحماية دي');
      return;
    }
    setBiometricEnabled(true);
    await saveBiometricEnabled(true);
  };

  const addBoard = (board) => persistBoards([...boards, { ...board, id: newId() }]);
  const deleteBoard = (id) => persistBoards(boards.filter((b) => b.id !== id));
  const updateBoard = (updated) => {
    setActiveBoard(updated);
    persistBoards(boards.map((b) => (b.id === updated.id ? updated : b)));
  };
  const setBoardIcon = (id, icon) => persistBoards(boards.map((b) => (b.id === id ? { ...b, icon } : b)));

  // ---------- شاشة القفل بالبصمة ----------
  // بتفضل شغالة قبل أي حاجة تانية طول ما الحماية مفعّلة ولسه محصلش تحقق ناجح
  // في الجلسة دي (unlocked بيتصفّر تاني كل ما التطبيق يتقفل ويتفتح من الأول).
  if (!ready) return null;
  if (biometricEnabled && !unlocked) {
    return <LockScreen onUnlocked={() => setUnlocked(true)} />;
  }

  // ---------- شاشة إعدادات الاتصال ----------
  if (screen === 'settings') {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
        <StatusBar barStyle={theme.id === 'daylight' ? 'dark-content' : 'light-content'} />
        <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
          <TouchableOpacity
            onPress={() => setScreen('boards')}
            style={styles.backRow}
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
          >
            <Text style={[styles.backText, { color: theme.textSecondary }]}>‹ رجوع</Text>
          </TouchableOpacity>
          <Text style={[styles.title, { color: theme.textPrimary }]}>إعدادات الاتصال بالسيرفر</Text>
          <Text style={[styles.hint, { color: theme.textSecondary }]}>
            بيانات البروكر (WebSocket) دي بتتشارك بين كل البوردات. كل بورد بعد كده بيتضاف تلقائي عن طريق الاكتشاف من الفيرموير.
          </Text>

          <Field label="Protocol" value={settings.protocol} onChange={(v) => setSettings({ ...settings, protocol: v })} placeholder="ws أو wss" />
          <Field label="Host" value={settings.host} onChange={(v) => setSettings({ ...settings, host: v })} placeholder="broker.example.com" />
          <Field label="WebSocket Port" value={settings.port} onChange={(v) => setSettings({ ...settings, port: v })} placeholder="8884" keyboardType="numeric" />
          <Field label="Path" value={settings.path} onChange={(v) => setSettings({ ...settings, path: v })} placeholder="/mqtt" />
          <Field label="Username" value={settings.username} onChange={(v) => setSettings({ ...settings, username: v })} />
          <Field label="Password" value={settings.password} onChange={(v) => setSettings({ ...settings, password: v })} secure />

          <View style={{ height: 8 }} />
          <Text style={[styles.title, { color: theme.textPrimary, fontSize: 16 }]}>مفتاح الربط (Pairing Key)</Text>
          <Field
            label="Pairing Key"
            value={pairingKey}
            onChange={setPairingKey}
            secure
          />

          <TouchableOpacity
            style={[styles.primaryBtn, { backgroundColor: theme.accent }]}
            onPress={async () => {
              if (!settings.host) {
                Alert.alert('خطأ', 'لازم تدخل عنوان السيرفر (Host)');
                return;
              }
              if (!pairingKey.trim()) {
                Alert.alert('خطأ', 'لازم تحط مفتاح ربط (Pairing Key) عشان الاكتشاف يشتغل بأمان');
                return;
              }
              await persistSettings(settings);
              await persistPairingKey(pairingKey.trim());
              setScreen('boards');
            }}
          >
            <Text style={styles.btnText}>حفظ ومتابعة</Text>
          </TouchableOpacity>

          <View style={{ height: 8 }} />
          <View style={[styles.bioRow, { backgroundColor: theme.cardAlt }]}>
            <View style={{ flex: 1 }}>
              <Text style={[styles.bioTitle, { color: theme.textPrimary }]}>الحماية بالبصمة</Text>
              <Text style={[styles.bioHint, { color: theme.textSecondary }]}>
                تفتح التطبيق ببصمة إصبعك أو بصمة وجهك بدل ما يفتح على طول
              </Text>
            </View>
            <Switch
              value={biometricEnabled}
              onValueChange={toggleBiometric}
              trackColor={{ false: theme.border, true: theme.accent }}
              thumbColor="#fff"
            />
          </View>
        </ScrollView>
      </SafeAreaView>
    );
  }

  // ---------- شاشة الثيمات / المظهر ----------
  if (screen === 'theme') {
    return <ThemeScreen onBack={() => setScreen('boards')} />;
  }

  // ---------- شاشة المشاهد (Scenes/Groups) ----------
  if (screen === 'scenes') {
    return (
      <ScenesScreen
        boards={boards}
        scenes={scenes}
        onSaveScenes={persistScenes}
        client={clientRef.current}
        connected={connected}
        onBack={() => setScreen('boards')}
      />
    );
  }

  // ---------- شاشة سجل الأحداث (History) ----------
  if (screen === 'history') {
    return <HistoryScreen client={clientRef.current} connected={connected} onBack={() => setScreen('boards')} />;
  }

  // ---------- شاشة النسخة الاحتياطية (تصدير/استيراد) ----------
  if (screen === 'backup') {
    return <BackupScreen onBack={() => setScreen('boards')} onImported={handleBackupImported} />;
  }

  // ---------- شاشة التحكم في بورد واحد ----------
  if (screen === 'board' && activeBoard) {
    const Screen = activeBoard.type === 'irrigation' ? IrrigationScreen : SwitchesScreen;
    return (
      <Screen
        board={activeBoard}
        client={clientRef.current}
        connected={connected}
        pairingKey={pairingKey}
        onUpdateBoard={updateBoard}
        onBack={() => {
          setActiveBoard(null);
          setScreen('boards');
        }}
      />
    );
  }

  // ---------- شاشة قائمة البوردات ----------
  return (
    <BoardsListScreen
      boards={boards}
      connected={connected}
      client={clientRef.current}
      pairingKey={pairingKey}
      onAdd={addBoard}
      onDelete={deleteBoard}
      onOpen={(b) => {
        setActiveBoard(b);
        setScreen('board');
      }}
      onOpenSettings={() => setScreen('settings')}
      onOpenTheme={() => setScreen('theme')}
      onOpenScenes={() => setScreen('scenes')}
      onOpenHistory={() => setScreen('history')}
      onOpenBackup={() => setScreen('backup')}
      pushEnabled={pushEnabled}
      onTogglePush={togglePush}
      configured={isConfigured}
      onSetBoardIcon={setBoardIcon}
    />
  );
}

function Field({ label, value, onChange, placeholder, secure, keyboardType }) {
  const { theme } = useTheme();
  return (
    <View style={{ marginBottom: 12 }}>
      <Text style={[styles.label, { color: theme.textSecondary }]}>{label}</Text>
      <TextInput
        style={[styles.input, { backgroundColor: theme.cardAlt, color: theme.textPrimary }]}
        value={value}
        onChangeText={onChange}
        placeholder={placeholder}
        placeholderTextColor={theme.textMuted}
        secureTextEntry={secure}
        keyboardType={keyboardType}
        autoCapitalize="none"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 18, paddingTop: 55 },
  backRow: { alignSelf: 'flex-start', marginBottom: 14 },
  backText: { fontSize: 14, fontWeight: '600' },
  title: { fontSize: 22, fontWeight: '700', marginBottom: 6 },
  hint: { fontSize: 12, marginBottom: 16 },
  label: { fontSize: 12, marginBottom: 6 },
  input: { borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10 },
  primaryBtn: { borderRadius: 12, paddingVertical: 14, alignItems: 'center', marginTop: 10 },
  btnText: { color: '#fff', fontWeight: '600', fontSize: 13 },
  bioRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 14,
    padding: 14,
    gap: 10,
  },
  bioTitle: { fontSize: 14, fontWeight: '700', marginBottom: 3 },
  bioHint: { fontSize: 11.5, lineHeight: 16 },
});
