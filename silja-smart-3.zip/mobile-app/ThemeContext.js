import React, { createContext, useContext, useEffect, useState } from 'react';
import { DEFAULT_THEME_ID, LIGHT_THEME_ID, getTheme } from './theme';
import { loadThemeId, saveThemeId, loadLastDarkThemeId, saveLastDarkThemeId } from './storage';

const ThemeContext = createContext({
  theme: getTheme(DEFAULT_THEME_ID),
  themeId: DEFAULT_THEME_ID,
  isLight: false,
  setThemeId: () => {},
  toggleLightDark: () => {},
});

export function ThemeProvider({ children }) {
  const [themeId, setThemeIdState] = useState(DEFAULT_THEME_ID);
  const [lastDarkThemeId, setLastDarkThemeId] = useState(DEFAULT_THEME_ID);

  useEffect(() => {
    (async () => {
      const [saved, savedLastDark] = await Promise.all([loadThemeId(), loadLastDarkThemeId()]);
      if (saved) setThemeIdState(saved);
      if (savedLastDark) setLastDarkThemeId(savedLastDark);
    })();
  }, []);

  const setThemeId = async (id) => {
    setThemeIdState(id);
    await saveThemeId(id);
    // أي ثيم غامق (مش الوضع النهاري) بيتسجل كـ"آخر ثيم غامق" عشان نرجعله لما نطفي
    // الوضع النهاري بزرار التبديل السريع.
    if (id !== LIGHT_THEME_ID) {
      setLastDarkThemeId(id);
      await saveLastDarkThemeId(id);
    }
  };

  // تبديل سريع بين الوضع الغامق (آخر ثيم غامق كان مختار) والوضع النهاري (الفاتح)
  const toggleLightDark = async () => {
    if (themeId === LIGHT_THEME_ID) {
      await setThemeId(lastDarkThemeId || DEFAULT_THEME_ID);
    } else {
      await setThemeId(LIGHT_THEME_ID);
    }
  };

  const theme = getTheme(themeId);
  const isLight = themeId === LIGHT_THEME_ID;

  return (
    <ThemeContext.Provider value={{ theme, themeId, isLight, setThemeId, toggleLightDark }}>
      {children}
    </ThemeContext.Provider>
  );
}

// Hook بسيط عشان أي شاشة تاخد الثيم الحالي وتقدر تغيّره
export function useTheme() {
  return useContext(ThemeContext);
}
