import React, { useEffect, useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Switch,
} from 'react-native';
import { useTheme } from '../ThemeContext';

const ZONE_NAMES = ['المنطقة 1', 'المنطقة 2', 'المنطقة 3', 'المنطقة 4'];

export default function IrrigationScreen({ board, client, connected, onBack }) {
  const { theme } = useTheme();
  const base = board.prefix;

  const [available, setAvailable] = useState(null);
  const [statusText, setStatusText] = useState('');
  const [status, setStatus] = useState({
    running: false,
    current_relay: 0,
    completed_cycles: 0,
    target_cycles: 1,
    remaining_minutes: 0,
    durations_min: [10, 10, 10, 10],
    manual_on: [0, 0, 0, 0],
  });
  const [manualMinutes, setManualMinutes] = useState(['10', '10', '10', '10']);
  const [durationInputs, setDurationInputs] = useState(['10', '10', '10', '10']);
  const [cyclesInput, setCyclesInput] = useState('1');

  useEffect(() => {
    if (!client) return undefined;

    const topics = [`${base}/status`, `${base}/status_text`, `${base}/availability`];
    topics.forEach((t) => client.subscribe(t));

    const handler = (topic, payload) => {
      const msg = payload.toString();
      if (topic === `${base}/status`) {
        try {
          setStatus((prev) => ({ ...prev, ...JSON.parse(msg) }));
        } catch (e) {
          // ignore malformed payload
        }
      } else if (topic === `${base}/status_text`) {
        setStatusText(msg);
      } else if (topic === `${base}/availability`) {
        setAvailable(msg);
      }
    };

    client.on('message', handler);
    return () => {
      client.off('message', handler);
      topics.forEach((t) => client.unsubscribe(t));
    };
  }, [client, base]);

  const publish = (subtopic, payload = '') => client?.publish(`${base}/${subtopic}`, String(payload));

  const startAuto = () => publish('cmd/start');
  const stopAll = () => publish('cmd/stop');
  const emergencyStop = () => {
    Alert.alert('إيقاف طوارئ', 'هيوقف كل المحابس فورًا. متأكد؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'إيقاف الآن', style: 'destructive', onPress: () => publish('cmd/emergency') },
    ]);
  };
  const applyCycles = () => publish('cmd/cycles', cyclesInput);
  const applyDuration = (i) => publish(`cmd/duration/${i + 1}`, durationInputs[i]);
  const manualOn = (i) => publish(`cmd/manual/${i + 1}/on`, manualMinutes[i] || '0');
  const manualOff = (i) => publish(`cmd/manual/${i + 1}/off`);

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={onBack}>
          <Text style={[styles.back, { color: theme.accentSoft }]}>‹ رجوع</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: theme.textPrimary }]}>{board.name}</Text>
        <View style={{ width: 50 }} />
      </View>

      <View style={styles.statusRow}>
        <View style={[styles.dot, { backgroundColor: connected ? theme.on : theme.off }]} />
        <Text style={[styles.statusLabel, { color: theme.textSecondary }]}>
          {connected ? 'متصل بالسيرفر' : 'جاري الاتصال…'}
          {available ? `  •  البورد: ${available === 'online' ? 'أونلاين' : 'أوفلاين'}` : ''}
        </Text>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 60 }}>
        {!!statusText && (
          <View style={[styles.card, { backgroundColor: theme.card }]}>
            <Text style={[styles.statusText, { color: theme.textPrimary }]}>{statusText}</Text>
          </View>
        )}

        <Text style={[styles.sectionTitle, { color: theme.accentSoft }]}>الوضع التلقائي</Text>
        <View style={[styles.card, { backgroundColor: theme.card }]}>
          <Text style={[styles.rowText, { color: theme.textPrimary }]}>
            الدورات: {status.completed_cycles} / {status.target_cycles}
          </Text>
          <Text style={[styles.rowText, { color: theme.textPrimary }]}>
            المنطقة الشغالة الآن: {status.current_relay > 0 ? ZONE_NAMES[status.current_relay - 1] : 'لا يوجد'}
          </Text>
          {status.running && (
            <Text style={[styles.rowText, { color: theme.textPrimary }]}>متبقي: {status.remaining_minutes} دقيقة</Text>
          )}

          <View style={styles.btnRow}>
            <TouchableOpacity style={[styles.smallBtn, { backgroundColor: theme.accent }]} onPress={startAuto}>
              <Text style={styles.btnText}>ابدأ تلقائي</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.smallBtn, { backgroundColor: theme.danger }]} onPress={stopAll}>
              <Text style={styles.btnText}>إيقاف الكل</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.inlineRow}>
            <Text style={[styles.label, { color: theme.textSecondary }]}>عدد الدورات:</Text>
            <TextInput
              style={[styles.smallInput, { backgroundColor: theme.cardAlt, color: theme.textPrimary }]}
              keyboardType="numeric"
              value={cyclesInput}
              onChangeText={setCyclesInput}
            />
            <TouchableOpacity style={[styles.tinyBtn, { backgroundColor: theme.accent }]} onPress={applyCycles}>
              <Text style={styles.btnText}>ضبط</Text>
            </TouchableOpacity>
          </View>
        </View>

        <Text style={[styles.sectionTitle, { color: theme.accentSoft }]}>المناطق</Text>
        {ZONE_NAMES.map((name, i) => (
          <View style={[styles.card, { backgroundColor: theme.card }]} key={i}>
            <View style={styles.zoneHeader}>
              <Text style={[styles.zoneName, { color: theme.textPrimary }]}>{name}</Text>
              <Switch
                value={!!status.manual_on[i]}
                onValueChange={() => (status.manual_on[i] ? manualOff(i) : manualOn(i))}
                trackColor={{ false: theme.border, true: theme.accent }}
                thumbColor={status.manual_on[i] ? theme.on : theme.textMuted}
              />
            </View>

            <View style={styles.inlineRow}>
              <Text style={[styles.label, { color: theme.textSecondary }]}>تشغيل يدوي (دقايق):</Text>
              <TextInput
                style={[styles.smallInput, { backgroundColor: theme.cardAlt, color: theme.textPrimary }]}
                keyboardType="numeric"
                value={manualMinutes[i]}
                onChangeText={(v) => {
                  const arr = [...manualMinutes];
                  arr[i] = v;
                  setManualMinutes(arr);
                }}
              />
              <TouchableOpacity style={[styles.tinyBtn, { backgroundColor: theme.accent }]} onPress={() => manualOn(i)}>
                <Text style={styles.btnText}>تشغيل</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.tinyBtn, { backgroundColor: theme.danger }]} onPress={() => manualOff(i)}>
                <Text style={styles.btnText}>إيقاف</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.inlineRow}>
              <Text style={[styles.label, { color: theme.textSecondary }]}>مدة الوضع التلقائي (دقايق):</Text>
              <TextInput
                style={[styles.smallInput, { backgroundColor: theme.cardAlt, color: theme.textPrimary }]}
                keyboardType="numeric"
                value={durationInputs[i]}
                onChangeText={(v) => {
                  const arr = [...durationInputs];
                  arr[i] = v;
                  setDurationInputs(arr);
                }}
              />
              <TouchableOpacity style={[styles.tinyBtn, { backgroundColor: theme.accent }]} onPress={() => applyDuration(i)}>
                <Text style={styles.btnText}>حفظ</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}

        <TouchableOpacity style={[styles.emergencyBtn, { backgroundColor: theme.danger }]} onPress={emergencyStop}>
          <Text style={styles.emergencyText}>⛔ إيقاف طوارئ فوري</Text>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 18, paddingTop: 55 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
  back: { fontSize: 15 },
  title: { fontSize: 18, fontWeight: '700' },
  statusRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
  dot: { width: 10, height: 10, borderRadius: 5, marginRight: 8 },
  statusLabel: { fontSize: 13 },
  statusText: { fontSize: 14, textAlign: 'center' },
  sectionTitle: { fontSize: 15, fontWeight: '700', marginTop: 6, marginBottom: 8 },
  card: { borderRadius: 14, padding: 16, marginBottom: 12 },
  rowText: { fontSize: 14, marginBottom: 4 },
  zoneHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  zoneName: { fontSize: 16, fontWeight: '600' },
  btnRow: { flexDirection: 'row', gap: 10, marginTop: 10, marginBottom: 10 },
  inlineRow: { flexDirection: 'row', alignItems: 'center', marginTop: 8, flexWrap: 'wrap', gap: 8 },
  label: { fontSize: 12 },
  smallInput: {
    borderRadius: 8,
    paddingHorizontal: 10,
    paddingVertical: 6,
    width: 60,
    textAlign: 'center',
  },
  smallBtn: { flex: 1, borderRadius: 10, paddingVertical: 10, alignItems: 'center' },
  tinyBtn: { borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6 },
  emergencyBtn: { borderRadius: 14, paddingVertical: 16, alignItems: 'center', marginTop: 10 },
  emergencyText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  btnText: { color: '#fff', fontWeight: '600', fontSize: 13 },
});
