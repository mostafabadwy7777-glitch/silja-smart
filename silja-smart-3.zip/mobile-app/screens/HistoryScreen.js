import React, { useEffect, useRef, useState } from 'react';
import { SafeAreaView, View, Text, TouchableOpacity, StyleSheet, FlatList, ActivityIndicator } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';

// السجل مش متخزن في التطبيق نفسه (لازم يفضل موجود حتى لو التطبيق مقفول ووقت
// حصول الحدث). بيتخزن في سيرفر مستقل بسيط (شوف server/) بيراقب كل المفاتيح على
// MQTT ويحتفظ بالأحداث. الشاشة دي بس بتطلب آخر الأحداث من السيرفر ده عن طريق
// نفس البروكر: بتنشر طلب على silja/app/history/request وبتستنى رد على
// silja/app/history/response/<replyId>.
const REQUEST_TOPIC = 'silja/app/history/request';
const RESPONSE_PREFIX = 'silja/app/history/response/';
const REQUEST_TIMEOUT_MS = 6000;

export default function HistoryScreen({ client, connected, onBack }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [gotResponse, setGotResponse] = useState(false);

  const timeoutRef = useRef(null);
  const replyTopicRef = useRef(null);
  const handlerRef = useRef(null);
  const gotResponseRef = useRef(false);

  const cleanup = () => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    if (client && replyTopicRef.current) {
      if (handlerRef.current) client.off('message', handlerRef.current);
      client.unsubscribe(replyTopicRef.current);
    }
    timeoutRef.current = null;
    replyTopicRef.current = null;
    handlerRef.current = null;
  };

  const fetchHistory = () => {
    if (!client || !connected) {
      setErrorMsg('مفيش اتصال بالسيرفر دلوقتي');
      return;
    }
    cleanup();
    setLoading(true);
    setErrorMsg('');
    setGotResponse(false);

    const replyId = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    const replyTopic = RESPONSE_PREFIX + replyId;
    replyTopicRef.current = replyTopic;

    client.subscribe(replyTopic);

    const handler = (topic, payload) => {
      if (topic !== replyTopic) return;
      setGotResponse(true);
      try {
        const data = JSON.parse(payload.toString());
        setEvents(Array.isArray(data.events) ? data.events : []);
      } catch (e) {
        setErrorMsg('رد السيرفر مش JSON صحيح');
      }
      setLoading(false);
      cleanup();
    };
    handlerRef.current = handler;
    client.on('message', handler);

    client.publish(REQUEST_TOPIC, JSON.stringify({ replyId, limit: 100 }));

    timeoutRef.current = setTimeout(() => {
      setLoading(false);
      if (!gotResponseRef.current) {
        setErrorMsg('مفيش رد من سيرفر السجل — اتأكد إنه شغال (شوف server/README.md)');
      }
      cleanup();
    }, REQUEST_TIMEOUT_MS);
  };

  // نستخدم ref موازي عشان الـ closure جوه setTimeout يشوف آخر قيمة
  useEffect(() => {
    gotResponseRef.current = gotResponse;
  }, [gotResponse]);

  useEffect(() => {
    fetchHistory();
    return cleanup;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client, connected]);

  const renderItem = ({ item }) => {
    const isOn = item.state === 'ON';
    const dt = new Date(item.ts);
    const timeStr = dt.toLocaleString('ar-EG', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' });
    return (
      <View style={[styles.row, { backgroundColor: theme.card, borderColor: theme.border }]}>
        <View style={[styles.dot, { backgroundColor: isOn ? theme.on : theme.off }]} />
        <View style={{ flex: 1 }}>
          <Text style={[styles.rowTitle, { color: theme.textPrimary }]}>
            {item.boardName ? `${item.boardName} — ` : ''}
            {item.switchName || item.topic}
          </Text>
          <Text style={[styles.rowMeta, { color: theme.textMuted }]}>{timeStr}</Text>
        </View>
        <Text style={[styles.stateBadge, { color: isOn ? theme.on : theme.off }]}>{isOn ? 'اتشغل' : 'اتقفل'}</Text>
      </View>
    );
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={onBack}>
          <Text style={[styles.back, { color: theme.accentSoft }]}>‹ رجوع</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: theme.textPrimary }]}>سجل الأحداث</Text>
        <TouchableOpacity onPress={fetchHistory}>
          <MaterialCommunityIcons name="refresh" size={22} color={theme.accentSoft} />
        </TouchableOpacity>
      </View>

      {loading && (
        <View style={{ paddingVertical: 30 }}>
          <ActivityIndicator color={theme.accent} />
        </View>
      )}

      {!loading && errorMsg ? <Text style={[styles.errorText, { color: theme.danger }]}>{errorMsg}</Text> : null}

      {!loading && !errorMsg && events.length === 0 && (
        <Text style={[styles.emptyText, { color: theme.textMuted }]}>مفيش أحداث مسجّلة لسه.</Text>
      )}

      <FlatList
        data={events}
        keyExtractor={(item, idx) => `${item.ts}-${idx}`}
        renderItem={renderItem}
        contentContainerStyle={{ paddingBottom: 40 }}
      />
    </SafeAreaView>
  );
}

const getStyles = (theme) =>
  StyleSheet.create({
    container: { flex: 1, padding: 18, paddingTop: 55 },
    headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
    back: { fontSize: 15 },
    title: { fontSize: 18, fontWeight: '700' },
    errorText: { fontSize: 12, textAlign: 'center', marginTop: 20, lineHeight: 18 },
    emptyText: { fontSize: 13, textAlign: 'center', marginTop: 20 },
    row: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderRadius: 12, padding: 12, marginBottom: 8, gap: 10 },
    dot: { width: 10, height: 10, borderRadius: 5 },
    rowTitle: { fontSize: 13, fontWeight: '700' },
    rowMeta: { fontSize: 11, marginTop: 2 },
    stateBadge: { fontSize: 12, fontWeight: '700' },
  });
