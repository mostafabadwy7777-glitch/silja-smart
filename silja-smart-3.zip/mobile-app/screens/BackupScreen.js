import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, TouchableOpacity, StyleSheet, Alert, ActivityIndicator } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import * as DocumentPicker from 'expo-document-picker';
import { useTheme } from '../ThemeContext';
import { exportBackupPayload, applyBackupPayload, validateBackupPayload } from '../storage';

// اسم ملف التصدير — بنحط فيه تاريخ اليوم عشان يبقى سهل تمييزه لو عندك أكتر من نسخة.
function backupFileName() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, '0');
  return `silja-smart-backup-${d.getFullYear()}${pad(d.getMonth() + 1)}${pad(d.getDate())}-${pad(d.getHours())}${pad(
    d.getMinutes()
  )}.json`;
}

export default function BackupScreen({ onBack, onImported }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);
  const [exporting, setExporting] = useState(false);
  const [importing, setImporting] = useState(false);

  const handleExport = async () => {
    setExporting(true);
    try {
      const payload = await exportBackupPayload();
      const json = JSON.stringify(payload, null, 2);
      const fileUri = FileSystem.cacheDirectory + backupFileName();
      await FileSystem.writeAsStringAsync(fileUri, json, { encoding: FileSystem.EncodingType.UTF8 });

      const canShare = await Sharing.isAvailableAsync();
      if (canShare) {
        await Sharing.shareAsync(fileUri, {
          mimeType: 'application/json',
          dialogTitle: 'حفظ نسخة Silja Smart الاحتياطية',
          UTI: 'public.json',
        });
      } else {
        Alert.alert('تم التصدير', `اتحفظ الملف هنا مؤقتًا:\n${fileUri}\n\nمشاركة الملفات مش متاحة على الجهاز ده.`);
      }
    } catch (e) {
      Alert.alert('فشل التصدير', e.message || 'حصل خطأ غير متوقع');
    } finally {
      setExporting(false);
    }
  };

  const handleImport = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: ['application/json', 'text/plain', '*/*'],
        copyToCacheDirectory: true,
      });
      if (result.canceled || !result.assets || result.assets.length === 0) return;

      const fileUri = result.assets[0].uri;
      setImporting(true);
      const raw = await FileSystem.readAsStringAsync(fileUri, { encoding: FileSystem.EncodingType.UTF8 });

      let data;
      try {
        data = JSON.parse(raw);
      } catch (e) {
        throw new Error('الملف اللي اخترته مش JSON صحيح');
      }

      const err = validateBackupPayload(data);
      if (err) throw new Error(err);

      const boardsCount = Array.isArray(data.boards) ? data.boards.length : 0;
      Alert.alert(
        'استيراد نسخة احتياطية',
        `هيتم استبدال كل الإعدادات والبوردات الحالية (${boardsCount} بورد جواها) بالنسخة دي. متأكد؟`,
        [
          { text: 'إلغاء', style: 'cancel', onPress: () => setImporting(false) },
          {
            text: 'استيراد',
            style: 'destructive',
            onPress: async () => {
              try {
                await applyBackupPayload(data);
                setImporting(false);
                Alert.alert('تم', 'اتستوردت النسخة الاحتياطية بنجاح. لازم تدخل التطبيق تاني عشان كل حاجة تتحدث.', [
                  { text: 'تمام', onPress: () => onImported?.() },
                ]);
              } catch (e2) {
                setImporting(false);
                Alert.alert('فشل الاستيراد', e2.message || 'حصل خطأ غير متوقع');
              }
            },
          },
        ]
      );
    } catch (e) {
      setImporting(false);
      Alert.alert('فشل الاستيراد', e.message || 'حصل خطأ غير متوقع');
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={onBack}>
          <Text style={styles.back}>‹ رجوع</Text>
        </TouchableOpacity>
        <Text style={styles.title}>نسخة احتياطية</Text>
        <View style={{ width: 50 }} />
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
        <Text style={styles.hint}>
          صدّر كل البوردات ومفاتيحها، إعدادات الاتصال بالسيرفر، مفتاح الربط، المشاهد، والثيم لملف JSON واحد تقدر تحفظه
          فين ما تحب (جوجل درايف، إيميل لنفسك، إلخ). لو غيّرت الموبايل أو مسحت التطبيق بالغلط، ترجّع الملف ده تاني
          وكل حاجة ترجع زي ما كانت من غير ما تعيد اكتشاف كل بورد من الأول.
        </Text>

        <View style={styles.card}>
          <View style={styles.cardHeaderRow}>
            <View style={styles.iconCircle}>
              <MaterialCommunityIcons name="tray-arrow-up" size={20} color={theme.accentSoft} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>تصدير الإعدادات</Text>
              <Text style={styles.cardText}>هيتعمل ملف JSON وهيفتحلك شاشة المشاركة عشان تحفظه فين ما تحب.</Text>
            </View>
          </View>
          <TouchableOpacity
            style={[styles.btn, { backgroundColor: theme.accent }, exporting && styles.btnDisabled]}
            onPress={handleExport}
            disabled={exporting}
            activeOpacity={0.85}
          >
            {exporting ? <ActivityIndicator color="#fff" /> : <Text style={styles.btnText}>تصدير الآن</Text>}
          </TouchableOpacity>
        </View>

        <View style={styles.card}>
          <View style={styles.cardHeaderRow}>
            <View style={styles.iconCircle}>
              <MaterialCommunityIcons name="tray-arrow-down" size={20} color={theme.accentSoft} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.cardTitle}>استيراد إعدادات</Text>
              <Text style={styles.cardText}>هيستبدل كل الإعدادات والبوردات الحالية بمحتوى الملف اللي هتختاره.</Text>
            </View>
          </View>
          <TouchableOpacity
            style={[styles.btn, { backgroundColor: theme.cardAlt, borderWidth: 1, borderColor: theme.border }, importing && styles.btnDisabled]}
            onPress={handleImport}
            disabled={importing}
            activeOpacity={0.85}
          >
            {importing ? (
              <ActivityIndicator color={theme.accentSoft} />
            ) : (
              <Text style={[styles.btnText, { color: theme.textPrimary }]}>اختيار ملف واستيراد</Text>
            )}
          </TouchableOpacity>
        </View>

        <Text style={styles.warning}>
          ⚠ الملف بيحتوي على مفتاح الربط (Pairing Key) وبيانات الاتصال بالسيرفر — احتفظ بيه في مكان آمن زي ما تحتفظ بأي
          باسورد.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
}

function getStyles(theme) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: theme.bg, padding: 18, paddingTop: 55 },
    headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
    back: { fontSize: 15, color: theme.accentSoft },
    title: { fontSize: 18, fontWeight: '700', color: theme.textPrimary },
    hint: { fontSize: 12.5, lineHeight: 19, color: theme.textSecondary, marginBottom: 18 },
    card: {
      backgroundColor: theme.card,
      borderRadius: 16,
      borderWidth: 1,
      borderColor: theme.border,
      padding: 16,
      marginBottom: 14,
    },
    cardHeaderRow: { flexDirection: 'row', gap: 12, marginBottom: 14, alignItems: 'flex-start' },
    iconCircle: {
      width: 38,
      height: 38,
      borderRadius: 19,
      backgroundColor: theme.cardAlt,
      alignItems: 'center',
      justifyContent: 'center',
    },
    cardTitle: { color: theme.textPrimary, fontSize: 14.5, fontWeight: '700', marginBottom: 4 },
    cardText: { color: theme.textSecondary, fontSize: 12, lineHeight: 17 },
    btn: { borderRadius: 12, paddingVertical: 13, alignItems: 'center' },
    btnDisabled: { opacity: 0.6 },
    btnText: { color: '#fff', fontWeight: '700', fontSize: 13.5 },
    warning: { color: theme.danger, fontSize: 11.5, lineHeight: 17, marginTop: 4 },
  });
}
