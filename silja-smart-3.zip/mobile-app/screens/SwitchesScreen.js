import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Modal,
  FlatList,
  Animated,
  ActivityIndicator,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { DEVICE_ICONS, getDeviceIcon } from '../deviceIcons';
import { COLOR_SWATCHES } from '../theme';
import { useTheme } from '../ThemeContext';
import { newId } from '../storage';
import { parseBoardDiscovery, boardAvailabilityTopic, parseAvailability } from '../discovery';

// بورد قديم كان بيستخدم شكل ثابت (relay1..relayN تحت prefix معيّن).
// الدالة دي بتحوّله لقايمة "أجهزة" عادية عشان يفضل شغال زي ما هو من غير ما يتمسح.
function deriveInitialDevices(board) {
  if (board.devices) return board.devices;
  if (board.prefix && board.relayCount) {
    const relayNames =
      board.relayNames && board.relayNames.length === board.relayCount
        ? board.relayNames
        : Array.from({ length: board.relayCount }, (_, i) => `المفتاح ${i + 1}`);
    return relayNames.map((name, i) => ({
      id: newId(),
      name,
      icon: (board.relayIcons && board.relayIcons[i]) || 'switch',
      controlType: 'toggle',
      controlTopic: `${board.prefix}/control/relay${i + 1}`,
      statusTopic: `${board.prefix}/status/relay${i + 1}`,
    }));
  }
  return [];
}

const SYNC_TIMEOUT_MS = 10000;

// تحقق من صيغة الوقت "HH:MM" بنظام 24 ساعة
function isValidHHMM(str) {
  return /^([01]\d|2[0-3]):([0-5]\d)$/.test(str);
}

export default function SwitchesScreen({ board, client, connected, pairingKey, onBack, onUpdateBoard }) {
  const { theme } = useTheme();
  const [devices, setDevices] = useState(() => deriveInitialDevices(board));
  const [deviceState, setDeviceState] = useState({}); // { [deviceId]: boolean } — لمفاتيح التشغيل/الإيقاف
  const [boardAvailable, setBoardAvailable] = useState(null); // 'online' | 'offline' | null = مش معروفة
  const [deviceRawStatus, setDeviceRawStatus] = useState({}); // { [deviceId]: string } — لأجهزة الطلوع/النزول

  const [formVisible, setFormVisible] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [fName, setFName] = useState('');
  const [fIcon, setFIcon] = useState('switch');
  const [fOnColor, setFOnColor] = useState(null); // null = لون الثيم الافتراضي
  const [fOffColor, setFOffColor] = useState(null);

  // تايمر لكل مفتاح: التايمر شغال جوه الفيرموير نفسه (مش من التطبيق)، عشان
  // يفضل شغال حتى لو التطبيق مقفول. التطبيق بس بيبعت أمر الإعداد للفيرموير
  // على `<control_topic>/timer/set`، وبيسمع حالة التايمر الحالية من
  // الفيرموير على `<control_topic>/timer/state` (شوف بروتوكول التايمر في
  // README.md) وبيعرضها زي ما هي.
  const [timerModalVisible, setTimerModalVisible] = useState(false);
  const [timerDeviceId, setTimerDeviceId] = useState(null);
  const [timerTab, setTimerTab] = useState('countdown'); // 'countdown' | 'schedule'
  const [countdownInput, setCountdownInput] = useState('30');
  const [scheduleOnInput, setScheduleOnInput] = useState('07:00');
  const [scheduleOffInput, setScheduleOffInput] = useState('22:00');
  const [scheduleEnabledInput, setScheduleEnabledInput] = useState(false);
  const [, forceTick] = useState(0); // بيتحدث كل ثانية عشان يحدّث عرض الوقت المتبقي بين رسايل الفيرموير
  // { [deviceId]: { mode: 'off'|'countdown'|'schedule', secondsLeft, receivedAt, scheduleEnabled, on, off } }
  const [deviceTimerState, setDeviceTimerState] = useState({});

  // مزامنة من الفيرموير: بيعيد الاستماع على نفس توبيك الاكتشاف بتاع البورد
  // (لازم يكون موقّع بنفس مفتاح الربط) ويضيف/يحدّث المفاتيح منه. مفيش أي
  // إضافة يدوية للتوبيكات — كل حاجة جاية من الفيرموير بتاعك فقط.
  const [syncing, setSyncing] = useState(false);
  const [syncError, setSyncError] = useState('');
  const syncTimeoutRef = useRef(null);
  const syncHandlerRef = useRef(null);

  const discoveryTopic = board.discoveryTopic || (board.prefix ? `${board.prefix}/discovery` : null);

  const persistDevices = (list) => {
    setDevices(list);
    onUpdateBoard?.({ ...board, devices: list });
  };

  // أول مرة نفتح بورد قديم اتحوّل لأجهزة، نحفظه بالشكل الجديد على طول
  useEffect(() => {
    if (!board.devices) {
      onUpdateBoard?.({ ...board, devices, relayNames: undefined, relayIcons: undefined, relayCount: undefined });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const statusTopics = useMemo(() => {
    const set = new Set();
    devices.forEach((d) => set.add(d.statusTopic || d.controlTopic));
    return Array.from(set);
  }, [devices]);

  // توبيكات حالة التايمر: `<control_topic>/timer/state` — الفيرموير هو اللي بينشرها (Retained يفضل).
  // مفيش تايمر لأجهزة الطلوع/النزول (updown).
  const timerStateTopics = useMemo(() => {
    const set = new Set();
    devices.forEach((d) => d.controlType !== 'updown' && set.add(`${d.controlTopic}/timer/state`));
    return Array.from(set);
  }, [devices]);

  // حالة "توفر" البورد ده لوحده (مش الاتصال العام بالسيرفر) — بتتقرأ من
  // `<device_id>/availability` اللي الفيرموير بينشرها Retained + كـ Last Will.
  useEffect(() => {
    const topic = boardAvailabilityTopic(board);
    if (!client || !connected || !topic) {
      setBoardAvailable(null);
      return undefined;
    }

    client.subscribe(topic);
    const handler = (t, payload) => {
      if (t !== topic) return;
      const state = parseAvailability(payload.toString());
      if (state) setBoardAvailable(state);
    };
    client.on('message', handler);

    return () => {
      client.off('message', handler);
      client.unsubscribe(topic);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client, connected, board.deviceId]);

  useEffect(() => {
    if (!client || statusTopics.length === 0) return undefined;

    statusTopics.forEach((t) => client.subscribe(t));

    const handler = (topic, payload) => {
      const raw = payload.toString();
      const msg = raw.trim().toUpperCase();
      const isOn = msg === 'ON' || msg === '1' || msg === 'TRUE';
      const isOff = msg === 'OFF' || msg === '0' || msg === 'FALSE';

      devices.forEach((d) => {
        if ((d.statusTopic || d.controlTopic) !== topic) return;
        if (d.controlType === 'updown') {
          setDeviceRawStatus((prev) => ({ ...prev, [d.id]: raw.trim() }));
        } else if (isOn || isOff) {
          setDeviceState((prev) => ({ ...prev, [d.id]: isOn }));
        }
      });
    };

    client.on('message', handler);
    return () => {
      client.off('message', handler);
      statusTopics.forEach((t) => client.unsubscribe(t));
    };
  }, [client, statusTopics, devices]);

  useEffect(() => {
    if (!client || timerStateTopics.length === 0) return undefined;

    timerStateTopics.forEach((t) => client.subscribe(t));

    const handler = (topic, payload) => {
      const device = devices.find((d) => `${d.controlTopic}/timer/state` === topic);
      if (!device) return;
      let data;
      try {
        data = JSON.parse(payload.toString());
      } catch (e) {
        return; // رسالة تايمر مش JSON صحيح — اتجاهلها
      }
      setDeviceTimerState((prev) => ({
        ...prev,
        [device.id]: {
          mode: data.mode === 'countdown' || data.mode === 'schedule' ? data.mode : 'off',
          secondsLeft: typeof data.seconds_left === 'number' ? data.seconds_left : null,
          receivedAt: Date.now(),
          scheduleEnabled: !!data.schedule_enabled,
          on: typeof data.on === 'string' ? data.on : null,
          off: typeof data.off === 'string' ? data.off : null,
        },
      }));
    };

    client.on('message', handler);
    return () => {
      client.off('message', handler);
      timerStateTopics.forEach((t) => client.unsubscribe(t));
    };
  }, [client, timerStateTopics, devices]);

  const cleanupSync = () => {
    if (syncTimeoutRef.current) {
      clearTimeout(syncTimeoutRef.current);
      syncTimeoutRef.current = null;
    }
    if (client && discoveryTopic && syncHandlerRef.current) {
      client.off('message', syncHandlerRef.current);
      client.unsubscribe(discoveryTopic);
    }
    syncHandlerRef.current = null;
  };

  useEffect(() => cleanupSync, []); // eslint-disable-line react-hooks/exhaustive-deps

  const startSync = () => {
    if (!discoveryTopic) {
      Alert.alert('خطأ', 'البورد ده مضاف قديم ومش متسجل عليه توبيك اكتشاف — احذفه وأضفه تاني بالاكتشاف التلقائي.');
      return;
    }
    if (!pairingKey) {
      Alert.alert('خطأ', 'لازم تحط مفتاح الربط (Pairing Key) في الإعدادات الأول');
      return;
    }
    if (!client || !connected) {
      Alert.alert('خطأ', 'لسه مش متصل بالسيرفر، استنى ثانية وحاول تاني');
      return;
    }

    cleanupSync();
    setSyncError('');
    setSyncing(true);
    client.subscribe(discoveryTopic);

    const handler = (t, payload) => {
      if (t !== discoveryTopic) return;
      const result = parseBoardDiscovery(payload.toString(), pairingKey);
      cleanupSync();
      setSyncing(false);
      if (!result.ok) {
        setSyncError(result.error);
        return;
      }
      if (result.board.type !== 'switches') {
        setSyncError('رسالة الاكتشاف اللي وصلت مش لبورد لوحة مفاتيح.');
        return;
      }
      const incoming = result.board.devices;
      let addedCount = 0;
      let updatedCount = 0;
      const byTopic = new Map(devices.map((d) => [d.controlTopic, d]));
      const merged = devices.map((d) => {
        const inc = byTopic.get(d.controlTopic) && incoming.find((i) => i.controlTopic === d.controlTopic);
        if (!inc) return d;
        updatedCount += 1;
        return { ...d, name: inc.name, icon: inc.icon, controlType: inc.controlType, statusTopic: inc.statusTopic };
      });
      incoming.forEach((inc) => {
        if (!byTopic.has(inc.controlTopic)) {
          addedCount += 1;
          merged.push({ id: newId(), ...inc });
        }
      });
      persistDevices(merged);
      Alert.alert('تمت المزامنة', `تمت إضافة ${addedCount} مفتاح جديد وتحديث ${updatedCount} مفتاح موجود.`);
    };
    syncHandlerRef.current = handler;
    client.on('message', handler);

    syncTimeoutRef.current = setTimeout(() => {
      cleanupSync();
      setSyncing(false);
      setSyncError('مفيش رد من الفيرموير. اتأكد إنها شغالة ومتصلة وناشرة رسالة الاكتشاف Retained.');
    }, SYNC_TIMEOUT_MS);
  };

  const toggleDevice = (device) => {
    const current = !!deviceState[device.id];
    client?.publish(device.controlTopic, current ? 'OFF' : 'ON');
    // تحديث تفاؤلي للواجهة لحد ما يوصل رد الحالة من الجهاز
    if (!device.statusTopic || device.statusTopic === device.controlTopic) {
      setDeviceState((prev) => ({ ...prev, [device.id]: !current }));
    }
  };

  const moveDevice = (device, direction) => client?.publish(device.controlTopic, direction);

  // بروتوكول التايمر (شوف README.md "بروتوكول التايمر"):
  // أمر يتبعت على `<control_topic>/timer/set` كـ JSON، والفيرموير هو اللي بينفذه ويحتفظ بيه.
  const publishTimerCommand = (device, payload) => {
    client?.publish(`${device.controlTopic}/timer/set`, JSON.stringify(payload));
  };

  const startCountdown = (device, minutesStr) => {
    const mins = Math.max(1, parseInt(minutesStr, 10) || 0);
    if (!mins) {
      Alert.alert('خطأ', 'اكتب عدد دقايق صحيح');
      return;
    }
    publishTimerCommand(device, { mode: 'countdown', minutes: mins });
    setTimerModalVisible(false);
  };

  const cancelCountdown = (device) => {
    publishTimerCommand(device, { mode: 'off' });
  };

  const saveSchedule = (device, onTime, offTime, enabled) => {
    if (enabled && (!isValidHHMM(onTime) || !isValidHHMM(offTime))) {
      Alert.alert('خطأ', 'اكتب الوقت بصيغة صحيحة زي 07:00 (24 ساعة)');
      return;
    }
    publishTimerCommand(device, { mode: 'schedule', enabled, on: onTime, off: offTime });
    setTimerModalVisible(false);
  };

  const openTimerModal = (device) => {
    const st = deviceTimerState[device.id];
    setTimerDeviceId(device.id);
    setTimerTab('countdown');
    setCountdownInput(st?.mode === 'countdown' && st.secondsLeft ? String(Math.ceil(st.secondsLeft / 60)) : '30');
    setScheduleOnInput(st?.on || '07:00');
    setScheduleOffInput(st?.off || '22:00');
    setScheduleEnabledInput(!!st?.scheduleEnabled);
    setTimerModalVisible(true);
  };

  // بيحدّث العرض كل ثانية طول ما فيه عد تنازلي شغال، عشان نعرض الوقت المتبقي وهو بينزل
  // بين رسالة وتانية من الفيرموير (interpolation)، مش إنه هو اللي بيتحكم في المفتاح.
  useEffect(() => {
    const hasActive = Object.values(deviceTimerState).some((s) => s.mode === 'countdown');
    if (!hasActive) return undefined;
    const id = setInterval(() => forceTick((t) => t + 1), 1000);
    return () => clearInterval(id);
  }, [deviceTimerState]);

  const getCountdownLabel = (device) => {
    const st = deviceTimerState[device.id];
    if (!st || st.mode !== 'countdown' || st.secondsLeft == null) return null;
    const elapsed = Math.floor((Date.now() - st.receivedAt) / 1000);
    const remaining = st.secondsLeft - elapsed;
    if (remaining <= 0) return null;
    const m = Math.floor(remaining / 60);
    const s = remaining % 60;
    return `${m}:${String(s).padStart(2, '0')}`;
  };

  const allOn = () =>
    devices.forEach((d) => d.controlType !== 'updown' && client?.publish(d.controlTopic, 'ON'));
  const allOff = () =>
    devices.forEach((d) => (d.controlType === 'updown' ? client?.publish(d.controlTopic, 'STOP') : client?.publish(d.controlTopic, 'OFF')));

  const openEditForm = (device) => {
    setEditingId(device.id);
    setFName(device.name);
    setFIcon(device.icon || 'switch');
    setFOnColor(device.onColor || null);
    setFOffColor(device.offColor || null);
    setFormVisible(true);
  };

  const deleteDevice = (id) => {
    Alert.alert('حذف المفتاح', 'متأكد إنك عايز تمسح المفتاح ده؟ (لو الفيرموير لسه بينشره، هيرجع تاني أول مزامنة)', [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'مسح',
        style: 'destructive',
        onPress: () => persistDevices(devices.filter((d) => d.id !== id)),
      },
    ]);
  };

  const saveForm = () => {
    if (!editingId) return;
    const current = devices.find((d) => d.id === editingId);
    if (!current) return;
    const payload = {
      name: fName.trim() || current.name,
      icon: fIcon,
      onColor: current.controlType === 'toggle' ? fOnColor || undefined : undefined,
      offColor: current.controlType === 'toggle' ? fOffColor || undefined : undefined,
    };
    persistDevices(devices.map((d) => (d.id === editingId ? { ...d, ...payload } : d)));
    setFormVisible(false);
  };

  const styles = getStyles(theme);
  const editingDevice = devices.find((d) => d.id === editingId);
  const timerDevice = devices.find((d) => d.id === timerDeviceId);
  const timerDeviceState = timerDevice ? deviceTimerState[timerDevice.id] : null;
  const activeCountdownLabel = timerDevice ? getCountdownLabel(timerDevice) : null;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={onBack}>
          <Text style={styles.back}>‹ رجوع</Text>
        </TouchableOpacity>
        <Text style={styles.title}>{board.name}</Text>
        <View style={{ width: 50 }} />
      </View>

      <View style={styles.statusRow}>
        <View style={[styles.dot, { backgroundColor: connected ? theme.on : theme.off }]} />
        <Text style={styles.statusLabel}>
          {connected ? 'متصل بالسيرفر' : 'جاري الاتصال…'}
          {connected && boardAvailabilityTopic(board)
            ? `  •  البورد: ${boardAvailable === 'online' ? 'أونلاين' : boardAvailable === 'offline' ? 'أوفلاين' : 'غير معروف'}`
            : ''}
        </Text>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 60 }}>
        {devices.length > 0 && (
          <View style={styles.btnRow}>
            <TouchableOpacity style={[styles.smallBtn, styles.onBtn]} onPress={allOn}>
              <Text style={styles.btnText}>تشغيل الكل</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.smallBtn, styles.offBtn]} onPress={allOff}>
              <Text style={styles.btnText}>إيقاف الكل</Text>
            </TouchableOpacity>
          </View>
        )}

        {devices.length === 0 && (
          <Text style={styles.emptyText}>
            مفيش مفاتيح لسه في البورد ده. دوس "🔄 مزامنة من الفيرموير" عشان الفيرموير يبعت المفاتيح تلقائي.
          </Text>
        )}

        <View style={styles.grid}>
          {devices.map((device) => (
            <DeviceCard
              key={device.id}
              device={device}
              theme={theme}
              isOn={!!deviceState[device.id]}
              rawStatus={deviceRawStatus[device.id]}
              countdownLabel={getCountdownLabel(device)}
              scheduleActive={!!deviceTimerState[device.id]?.scheduleEnabled}
              onToggle={() => toggleDevice(device)}
              onEdit={() => openEditForm(device)}
              onDelete={() => deleteDevice(device.id)}
              onUp={() => moveDevice(device, 'UP')}
              onStop={() => moveDevice(device, 'STOP')}
              onDown={() => moveDevice(device, 'DOWN')}
              onOpenTimer={() => openTimerModal(device)}
            />
          ))}
        </View>

        {syncing && (
          <View style={styles.syncRow}>
            <ActivityIndicator color={theme.accent} />
            <Text style={styles.listeningHint}>بيزامن مع الفيرموير…</Text>
          </View>
        )}
        {!!syncError && <Text style={styles.errorText}>⚠ {syncError}</Text>}

        <View style={styles.btnRow}>
          <TouchableOpacity
            style={[styles.addBtn, styles.discoverBtn, { flex: 1 }]}
            onPress={startSync}
            disabled={syncing}
          >
            <Text style={styles.discoverBtnText}>🔄 مزامنة من الفيرموير</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* مودال تعديل شكل المفتاح — الاسم والأيقونة والألوان بس، مش التوبيكات.
          التوبيكات بتيجي من الفيرموير عن طريق الاكتشاف الموقّع فقط. */}
      <Modal visible={formVisible} transparent animationType="fade" onRequestClose={() => setFormVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <ScrollView keyboardShouldPersistTaps="handled">
              <Text style={styles.modalTitle}>تعديل شكل المفتاح</Text>

              <Text style={styles.label}>اسم المفتاح</Text>
              <TextInput
                style={styles.input}
                value={fName}
                onChangeText={setFName}
                placeholder="لمبة الصالة"
                placeholderTextColor={theme.textMuted}
              />

              <Text style={styles.label}>توبيك التحكم (من الفيرموير — مش قابل للتعديل)</Text>
              <View style={styles.codeBox}>
                <Text style={styles.codeText}>{editingDevice?.controlTopic}</Text>
              </View>

              <Text style={styles.label}>توبيك الحالة (من الفيرموير)</Text>
              <View style={styles.codeBox}>
                <Text style={styles.codeText}>{editingDevice?.statusTopic || editingDevice?.controlTopic}</Text>
              </View>

              {editingDevice?.controlType !== 'updown' && (
                <>
                  <Text style={styles.label}>لون حالة التشغيل (ON)</Text>
                  <ColorPickerRow styles={styles} themeColor={theme.on} value={fOnColor} onChange={setFOnColor} />

                  <Text style={styles.label}>لون حالة الإيقاف (OFF)</Text>
                  <ColorPickerRow styles={styles} themeColor={theme.off} value={fOffColor} onChange={setFOffColor} />
                </>
              )}

              <Text style={styles.label}>شكل المفتاح</Text>
              <FlatList
                data={DEVICE_ICONS}
                keyExtractor={(item) => item.id}
                numColumns={5}
                scrollEnabled={false}
                contentContainerStyle={{ marginTop: 4 }}
                renderItem={({ item }) => {
                  const selected = fIcon === item.id;
                  return (
                    <TouchableOpacity
                      style={[styles.iconOption, selected && styles.iconOptionSelected]}
                      onPress={() => setFIcon(item.id)}
                    >
                      <MaterialCommunityIcons
                        name={item.icon}
                        size={24}
                        color={selected ? theme.on : theme.textPrimary}
                      />
                      <Text style={styles.iconOptionLabel} numberOfLines={1}>
                        {item.label}
                      </Text>
                    </TouchableOpacity>
                  );
                }}
              />

              <View style={styles.btnRow}>
                <TouchableOpacity style={[styles.smallBtn, styles.onBtn]} onPress={saveForm}>
                  <Text style={styles.btnText}>حفظ</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.smallBtn, styles.offBtn]} onPress={() => setFormVisible(false)}>
                  <Text style={styles.btnText}>إلغاء</Text>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* مودال التايمر: عد تنازلي (يقفل بعد مدة) أو جدولة يومية (يشتغل ويقفل في وقت معين) */}
      <Modal visible={timerModalVisible} transparent animationType="fade" onRequestClose={() => setTimerModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <ScrollView keyboardShouldPersistTaps="handled">
              <Text style={styles.modalTitle}>تايمر — {timerDevice?.name}</Text>

              <View style={styles.tabRow}>
                <TouchableOpacity
                  style={[styles.tabBtn, timerTab === 'countdown' && styles.tabBtnActive]}
                  onPress={() => setTimerTab('countdown')}
                >
                  <Text style={[styles.tabBtnText, timerTab === 'countdown' && styles.tabBtnTextActive]}>
                    عد تنازلي
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.tabBtn, timerTab === 'schedule' && styles.tabBtnActive]}
                  onPress={() => setTimerTab('schedule')}
                >
                  <Text style={[styles.tabBtnText, timerTab === 'schedule' && styles.tabBtnTextActive]}>
                    جدولة يومية
                  </Text>
                </TouchableOpacity>
              </View>

              {timerTab === 'countdown' ? (
                <>
                  <Text style={styles.label}>هيشتغل المفتاح دلوقتي ويقفل لوحده بعد كام دقيقة؟</Text>
                  <TextInput
                    style={styles.input}
                    value={countdownInput}
                    onChangeText={setCountdownInput}
                    keyboardType="number-pad"
                    placeholder="30"
                    placeholderTextColor={theme.textMuted}
                  />
                  <Text style={styles.hint}>
                    الأمر بيتبعت للفيرموير وهو اللي بيحسب العد التنازلي ويقفل المفتاح — يفضل شغال حتى لو قفلت التطبيق.
                  </Text>

                  {activeCountdownLabel && (
                    <Text style={[styles.hint, { color: theme.accentSoft, marginTop: 8 }]}>
                      متبقي دلوقتي: {activeCountdownLabel}
                    </Text>
                  )}

                  <View style={styles.btnRow}>
                    <TouchableOpacity
                      style={[styles.smallBtn, styles.onBtn]}
                      onPress={() => timerDevice && startCountdown(timerDevice, countdownInput)}
                    >
                      <Text style={styles.btnText}>ابدأ العد التنازلي</Text>
                    </TouchableOpacity>
                    {timerDeviceState?.mode === 'countdown' && (
                      <TouchableOpacity
                        style={[styles.smallBtn, styles.offBtn]}
                        onPress={() => {
                          cancelCountdown(timerDevice);
                          setTimerModalVisible(false);
                        }}
                      >
                        <Text style={styles.btnText}>إلغاء التايمر</Text>
                      </TouchableOpacity>
                    )}
                  </View>
                </>
              ) : (
                <>
                  <TouchableOpacity
                    style={styles.syncRow}
                    onPress={() => setScheduleEnabledInput((v) => !v)}
                  >
                    <MaterialCommunityIcons
                      name={scheduleEnabledInput ? 'toggle-switch' : 'toggle-switch-off-outline'}
                      size={30}
                      color={scheduleEnabledInput ? theme.accent : theme.textMuted}
                    />
                    <Text style={styles.statusLabel}>{scheduleEnabledInput ? 'الجدولة مفعّلة' : 'الجدولة متوقفة'}</Text>
                  </TouchableOpacity>

                  <Text style={styles.label}>وقت التشغيل (24 ساعة، مثال 07:00)</Text>
                  <TextInput
                    style={styles.input}
                    value={scheduleOnInput}
                    onChangeText={setScheduleOnInput}
                    placeholder="07:00"
                    placeholderTextColor={theme.textMuted}
                  />

                  <Text style={styles.label}>وقت الإيقاف (24 ساعة، مثال 22:00)</Text>
                  <TextInput
                    style={styles.input}
                    value={scheduleOffInput}
                    onChangeText={setScheduleOffInput}
                    placeholder="22:00"
                    placeholderTextColor={theme.textMuted}
                  />
                  <Text style={styles.hint}>
                    بيتكرر كل يوم في نفس الميعاد — محسوب جوه الفيرموير نفسه، فمش لازم التطبيق يكون فاتح وقت الميعاد.
                  </Text>

                  <View style={styles.btnRow}>
                    <TouchableOpacity
                      style={[styles.smallBtn, styles.onBtn]}
                      onPress={() =>
                        timerDevice && saveSchedule(timerDevice, scheduleOnInput, scheduleOffInput, scheduleEnabledInput)
                      }
                    >
                      <Text style={styles.btnText}>حفظ</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.smallBtn, styles.offBtn]} onPress={() => setTimerModalVisible(false)}>
                      <Text style={styles.btnText}>إلغاء</Text>
                    </TouchableOpacity>
                  </View>
                </>
              )}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}
// كارت جهاز واحد — بيدير نبضة الضوء (الـ glow) بنفسه لما يكون شغال، وبيرسم لوحة طلوع/نزول للأجهزة المتحركة
function DeviceCard({
  device,
  theme,
  isOn,
  rawStatus,
  countdownLabel,
  scheduleActive,
  onToggle,
  onEdit,
  onDelete,
  onUp,
  onStop,
  onDown,
  onOpenTimer,
}) {
  const pulse = useRef(new Animated.Value(0)).current;
  const isUpdown = device.controlType === 'updown';
  const iconDef = getDeviceIcon(device.icon);
  const onColor = device.onColor || theme.on;
  const offColor = device.offColor || theme.off;
  const color = isUpdown ? theme.accentSoft : isOn ? onColor : offColor;
  const styles = getStyles(theme);

  useEffect(() => {
    if (isUpdown || !isOn) {
      pulse.setValue(0);
      return undefined;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 900, useNativeDriver: false }),
        Animated.timing(pulse, { toValue: 0, duration: 900, useNativeDriver: false }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [isOn, isUpdown, pulse]);

  const glowOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.55, 1] });
  const glowScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.08] });

  return (
    <View style={[styles.card, { borderColor: isOn || isUpdown ? theme.accent : theme.border }]}>
      <View style={styles.cardTopRow}>
        {!isUpdown && (
          <TouchableOpacity onPress={onOpenTimer}>
            <MaterialCommunityIcons
              name={countdownLabel || scheduleActive ? 'timer' : 'timer-outline'}
              size={16}
              color={countdownLabel || scheduleActive ? theme.accentSoft : theme.textSecondary}
            />
          </TouchableOpacity>
        )}
        <TouchableOpacity onPress={onEdit}>
          <MaterialCommunityIcons name="pencil-outline" size={16} color={theme.textSecondary} />
        </TouchableOpacity>
        <TouchableOpacity onPress={onDelete}>
          <MaterialCommunityIcons name="trash-can-outline" size={16} color={theme.danger} />
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.iconWrap} onPress={onEdit} activeOpacity={0.7}>
        <Animated.View
          style={[
            styles.iconGlow,
            {
              borderColor: color,
              shadowColor: color,
              opacity: isOn && !isUpdown ? glowOpacity : 1,
              transform: [{ scale: isOn && !isUpdown ? glowScale : 1 }],
            },
          ]}
        >
          <MaterialCommunityIcons name={iconDef.icon} size={40} color={color} />
        </Animated.View>
      </TouchableOpacity>

      <Text style={styles.deviceName} numberOfLines={1}>
        {device.name}
      </Text>
      <Text style={styles.deviceTopic} numberOfLines={1}>
        {device.controlTopic}
      </Text>

      {!isUpdown && (countdownLabel || scheduleActive) && (
        <Text style={[styles.deviceTopic, { color: theme.accentSoft }]} numberOfLines={1}>
          {countdownLabel ? `⏱ باقي ${countdownLabel}` : '🕐 مجدول يوميًا'}
        </Text>
      )}

      {isUpdown ? (
        <>
          <View style={styles.updownRow}>
            <TouchableOpacity style={[styles.updownBtn, { backgroundColor: theme.accent }]} onPress={onUp}>
              <MaterialCommunityIcons name="chevron-up" size={20} color="#fff" />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.updownBtn, styles.updownStopBtn]} onPress={onStop}>
              <MaterialCommunityIcons name="stop" size={14} color={theme.textSecondary} />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.updownBtn, { backgroundColor: theme.danger }]} onPress={onDown}>
              <MaterialCommunityIcons name="chevron-down" size={20} color="#fff" />
            </TouchableOpacity>
          </View>
          {!!rawStatus && (
            <Text style={styles.deviceTopic} numberOfLines={1}>
              آخر حالة: {rawStatus}
            </Text>
          )}
        </>
      ) : (
        <TouchableOpacity
          style={[styles.pill, { borderColor: color, backgroundColor: isOn ? theme.cardAlt : theme.cardAlt }]}
          onPress={onToggle}
        >
          <View style={[styles.pillDot, { backgroundColor: color }]} />
          <Text style={[styles.pillText, { color }]}>{isOn ? 'ON' : 'OFF'}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

// صف اختيار لون: أول خيار "افتراضي" (لون الثيم)، وبعده باليتة الألوان الجاهزة
function ColorPickerRow({ styles, themeColor, value, onChange }) {
  return (
    <View style={styles.colorRow}>
      <TouchableOpacity
        style={[styles.colorSwatch, { backgroundColor: themeColor }, value === null && styles.colorSwatchSelected]}
        onPress={() => onChange(null)}
      >
        {value === null && <MaterialCommunityIcons name="check" size={14} color="#fff" />}
      </TouchableOpacity>
      {COLOR_SWATCHES.map((c) => (
        <TouchableOpacity
          key={c}
          style={[styles.colorSwatch, { backgroundColor: c }, value === c && styles.colorSwatchSelected]}
          onPress={() => onChange(c)}
        >
          {value === c && <MaterialCommunityIcons name="check" size={14} color="#0f1712" />}
        </TouchableOpacity>
      ))}
    </View>
  );
}

function getStyles(theme) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: theme.bg, padding: 18, paddingTop: 55 },
    headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
    back: { color: theme.accentSoft, fontSize: 15 },
    title: { color: theme.textPrimary, fontSize: 18, fontWeight: '700' },
    statusRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
    dot: { width: 10, height: 10, borderRadius: 5, marginRight: 8 },
    statusLabel: { color: theme.textSecondary, fontSize: 13 },
    btnRow: { flexDirection: 'row', gap: 10, marginBottom: 14 },
    smallBtn: { flex: 1, borderRadius: 10, paddingVertical: 12, alignItems: 'center' },
    onBtn: { backgroundColor: theme.accent },
    offBtn: { backgroundColor: theme.danger },
    emptyText: { color: theme.textSecondary, textAlign: 'center', marginTop: 20, marginBottom: 10, fontSize: 13, lineHeight: 20 },

    grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
    card: {
      backgroundColor: theme.card,
      borderRadius: 16,
      borderWidth: 1,
      width: '48%',
      padding: 14,
      marginBottom: 12,
      alignItems: 'center',
    },
    cardTopRow: { flexDirection: 'row', justifyContent: 'space-between', width: '100%' },
    iconWrap: { marginTop: 8, marginBottom: 10 },
    iconGlow: {
      width: 74,
      height: 74,
      borderRadius: 37,
      borderWidth: 1.5,
      alignItems: 'center',
      justifyContent: 'center',
      shadowOpacity: 0.9,
      shadowRadius: 12,
      shadowOffset: { width: 0, height: 0 },
      elevation: 7,
    },
    deviceName: { color: theme.textPrimary, fontSize: 14, fontWeight: '600', textAlign: 'center' },
    deviceTopic: { color: theme.textMuted, fontSize: 10, marginBottom: 6, textAlign: 'center' },
    pill: {
      flexDirection: 'row',
      alignItems: 'center',
      borderWidth: 1,
      borderRadius: 20,
      paddingHorizontal: 14,
      paddingVertical: 6,
      gap: 6,
      marginTop: 4,
    },
    pillDot: { width: 8, height: 8, borderRadius: 4 },
    pillText: { fontSize: 12, fontWeight: '700' },

    updownRow: { flexDirection: 'row', gap: 8, marginTop: 4, marginBottom: 4 },
    updownBtn: {
      width: 40,
      height: 34,
      borderRadius: 10,
      alignItems: 'center',
      justifyContent: 'center',
    },
    updownStopBtn: { backgroundColor: theme.cardAlt, borderWidth: 1, borderColor: theme.border },

    addBtn: { borderWidth: 1, borderColor: theme.accent, borderRadius: 12, paddingVertical: 14, alignItems: 'center', marginTop: 6 },
    addBtnText: { color: theme.accentSoft, fontWeight: '700', fontSize: 15 },
    discoverBtn: { borderColor: theme.accentSoft },
    discoverBtnText: { color: theme.accentSoft, fontWeight: '700', fontSize: 15 },
    listeningHint: { color: theme.accentSoft, fontSize: 11, marginBottom: 10, textAlign: 'center' },
    syncRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 6, marginBottom: 4 },
    discoveredRow: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: theme.bg,
      borderRadius: 10,
      padding: 10,
      marginBottom: 8,
      borderWidth: 1,
      borderColor: theme.border,
    },
    discoveredRowSelected: { borderColor: theme.accent },
    discoveredTopic: { color: theme.textPrimary, fontSize: 13, fontWeight: '600' },
    discoveredPayload: { color: theme.textSecondary, fontSize: 11, marginTop: 2 },

    tabRow: { flexDirection: 'row', gap: 8, marginBottom: 12 },
    tabBtn: { flex: 1, borderRadius: 10, paddingVertical: 10, alignItems: 'center', backgroundColor: theme.bg, borderWidth: 1, borderColor: theme.border },
    tabBtnActive: { backgroundColor: theme.accent, borderColor: theme.accent },
    tabBtnText: { color: theme.textSecondary, fontSize: 12, fontWeight: '700' },
    tabBtnTextActive: { color: '#fff' },
    codeBox: { backgroundColor: theme.bg, borderRadius: 10, padding: 10, marginBottom: 8, borderWidth: 1, borderColor: theme.border },
    codeText: { color: theme.accentSoft, fontSize: 11, fontFamily: 'monospace' },
    errorText: { color: theme.off, fontSize: 12, marginBottom: 8, textAlign: 'center' },

    colorRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 4, marginBottom: 4 },
    colorSwatch: {
      width: 30,
      height: 30,
      borderRadius: 15,
      alignItems: 'center',
      justifyContent: 'center',
      borderWidth: 2,
      borderColor: 'transparent',
    },
    colorSwatchSelected: { borderColor: theme.textPrimary },

    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', padding: 20 },
    modalBox: { backgroundColor: theme.cardAlt, borderRadius: 16, padding: 16, maxHeight: '85%' },
    modalTitle: { color: theme.textPrimary, fontSize: 16, fontWeight: '700', marginBottom: 10, textAlign: 'center' },
    label: { color: theme.textSecondary, fontSize: 12, marginTop: 10, marginBottom: 6 },
    hint: { color: theme.textMuted, fontSize: 10, marginTop: 4 },
    input: { backgroundColor: theme.bg, color: theme.textPrimary, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10 },
    iconOption: { width: '20%', alignItems: 'center', paddingVertical: 10, borderRadius: 10 },
    iconOptionSelected: { backgroundColor: theme.bg },
    iconOptionLabel: { color: theme.textSecondary, fontSize: 8, marginTop: 4, textAlign: 'center' },
  });
}
