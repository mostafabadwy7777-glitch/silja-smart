import React from 'react';
import { SafeAreaView, ScrollView, View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { THEMES } from '../theme';
import { useTheme } from '../ThemeContext';

export default function ThemeScreen({ onBack }) {
  const { theme, themeId, setThemeId } = useTheme();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={onBack}>
          <Text style={[styles.back, { color: theme.accentSoft }]}>‹ رجوع</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: theme.textPrimary }]}>الثيمات والمظهر</Text>
        <View style={{ width: 50 }} />
      </View>

      <Text style={[styles.hint, { color: theme.textSecondary }]}>
        اختار الشكل اللي يعجبك، هيتطبق على كل شاشات التطبيق فورًا. تقدر كمان تحدد لون كل مفتاح لوحده من داخل شاشة
        المفاتيح.
      </Text>

      <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
        {THEMES.map((t) => {
          const selected = t.id === themeId;
          return (
            <TouchableOpacity
              key={t.id}
              onPress={() => setThemeId(t.id)}
              activeOpacity={0.85}
              style={[styles.card, { backgroundColor: t.card, borderColor: selected ? t.accent : t.border }]}
            >
              <View style={styles.cardTop}>
                <Text style={[styles.themeName, { color: t.textPrimary }]}>{t.name}</Text>
                {selected ? (
                  <MaterialCommunityIcons name="check-circle" size={22} color={t.accent} />
                ) : (
                  <MaterialCommunityIcons name="circle-outline" size={22} color={t.border} />
                )}
              </View>

              <View style={styles.swatchRow}>
                <View style={[styles.swatch, { backgroundColor: t.bg, borderColor: t.border }]} />
                <View style={[styles.swatch, { backgroundColor: t.accent, shadowColor: t.accent }]} />
                <View style={[styles.swatch, { backgroundColor: t.on, shadowColor: t.on }]} />
                <View style={[styles.swatch, { backgroundColor: t.off, shadowColor: t.off }]} />
              </View>

              <View style={styles.previewRow}>
                <View style={[styles.previewGlow, { borderColor: t.on, shadowColor: t.on, backgroundColor: t.cardAlt }]}>
                  <MaterialCommunityIcons name="lightbulb-on" size={22} color={t.on} />
                </View>
                <Text style={[styles.previewLabel, { color: t.textSecondary }]}>شغال</Text>
                <View style={[styles.previewGlow, { borderColor: t.off, shadowColor: t.off, backgroundColor: t.cardAlt }]}>
                  <MaterialCommunityIcons name="lightbulb-off-outline" size={22} color={t.off} />
                </View>
                <Text style={[styles.previewLabel, { color: t.textSecondary }]}>مطفي</Text>
              </View>
            </TouchableOpacity>
          );
        })}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 18, paddingTop: 55 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  back: { fontSize: 15 },
  title: { fontSize: 18, fontWeight: '700' },
  hint: { fontSize: 12, marginBottom: 16, lineHeight: 18 },
  card: { borderRadius: 16, borderWidth: 1.5, padding: 16, marginBottom: 14 },
  cardTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  themeName: { fontSize: 16, fontWeight: '700' },
  swatchRow: { flexDirection: 'row', gap: 8, marginBottom: 14 },
  swatch: {
    width: 28,
    height: 28,
    borderRadius: 8,
    borderWidth: 1,
    shadowOpacity: 0.8,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 0 },
    elevation: 3,
  },
  previewRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  previewGlow: {
    width: 42,
    height: 42,
    borderRadius: 21,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
    shadowOpacity: 0.9,
    shadowRadius: 9,
    shadowOffset: { width: 0, height: 0 },
    elevation: 5,
  },
  previewLabel: { fontSize: 11, fontWeight: '700', marginRight: 6 },
});
