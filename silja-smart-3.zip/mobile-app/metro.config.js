// ============================================================================
// إعداد Metro (الـ bundler بتاع Expo/React Native) عشان يعرف يلاقي مكافئات
// متوافقة مع React Native لمكونات Node اللي مكتبة "mqtt" بتحتاجها
// (stream, events) واللي مش موجودة أصلاً في بيئة الموبايل.
// ============================================================================
const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

config.resolver.extraNodeModules = {
  ...(config.resolver.extraNodeModules || {}),
  stream: require.resolve('readable-stream'),
  events: require.resolve('events'),
  buffer: require.resolve('buffer'),
};

module.exports = config;
