// ============================================================================
// سجل انقطاع الكهربا — امتى قطعت وخدت قد إيه.
// ============================================================================
// الفيرموير بيحسب الانقطاع بنفسه (بيسجل "آخر وقت كان شغال" في الفلاش، ولما الكهربا
// ترجع بيحسب المدة) وبينشرها Retained على `<device_id>/outage`. التطبيق بيشترك فيها
// ويحفظ السجل محليًا (بدون تكرار)، فحتى لو التطبيق كان مقفول وقت الانقطاع هتلاقيه
// أول ما تفتحه (آخر انقطاع بس بيتحفظ على البروكر؛ الأقدم منه بيتخزن لو التطبيق شافه).
// outages[boardId] = [{ start, end, dur }]  (ms، الأحدث الأول)
// ============================================================================
import { useCallback, useEffect, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { boardOutageTopic, parseOutage } from './discovery';

const KEY = 'silja_power_outages_v1';
const MAX_PER_BOARD = 100;

async function load() {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch (_) {
    return {};
  }
}

function save(data) {
  return AsyncStorage.setItem(KEY, JSON.stringify(data)).catch(() => {});
}

// "ساعتين و5 دقايق" / "3 دقايق و20 ثانية" / "40 ثانية"
export function formatDuration(ms) {
  const total = Math.max(0, Math.round(ms / 1000));
  const d = Math.floor(total / 86400);
  const h = Math.floor((total % 86400) / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  const parts = [];
  if (d) parts.push(`${d} يوم`);
  if (h) parts.push(`${h} ساعة`);
  if (m && !d) parts.push(`${m} دقيقة`);
  if (s && !d && !h) parts.push(`${s} ثانية`);
  return parts.length ? parts.join(' و') : '0 ثانية';
}

export function usePowerOutages(client, connected, boards = []) {
  const [outages, setOutages] = useState({});
  const ref = useRef({});
  const loadedRef = useRef(false);
  const queueRef = useRef([]);

  const add = useCallback((boardId, ev) => {
    const list = ref.current[boardId] || [];
    if (list.some((e) => e.start === ev.start)) return; // اتسجل قبل كده
    const next = { ...ref.current, [boardId]: [ev, ...list].sort((a, b) => b.start - a.start).slice(0, MAX_PER_BOARD) };
    ref.current = next;
    setOutages(next);
    save(next);
  }, []);

  useEffect(() => {
    let alive = true;
    load().then((saved) => {
      if (!alive) return;
      ref.current = saved;
      loadedRef.current = true;
      setOutages(saved);
      queueRef.current.forEach((q) => add(q.boardId, q.ev));
      queueRef.current = [];
    });
    return () => { alive = false; };
  }, [add]);

  const key = boards.map((b) => `${b.id}:${boardOutageTopic(b)}`).join(',');

  useEffect(() => {
    if (!client || !connected) return undefined;
    const topicToIds = new Map();
    boards.forEach((b) => {
      const t = boardOutageTopic(b);
      if (!t) return;
      if (!topicToIds.has(t)) topicToIds.set(t, []);
      topicToIds.get(t).push(b.id);
    });
    if (topicToIds.size === 0) return undefined;
    const topics = Array.from(topicToIds.keys());
    topics.forEach((t) => { try { client.subscribe(t); } catch (_) {} });
    const handler = (topic, payload) => {
      const ids = topicToIds.get(topic);
      if (!ids) return;
      const ev = parseOutage(payload);
      if (!ev) return;
      ids.forEach((boardId) => {
        if (!loadedRef.current) queueRef.current.push({ boardId, ev });
        else add(boardId, ev);
      });
    };
    client.on('message', handler);
    return () => {
      client.off('message', handler);
      topics.forEach((t) => { try { client.unsubscribe(t); } catch (_) {} });
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client, connected, key, add]);

  const reset = useCallback(() => {
    ref.current = {};
    setOutages({});
    save({});
  }, []);

  return { outages, resetOutages: reset };
}
