// ============================================================================
// صحة البوردات — آخر ظهور وعدد مرات الانقطاع لكل بورد.
// ============================================================================
// البيانات بتتحسب من رسائل availability اللي مراقب التنبيهات (alerts.js) بيستقبلها،
// وبتتخزن محليًا. يعني بتتسجل بس طول ما التطبيق مفتوح ومتصل بالسيرفر؛ أي انقطاع
// حصل والتطبيق مقفول مش هيتعد. أول رسالة بعد فتح التطبيق (الحالة الحالية) مبتتعدش
// كانقطاع، بس بتحدّد الحالة الحالية.
// stats[boardId] = { state: 'online'|'offline', lastSeen: ms|null, drops: [ms...], since: ms }
// ============================================================================
import { useCallback, useEffect, useRef, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const KEY = 'silja_board_health_v1';
const MAX_DROPS = 100;

async function loadStats() {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    const parsed = raw ? JSON.parse(raw) : {};
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch (_) {
    return {};
  }
}

function saveStats(stats) {
  return AsyncStorage.setItem(KEY, JSON.stringify(stats)).catch(() => {});
}

// بيرجّع { stats, recordAvailability, reset }
export function useBoardHealth() {
  const [stats, setStats] = useState({});
  const statsRef = useRef({});
  const loadedRef = useRef(false);
  const pendingRef = useRef([]); // أحداث وصلت قبل ما التحميل يخلص

  const apply = useCallback((base, boardId, state, prev, now) => {
    const cur = base[boardId] || { state: null, lastSeen: null, drops: [], since: now };
    const next = { ...cur, state };
    if (state === 'online') next.lastSeen = now;
    if (state === 'offline') {
      if (prev === 'online') {
        next.drops = [...(cur.drops || []), now].slice(-MAX_DROPS);
        next.lastSeen = now;
      }
    }
    return { ...base, [boardId]: next };
  }, []);

  useEffect(() => {
    let alive = true;
    loadStats().then((saved) => {
      if (!alive) return;
      let merged = saved;
      pendingRef.current.forEach((e) => { merged = apply(merged, e.boardId, e.state, e.prev, e.now); });
      pendingRef.current = [];
      loadedRef.current = true;
      statsRef.current = merged;
      setStats(merged);
      if (merged !== saved) saveStats(merged);
    });
    return () => { alive = false; };
  }, [apply]);

  // prev = الحالة اللي قبلها في نفس الجلسة (undefined لو دي أول رسالة بعد الاشتراك)
  const recordAvailability = useCallback((board, state, prev) => {
    if (!board || !board.id || (state !== 'online' && state !== 'offline')) return;
    const now = Date.now();
    if (!loadedRef.current) { pendingRef.current.push({ boardId: board.id, state, prev, now }); return; }
    const next = apply(statsRef.current, board.id, state, prev, now);
    statsRef.current = next;
    setStats(next);
    saveStats(next);
  }, [apply]);

  const reset = useCallback(() => {
    statsRef.current = {};
    setStats({});
    saveStats({});
  }, []);

  return { stats, recordAvailability, reset };
}
