import { useEffect, useRef } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { boardAvailabilityTopic, parseAvailability } from './discovery';
import { notifyLocal } from './notifications';

// ============================================================================
// التنبيهات — مراقبة حالة البوردات والمفاتيح أثناء فتح التطبيق وتسجيلها محليًا.
// ============================================================================
// - بتراقب توبيك availability لكل بورد: لو بورد كان متصل وفصل (أو العكس) بنسجّل تنبيه.
// - اختياريًا بتراقب تغيّر حالة كل مفتاح (ON/OFF).
// - أول رسالة بتوصل بعد الاشتراك (الحالة الحالية) بتتسجل كخط أساس بس ومبتطلعش تنبيه،
//   عشان مفيش سيل تنبيهات كل ما التطبيق يتفتح.
// - التنبيهات بتتخزن على الموبايل (آخر 200). الإشعار الفعلي وقت التطبيق مقفول
//   بيحتاج سيرفر الإشعارات (شوف server/README.md) — ده خارج نطاق الشاشة دي.
// ============================================================================

const SETTINGS_KEY = 'iot_alerts_settings_v1';
const LOG_KEY = 'iot_alerts_log_v1';
export const MAX_ALERTS = 200;

export const DEFAULT_ALERT_SETTINGS = {
  boardOffline: true, // بورد فصل
  boardOnline: true, // بورد رجع
  switchChange: false, // أي مفتاح اتشغل/اتقفل
  phoneNotify: true, // كمان إشعار على الموبايل (لو الإذن مفعّل)
};

export async function loadAlertSettings() {
  try {
    const raw = await AsyncStorage.getItem(SETTINGS_KEY);
    const parsed = raw ? JSON.parse(raw) : null;
    return { ...DEFAULT_ALERT_SETTINGS, ...(parsed && typeof parsed === 'object' ? parsed : {}) };
  } catch (_) {
    return { ...DEFAULT_ALERT_SETTINGS };
  }
}

export async function saveAlertSettings(settings) {
  await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

export async function loadAlertLog() {
  try {
    const raw = await AsyncStorage.getItem(LOG_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.slice(0, MAX_ALERTS) : [];
  } catch (_) {
    return [];
  }
}

export async function saveAlertLog(list) {
  await AsyncStorage.setItem(LOG_KEY, JSON.stringify(list.slice(0, MAX_ALERTS)));
}

function parseSwitchState(payload) {
  const raw = payload.toString().trim();
  let value = raw.toUpperCase();
  try {
    const data = JSON.parse(raw);
    if (data && typeof data === 'object') value = String(data.state ?? data.status ?? data.value ?? data.on ?? '').toUpperCase();
  } catch (_) {}
  if (value === 'ON' || value === '1' || value === 'TRUE') return true;
  if (value === 'OFF' || value === '0' || value === 'FALSE') return false;
  return null;
}

// hook بيشتغل على مستوى التطبيق كله (مش بس لما شاشة التنبيهات تكون مفتوحة).
// onAlert({ id, ts, kind, title, body, read:false })
export function useAlertsMonitor({ client, connected, boards, settings, onAlert, onAvailability }) {
  const settingsRef = useRef(settings);
  const onAlertRef = useRef(onAlert);
  const onAvailabilityRef = useRef(onAvailability);
  onAvailabilityRef.current = onAvailability;
  settingsRef.current = settings;
  onAlertRef.current = onAlert;

  // مفتاح ثابت يتغير بس لو تغيّرت توبيكات المراقبة فعلًا (مش مع كل render)
  const watchKey = JSON.stringify(
    (boards || []).map((b) => [
      b.id,
      boardAvailabilityTopic(b),
      (b.devices || []).map((d) => [d.name, d.statusTopic || d.controlTopic]),
    ])
  );

  useEffect(() => {
    if (!client || !connected) return undefined;

    const availTopics = new Map(); // topic -> board
    const switchTopics = new Map(); // topic -> [{ board, device }]
    (boards || []).forEach((board) => {
      const at = boardAvailabilityTopic(board);
      if (at) availTopics.set(at, board);
      (board.devices || []).forEach((device) => {
        const t = device.statusTopic || device.controlTopic;
        if (!t) return;
        if (!switchTopics.has(t)) switchTopics.set(t, []);
        switchTopics.get(t).push({ board, device });
      });
    });

    const lastAvail = {};
    const lastSwitch = {};
    let seq = 0;

    const emit = (kind, title, body, notify) => {
      const ts = Date.now();
      onAlertRef.current({ id: `${ts}-${seq++}`, ts, kind, title, body, read: false });
      if (notify && settingsRef.current.phoneNotify) notifyLocal(title, body);
    };

    const handler = (topic, payload) => {
      const s = settingsRef.current;
      const board = availTopics.get(topic);
      if (board) {
        const state = parseAvailability(payload.toString());
        if (!state) return;
        const prev = lastAvail[topic];
        lastAvail[topic] = state;
        if (onAvailabilityRef.current) onAvailabilityRef.current(board, state, prev);
        if (prev === undefined || prev === state) return;
        const name = board.name || 'بورد بدون اسم';
        if (state === 'offline' && s.boardOffline) emit('offline', 'بورد فصل', `${name} مبقاش متصل.`, true);
        if (state === 'online' && s.boardOnline) emit('online', 'بورد رجع', `${name} رجع متصل.`, false);
        return;
      }
      const targets = switchTopics.get(topic);
      if (targets) {
        const value = parseSwitchState(payload);
        if (value === null) return;
        const prev = lastSwitch[topic];
        lastSwitch[topic] = value;
        if (prev === undefined || prev === value) return;
        if (!s.switchChange) return;
        targets.forEach(({ board, device }) => {
          emit(
            value ? 'switch_on' : 'switch_off',
            value ? 'مفتاح اتشغل' : 'مفتاح اتقفل',
            `${device.name || 'مفتاح'}${board.name ? ` — ${board.name}` : ''}`,
            false
          );
        });
      }
    };

    const topics = [...availTopics.keys(), ...switchTopics.keys()];
    topics.forEach((t) => client.subscribe(t));
    client.on('message', handler);
    return () => {
      client.off('message', handler);
      topics.forEach((t) => client.unsubscribe(t));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client, connected, watchKey]);
}
