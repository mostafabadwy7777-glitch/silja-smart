// ============================================================================
// أشكال (تخطيطات) مختلفة لكارت "المفتاح الذكي" في شاشة مفاتيح البورد.
// كل خيار هنا اسمه وشكله فقط (بيستخدم في شاشة الثيمات لعرض الاختيارات)،
// أما التنفيذ الفعلي لكل تخطيط فموجود جوه DeviceCard في SwitchesScreen.js.
// ============================================================================

export const SWITCH_CARD_STYLES = [
  {
    id: 'classic',
    name: 'كلاسيك',
    description: 'أيقونة كبيرة في النص، الاسم تحتها، وزرار ON/OFF أسفل الكارت',
  },
  {
    id: 'horizontal',
    name: 'أفقي أنيق',
    description: 'كارت أفقي بسيط بإطار شامبين هادئ وحالة واضحة عند التشغيل',
  },
  {
    id: 'minimal',
    name: 'Noir Champagne',
    description: 'كارت فخم أسود مطفي وأيقونة شامبين وتحكم واضح بحركة هادئة',
  },
];

export const DEFAULT_SWITCH_CARD_STYLE = 'minimal';

export function getSwitchCardStyleName(id) {
  return SWITCH_CARD_STYLES.find((s) => s.id === id)?.name || SWITCH_CARD_STYLES[0].name;
}
