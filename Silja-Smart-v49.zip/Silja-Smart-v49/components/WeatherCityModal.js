import React, { useState } from 'react';
import { Modal, View, Text, TextInput, ActivityIndicator, StyleSheet } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';
import { FONTS } from '../fonts';
import { DEFAULT_CITY, saveWeatherCity, searchCities } from '../weather';

// اختيار مدينة الطقس: بحث بالاسم (Open-Meteo) وبعدين دوس على النتيجة.
export default function WeatherCityModal({ visible, onClose }) {
  const { theme } = useTheme();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');

  const search = async () => {
    const q = query.trim();
    if (q.length < 2) return;
    setLoading(true);
    setMsg('');
    try {
      const r = await searchCities(q);
      setResults(r);
      if (!r.length) setMsg('مفيش نتائج — جرب اسم تاني');
    } catch (_) {
      setResults([]);
      setMsg('تعذر البحث. اتأكد من الإنترنت وجرب تاني.');
    } finally {
      setLoading(false);
    }
  };

  const choose = async (city) => {
    await saveWeatherCity({ name: city.name, lat: city.lat, lon: city.lon });
    onClose();
  };

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={[styles.box, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={styles.headerRow}>
            <Text style={[styles.title, { color: theme.textPrimary }]}>مدينة الطقس</Text>
            <TouchableOpacity onPress={onClose} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <MaterialCommunityIcons name="close" size={20} color={theme.textMuted} />
            </TouchableOpacity>
          </View>
          <View style={styles.searchRow}>
            <TextInput
              style={[styles.input, { backgroundColor: theme.cardAlt, color: theme.textPrimary, borderColor: theme.border }]}
              value={query}
              onChangeText={setQuery}
              placeholder="ابحث عن مدينة..."
              placeholderTextColor={theme.textMuted}
              textAlign="right"
              returnKeyType="search"
              onSubmitEditing={search}
            />
            <TouchableOpacity style={[styles.searchBtn, { backgroundColor: theme.accentSoft }]} onPress={search}>
              <MaterialCommunityIcons name="magnify" size={22} color="#17130B" />
            </TouchableOpacity>
          </View>
          {loading && <ActivityIndicator color={theme.accent} style={{ marginVertical: 12 }} />}
          {!!msg && <Text style={[styles.msg, { color: theme.textMuted }]}>{msg}</Text>}
          {results.map((c, i) => (
            <TouchableOpacity key={`${c.lat}-${c.lon}-${i}`} style={[styles.result, { borderColor: theme.border }]} onPress={() => choose(c)}>
              <Text style={[styles.resName, { color: theme.textPrimary }]}>{c.name}</Text>
              {!!c.region && <Text style={[styles.resRegion, { color: theme.textMuted }]}>{c.region}</Text>}
            </TouchableOpacity>
          ))}
          <TouchableOpacity style={styles.reset} onPress={() => choose(DEFAULT_CITY)}>
            <Text style={[styles.resetText, { color: theme.accentSoft }]}>الرجوع للقاهرة (الافتراضي)</Text>
          </TouchableOpacity>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', padding: 24 },
  box: { borderRadius: 24, borderWidth: 1, padding: 18 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  title: { fontSize: 17, fontWeight: '800', fontFamily: FONTS.display },
  searchRow: { flexDirection: 'row', gap: 8 },
  input: { flex: 1, borderWidth: 1, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 10, fontSize: 14 },
  searchBtn: { width: 46, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  msg: { fontSize: 12.5, textAlign: 'center', marginTop: 12 },
  result: { borderBottomWidth: StyleSheet.hairlineWidth, paddingVertical: 12 },
  resName: { fontSize: 14.5, fontWeight: '700', textAlign: 'right' },
  resRegion: { fontSize: 11.5, marginTop: 2, textAlign: 'right' },
  reset: { alignItems: 'center', marginTop: 16 },
  resetText: { fontSize: 13, fontWeight: '700' },
});
