import React, { useEffect, useRef, useState } from 'react';
import { SafeAreaView, View, Text, StyleSheet, FlatList, ActivityIndicator } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FONTS } from '../fonts';
import { useTheme } from '../ThemeContext';
import ConnectionStatusBanner from '../components/ConnectionStatusBanner';
import ScreenBackground from '../components/ScreenBackground';
import ScreenHeader from '../components/ScreenHeader';

// السجل مش متخزن في التطبيق نفسه (لازم يفضل موجود حتى لو التطبيق مقفول ووقت
// حصول الحدث). بيتخزن في سيرفر مستقل بسيط (شوف server/) بيراقب كل المفاتيح على
// MQTT ويحتفظ بالأحداث. الشاشة دي بس بتطلب آخر الأحداث من السيرفر ده عن طريق
// نفس البروكر: بتنشر طلب على silja/app/history/request وبتستنى رد على
// silja/app/history/response/<replyId>.
const REQUEST_TOPIC = 'silja/app/history/request';
const RESPONSE_PREFIX = 'silja/app/history/response/';
const REQUEST_TIMEOUT_MS = 6000;

// تصنيف الحدث: لو السيرفر بعت type صريح نستخدمه، وإلا بنخمّن من الـ topic/الاسم.
function eventKind(item) {
  const t = String(item.type || item.kind || '').toLowerCase();
  if (t.includes('scene')) return 'scene';
  if (t.includes('irrig')) return 'irrigation';
  if (t.includes('switch')) return 'switch';
  const topic = String(item.topic || '').toLowerCase();
  if (topic.includes('scene')) return 'scene';
  if (topic.includes('irrig')) return 'irrigation';
  return 'switch';
}
const FILTERS = [['all', 'الكل'], ['switch', 'المفاتيح'], ['scene', 'المشاهد'], ['irrigation', 'الري']];
const KIND_ICON = { switch: 'lightbulb-outline', scene: 'weather-night', irrigation: 'water-outline' };

export default function HistoryScreen({ client, connected, onBack }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [gotResponse, setGotResponse] = useState(false);
  const [filter, setFilter] = useState('all');
  const shown = filter === 'all' ? events : events.filter((e) => eventKind(e) === filter);

  const timeoutRef = useRef(null);
  const replyTopicRef = useRef(null);
  const handlerRef = useRef(null);
  const gotResponseRef = useRef(false);
  const requestInProgressRef = useRef(false);

  const cleanup = () => {
    if (timeoutRef.current) clearTimeout(timeoutRef.current);
    if (client && replyTopicRef.current) {
      if (handlerRef.current) client.off('message', handlerRef.current);
      client.unsubscribe(replyTopicRef.current);
    }
    timeoutRef.current = null;
    requestInProgressRef.current = false;
    replyTopicRef.current = null;
    handlerRef.current = null;
  };

  const fetchHistory = () => {
    if (!client || !connected) {
      setErrorMsg('مفيش اتصال بالسيرفر دلوقتي');
      return;
    }
    if (requestInProgressRef.current) return;
    cleanup();
    requestInProgressRef.current = true;
    gotResponseRef.current = false;
    setLoading(true);
    setErrorMsg('');
    setGotResponse(false);

    const replyId = Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    const replyTopic = RESPONSE_PREFIX + replyId;
    replyTopicRef.current = replyTopic;

    const handler = (topic, payload) => {
      if (topic !== replyTopic) return;
      gotResponseRef.current = true;
      setGotResponse(true);
      try {
        const data = JSON.parse(payload.toString());
        setEvents(Array.isArray(data.events) ? data.events : []);
      } catch (e) {
        setErrorMsg('رد السيرفر مش JSON صحيح');
      }
      setLoading(false);
      cleanup();
    };
    handlerRef.current = handler;
    try {
      client.on('message', handler);
      client.subscribe(replyTopic, (subscribeError) => {
        if (subscribeError) {
          setLoading(false);
          setErrorMsg('تعذر الاشتراك في ردود السجل. راجع اتصال MQTT.');
          cleanup();
          return;
        }
        client.publish(REQUEST_TOPIC, JSON.stringify({ replyId, limit: 100 }), { qos: 1 }, (publishError) => {
          if (publishError) {
            setLoading(false);
            setErrorMsg('تعذر إرسال طلب السجل إلى السيرفر.');
            cleanup();
          }
        });
      });
    } catch (requestError) {
      setLoading(false);
      setErrorMsg('تعذر بدء طلب السجل. راجع اتصال MQTT وحاول مرة أخرى.');
      cleanup();
      return;
    }

    timeoutRef.current = setTimeout(() => {
      setLoading(false);
      if (!gotResponseRef.current) {
        setErrorMsg('مفيش رد من سيرفر السجل — اتأكد إنه شغال (شوف server/README.md)');
      }
      cleanup();
    }, REQUEST_TIMEOUT_MS);
  };

  // نستخدم ref موازي عشان الـ closure جوه setTimeout يشوف آخر قيمة
  useEffect(() => {
    gotResponseRef.current = gotResponse;
  }, [gotResponse]);

  useEffect(() => {
    fetchHistory();
    return cleanup;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client, connected]);

  const renderItem = ({ item }) => {
    const isOn = item.state === 'ON';
    const dt = new Date(item.ts);
    const timeStr = dt.toLocaleString('ar-EG', { hour: '2-digit', minute: '2-digit', day: '2-digit', month: '2-digit' });
    return (
      <View style={[styles.row, { backgroundColor: theme.card, borderColor: theme.border }]}>
        <View style={[styles.kindIcon, { backgroundColor: theme.cardAlt, borderColor: isOn ? theme.on : theme.border }]}>
          <MaterialCommunityIcons name={KIND_ICON[eventKind(item)]} size={20} color={isOn ? theme.on : theme.textSecondary} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={[styles.rowTitle, { color: theme.textPrimary }]}>
            {item.boardName ? `${item.boardName} — ` : ''}
            {item.switchName || item.topic}
          </Text>
          <Text style={[styles.rowMeta, { color: theme.textMuted }]}>{timeStr}</Text>
        </View>
        <Text style={[styles.stateBadge, { color: isOn ? theme.on : theme.off }]}>{isOn ? 'اتشغل' : 'اتقفل'}</Text>
      </View>
    );
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <ScreenBackground theme={theme} />
      <ScreenHeader title="سجل الأحداث" onBack={onBack} right={
        <TouchableOpacity onPress={fetchHistory}><MaterialCommunityIcons name="refresh" size={22} color={theme.accentSoft} /></TouchableOpacity>
      } />

      <ConnectionStatusBanner theme={theme} connected={!!connected} detail={connected ? 'بيتم جلب آخر الأحداث من خدمة السجل.' : 'السجل يحتاج اتصال MQTT؛ البيانات القديمة تظل ظاهرة لو موجودة.'} />

      <View style={[styles.filterRow, { backgroundColor: theme.card, borderColor: theme.border }]}>
        {FILTERS.map(([key, label]) => (
          <TouchableOpacity key={key} onPress={() => setFilter(key)} style={[styles.filterBtn, filter === key && { backgroundColor: theme.accentSoft }]}>
            <Text style={[styles.filterText, { color: filter === key ? '#17130B' : theme.textSecondary }]}>{label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {loading && (
        <View style={{ paddingVertical: 30 }}>
          <ActivityIndicator color={theme.accent} />
        </View>
      )}

      {!loading && errorMsg ? <Text style={[styles.errorText, { color: theme.danger }]}>{errorMsg}</Text> : null}

      {!loading && !errorMsg && shown.length === 0 && (
        <Text style={[styles.emptyText, { color: theme.textMuted }]}>مفيش أحداث مسجّلة لسه.</Text>
      )}

      <FlatList
        data={shown}
        keyExtractor={(item, idx) => `${item.ts}-${idx}`}
        renderItem={renderItem}
        contentContainerStyle={{ paddingBottom: 40 }}
      />
    </SafeAreaView>
  );
}

const getStyles = (theme) =>
  StyleSheet.create({
    container: { flex: 1, paddingHorizontal: 20, paddingTop: 48, backgroundColor: theme.bg },
    headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, minHeight: 48, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: theme.border },
    back: { fontSize: 15, paddingVertical: 8, paddingHorizontal: 4, fontWeight: '700' },
    title: { fontSize: 21, fontWeight: '800', fontFamily: FONTS.display },
    errorText: { fontSize: 12, textAlign: 'center', marginTop: 20, lineHeight: 18 },
    emptyText: { fontSize: 13, textAlign: 'center', marginTop: 20 },
    row: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderRadius: 20, padding: 15, marginBottom: 11, gap: 12, shadowColor: '#000', shadowOpacity: 0.12, shadowRadius: 8, shadowOffset: { width: 0, height: 3 }, elevation: 2 },
    kindIcon: { width: 40, height: 40, borderRadius: 14, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
    filterRow: { flexDirection: 'row', borderRadius: 16, borderWidth: 1, padding: 4, marginBottom: 12 },
    filterBtn: { flex: 1, paddingVertical: 9, borderRadius: 12, alignItems: 'center' },
    filterText: { fontSize: 13, fontWeight: '800' },
    rowTitle: { fontSize: 13, fontWeight: '700' },
    rowMeta: { fontSize: 11, marginTop: 2 },
    stateBadge: { fontSize: 12, fontWeight: '700' },
  });
