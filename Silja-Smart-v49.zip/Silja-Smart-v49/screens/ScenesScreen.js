import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, TextInput, StyleSheet } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FONTS } from '../fonts';
import { showAlert } from '../components/PremiumAlert';
import { useTheme } from '../ThemeContext';
import { getDeviceIcon } from '../deviceIcons';
import { flattenSwitchDevices, runScene } from '../scenes';
import { newId } from '../storage';
import ConnectionStatusBanner from '../components/ConnectionStatusBanner';
import ScreenBackground from '../components/ScreenBackground';
import ScreenHeader from '../components/ScreenHeader';

// أفعال ممكنة لكل نوع مفتاح
const TOGGLE_ACTIONS = [
  { value: 'ON', label: 'شغّل', icon: 'power-plug' },
  { value: 'OFF', label: 'اقفل', icon: 'power-plug-off' },
];
const UPDOWN_ACTIONS = [
  { value: 'UP', label: 'طلوع', icon: 'arrow-up-bold' },
  { value: 'DOWN', label: 'نزول', icon: 'arrow-down-bold' },
  { value: 'STOP', label: 'وقف', icon: 'stop' },
];

export default function ScenesScreen({ boards, scenes, onSaveScenes, client, connected, onBack }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);
  const devices = flattenSwitchDevices(boards);

  const [editing, setEditing] = useState(null); // null | scene draft object
  const [running, setRunning] = useState(null);
  const lastSceneRunRef = React.useRef({});

  const startNew = () => setEditing({ id: newId(), name: '', icon: 'star-four-points', actions: [] });
  const startEdit = (scene) => setEditing({ ...scene, actions: scene.actions.map((a) => ({ ...a })) });

  const persist = (list) => onSaveScenes(list);

  const deleteScene = (id) => {
    showAlert('مسح المشهد', 'متأكد؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'مسح', style: 'destructive', onPress: () => persist(scenes.filter((s) => s.id !== id)) },
    ]);
  };

  const trigger = async (scene) => {
    if (!connected || !client) { showAlert('الاتصال غير متاح', 'اتصل بالسيرفر قبل تشغيل المشهد.'); return; }
    if (running) return;
    const lastRunAt = lastSceneRunRef.current[scene.id] || 0;
    if (Date.now() - lastRunAt < 900) return;
    lastSceneRunRef.current[scene.id] = Date.now();
    setRunning(scene.id);
    try {
      const res = runScene(scene, client);
      if (!res.ok) showAlert('تعذر التشغيل', res.error || 'مقدرش أشغّل المشهد');
    } catch (error) {
      showAlert('فشل تشغيل المشهد', error?.message || 'تعذر إرسال أوامر المشهد.');
    } finally {
      setRunning(null);
    }
  };

  const toggleActionInDraft = (device, value) => {
    setEditing((prev) => {
      const idx = prev.actions.findIndex((a) => a.controlTopic === device.controlTopic);
      const actions = [...prev.actions];
      if (idx >= 0 && actions[idx].value === value) {
        // نفس القيمة تاني = شيل الفعل ده من المشهد
        actions.splice(idx, 1);
      } else if (idx >= 0) {
        actions[idx] = { ...actions[idx], value };
      } else {
        actions.push({
          controlTopic: device.controlTopic,
          boardName: device.boardName,
          name: device.name,
          icon: device.icon,
          controlType: device.controlType,
          value,
        });
      }
      return { ...prev, actions };
    });
  };

  const saveDraft = () => {
    if (!editing.name.trim()) {
      showAlert('خطأ', 'لازم تحط اسم للمشهد');
      return;
    }
    if (editing.actions.length === 0) {
      showAlert('خطأ', 'لازم تختار مفتاح واحد على الأقل وحالته');
      return;
    }
    const exists = scenes.some((s) => s.id === editing.id);
    const list = exists ? scenes.map((s) => (s.id === editing.id ? editing : s)) : [...scenes, editing];
    persist(list);
    setEditing(null);
  };

  // ---------- شاشة تعديل/إنشاء مشهد ----------
  if (editing) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <ScreenBackground theme={theme} />
        <ScreenHeader title="مشهد جديد" onBack={() => setEditing(null)} />

        <TextInput
          style={[styles.input, { backgroundColor: theme.cardAlt, color: theme.textPrimary }]}
          value={editing.name}
          onChangeText={(v) => setEditing({ ...editing, name: v })}
          placeholder="اسم المشهد (مثلاً: وضع النوم)"
          placeholderTextColor={theme.textMuted}
        />

        <Text style={[styles.hint, { color: theme.textSecondary }]}>
          اختار حالة كل مفتاح عايزه يتغيّر لما المشهد يشتغل. المفاتيح اللي مش هتلمسها هتفضل زي ما هي.
        </Text>

        <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
          {devices.length === 0 && (
            <Text style={[styles.emptyText, { color: theme.textMuted }]}>مفيش مفاتيح متاحة — ضيف بوردات الأول.</Text>
          )}
          {devices.map((device) => {
            const current = editing.actions.find((a) => a.controlTopic === device.controlTopic);
            const actionsList = device.controlType === 'updown' ? UPDOWN_ACTIONS : TOGGLE_ACTIONS;
            const meta = getDeviceIcon(device.icon);
            return (
              <View key={device.controlTopic} style={[styles.deviceRow, { backgroundColor: theme.card, borderColor: theme.border }]}>
                <View style={styles.deviceInfo}>
                  <MaterialCommunityIcons name={meta.icon} size={20} color={theme.textSecondary} />
                  <View style={{ marginRight: 8 }}>
                    <Text style={[styles.deviceName, { color: theme.textPrimary }]}>{device.name}</Text>
                    <Text style={[styles.boardName, { color: theme.textMuted }]}>{device.boardName}</Text>
                  </View>
                </View>
                <View style={styles.actionsRow}>
                  {actionsList.map((a) => {
                    const selected = current?.value === a.value;
                    return (
                      <TouchableOpacity
                        key={a.value}
                        onPress={() => toggleActionInDraft(device, a.value)}
                        style={[
                          styles.actionChip,
                          {
                            backgroundColor: selected ? theme.accent : theme.cardAlt,
                            borderColor: selected ? theme.accent : theme.border,
                          },
                        ]}
                      >
                        <Text style={{ color: selected ? '#fff' : theme.textSecondary, fontSize: 11, fontWeight: '700' }}>
                          {a.label}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              </View>
            );
          })}
        </ScrollView>

        <TouchableOpacity style={[styles.primaryBtn, { backgroundColor: theme.accent }]} onPress={saveDraft}>
          <Text style={styles.btnText}>حفظ المشهد</Text>
        </TouchableOpacity>
      </SafeAreaView>
    );
  }

  // ---------- قائمة المشاهد ----------
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}>
      <ScreenBackground theme={theme} />
      <ScreenHeader title="المشاهد" onBack={onBack} right={
        <TouchableOpacity onPress={startNew}><MaterialCommunityIcons name="plus-circle" size={26} color={theme.accentSoft} /></TouchableOpacity>
      } />

      <Text style={[styles.hint, { color: theme.textSecondary }]}>
        جمّع مفاتيح من أي بورد في مشهد واحد وشغّلهم كلهم بدوسة واحدة (مثلاً "وضع النوم" يقفل كل حاجة إلا الإنذار).
      </Text>
      <View style={{ marginHorizontal: 16 }}><ConnectionStatusBanner theme={theme} connected={connected} title={connected ? 'جاهز لتشغيل المشاهد' : 'المشاهد محفوظة — التشغيل متوقف'} detail={connected ? 'التشغيل يرسل الأوامر المحفوظة للبوردات.' : 'ارجع الاتصال قبل تشغيل أي مشهد.'} /></View>

      <ScrollView contentContainerStyle={{ paddingBottom: 40 }}>
        {scenes.length === 0 && (
          <Text style={[styles.emptyText, { color: theme.textMuted }]}>مفيش مشاهد لسه. دوس + عشان تعمل واحد.</Text>
        )}
        {scenes.map((scene) => (
          <View key={scene.id} style={[styles.sceneCard, { backgroundColor: theme.card, borderColor: theme.border }]}>
            <TouchableOpacity
              style={styles.sceneMain}
              activeOpacity={0.8}
              onPress={() => trigger(scene)}
              disabled={!connected || running === scene.id}
            >
              <View style={[styles.sceneIconWrap, { backgroundColor: theme.cardAlt, borderColor: theme.accentSoft }]}>
                <MaterialCommunityIcons name="star-four-points" size={20} color={theme.accentSoft} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.sceneName, { color: theme.textPrimary }]}>{scene.name}</Text>
                <Text style={[styles.sceneMeta, { color: theme.textMuted }]}>{scene.actions.length} إجراءات</Text>
              </View>
              <View style={[styles.playCircle, { backgroundColor: connected ? theme.accentSoft : theme.cardAlt }]}>
                <MaterialCommunityIcons name="play" size={22} color={connected ? '#17130B' : theme.textMuted} />
              </View>
            </TouchableOpacity>
            <View style={styles.sceneFooter}>
              <TouchableOpacity onPress={() => startEdit(scene)} style={styles.footerBtn}>
                <MaterialCommunityIcons name="pencil-outline" size={16} color={theme.textSecondary} />
                <Text style={[styles.footerBtnText, { color: theme.textSecondary }]}>تعديل</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => deleteScene(scene.id)} style={styles.footerBtn}>
                <MaterialCommunityIcons name="trash-can-outline" size={16} color={theme.danger} />
                <Text style={[styles.footerBtnText, { color: theme.danger }]}>مسح</Text>
              </TouchableOpacity>
            </View>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const getStyles = (theme) =>
  StyleSheet.create({
    container: { flex: 1, paddingHorizontal: 20, paddingTop: 50, backgroundColor: theme.bg },
    headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16, paddingBottom: 14, borderBottomWidth: 1, borderBottomColor: theme.border, minHeight: 48 },
    back: { fontSize: 15 },
    title: { fontSize: 21, fontWeight: '800', fontFamily: FONTS.display, letterSpacing: 0.2 },
    hint: { fontSize: 12, marginBottom: 16, lineHeight: 18 },
    emptyText: { fontSize: 13, textAlign: 'center', marginTop: 40 },
    input: { borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12, marginBottom: 14, fontSize: 14, borderWidth: 1 },
    deviceRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      borderWidth: 1,
      borderRadius: 18,
      padding: 14,
      marginBottom: 12,
    },
    deviceInfo: { flexDirection: 'row', alignItems: 'center', flex: 1 },
    deviceName: { fontSize: 13, fontWeight: '700' },
    boardName: { fontSize: 11, marginTop: 2 },
    actionsRow: { flexDirection: 'row', gap: 6 },
    actionChip: { borderWidth: 1, borderRadius: 11, paddingVertical: 8, paddingHorizontal: 12 },
    primaryBtn: { borderRadius: 15, paddingVertical: 15, alignItems: 'center', marginTop: 4 },
    btnText: { color: '#fff', fontWeight: '600', fontSize: 13 },
    sceneCard: { borderWidth: 1, borderRadius: 22, marginBottom: 15, overflow: 'hidden', shadowColor: '#000', shadowOpacity: 0.14, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 3 },
    sceneMain: { flexDirection: 'row', alignItems: 'center', padding: 15, gap: 12 },
    sceneIconWrap: {
      width: 44,
      height: 44,
      borderRadius: 15,
      borderWidth: 1.5,
      alignItems: 'center',
      justifyContent: 'center',
    },
    playCircle: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center' },
    sceneName: { fontSize: 15, fontWeight: '700' },
    sceneMeta: { fontSize: 11, marginTop: 2 },
    sceneFooter: { flexDirection: 'row', borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: '#0002' },
    footerBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 10, gap: 6 },
    footerBtnText: { fontSize: 12, fontWeight: '600' },
  });
