import AsyncStorage from '@react-native-async-storage/async-storage';

// مدينة الطقس المختارة (الافتراضي القاهرة) + اشتراك بسيط عشان الشارة تتحدّث فورًا
// لما المستخدم يغيّر المدينة من الإعدادات.
const KEY = 'iot_weather_city_v1';
export const DEFAULT_CITY = { name: 'القاهرة', lat: 30.0444, lon: 31.2357 };
const listeners = new Set();

export async function loadWeatherCity() {
  try {
    const raw = await AsyncStorage.getItem(KEY);
    const c = raw ? JSON.parse(raw) : null;
    if (c && Number.isFinite(c.lat) && Number.isFinite(c.lon)) return c;
  } catch (_) {}
  return DEFAULT_CITY;
}

export async function saveWeatherCity(city) {
  await AsyncStorage.setItem(KEY, JSON.stringify(city));
  listeners.forEach((fn) => fn(city));
}

export function subscribeWeatherCity(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

export async function searchCities(query) {
  const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=6&language=ar&format=json`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('search failed');
  const data = await res.json();
  return (data.results || []).map((r) => ({
    name: r.name,
    region: [r.admin1, r.country].filter(Boolean).join('، '),
    lat: r.latitude,
    lon: r.longitude,
  }));
}
