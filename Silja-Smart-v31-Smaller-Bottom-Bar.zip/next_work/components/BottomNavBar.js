import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Platform, Animated } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as NavigationBar from 'expo-navigation-bar';
import { useTheme } from '../ThemeContext';

// شريط التنقل السفلي — 5 عناصر: الرئيسية / الأجهزة / زرار الإضافة العائم في
// النص / المشاهد / الإعدادات. العنصر النشط بياخد لون accent الثيم الحالي
// وهالة متوهجة حواليه، والباقي بلون رمادي باهت. كل أيقونة كمان بتتوهج لحظة
// الدوس عليها (حتى لو مش هي العنصر النشط) عشان تدي إحساس فيه استجابة فورية.
export default function BottomNavBar({ screen, onNavigate, onAddPress, onSettingsPress, menuOpen }) {
  const { theme, bottomNavOpacity, bottomNavGradient } = useTheme();
  const styles = getStyles(theme);

  // Match the Android system navigation area to the active theme so light themes
  // do not show a separate rectangular strip beneath the floating tab bar.
  useEffect(() => {
    if (Platform.OS === 'android') {
      // Disable Android's forced contrast scrim so it does not paint a separate
      // rectangle below the floating bottom navigation on light themes.
      // Let the app background continue behind Android's system navigation area.
      // A solid system-bar color can appear as a separate rectangle below the tabs
      // on light themes, so use a transparent bar with absolute positioning.
      if (typeof NavigationBar.setPositionAsync === 'function') {
        NavigationBar.setPositionAsync('absolute').catch(() => {});
      }
      NavigationBar.setBackgroundColorAsync('transparent').catch(() => {});
      NavigationBar.setButtonStyleAsync(theme.isLight ? 'dark' : 'light').catch(() => {});
      if (typeof NavigationBar.setContrastEnforcedAsync === 'function') {
        NavigationBar.setContrastEnforcedAsync(false).catch(() => {});
      }
    }
  }, [theme.bg, theme.isLight]);

  const isScenesActive = screen === 'scenes';
  const isDevicesActive = screen === 'devices';
  // بقى بيتفعّل كمان لو الصفحة الجانبية (الدرج) فاتحة، أو لو واحدة من
  // الشاشات الفرعية اللي بتتفتح من جواها (إعدادات الاتصال/الثيمات/السجل/
  // النسخ الاحتياطي) هي الظاهرة دلوقتي.
  const isSettingsActive = screen === 'settingsHome' || screen === 'settings' || screen === 'theme' || screen === 'history' || screen === 'backup' || screen === 'bottomNavSettings' || screen === 'switchDisplay';

  const gradientSets = {
    midnight: ['#101C2A', '#163541', '#1C3D45', '#292D3A'],
    aurora: ['#15363A', '#205653', '#294C5A', '#333047'],
    ocean: ['#152B3A', '#1D4652', '#2B455A', '#34344A'],
    sunset: ['#342A32', '#59404A', '#6B4B4D', '#625443'],
    gold: ['#282A32', '#44434A', '#5B5548', '#6A604C'],
  };
  const gradient = gradientSets[bottomNavGradient] || gradientSets.midnight;
  const gradientColors = gradient.map((c) => withAlpha(c, Math.max(0.30, Math.min(0.78, bottomNavOpacity))));
  const palettes = {
    midnight: { plus: '#62D8C6', chip: '#76C9D8', night: '#A8B6D8', cog: '#E0D0A2' },
    aurora: { plus: '#6BD8C4', chip: '#78C8D0', night: '#B0B8D9', cog: '#D3C7E7' },
    ocean: { plus: '#75D4DF', chip: '#92B8E2', night: '#BDB7DF', cog: '#DDE7EE' },
    sunset: { plus: '#E8B8C8', chip: '#E8B79B', night: '#DCA5C7', cog: '#EAD6A6' },
    gold: { plus: '#E6D09A', chip: '#D6C69B', night: '#D9D0B3', cog: '#F0E6C9' },
  };
  const palette = palettes[bottomNavGradient] || palettes.aurora;
  return (
    <View style={styles.wrap}>
      <View style={styles.bar}>
        <LinearGradient pointerEvents="none" colors={gradientColors} start={{x:0,y:0}} end={{x:1,y:0}} style={styles.gradientBg} />
        <NavItem
          icon="plus"
          label="إضافة"
          active={false}
          theme={theme}
          palette={palette}
          onPress={onAddPress}
          radar
        />
        <NavItem
          icon="chip"
          label="الأجهزة"
          active={isDevicesActive}
          theme={theme}
          palette={palette}
          onPress={() => onNavigate('devices')}
        />

        <View style={styles.fabSlot}>
          <GlowFab theme={theme} icon="home-variant" onPress={() => onNavigate('boards')} />
        </View>

        <NavItem
          icon="weather-night"
          label="المشاهد"
          active={isScenesActive}
          theme={theme}
          palette={palette}
          onPress={() => onNavigate('scenes')}
        />
        <NavItem
          icon="cog"
          label="الإعدادات"
          active={isSettingsActive}
          theme={theme}
          palette={palette}
          onPress={onSettingsPress}
        />
      </View>
    </View>
  );
}

// عنصر واحد في الشريط — أيقونة جوه هالة توهج بتتحرك بـ Animated:
// - لما يبقى "active" (التاب الحالي) الهالة بتفضل ظاهرة بهدوء طول الوقت.
// - لما تدوس عليه (حتى لو مش active) الهالة بتومض بسرعة كإحساس لمسي فوري،
//   وبعدين بترجع لحالتها (فاضية لو مش active، أو متوهجة لو active).
function NavItem({ icon, label, active, theme, onPress, radar, palette }) {
  const iconPalette = {
    'plus': palette?.plus || '#38D9C5',
    'chip': palette?.chip || '#63B3FF',
    'weather-night': palette?.night || '#A98BFF',
    'cog': palette?.cog || '#FF9ACD',
  };
  const glassColor = iconPalette[icon] || theme.accent;
  const color = active ? glassColor : theme.textSecondary;
  const glow = useRef(new Animated.Value(active ? 1 : 0)).current;

  useEffect(() => {
    Animated.timing(glow, {
      toValue: active ? 1 : 0,
      duration: 220,
      useNativeDriver: true,
    }).start();
  }, [active]);

  const flashOn = () => {
    Animated.timing(glow, { toValue: 1, duration: 90, useNativeDriver: true }).start();
  };
  const flashOff = () => {
    Animated.timing(glow, {
      toValue: active ? 1 : 0,
      duration: 260,
      useNativeDriver: true,
    }).start();
  };

  const glowOpacityOuter = glow.interpolate({ inputRange: [0, 1], outputRange: [0.10, 0.58] });
  const glowOpacityInner = glow.interpolate({ inputRange: [0, 1], outputRange: [0.16, 0.75] });
  const glowScale = glow.interpolate({ inputRange: [0, 1], outputRange: [0.5, 1] });

  return (
    <TouchableOpacity
      style={styles_.item}
      activeOpacity={0.7}
      onPress={onPress}
      onPressIn={flashOn}
      onPressOut={flashOff}
    >
      <View style={styles_.iconWrap}>
        {radar ? (
          <>
            <RadarWaves theme={theme} color={glassColor} />
            <View style={[styles_.radarCore, { backgroundColor: `${glassColor}55`, borderColor: `${glassColor}DD` }]}>
              <MaterialCommunityIcons name="plus" size={18} color={glassColor} />
            </View>
          </>
        ) : (
          <>
            <Animated.View
              pointerEvents="none"
              style={[
                styles_.glassGlow,
                { backgroundColor: glassColor, opacity: glowOpacityOuter, transform: [{ scale: glowScale }] },
              ]}
            />
            <View
              style={[
                styles_.glassIcon,
                {
                  backgroundColor: active ? `${glassColor}72` : `${glassColor}38`,
                  borderColor: active ? `${glassColor}F0` : `${glassColor}85`,
                  shadowColor: glassColor,
                },
              ]}
            >
              <View style={[styles_.glassHighlight, { backgroundColor: `${glassColor}26` }]} />
              <MaterialCommunityIcons name={icon} size={20} color={color} style={{ zIndex: 2 }} />
            </View>
          </>
        )}
      </View>
      <Text style={[styles_.label, { color }]} numberOfLines={1}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

// حلقات رادار صغيرة بتتوسع وتخفت بشكل متتابع حوالين أيقونة "الإضافة" —
// نفس فكرة شاشة البحث عن الأجهزة، عشان الأيقونة نفسها تدي إحساس إن في
// بحث مستمر عن بوردات جديدة حتى وهي واقفة في الشريط.
function RadarWaves({ theme, color }) {
  const waves = useRef([0, 1, 2].map(() => new Animated.Value(0))).current;

  useEffect(() => {
    const loops = waves.map((w, i) =>
      Animated.loop(
        Animated.sequence([
          Animated.delay(i * 650),
          Animated.timing(w, { toValue: 1, duration: 1950, useNativeDriver: true }),
        ])
      )
    );
    loops.forEach((l) => l.start());
    return () => loops.forEach((l) => l.stop());
  }, [waves]);

  return (
    <>
      {waves.map((w, i) => (
        <Animated.View
          key={i}
          pointerEvents="none"
          style={[
            styles_.radarWave,
            {
              borderColor: color || theme.accent,
              opacity: w.interpolate({ inputRange: [0, 0.7, 1], outputRange: [0.55, 0.18, 0] }),
              transform: [{ scale: w.interpolate({ inputRange: [0, 1], outputRange: [0.3, 1] }) }],
            },
          ]}
        />
      ))}
    </>
  );
}

// زرار "+" العائم في النص — نفس فكرة التوهج، مع نبضة تكبير بسيطة لحظة الدوس
// عشان يحس المستخدم إنه ضغط بجد.
function GlowFab({ theme, onPress, icon = 'plus' }) {
  const glow = useRef(new Animated.Value(0)).current;
  const scale = useRef(new Animated.Value(1)).current;

  const pressIn = () => {
    Animated.parallel([
      Animated.timing(glow, { toValue: 1, duration: 100, useNativeDriver: true }),
      Animated.spring(scale, { toValue: 1.12, useNativeDriver: true, friction: 5 }),
    ]).start();
  };
  const pressOut = () => {
    Animated.parallel([
      Animated.timing(glow, { toValue: 0, duration: 260, useNativeDriver: true }),
      Animated.spring(scale, { toValue: 1, useNativeDriver: true, friction: 5 }),
    ]).start();
  };

  const glowOpacity = glow.interpolate({ inputRange: [0, 1], outputRange: [0, 0.6] });
  const glowScale = glow.interpolate({ inputRange: [0, 1], outputRange: [0.8, 1.5] });

  return (
    <TouchableOpacity
      style={getStyles(theme).fab}
      activeOpacity={0.85}
      onPress={onPress}
      onPressIn={pressIn}
      onPressOut={pressOut}
    >
      <Animated.View
        pointerEvents="none"
        style={[
          styles_.fabGlow,
          { backgroundColor: theme.accent, opacity: glowOpacity, transform: [{ scale: glowScale }] },
        ]}
      />
      <Animated.View style={{ transform: [{ scale }] }}>
        <MaterialCommunityIcons name={icon} size={23} color="#fff" />
      </Animated.View>
    </TouchableOpacity>
  );
}

const styles_ = StyleSheet.create({
  item: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 2, paddingTop: 2 },
  iconWrap: { width: 38, height: 38, alignItems: 'center', justifyContent: 'center' },
  glassIcon: { width: 35, height: 35, borderRadius: 12, alignItems: 'center', justifyContent: 'center', borderWidth: 1.2, overflow: 'hidden', shadowOpacity: 0.12, shadowRadius: 7, shadowOffset: { width: 0, height: 3 }, elevation: 5 },
  glassHighlight: { position: 'absolute', top: 2, left: 4, right: 4, height: 10, borderRadius: 10 },
  glassGlow: { position: 'absolute', width: 40, height: 40, borderRadius: 15 },
  radarWave: { position: 'absolute', width: 36, height: 36, borderRadius: 18, borderWidth: 1.5 },
  radarCore: { width: 32, height: 32, borderRadius: 16, borderWidth: 1.2, alignItems: 'center', justifyContent: 'center' },
  label: { fontSize: 10, fontWeight: '800', opacity: 1, textShadowColor: 'rgba(0,0,0,0.18)', textShadowOffset: { width: 0, height: 1 }, textShadowRadius: 2 },
  fabGlow: { position: 'absolute', width: 44, height: 44, borderRadius: 22 },
});

function withAlpha(hex, alpha) {
  const h = String(hex).replace('#','');
  if (h.length !== 6) return hex;
  return `rgba(${parseInt(h.slice(0,2),16)},${parseInt(h.slice(2,4),16)},${parseInt(h.slice(4,6),16)},${Math.max(0,Math.min(1,alpha))})`;
}

const getStyles = (theme) =>
  StyleSheet.create({
    wrap: {
      paddingHorizontal: 14,
      paddingBottom: Platform.OS === 'ios' ? 22 : 4,
      backgroundColor: 'transparent',
    },
    bar: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: theme.isLight ? 'rgba(250,252,255,0.97)' : 'rgba(5,14,29,0.94)',
      overflow: 'hidden',
      borderRadius: 28,
      borderWidth: 1.2,
      borderColor: theme.isLight ? 'rgba(45,111,132,0.22)' : 'rgba(72,220,205,0.38)',
      paddingVertical: 6,
      paddingHorizontal: 5,
      shadowColor: theme.isLight ? '#516C7A' : '#23DCCB',
      shadowOpacity: theme.isLight ? 0.09 : 0.12,
      shadowRadius: theme.isLight ? 7 : 9,
      shadowOffset: { width: 0, height: 6 },
      elevation: 10,
    },
    gradientBg: { position: 'absolute', top: 0, bottom: 0, left: 0, right: 0, borderRadius: 26, opacity: theme.isLight ? 0.28 : 1 },
    fabSlot: { width: 52, alignItems: 'center' },
    fab: {
      width: 48,
      height: 48,
      borderRadius: 24,
      backgroundColor: theme.accent,
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: -22,
      borderWidth: 4,
      borderColor: theme.bg,
      shadowColor: theme.accent,
      shadowOpacity: 0.18,
      shadowRadius: 8,
      shadowOffset: { width: 0, height: 3 },
      elevation: 8,
    },
  });
