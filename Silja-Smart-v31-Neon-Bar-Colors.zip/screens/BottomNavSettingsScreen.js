import React from 'react';
import { SafeAreaView, ScrollView, View, Text, StyleSheet } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useTheme } from '../ThemeContext';

const OPACITIES = [
  { value: 0.45, label: '45%', name: 'شفاف جدًا' },
  { value: 0.60, label: '60%', name: 'شفاف' },
  { value: 0.75, label: '75%', name: 'متوازن' },
  { value: 0.88, label: '88%', name: 'Glass Premium' },
  { value: 1.00, label: '100%', name: 'أوضح' },
];

const GRADIENTS = [
  { id: 'midnight', name: 'نيون ملكي', colors: ['#07152F', '#173B78', '#40216F'] },
  { id: 'aurora', name: 'أورورا عميق', colors: ['#073B4C', '#2456A6', '#552B83'] },
  { id: 'ocean', name: 'محيط ليلي', colors: ['#052D46', '#075985', '#3730A3'] },
  { id: 'sunset', name: 'عنابي فاخر', colors: ['#4A1738', '#9D3157', '#B85B3C'] },
  { id: 'gold', name: 'أسود وذهبي', colors: ['#211B2D', '#66502A', '#A88746'] },
];

export default function BottomNavSettingsScreen({ onBack }) {
  const { theme, bottomNavOpacity, bottomNavGradient, setBottomNavOpacity, setBottomNavGradient } = useTheme();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}> 
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <View style={styles.header}>
          <TouchableOpacity onPress={onBack}><Text style={[styles.back, { color: theme.accent }]}>رجوع ‹</Text></TouchableOpacity>
          <Text style={[styles.title, { color: theme.textPrimary }]}>شريط الأيقونات</Text>
        </View>
        <Text style={[styles.subtitle, { color: theme.textSecondary }]}>تحكم في شفافية الشريط السفلي وتدريج ألوانه. التغيير يظهر فورًا.</Text>

        <View style={[styles.box, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={styles.head}>
            <View style={[styles.iconBox, { backgroundColor: `${theme.accent}18` }]}><MaterialCommunityIcons name="blur" size={21} color={theme.accent} /></View>
            <View style={{ flex: 1 }}><Text style={[styles.boxTitle, { color: theme.textPrimary }]}>شفافية الشريط</Text><Text style={[styles.boxSub, { color: theme.textSecondary }]}>اختار مقدار ظهور الخلفية من خلال الزجاج.</Text></View>
          </View>
          <View style={styles.row}>
            {OPACITIES.map(o => {
              const selected = Math.abs(bottomNavOpacity - o.value) < 0.01;
              return (
                <TouchableOpacity key={o.value} onPress={() => setBottomNavOpacity(o.value)} style={[styles.opacity, { backgroundColor: `rgba(255,255,255,${Math.min(.96,o.value)})`, borderColor: selected ? theme.accent : theme.border }, selected && { shadowColor: theme.accent, shadowOpacity: .25, shadowRadius: 8, elevation: 3 }]}>
                  <MaterialCommunityIcons name="glass-mug-variant" size={18} color={selected ? theme.accent : theme.textSecondary} />
                  <Text style={[styles.label, { color: theme.textPrimary }]}>{o.label}</Text>
                  <Text style={[styles.name, { color: theme.textSecondary }]}>{o.name}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        </View>

        <View style={[styles.box, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={styles.head}>
            <View style={[styles.iconBox, { backgroundColor: `${theme.accent}18` }]}><MaterialCommunityIcons name="gradient-horizontal" size={21} color={theme.accent} /></View>
            <View style={{ flex: 1 }}><Text style={[styles.boxTitle, { color: theme.textPrimary }]}>تدريج ألوان الشريط</Text><Text style={[styles.boxSub, { color: theme.textSecondary }]}>اختار تدرج الألوان اللي يناسب شكل التطبيق.</Text></View>
          </View>
          <View style={styles.gradientGrid}>
            {GRADIENTS.map(g => {
              const selected = bottomNavGradient === g.id;
              return (
                <TouchableOpacity key={g.id} onPress={() => setBottomNavGradient(g.id)} style={[styles.gradientCard, { backgroundColor: theme.cardAlt, borderColor: selected ? theme.accent : theme.border }, selected && { shadowColor: theme.accent, shadowOpacity: .28, shadowRadius: 9, elevation: 4 }]}>
                  <LinearGradient colors={g.colors} start={{x:0,y:0}} end={{x:1,y:0}} style={styles.preview} />
                  <Text style={[styles.gradientName, { color: theme.textPrimary }]}>{g.name}</Text>
                  <MaterialCommunityIcons name={selected ? 'check-circle' : 'circle-outline'} size={18} color={selected ? theme.accent : theme.border} />
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 18, paddingTop: 36 },
  content: { paddingBottom: 30 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  title: { fontSize: 23, fontWeight: '800' },
  back: { fontSize: 15, fontWeight: '800' },
  subtitle: { fontSize: 12, lineHeight: 19, textAlign: 'right', marginBottom: 16 },
  box: { borderRadius: 22, borderWidth: 1, padding: 14, marginBottom: 14 },
  head: { flexDirection: 'row', alignItems: 'center', gap: 11, marginBottom: 14 },
  iconBox: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  boxTitle: { fontSize: 16, fontWeight: '800', textAlign: 'right' },
  boxSub: { fontSize: 11.5, lineHeight: 17, textAlign: 'right', marginTop: 2 },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  opacity: { flex: 1, minWidth: 58, minHeight: 78, borderRadius: 15, borderWidth: 1.2, alignItems: 'center', justifyContent: 'center', paddingVertical: 8 },
  label: { fontSize: 11, fontWeight: '800', marginTop: 3 },
  name: { fontSize: 7.5, marginTop: 1 },
  gradientGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 9 },
  gradientCard: { width: '48%', borderRadius: 17, borderWidth: 1.2, padding: 9, alignItems: 'center', gap: 7 },
  preview: { width: '100%', height: 38, borderRadius: 12 },
  gradientName: { fontSize: 12, fontWeight: '800' },
});
