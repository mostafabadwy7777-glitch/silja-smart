import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Platform, Animated } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import * as NavigationBar from 'expo-navigation-bar';
import { useTheme } from '../ThemeContext';
import { readableOn } from '../colorUtils';

// شريط التنقل السفلي — 5 عناصر: الرئيسية / الأجهزة / زرار الإضافة العائم في
// النص / المشاهد / المزيد (نفس ترتيب التصميم المرجعي). العنصر النشط بياخد لون accent الثيم الحالي
// وهالة متوهجة حواليه، والباقي بلون رمادي باهت. كل أيقونة كمان بتتوهج لحظة
// الدوس عليها (حتى لو مش هي العنصر النشط) عشان تدي إحساس فيه استجابة فورية.
export default function BottomNavBar({ screen, onNavigate, onAddPress, onSettingsPress, menuOpen }) {
  const { theme, bottomNavOpacity, bottomNavGradient, bottomNavSize = 'compact', bottomNavLift = 12 } = useTheme();
  const styles = getStyles(theme);

  // Match the Android system navigation area to the active theme so light themes
  // do not show a separate rectangular strip beneath the floating tab bar.
  useEffect(() => {
    if (Platform.OS === 'android') {
      // Disable Android's forced contrast scrim so it does not paint a separate
      // rectangle below the floating bottom navigation on light themes.
      // Let the app background continue behind Android's system navigation area.
      // A solid system-bar color can appear as a separate rectangle below the tabs
      // on light themes, so use a transparent bar with absolute positioning.
      if (typeof NavigationBar.setPositionAsync === 'function') {
        NavigationBar.setPositionAsync('absolute').catch(() => {});
      }
      NavigationBar.setBackgroundColorAsync('transparent').catch(() => {});
      NavigationBar.setButtonStyleAsync(theme.isLight ? 'dark' : 'light').catch(() => {});
      if (typeof NavigationBar.setContrastEnforcedAsync === 'function') {
        NavigationBar.setContrastEnforcedAsync(false).catch(() => {});
      }
    }
  }, [theme.bg, theme.isLight]);

  const isHomeActive = screen === 'boards' || screen === 'board';
  const isScenesActive = screen === 'scenes';
  const isDevicesActive = screen === 'devices';
  // بقى بيتفعّل كمان لو الصفحة الجانبية (الدرج) فاتحة، أو لو واحدة من
  // الشاشات الفرعية اللي بتتفتح من جواها (إعدادات الاتصال/الثيمات/السجل/
  // النسخ الاحتياطي) هي الظاهرة دلوقتي.
  const isSettingsActive = screen === 'settingsHome' || screen === 'settings' || screen === 'theme' || screen === 'history' || screen === 'backup' || screen === 'bottomNavSettings' || screen === 'switchDisplay';

  // Distinct palettes matching BottomNavSettingsScreen. The opacity control is
  // applied directly so the preview and the real navigation bar stay in sync.
  const gradientSets = {
    midnight: ['#101D30', '#263447', '#343047'],
    aurora: ['#123039', '#1C5559', '#302B46'],
    ocean: ['#12283B', '#1B4556', '#302C4B'],
    sunset: ['#302431', '#593746', '#655044'],
    gold: ['#252630', '#454047', '#6B5C43'],
  };
  // "مع الثيم" (الافتراضي): زجاج شفاف بلون كروت الثيم الحالي، والصفحة باينة من تحته
  const themed = bottomNavGradient === 'theme' || !gradientSets[bottomNavGradient];
  const gradient = gradientSets[bottomNavGradient] || gradientSets.gold;
  const gradientColors = gradient.map((c) => withAlpha(c, bottomNavOpacity));
  const champagne = '#D6B36A';
  const palettes = {
    midnight: { plus: champagne, chip: champagne, night: champagne, cog: champagne },
    aurora: { plus: champagne, chip: champagne, night: champagne, cog: champagne },
    ocean: { plus: champagne, chip: champagne, night: champagne, cog: champagne },
    sunset: { plus: champagne, chip: champagne, night: champagne, cog: champagne },
    gold: { plus: champagne, chip: champagne, night: champagne, cog: champagne },
  };
  const palette = palettes[bottomNavGradient] || palettes.aurora;
  return (
    <View pointerEvents="box-none" style={[styles.wrap, { paddingBottom: 22 + bottomNavLift }]}>
      <View style={[styles.bar, themed && { backgroundColor: withAlpha(theme.card, bottomNavOpacity * 0.6), borderColor: withAlpha(theme.accent, theme.isLight ? 0.35 : 0.30) }, bottomNavSize === 'compact' ? styles.compactBar : bottomNavSize === 'large' ? styles.largeBar : null]}>
        {!themed && <LinearGradient pointerEvents="none" colors={gradientColors} start={{x:0,y:0}} end={{x:1,y:0}} style={styles.gradientBg} />}
        <NavItem
          icon="home-variant-outline"
          label="الرئيسية"
          active={isHomeActive}
          theme={theme}
          palette={palette}
          themed={themed}
          onPress={() => onNavigate('boards')}
        />
        <NavItem
          icon="devices"
          label="الأجهزة"
          active={isDevicesActive}
          theme={theme}
          palette={palette}
          themed={themed}
          onPress={() => onNavigate('devices')}
        />

        <View style={styles.fabSlot}>
          <GlowFab theme={theme} icon="plus" onPress={onAddPress} themed={themed} />
        </View>

        <NavItem
          icon="weather-night"
          label="المشاهد"
          active={isScenesActive}
          theme={theme}
          palette={palette}
          themed={themed}
          onPress={() => onNavigate('scenes')}
        />
        <NavItem
          icon="dots-grid"
          label="المزيد"
          active={isSettingsActive}
          theme={theme}
          palette={palette}
          themed={themed}
          onPress={onSettingsPress}
        />
      </View>
    </View>
  );
}

// عنصر واحد في الشريط — أيقونة جوه هالة توهج بتتحرك بـ Animated:
// - لما يبقى "active" (التاب الحالي) الهالة بتفضل ظاهرة بهدوء طول الوقت.
// - لما تدوس عليه (حتى لو مش active) الهالة بتومض بسرعة كإحساس لمسي فوري،
//   وبعدين بترجع لحالتها (فاضية لو مش active، أو متوهجة لو active).
function NavItem({ icon, label, active, theme, onPress, radar, palette, themed }) {
  const iconPalette = {
    'home-variant-outline': '#D6B36A',
    'dots-grid': '#D6B36A',
    'devices': '#D6B36A',
    'weather-night': '#D6B36A',
    'cog': '#D6B36A',
  };
  const glassColor = themed ? theme.accent : (iconPalette[icon] || '#D6B36A');
  const color = themed ? (active ? theme.accent : theme.textSecondary) : (active ? '#F0D9A2' : '#A7A196');
  const glow = useRef(new Animated.Value(active ? 1 : 0)).current;

  useEffect(() => {
    Animated.timing(glow, {
      toValue: active ? 1 : 0,
      duration: 220,
      useNativeDriver: true,
    }).start();
  }, [active]);

  const flashOn = () => {
    Animated.timing(glow, { toValue: 1, duration: 90, useNativeDriver: true }).start();
  };
  const flashOff = () => {
    Animated.timing(glow, {
      toValue: active ? 1 : 0,
      duration: 260,
      useNativeDriver: true,
    }).start();
  };

  const glowOpacityOuter = glow.interpolate({ inputRange: [0, 1], outputRange: [0.00, 0.10] });
  const glowOpacityInner = glow.interpolate({ inputRange: [0, 1], outputRange: [0.00, 0.10] });
  const glowScale = glow.interpolate({ inputRange: [0, 1], outputRange: [0.5, 1] });

  // ---- شكل "مع الثيم": أيقونة + اسم دايمًا ظاهرين، والتاب النشط جواه كبسولة بلون الثيم ----
  if (themed && !radar) {
    return (
      <TouchableOpacity style={styles_.item} activeOpacity={0.7} onPress={onPress}>
        <Animated.View
          style={[
            styles_.themedPill,
            {
              backgroundColor: active ? withAlpha(theme.accent, 0.18) : 'transparent',
              borderColor: active ? withAlpha(theme.accent, 0.55) : 'transparent',
              transform: [{ scale: glow.interpolate({ inputRange: [0, 1], outputRange: [1, 1.04] }) }],
            },
          ]}
        >
          <MaterialCommunityIcons name={icon} size={22} color={color} />
          <Text style={[styles_.themedLabel, { color, fontWeight: active ? '800' : '600' }]} numberOfLines={1}>{label}</Text>
        </Animated.View>
      </TouchableOpacity>
    );
  }

  return (
    <TouchableOpacity
      style={styles_.item}
      activeOpacity={0.7}
      onPress={onPress}
      onPressIn={flashOn}
      onPressOut={flashOff}
    >
      <View style={styles_.iconWrap}>
        {radar ? (
          <>
            <RadarWaves theme={theme} color={glassColor} />
            <View style={[styles_.radarCore, { backgroundColor: `${glassColor}55`, borderColor: `${glassColor}DD` }]}>
              <MaterialCommunityIcons name="plus" size={18} color={glassColor} />
            </View>
          </>
        ) : (
          <>
            <Animated.View
              pointerEvents="none"
              style={[
                styles_.glassGlow,
                { backgroundColor: glassColor, opacity: glowOpacityOuter, transform: [{ scale: glowScale }] },
              ]}
            />
            <View
              style={[
                styles_.glassIcon,
                {
                  backgroundColor: themed ? (active ? withAlpha(theme.accent, 0.16) : 'transparent') : (active ? 'rgba(214,179,106,0.16)' : 'rgba(214,179,106,0.035)'),
                  borderColor: themed ? (active ? withAlpha(theme.accent, 0.6) : withAlpha(theme.border, 0.6)) : (active ? 'rgba(214,179,106,0.62)' : 'rgba(214,179,106,0.14)'),
                  shadowColor: glassColor,
                },
              ]}
            >
              <View style={[styles_.glassHighlight, { backgroundColor: 'rgba(255,255,255,0.035)' }]} />
              <MaterialCommunityIcons name={icon} size={18} color={color} style={{ zIndex: 2 }} />
            </View>
          </>
        )}
      </View>
      <Text style={[styles_.label, { color }]} numberOfLines={1}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

// حلقات رادار صغيرة بتتوسع وتخفت بشكل متتابع حوالين أيقونة "الإضافة" —
// نفس فكرة شاشة البحث عن الأجهزة، عشان الأيقونة نفسها تدي إحساس إن في
// بحث مستمر عن بوردات جديدة حتى وهي واقفة في الشريط.
function RadarWaves({ theme, color }) {
  const waves = useRef([0, 1, 2].map(() => new Animated.Value(0))).current;

  useEffect(() => {
    const loops = waves.map((w, i) =>
      Animated.loop(
        Animated.sequence([
          Animated.delay(i * 650),
          Animated.timing(w, { toValue: 1, duration: 1950, useNativeDriver: true }),
        ])
      )
    );
    loops.forEach((l) => l.start());
    return () => loops.forEach((l) => l.stop());
  }, [waves]);

  return (
    <>
      {waves.map((w, i) => (
        <Animated.View
          key={i}
          pointerEvents="none"
          style={[
            styles_.radarWave,
            {
              borderColor: color || theme.accent,
              opacity: w.interpolate({ inputRange: [0, 0.7, 1], outputRange: [0.55, 0.18, 0] }),
              transform: [{ scale: w.interpolate({ inputRange: [0, 1], outputRange: [0.3, 1] }) }],
            },
          ]}
        />
      ))}
    </>
  );
}

// زرار "+" العائم في النص — نفس فكرة التوهج، مع نبضة تكبير بسيطة لحظة الدوس
// عشان يحس المستخدم إنه ضغط بجد.
function GlowFab({ theme, onPress, icon = 'plus', themed }) {
  const glow = useRef(new Animated.Value(0)).current;
  const scale = useRef(new Animated.Value(1)).current;

  const pressIn = () => {
    Animated.parallel([
      Animated.timing(glow, { toValue: 1, duration: 100, useNativeDriver: true }),
      Animated.spring(scale, { toValue: 1.12, useNativeDriver: true, friction: 5 }),
    ]).start();
  };
  const pressOut = () => {
    Animated.parallel([
      Animated.timing(glow, { toValue: 0, duration: 260, useNativeDriver: true }),
      Animated.spring(scale, { toValue: 1, useNativeDriver: true, friction: 5 }),
    ]).start();
  };

  const glowOpacity = glow.interpolate({ inputRange: [0, 1], outputRange: [0, 0.6] });
  const glowScale = glow.interpolate({ inputRange: [0, 1], outputRange: [0.8, 1.5] });

  return (
    <TouchableOpacity
      style={[getStyles(theme).fab, themed && { backgroundColor: theme.accent, borderColor: theme.bg, shadowColor: theme.accent, shadowOpacity: 0.5, shadowRadius: 10 }]}
      activeOpacity={0.85}
      onPress={onPress}
      onPressIn={pressIn}
      onPressOut={pressOut}
    >
      <Animated.View
        pointerEvents="none"
        style={[
          styles_.fabGlow,
          { backgroundColor: theme.accent, opacity: glowOpacity, transform: [{ scale: glowScale }] },
        ]}
      />
      <Animated.View style={{ transform: [{ scale }] }}>
        <MaterialCommunityIcons name={icon} size={22} color={themed ? readableOn(theme.accent) : '#17140E'} />
      </Animated.View>
    </TouchableOpacity>
  );
}

const styles_ = StyleSheet.create({
  item: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 4, paddingTop: 2, minHeight: 50 },
  iconWrap: { width: 34, height: 32, alignItems: 'center', justifyContent: 'center' },
  glassIcon: { width: 28, height: 28, borderRadius: 10, alignItems: 'center', justifyContent: 'center', borderWidth: 1, overflow: 'hidden', shadowOpacity: 0.06, shadowRadius: 4, shadowOffset: { width: 0, height: 2 } },
  glassHighlight: { position: 'absolute', top: 2, left: 4, right: 4, height: 10, borderRadius: 10 },
  glassGlow: { position: 'absolute', width: 30, height: 30, borderRadius: 10 },
  radarWave: { position: 'absolute', width: 32, height: 32, borderRadius: 16, borderWidth: 1.5 },
  radarCore: { width: 28, height: 28, borderRadius: 14, borderWidth: 1.2, alignItems: 'center', justifyContent: 'center' },
  themedPill: { alignItems: 'center', justifyContent: 'center', gap: 2, paddingHorizontal: 12, paddingVertical: 5, borderRadius: 18, borderWidth: 1, minWidth: 62 },
  themedLabel: { fontSize: 10.5 },
  label: { fontSize: 10, fontWeight: '700', letterSpacing: 0.05, opacity: 1 },
  fabGlow: { position: 'absolute', width: 44, height: 44, borderRadius: 22 },
});

function withAlpha(hex, alpha) {
  const h = String(hex).replace('#','');
  if (h.length !== 6) return hex;
  return `rgba(${parseInt(h.slice(0,2),16)},${parseInt(h.slice(2,4),16)},${parseInt(h.slice(4,6),16)},${Math.max(0,Math.min(1,alpha))})`;
}

const getStyles = (theme) =>
  StyleSheet.create({
    // الشريط بقى عايم فوق الصفحة (مش تحتها) عشان محتوى الشاشة يبان من تحت الزجاج
    wrap: {
      position: 'absolute',
      left: 0,
      right: 0,
      bottom: 0,
      paddingHorizontal: 16,
      paddingTop: 4,
      paddingBottom: Platform.OS === 'ios' ? 18 : 18,
      backgroundColor: 'transparent',
    },
    compactBar: { paddingVertical: 4, borderRadius: 25 },
    largeBar: { paddingVertical: 7, borderRadius: 27 },
    bar: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: theme.isLight ? 'rgba(250,248,242,0.72)' : 'rgba(12,13,15,0.50)',
      overflow: 'hidden',
      borderRadius: 25,
      borderWidth: 1,
      borderColor: theme.isLight ? 'rgba(45,40,30,0.13)' : 'rgba(214,179,106,0.30)',
      paddingVertical: 3,
      paddingHorizontal: 4,
      shadowColor: '#000000',
      shadowOpacity: theme.isLight ? 0.08 : 0.22,
      shadowRadius: theme.isLight ? 7 : 14,
      shadowOffset: { width: 0, height: 5 },
    },
    gradientBg: { position: 'absolute', top: 0, bottom: 0, left: 0, right: 0, borderRadius: 24, opacity: theme.isLight ? 0.55 : 0.92 },
    fabSlot: { width: 48, alignItems: 'center' },
    fab: {
      width: 38,
      height: 38,
      borderRadius: 19,
      backgroundColor: '#D6B36A',
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: -8,
      borderWidth: 2,
      borderColor: theme.isLight ? theme.bg : '#0B0D10',
      shadowColor: '#D6B36A',
      shadowOpacity: 0.12,
      shadowRadius: 8,
      shadowOffset: { width: 0, height: 3 },
      elevation: 8,
    },
  });
