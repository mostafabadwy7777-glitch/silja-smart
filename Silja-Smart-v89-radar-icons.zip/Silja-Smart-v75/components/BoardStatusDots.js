import React, { useEffect, useMemo, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, Animated, Easing } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { useTheme } from '../ThemeContext';
import MarqueeText from './MarqueeText';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { rssiInfo } from '../boardRssi';

// نقطة بنبض هادي (هالة بتكبر وتختفي) للبورد المتصل؛ باقي الحالات نقطة ثابتة.
function StatusDot({ color, pulse }) {
  const p = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!pulse) return undefined;
    const loop = Animated.loop(
      Animated.timing(p, { toValue: 1, duration: 1800, easing: Easing.out(Easing.quad), useNativeDriver: true })
    );
    loop.start();
    return () => loop.stop();
  }, [pulse, p]);
  return (
    <View style={{ width: 9, height: 9, alignItems: 'center', justifyContent: 'center' }}>
      {pulse ? (
        <Animated.View
          style={{
            position: 'absolute', width: 9, height: 9, borderRadius: 5, backgroundColor: color,
            opacity: p.interpolate({ inputRange: [0, 1], outputRange: [0.5, 0] }),
            transform: [{ scale: p.interpolate({ inputRange: [0, 1], outputRange: [1, 2.6] }) }],
          }}
        />
      ) : null}
      <View style={{ width: 9, height: 9, borderRadius: 5, backgroundColor: color }} />
    </View>
  );
}

// نقط ملونة صغيرة: أخضر = متصل (ولو الواي فاي ضعيف بيتحول لبرتقالي + أيقونة إشارة)، أحمر = مقطوع، رمادي = لسه مش معروف. نقطة لكل بورد في صف واحد.
export default function BoardStatusDots({ boards = [], statusOf, rssiOf, onOpen }) {
  const { theme } = useTheme();
  const styles = useMemo(() => getStyles(theme), [theme]);
  if (!boards.length) return null;
  const colorOf = (s) => (s === 'online' ? theme.on : s === 'offline' ? (theme.off || '#E5484D') : theme.textMuted);

  return (
    <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.row} style={styles.scroll}>
      {boards.map((b) => {
        const st = statusOf(b.id);
        const sig = st === 'online' && rssiOf ? rssiInfo(rssiOf(b.id), theme) : null;
        return (
          <TouchableOpacity key={b.id} style={styles.item} onPress={() => onOpen && onOpen(b)} activeOpacity={0.8}>
            <StatusDot color={sig ? sig.color : colorOf(st)} pulse={st === 'online'} />
            <MarqueeText text={b.name || 'بورد'} style={styles.name} maxWidth={110} />
            {sig ? <MaterialCommunityIcons name={sig.icon} size={13} color={sig.color} /> : null}
          </TouchableOpacity>
        );
      })}
    </ScrollView>
  );
}

function getStyles(theme) {
  return StyleSheet.create({
    scroll: { marginBottom: 14 },
    row: { flexDirection: 'row', gap: 14, paddingHorizontal: 4 },
    item: { flexDirection: 'row', alignItems: 'center', gap: 6 },
    dot: { width: 9, height: 9, borderRadius: 5 },
    name: { color: theme.textSecondary, fontSize: 12 },
  });
}
