import AsyncStorage from '@react-native-async-storage/async-storage';
import CryptoJS from 'crypto-js';

const SETTINGS_KEY = 'iot_mqtt_settings_v1';
const BOARDS_KEY = 'iot_boards_v1';
const THEME_KEY = 'iot_theme_v2'; // v2: الافتراضي بقى Aqua Night
const LAST_DARK_THEME_KEY = 'iot_last_dark_theme_v1';
const CUSTOM_THEME_KEY = 'iot_custom_theme_v1';
const PAIRING_KEY_KEY = 'iot_pairing_key_v1';
const SCENES_KEY = 'iot_scenes_v1';
const INSTALL_ID_KEY = 'iot_install_id_v1';
const PUSH_ENABLED_KEY = 'iot_push_enabled_v1';
const BIOMETRIC_ENABLED_KEY = 'iot_biometric_enabled_v1';
const PIN_HASH_KEY = 'iot_pin_hash_v1';
const PIN_SALT_KEY = 'iot_pin_salt_v1';
const BOARDS_VIEW_MODE_KEY = 'iot_boards_view_mode_v1';
const HERO_BG_KEY = 'iot_hero_bg_v1';
const HERO_BG_OPACITY_KEY = 'iot_hero_bg_opacity_v1';
const HERO_TEXT_COLOR_KEY = 'iot_hero_text_color_v1';
const SWITCH_CARD_STYLE_KEY = 'iot_switch_card_style_v3'; // v3: الافتراضي بقى "دوائر"
const SWITCH_SHAPE_KEY = 'iot_switch_shape_v1';
const SWITCH_CARD_SIZE_KEY = 'iot_switch_card_size_v1';
const SWITCH_CARD_OPACITY_KEY = 'iot_switch_card_opacity_v1';
const BOTTOM_NAV_OPACITY_KEY = 'iot_bottom_nav_opacity_v1';
const BOTTOM_NAV_GRADIENT_KEY = 'iot_bottom_nav_gradient_v2'; // v2: الافتراضي بقى "مع الثيم"
const BOTTOM_NAV_SIZE_KEY = 'iot_bottom_nav_size_v1';
const BOTTOM_NAV_LIFT_KEY = 'iot_bottom_nav_lift_v1';

// قراءة آمنة للتخزين: قيمة تالفة أو إصدار قديم غير متوافق لا يجب أن يُسقط التطبيق.
function parseStoredJSON(raw, fallback) {
  if (raw == null || raw === '') return fallback;
  try {
    return JSON.parse(raw);
  } catch (error) {
    console.warn('[Silja Smart] تعذر قراءة بيانات محفوظة؛ سيتم استخدام القيمة الافتراضية.', error?.message);
    return fallback;
  }
}

export const DEFAULT_SETTINGS = {
  protocol: 'wss',
  host: '',
  port: '8884',
  path: '/mqtt',
  username: '',
  password: '',
};

export async function loadSettings() {
  const raw = await AsyncStorage.getItem(SETTINGS_KEY);
  return parseStoredJSON(raw, null);
}

export async function saveSettings(settings) {
  await AsyncStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
}

export async function loadBoards() {
  const raw = await AsyncStorage.getItem(BOARDS_KEY);
  const value = parseStoredJSON(raw, []);
  return Array.isArray(value) ? value : [];
}

export async function saveBoards(boards) {
  await AsyncStorage.setItem(BOARDS_KEY, JSON.stringify(boards));
}

export async function loadThemeId() {
  const raw = await AsyncStorage.getItem(THEME_KEY);
  return raw || null;
}

export async function saveThemeId(id) {
  await AsyncStorage.setItem(THEME_KEY, id);
}

// بيحفظ آخر ثيم "غامق" كان مختار قبل ما المستخدم يحول للوضع النهاري (الفاتح)،
// عشان لو رجع للوضع الغامق تاني يرجع لنفس الثيم اللي كان مختاره، مش الافتراضي.
export async function loadLastDarkThemeId() {
  const raw = await AsyncStorage.getItem(LAST_DARK_THEME_KEY);
  return raw || null;
}

export async function saveLastDarkThemeId(id) {
  await AsyncStorage.setItem(LAST_DARK_THEME_KEY, id);
}

// ألوان الثيم المخصص اللي المستخدم حددها بنفسه (خلفية، كروت، لون أساسي،
// لون التشغيل/الإيقاف... إلخ) — كائن كامل بنفس شكل أي ثيم جاهز من THEMES.
export async function loadCustomTheme() {
  const raw = await AsyncStorage.getItem(CUSTOM_THEME_KEY);
  return parseStoredJSON(raw, null);
}

export async function saveCustomTheme(colors) {
  await AsyncStorage.setItem(CUSTOM_THEME_KEY, JSON.stringify(colors));
}

// "مفتاح الربط" — سر مشترك بينك وبين الفيرموير بتاعك بس. التطبيق بيستخدمه عشان
// يتحقق من توقيع أي رسالة اكتشاف قبل ما يضيف بورد أو يزامن مفاتيح، فحتى لو حد تاني
// نصّب نفس التطبيق أو عرف اسم الجهاز (Device ID)، مش هيقدر يضيف بورده لأن الفيرموير
// بتاعه مش هيعرف يعمل توقيع صحيح من غير نفس المفتاح ده بالظبط.
export async function loadPairingKey() {
  const raw = await AsyncStorage.getItem(PAIRING_KEY_KEY);
  return raw || '';
}

export async function savePairingKey(key) {
  await AsyncStorage.setItem(PAIRING_KEY_KEY, key);
}

export function newId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

// ---------- مجموعات / مشاهد (Scenes) ----------
// كل scene = اسم + أيقونة + قايمة أفعال، كل فعل بيحدد مفتاح (من أي بورد) والحالة
// المطلوبة له. التشغيل بيبعت أوامر MQTT مباشرة زي ما لو كنت بتدوس على كل مفتاح لوحده.
export async function loadScenes() {
  const raw = await AsyncStorage.getItem(SCENES_KEY);
  const value = parseStoredJSON(raw, []);
  return Array.isArray(value) ? value : [];
}

export async function saveScenes(scenes) {
  await AsyncStorage.setItem(SCENES_KEY, JSON.stringify(scenes));
}

// ---------- معرّف تركيب ثابت (Installation ID) ----------
// بيتحدد مرة واحدة ويتخزن محليًا، بنستخدمه كـ "اسم" لتوكن الإشعارات وقت التسجيل
// عند سيرفر الإشعارات (topic ثابت لكل جهاز بدل ما يتغير كل مرة).
export async function loadOrCreateInstallId() {
  let id = await AsyncStorage.getItem(INSTALL_ID_KEY);
  if (!id) {
    id = newId();
    await AsyncStorage.setItem(INSTALL_ID_KEY, id);
  }
  return id;
}

export async function loadPushEnabled() {
  const raw = await AsyncStorage.getItem(PUSH_ENABLED_KEY);
  return raw === '1';
}

export async function savePushEnabled(enabled) {
  await AsyncStorage.setItem(PUSH_ENABLED_KEY, enabled ? '1' : '0');
}

// تفعيل/تعطيل قفل فتح التطبيق بالبصمة (بصمة إصبع أو بصمة وجه — أيًا كان
// المتاح على الموبايل). القفل نفسه بيتحقق وقت التشغيل، هنا بس بنحفظ رغبة
// المستخدم إنه عايز الحماية دي مفعّلة ولا لأ.
export async function loadBiometricEnabled() {
  const raw = await AsyncStorage.getItem(BIOMETRIC_ENABLED_KEY);
  return raw === '1';
}

export async function saveBiometricEnabled(enabled) {
  await AsyncStorage.setItem(BIOMETRIC_ENABLED_KEY, enabled ? '1' : '0');
}

// شكل عرض شاشة "بوردات التحكم" الرئيسية: قائمة (list) أو شبكة (grid).
// بنحفظ اختيار المستخدم عشان يفضل زي ما سابه لما يفتح التطبيق تاني.
export async function loadBoardsViewMode() {
  const raw = await AsyncStorage.getItem(BOARDS_VIEW_MODE_KEY);
  return raw === 'grid' || raw === 'compact' ? raw : 'list';
}

export async function saveBoardsViewMode(mode) {
  await AsyncStorage.setItem(BOARDS_VIEW_MODE_KEY, mode === 'grid' || mode === 'compact' ? mode : 'list');
}

// شكل كروت "المفاتيح الذكية" (شاشة مفاتيح البورد): كلاسيك، نيون متدرج،
// أو فخم Glass. بنحفظ اختيار المستخدم عشان يفضل زي ما سابه في كل البوردات.
const SWITCH_CARD_STYLES_VALID = ['tile', 'ring', 'classic', 'horizontal', 'minimal'];

export async function loadSwitchCardStyle() {
  const raw = await AsyncStorage.getItem(SWITCH_CARD_STYLE_KEY);
  return SWITCH_CARD_STYLES_VALID.includes(raw) ? raw : 'tile';
}

export async function saveSwitchCardStyle(style) {
  const safe = SWITCH_CARD_STYLES_VALID.includes(style) ? style : 'tile';
  await AsyncStorage.setItem(SWITCH_CARD_STYLE_KEY, safe);
}

const SWITCH_SHAPES_VALID = ['square', 'round', 'text'];

export async function loadSwitchShape() {
  const raw = await AsyncStorage.getItem(SWITCH_SHAPE_KEY);
  return SWITCH_SHAPES_VALID.includes(raw) ? raw : 'round';
}

export async function saveSwitchShape(shape) {
  const safe = SWITCH_SHAPES_VALID.includes(shape) ? shape : 'round';
  await AsyncStorage.setItem(SWITCH_SHAPE_KEY, safe);
}

// حجم كروت المفاتيح في وضع الشبكة: صغير، متوسط، كبير.
const SWITCH_CARD_SIZES_VALID = ['small', 'medium', 'large'];

export async function loadSwitchCardSize() {
  const raw = await AsyncStorage.getItem(SWITCH_CARD_SIZE_KEY);
  return SWITCH_CARD_SIZES_VALID.includes(raw) ? raw : 'medium';
}

export async function saveSwitchCardSize(size) {
  const safe = SWITCH_CARD_SIZES_VALID.includes(size) ? size : 'medium';
  await AsyncStorage.setItem(SWITCH_CARD_SIZE_KEY, safe);
}

// شفافية كارت المفتاح: 0.35 زجاج شفاف جدًا إلى 1 كارت معتم.
export async function loadSwitchCardOpacity() {
  const raw = await AsyncStorage.getItem(SWITCH_CARD_OPACITY_KEY);
  const n = raw != null ? parseFloat(raw) : NaN;
  return Number.isFinite(n) ? Math.max(0.35, Math.min(1, n)) : 0.82;
}

export async function saveSwitchCardOpacity(value) {
  const n = Number(value);
  const safe = Number.isFinite(n) ? Math.max(0.35, Math.min(1, n)) : 0.82;
  await AsyncStorage.setItem(SWITCH_CARD_OPACITY_KEY, String(safe));
}


const BOTTOM_NAV_GRADIENTS = ['theme', 'midnight', 'aurora', 'ocean', 'sunset', 'gold'];

export async function loadBottomNavOpacity() {
  const raw = await AsyncStorage.getItem(BOTTOM_NAV_OPACITY_KEY);
  const n = raw != null ? parseFloat(raw) : NaN;
  return Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0.90;
}

export async function saveBottomNavOpacity(value) {
  const n = Number(value);
  const safe = Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0.90;
  await AsyncStorage.setItem(BOTTOM_NAV_OPACITY_KEY, String(safe));
}

export async function loadBottomNavGradient() {
  const raw = await AsyncStorage.getItem(BOTTOM_NAV_GRADIENT_KEY);
  return BOTTOM_NAV_GRADIENTS.includes(raw) ? raw : 'theme';
}

export async function saveBottomNavGradient(id) {
  const safe = BOTTOM_NAV_GRADIENTS.includes(id) ? id : 'theme';
  await AsyncStorage.setItem(BOTTOM_NAV_GRADIENT_KEY, safe);
}

// خلفية كارت "حالة النظام" (المستطيل اللي فيه الساعة فوق شاشة البوردات) —
// مسار محلي لصورة اختارها المستخدم بنفسه (أو null لو مفيش خلفية مخصوصة
// وهيفضل يعرض الشكل الافتراضي بتاع الثيم).
export async function loadHeroBackground() {
  const raw = await AsyncStorage.getItem(HERO_BG_KEY);
  return raw || null;
}

export async function saveHeroBackground(uri) {
  if (uri) {
    await AsyncStorage.setItem(HERO_BG_KEY, uri);
  } else {
    await AsyncStorage.removeItem(HERO_BG_KEY);
  }
}

// درجة تعتيم الطبقة اللي بتتحط فوق خلفية كارت "حالة النظام" عشان الكلام
// يفضل واضح فوق أي صورة — رقم من 0 (شفافة خالص) لحد 1 (تعتيم كامل).
// الافتراضي 0.72 هو نفس القيمة اللي كانت ثابتة قبل كده.
const DEFAULT_HERO_BG_OPACITY = 0.72;

export async function loadHeroBgOpacity() {
  const raw = await AsyncStorage.getItem(HERO_BG_OPACITY_KEY);
  const n = raw != null ? parseFloat(raw) : NaN;
  return Number.isFinite(n) ? n : DEFAULT_HERO_BG_OPACITY;
}

export async function saveHeroBgOpacity(value) {
  const clamped = Math.max(0, Math.min(1, value));
  await AsyncStorage.setItem(HERO_BG_OPACITY_KEY, String(clamped));
}

// قوة التدريج الغامق تحت صورة كارت "حالة النظام" (بيساعد الساعة والتاريخ يبانوا فوق أي صورة).
// 0 = بدون تدريج (ملغي)، 1 = أقوى درجة. الافتراضي متوسط.
const HERO_GRADIENT_KEY = 'iot_hero_gradient_v1';
const DEFAULT_HERO_GRADIENT = 0.5;

export async function loadHeroGradient() {
  const raw = await AsyncStorage.getItem(HERO_GRADIENT_KEY);
  const n = raw != null ? parseFloat(raw) : NaN;
  return Number.isFinite(n) ? n : DEFAULT_HERO_GRADIENT;
}

export async function saveHeroGradient(value) {
  const clamped = Math.max(0, Math.min(1, value));
  await AsyncStorage.setItem(HERO_GRADIENT_KEY, String(clamped));
}

// لون كلام كارت "حالة النظام" (الحالة/الساعة/التاريخ) — null يعني "تلقائي"
// (يتبع ألوان الثيم العادية زي ما كان قبل كده)، أو hex ثابت اختاره المستخدم
// بنفسه عشان يفضل واضح فوق أي خلفية صورة حطها.
export async function loadHeroTextColor() {
  const raw = await AsyncStorage.getItem(HERO_TEXT_COLOR_KEY);
  return raw || null;
}

export async function saveHeroTextColor(color) {
  if (color) {
    await AsyncStorage.setItem(HERO_TEXT_COLOR_KEY, color);
  } else {
    await AsyncStorage.removeItem(HERO_TEXT_COLOR_KEY);
  }
}

// ============================================================================
// نسخة احتياطية / استيراد — تصدير كل حاجة محفوظة على الموبايل (إعدادات
// الاتصال، مفتاح الربط، البوردات وكل مفاتيحها، المشاهد، الثيم، تفعيل
// الإشعارات) لملف JSON واحد، والقدرة إنك ترجّعه على موبايل تاني أو بعد ما
// تمسح التطبيق. مفيش تواصل بالإنترنت هنا خالص — كله محلي على الموبايل.
// ============================================================================
export const BACKUP_FORMAT_VERSION = 1;

// بيجمع كل البيانات المحفوظة في كائن واحد جاهز للتصدير (JSON.stringify).
export async function exportBackupPayload() {
  const [settings, pairingKey, boards, scenes, pushEnabled, themeId, customTheme, appBgDim] = await Promise.all([
    loadSettings(),
    loadPairingKey(),
    loadBoards(),
    loadScenes(),
    loadPushEnabled(),
    loadThemeId(),
    loadCustomTheme(),
    loadAppBgDim(),
  ]);

  return {
    app: 'silja-smart',
    formatVersion: BACKUP_FORMAT_VERSION,
    exportedAt: new Date().toISOString(),
    settings: settings || DEFAULT_SETTINGS,
    pairingKey: pairingKey || '',
    boards: boards || [],
    scenes: scenes || [],
    pushEnabled: !!pushEnabled,
    themeId: themeId || null,
    customTheme: customTheme || null,
    appBgDim,
  };
}

// بيتحقق إن الملف اللي جاي فعلاً نسخة احتياطية من التطبيق ده قبل ما يكتب أي حاجة.
export function validateBackupPayload(data) {
  if (!data || typeof data !== 'object') return 'الملف مش بصيغة صحيحة';
  if (data.app !== 'silja-smart') return 'الملف ده مش نسخة احتياطية من Silja Smart';
  if (!Array.isArray(data.boards)) return 'الملف ناقصه بيانات البوردات';
  return null;
}

// بيكتب كل البيانات من نسخة احتياطية سبق تصديرها فوق أي بيانات موجودة حاليًا
// على الموبايل. استخدمها بعد تأكيد من المستخدم لأنها بتستبدل كل حاجة.
export async function applyBackupPayload(data) {
  const err = validateBackupPayload(data);
  if (err) throw new Error(err);

  await Promise.all([
    saveSettings(data.settings || DEFAULT_SETTINGS),
    savePairingKey(data.pairingKey || ''),
    saveBoards(Array.isArray(data.boards) ? data.boards : []),
    saveScenes(Array.isArray(data.scenes) ? data.scenes : []),
    savePushEnabled(!!data.pushEnabled),
    data.themeId ? saveThemeId(data.themeId) : Promise.resolve(),
    data.customTheme ? saveCustomTheme(data.customTheme) : Promise.resolve(),
    Number.isFinite(data.appBgDim) ? saveAppBgDim(data.appBgDim) : Promise.resolve(),
  ]);
}


// حجم وارتفاع شريط التنقل السفلي — إعدادات محفوظة يغيّرها المستخدم من داخل التطبيق.
export async function loadBottomNavSize() {
  const raw = await AsyncStorage.getItem(BOTTOM_NAV_SIZE_KEY);
  return ['compact', 'standard', 'large'].includes(raw) ? raw : 'compact';
}
export async function saveBottomNavSize(value) {
  const safe = ['compact', 'standard', 'large'].includes(value) ? value : 'compact';
  await AsyncStorage.setItem(BOTTOM_NAV_SIZE_KEY, safe);
}
export async function loadBottomNavLift() {
  const raw = await AsyncStorage.getItem(BOTTOM_NAV_LIFT_KEY);
  const n = raw != null ? parseInt(raw, 10) : NaN;
  return Number.isFinite(n) ? Math.max(0, Math.min(24, n)) : 12;
}
export async function saveBottomNavLift(value) {
  const n = Number(value);
  const safe = Number.isFinite(n) ? Math.max(0, Math.min(24, n)) : 12;
  await AsyncStorage.setItem(BOTTOM_NAV_LIFT_KEY, String(safe));
}

// ---- رمز الدخول (PIN) ----
// بنخزّن هاش (SHA-256 بملح عشوائي) مش الرمز نفسه. ده بيحمي من القراءة المباشرة
// للتخزين، لكن PIN من 4 أرقام يفضل ضعيف قدام أي حد بيجرّب على جهاز مفكوك،
// فالحماية الحقيقية هي قفل الموبايل نفسه.
const hashPin = (pin, salt) => CryptoJS.SHA256(`${salt}:${pin}`).toString();

export async function hasPin() {
  return !!(await AsyncStorage.getItem(PIN_HASH_KEY));
}

export async function savePin(pin) {
  const salt = CryptoJS.lib.WordArray.random(16).toString();
  await AsyncStorage.setItem(PIN_SALT_KEY, salt);
  await AsyncStorage.setItem(PIN_HASH_KEY, hashPin(pin, salt));
}

export async function verifyPin(pin) {
  const [hash, salt] = await Promise.all([AsyncStorage.getItem(PIN_HASH_KEY), AsyncStorage.getItem(PIN_SALT_KEY)]);
  if (!hash || !salt) return false;
  return hashPin(pin, salt) === hash;
}

export async function clearPin() {
  await AsyncStorage.removeItem(PIN_HASH_KEY);
  await AsyncStorage.removeItem(PIN_SALT_KEY);
  await resetPinFailures();
}

// ---- خلفية التطبيق (صورة من المعرض تتطبق على كل الشاشات) ----
const APP_BG_KEY = 'iot_app_bg_v1';
const APP_BG_DIM_KEY = 'iot_app_bg_dim_v1';
export const DEFAULT_APP_BG_DIM = 0.55;

export async function loadAppBg() {
  return (await AsyncStorage.getItem(APP_BG_KEY)) || null;
}
export async function saveAppBg(uri) {
  if (uri) await AsyncStorage.setItem(APP_BG_KEY, uri);
  else await AsyncStorage.removeItem(APP_BG_KEY);
}
export async function loadAppBgDim() {
  const n = parseFloat(await AsyncStorage.getItem(APP_BG_DIM_KEY));
  return Number.isFinite(n) ? n : DEFAULT_APP_BG_DIM;
}
export async function saveAppBgDim(value) {
  await AsyncStorage.setItem(APP_BG_DIM_KEY, String(Math.max(0, Math.min(1, value))));
}

// ---- القفل التلقائي (بعد كام ثانية في الخلفية يتقفل التطبيق تاني) ----
// -1 = أبدًا (القفل عند فتح التطبيق من الصفر بس).
const AUTO_LOCK_KEY = 'iot_auto_lock_sec_v1';
export const DEFAULT_AUTO_LOCK_SEC = 60;
export async function loadAutoLockSec() {
  const n = parseInt(await AsyncStorage.getItem(AUTO_LOCK_KEY), 10);
  return Number.isFinite(n) ? n : DEFAULT_AUTO_LOCK_SEC;
}
export async function saveAutoLockSec(sec) {
  await AsyncStorage.setItem(AUTO_LOCK_KEY, String(sec));
}

// ---- حماية الـ PIN من التخمين ----
// كل 5 محاولات غلط ورا بعض = قفل مؤقت (30 ثانية، وبيتضاعف كل مرة لحد 15 دقيقة).
// العدّاد متخزن، فإغلاق التطبيق وفتحه مش بيصفّره.
const PIN_FAILS_KEY = 'iot_pin_fails_v1';
const PIN_LOCK_UNTIL_KEY = 'iot_pin_lock_until_v1';
export async function getPinLockRemainingMs() {
  const until = parseInt(await AsyncStorage.getItem(PIN_LOCK_UNTIL_KEY), 10);
  return Number.isFinite(until) ? Math.max(0, until - Date.now()) : 0;
}
export async function registerPinFailure() {
  const fails = (parseInt(await AsyncStorage.getItem(PIN_FAILS_KEY), 10) || 0) + 1;
  await AsyncStorage.setItem(PIN_FAILS_KEY, String(fails));
  if (fails % 5 !== 0) return { remainingMs: 0, triesLeft: 5 - (fails % 5) };
  const ms = Math.min(15 * 60 * 1000, 30000 * Math.pow(2, fails / 5 - 1));
  await AsyncStorage.setItem(PIN_LOCK_UNTIL_KEY, String(Date.now() + ms));
  return { remainingMs: ms, triesLeft: 0 };
}
export async function resetPinFailures() {
  await AsyncStorage.removeItem(PIN_FAILS_KEY);
  await AsyncStorage.removeItem(PIN_LOCK_UNTIL_KEY);
}

// المفضلة في الشاشة الرئيسية: قايمة مفاتيح "boardId|controlTopic" بالترتيب.
const HOME_FAVORITES_KEY = 'iot_home_favorites_v1';
export async function loadHomeFavorites() {
  const raw = await AsyncStorage.getItem(HOME_FAVORITES_KEY);
  const list = parseStoredJSON(raw, []);
  return Array.isArray(list) ? list.filter((x) => typeof x === 'string') : [];
}
export async function saveHomeFavorites(list) {
  await AsyncStorage.setItem(HOME_FAVORITES_KEY, JSON.stringify(list));
}

// أوضاع الرئيسية (خروج / نوم): لكل وضع قايمة مفاتيح "boardId|controlTopic" اللي تتأثر.
// null = لسه المستخدم ماختارش، فالشاشة بتستخدم الافتراضي (كل الإضاءة + إيقاف الستائر).
const HOME_MODES_KEY = 'iot_home_modes_v1';
export async function loadHomeModes() {
  const raw = await AsyncStorage.getItem(HOME_MODES_KEY);
  const obj = parseStoredJSON(raw, {});
  const clean = (v) => (Array.isArray(v) ? v.filter((x) => typeof x === 'string') : null);
  return { away: clean(obj && obj.away), sleep: clean(obj && obj.sleep) };
}
export async function saveHomeModes(modes) {
  await AsyncStorage.setItem(HOME_MODES_KEY, JSON.stringify(modes));
}
