import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  Modal,
  FlatList,
  Animated,
  ActivityIndicator,
  BackHandler,
  Image,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import { DEVICE_ICONS, REALISTIC_ICON_OPTIONS, getDeviceIcon, getDeviceIconImage } from '../deviceIcons';
import { COLOR_SWATCHES } from '../theme';
import { useTheme } from '../ThemeContext';
import { newId } from '../storage';
import { parseBoardDiscovery, boardAvailabilityTopic, parseAvailability } from '../discovery';
import { notifyLocal } from '../notifications';

// لون الإضاءة "الحقيقي" لما لمبة/نجفة/فانوس/سبوت... يبقى شغال —
// نفس دفء لون اللمبة الأصفر بدل لون الثيم العام.
const LIGHT_WARM_ON = '#FFC94A';
// لون التحذير الأحمر الثابت لزرار الطوارئ لما يبقى نشط — بغض النظر عن
// لون الثيم، عشان يفضل واضح إنه حالة خطر مش مجرد "تشغيل" عادي.
const EMERGENCY_ON = '#FF3B30';

// بيتحفظ الجزء الدائم من صور المفتاح المخصوصة (اللي المستخدم اختارها من
// المعرض/الكاميرا) على الموبايل نفسه (مش على الكاش اللي بيتمسح)، عشان تفضل
// موجودة حتى لو التطبيق قفل وفتح تاني أو الموبايل عمل ريستارت. نفس فكرة
// صورة البورد في EditBoardModal.js بس هنا لكل مفتاح لوحده، وبصورتين
// منفصلتين (شغال / مطفي) عشان الصورة نفسها تبين حالة المفتاح.
const DEVICE_IMAGES_DIR = FileSystem.documentDirectory + 'device-images/';

async function persistPickedDeviceImage(sourceUri, deviceId, state) {
  await FileSystem.makeDirectoryAsync(DEVICE_IMAGES_DIR, { intermediates: true }).catch(() => {});
  const destUri = `${DEVICE_IMAGES_DIR}${deviceId}-${state}.jpg`;
  // بنمسح أي نسخة قديمة الأول عشان copyAsync ميرفضش الكتابة فوق ملف موجود.
  await FileSystem.deleteAsync(destUri, { idempotent: true }).catch(() => {});
  await FileSystem.copyAsync({ from: sourceUri, to: destUri });
  return destUri;
}

// شكل المفتاح المعروض حسب حالته الحالية: لو المستخدم حاطط صورة مخصوصة
// لحالة "شغال" (customImageOn) ولحالة "مطفي" (customImageOff) نعرض الصورة
// المناسبة للحالة الحالية بدل أيقونة المكتبة. لو صورة حالة واحدة بس متحطة
// (مش الاتنين)، بتترجع هي في الحالتين لحد ما يحط التانية. غير كده بترجع
// أيقونة المكتبة العادية زي ما هي.
// isOn = undefined معناها "مفيش حالة تشغيل معروفة دلوقتي" (زي شاشة اختيار
// الأيقونة نفسها) فبنفضّل صورة الـ OFF كصورة تمثيلية افتراضية.
function deviceImageSource(device, isOn) {
  if (!device) return getDeviceIconImage(undefined);
  const on = device.customImageOn;
  const off = device.customImageOff || device.customImage; // customImage = التوافق مع نسخة قديمة كانت بتحفظ صورة واحدة بس
  if (isOn && on) return { uri: on };
  if (!isOn && off) return { uri: off };
  // مفيش صورة للحالة الحالية بالتحديد؛ استخدم أي صورة مخصوصة موجودة كبديل
  // أفضل من الرجوع للأيقونة الجاهزة على طول.
  if (on) return { uri: on };
  if (off) return { uri: off };
  return getDeviceIconImage(device.icon);
}

// بورد قديم كان بيستخدم شكل ثابت (relay1..relayN تحت prefix معيّن).
// الدالة دي بتحوّله لقايمة "أجهزة" عادية عشان يفضل شغال زي ما هو من غير ما يتمسح.
function deriveInitialDevices(board) {
  if (board.devices) return board.devices;
  if (board.prefix && board.relayCount) {
    const relayNames =
      board.relayNames && board.relayNames.length === board.relayCount
        ? board.relayNames
        : Array.from({ length: board.relayCount }, (_, i) => `المفتاح ${i + 1}`);
    return relayNames.map((name, i) => ({
      id: newId(),
      name,
      icon: (board.relayIcons && board.relayIcons[i]) || 'switch',
      controlType: 'toggle',
      controlTopic: `${board.prefix}/control/relay${i + 1}`,
      statusTopic: `${board.prefix}/status/relay${i + 1}`,
    }));
  }
  return [];
}

const SYNC_TIMEOUT_MS = 10000;

// تحقق من صيغة الوقت "HH:MM" بنظام 24 ساعة
function isValidHHMM(str) {
  return /^([01]\d|2[0-3]):([0-5]\d)$/.test(str);
}

export default function SwitchesScreen({ board, client, connected, pairingKey, onBack, onUpdateBoard }) {
  const { theme } = useTheme();
  const [devices, setDevices] = useState(() => deriveInitialDevices(board));
  const [deviceState, setDeviceState] = useState({}); // { [deviceId]: boolean } — لمفاتيح التشغيل/الإيقاف
  const [boardAvailable, setBoardAvailable] = useState(null); // 'online' | 'offline' | null = مش معروفة
  const [deviceRawStatus, setDeviceRawStatus] = useState({}); // { [deviceId]: string } — لأجهزة الطلوع/النزول

  // مؤشر بصري لحظي لزرار الاختبار (لحد ما يوصل رد OFF من الفيرموير) —
  // مش حالة حقيقية محفوظة، بس عشان يحس المستخدم إن الضغطة اتسجلت فورًا.
  const [testSending, setTestSending] = useState(false);

  const [formVisible, setFormVisible] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [fName, setFName] = useState('');
  const [fIcon, setFIcon] = useState('switch');
  const [fOnColor, setFOnColor] = useState(null); // null = لون الثيم الافتراضي
  const [fOffColor, setFOffColor] = useState(null);

  // صفحة "تعديل شكل المفاتيح" — نافذة واحدة منفصلة بتوريك كل المفاتيح مع
  // شكلها الحالي، وتقدر تغيّر شكل أي مفتاح على طول من غير ما تدخل على كارت
  // المفتاح نفسه وتفتح فورم التعديل الكامل (اللي فيه اسم وألوان وتوبيكات
  // كمان) — ده كان بيسبب لخبطة لو كل اللي عايزه بس تغيير الشكل.
  const [iconSettingsVisible, setIconSettingsVisible] = useState(false);
  const [iconEditDeviceId, setIconEditDeviceId] = useState(null);
  const [deviceImageBusy, setDeviceImageBusy] = useState(false);

  // تايمر لكل مفتاح: التايمر شغال جوه الفيرموير نفسه (مش من التطبيق)، عشان
  // يفضل شغال حتى لو التطبيق مقفول. التطبيق بس بيبعت أمر الإعداد للفيرموير
  // على `<control_topic>/timer/set`، وبيسمع حالة التايمر الحالية من
  // الفيرموير على `<control_topic>/timer/state` (شوف بروتوكول التايمر في
  // README.md) وبيعرضها زي ما هي.
  const [timerModalVisible, setTimerModalVisible] = useState(false);
  const [timerDeviceId, setTimerDeviceId] = useState(null);
  const [timerTab, setTimerTab] = useState('countdown'); // 'countdown' | 'schedule'
  const [countdownInput, setCountdownInput] = useState('30');
  const [scheduleOnInput, setScheduleOnInput] = useState('07:00');
  const [scheduleOffInput, setScheduleOffInput] = useState('22:00');
  const [scheduleEnabledInput, setScheduleEnabledInput] = useState(false);
  const [, forceTick] = useState(0); // بيتحدث كل ثانية عشان يحدّث عرض الوقت المتبقي بين رسايل الفيرموير
  // { [deviceId]: { mode: 'off'|'countdown'|'schedule', secondsLeft, receivedAt, scheduleEnabled, on, off } }
  const [deviceTimerState, setDeviceTimerState] = useState({});

  // مزامنة من الفيرموير: بيعيد الاستماع على نفس توبيك الاكتشاف بتاع البورد
  // (لازم يكون موقّع بنفس مفتاح الربط) ويضيف/يحدّث المفاتيح منه. مفيش أي
  // إضافة يدوية للتوبيكات — كل حاجة جاية من الفيرموير بتاعك فقط.
  const [syncing, setSyncing] = useState(false);
  const [syncError, setSyncError] = useState('');
  const syncTimeoutRef = useRef(null);
  const syncHandlerRef = useRef(null);

  const discoveryTopic = board.discoveryTopic || (board.prefix ? `${board.prefix}/discovery` : null);

  // زرار الموبايل الفيزيقي للرجوع — لو فيه مودال مفتوح (فورم إضافة/تعديل
  // مفتاح، أو مودال التايمر، أو صفحة تعديل الشكل)، بنسكّره الأول بدل ما نرجع لشاشة البوردات على طول.
  useEffect(() => {
    const onBackPress = () => {
      if (timerModalVisible) {
        setTimerModalVisible(false);
        return true;
      }
      if (formVisible) {
        setFormVisible(false);
        return true;
      }
      if (iconEditDeviceId) {
        setIconEditDeviceId(null);
        return true;
      }
      if (iconSettingsVisible) {
        setIconSettingsVisible(false);
        return true;
      }
      return false;
    };
    const sub = BackHandler.addEventListener('hardwareBackPress', onBackPress);
    return () => sub.remove();
  }, [timerModalVisible, formVisible, iconEditDeviceId, iconSettingsVisible]);

  const persistDevices = (list) => {
    // حدّث المرجع فورًا قبل أي إعادة رسم حتى لا يقرأ أي handler القيمة القديمة.
    devicesRef.current = list;
    setDevices(list);
    // تحديث البورد الأب فورًا حتى لا يرجع الاختيار القديم عند إغلاق الصفحة.
    onUpdateBoard?.({ ...board, devices: list });
  };

  // أول مرة نفتح بورد قديم اتحوّل لأجهزة، نحفظه بالشكل الجديد على طول
  useEffect(() => {
    if (!board.devices) {
      onUpdateBoard?.({ ...board, devices, relayNames: undefined, relayIcons: undefined, relayCount: undefined });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // نسخة دايمًا محدّثة من devices تُقرأ جوه الـ handlers، عشان الاشتراكات
  // في المقبس (subscribe/unsubscribe) متتربطش بأي تغيير في الأجهزة (زي تغيير
  // شكل مفتاح) وترتبط بس بتغيّر التوبيكات الفعلي. لو سبناها معتمدة على
  // devices نفسه، أي تعديل شكل (icon) كان بيعمل unsubscribe/resubscribe
  // لكل مفاتيح الحالة مرة واحدة، وده كان بيسبب فوات أو تلخبط في الرسايل
  // الواصلة لحظة التغيير — وده اللي كان بيبان إنه "كل الحالات بتتغير".
  const devicesRef = useRef(devices);
  useEffect(() => {
    devicesRef.current = devices;
  }, [devices]);

  const statusTopics = useMemo(() => {
    const set = new Set();
    devices.forEach((d) => set.add(d.statusTopic || d.controlTopic));
    return Array.from(set);
  }, [devices]);

  // توبيكات حالة التايمر: `<control_topic>/timer/state` — الفيرموير هو اللي بينشرها (Retained يفضل).
  // مفيش تايمر لأجهزة الطلوع/النزول (updown).
  const timerStateTopics = useMemo(() => {
    const set = new Set();
    devices.forEach((d) => d.controlType !== 'updown' && set.add(`${d.controlTopic}/timer/state`));
    return Array.from(set);
  }, [devices]);

  // مفتاح نصي ثابت من التوبيكات الفعلية بس (مش من كائن devices كله)، عشان
  // نستخدمه كـ dependency للـ effects بتاعة الاشتراك بدل الاعتماد على
  // statusTopics/timerStateTopics كمصفوفات — دول بيتعملهم إنشاء مصفوفة
  // جديدة (reference) في كل مرة devices يتغيّر فيها أي حاجة (زي تغيير شكل
  // مفتاح)، حتى لو التوبيكات نفسها متغيّرتش، وده كان بيخلي الـ effect يعمل
  // unsubscribe/resubscribe لكل المفاتيح من غير داعي.
  const statusTopicsKey = statusTopics.join('|');
  const timerStateTopicsKey = timerStateTopics.join('|');

  // حالة "توفر" البورد ده لوحده (مش الاتصال العام بالسيرفر) — بتتقرأ من
  // `<device_id>/availability` اللي الفيرموير بينشرها Retained + كـ Last Will.
  useEffect(() => {
    const topic = boardAvailabilityTopic(board);
    if (!client || !connected || !topic) {
      setBoardAvailable(null);
      return undefined;
    }

    client.subscribe(topic);
    const handler = (t, payload) => {
      if (t !== topic) return;
      const state = parseAvailability(payload.toString());
      if (state) setBoardAvailable(state);
    };
    client.on('message', handler);

    return () => {
      client.off('message', handler);
      client.unsubscribe(topic);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client, connected, board.deviceId]);

  useEffect(() => {
    if (!client || statusTopics.length === 0) return undefined;

    statusTopics.forEach((t) => client.subscribe(t));

    const handler = (topic, payload) => {
      const raw = payload.toString().trim();
      const msg = raw.toUpperCase();
      const devicesNow = devicesRef.current;

      // مهم جدًا: بعض نسخ الـFirmware القديمة كانت تستخدم status topic واحد
      // لأكثر من ريليه. لو لفّينا على كل الأجهزة هنا، رسالة ON واحدة كانت
      // تغيّر كل المفاتيح معًا. لا نوزّع الحالة على أكثر من جهاز إلا لو قدرنا
      // تحديد الريليه بوضوح من التوبيك أو من JSON الرسالة.
      let targets = devicesNow.filter((d) => (d.statusTopic || d.controlTopic) === topic);

      // لو الـstatus topic مشترك، حاول تحديد الريليه من آخر رقم في التوبيك
      // (مثل relay1 / relay2)، أو من JSON مثل {relay: 2, state: "ON"}.
      if (targets.length > 1) {
        const relayMatch = topic.match(/(?:relay|switch)[_\/-]?(\d+)$/i);
        let relayNo = relayMatch ? Number(relayMatch[1]) : null;
        let jsonState = null;
        try {
          const data = JSON.parse(raw);
          if (relayNo == null && Number.isFinite(Number(data.relay ?? data.relay_index ?? data.switch))) {
            relayNo = Number(data.relay ?? data.relay_index ?? data.switch);
          }
          jsonState = data.state ?? data.status ?? data.value ?? data.on;
        } catch (_) {}

        if (relayNo != null) {
          const suffix = `relay${relayNo}`;
          targets = devicesNow.filter((d) =>
            String(d.controlTopic || '').toLowerCase().endsWith(suffix.toLowerCase()) ||
            String(d.statusTopic || '').toLowerCase().endsWith(suffix.toLowerCase())
          );
        }

        if (targets.length > 1) targets = [];
      }

      let stateValue = null;
      if (msg === 'ON' || msg === '1' || msg === 'TRUE') stateValue = true;
      else if (msg === 'OFF' || msg === '0' || msg === 'FALSE') stateValue = false;
      else {
        try {
          const data = JSON.parse(raw);
          const v = String(data.state ?? data.status ?? data.value ?? '').trim().toUpperCase();
          if (v === 'ON' || v === '1' || v === 'TRUE') stateValue = true;
          if (v === 'OFF' || v === '0' || v === 'FALSE') stateValue = false;
        } catch (_) {}
      }

      if (targets.length !== 1) return;
      const d = targets[0];
      if (d.controlType === 'updown') {
        setDeviceRawStatus((prev) => ({ ...prev, [d.id]: raw }));
      } else if (stateValue !== null) {
        setDeviceState((prev) => ({ ...prev, [d.id]: stateValue }));
      }
    };

    client.on('message', handler);
    return () => {
      client.off('message', handler);
      statusTopics.forEach((t) => client.unsubscribe(t));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client, statusTopicsKey]);

  useEffect(() => {
    if (!client || timerStateTopics.length === 0) return undefined;

    timerStateTopics.forEach((t) => client.subscribe(t));

    const handler = (topic, payload) => {
      const device = devicesRef.current.find((d) => `${d.controlTopic}/timer/state` === topic);
      if (!device) return;
      let data;
      try {
        data = JSON.parse(payload.toString());
      } catch (e) {
        return; // رسالة تايمر مش JSON صحيح — اتجاهلها
      }
      setDeviceTimerState((prev) => ({
        ...prev,
        [device.id]: {
          mode: data.mode === 'countdown' || data.mode === 'schedule' ? data.mode : 'off',
          secondsLeft: typeof data.seconds_left === 'number' ? data.seconds_left : null,
          receivedAt: Date.now(),
          scheduleEnabled: !!data.schedule_enabled,
          on: typeof data.on === 'string' ? data.on : null,
          off: typeof data.off === 'string' ? data.off : null,
        },
      }));
    };

    client.on('message', handler);
    return () => {
      client.off('message', handler);
      timerStateTopics.forEach((t) => client.unsubscribe(t));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client, timerStateTopicsKey]);

  const cleanupSync = () => {
    if (syncTimeoutRef.current) {
      clearTimeout(syncTimeoutRef.current);
      syncTimeoutRef.current = null;
    }
    if (client && discoveryTopic && syncHandlerRef.current) {
      client.off('message', syncHandlerRef.current);
      client.unsubscribe(discoveryTopic);
    }
    syncHandlerRef.current = null;
  };

  useEffect(() => cleanupSync, []); // eslint-disable-line react-hooks/exhaustive-deps

  const startSync = () => {
    if (!discoveryTopic) {
      Alert.alert('خطأ', 'البورد ده مضاف قديم ومش متسجل عليه توبيك اكتشاف — احذفه وأضفه تاني بالاكتشاف التلقائي.');
      return;
    }
    if (!pairingKey) {
      Alert.alert('خطأ', 'لازم تحط مفتاح الربط (Pairing Key) في الإعدادات الأول');
      return;
    }
    if (!client || !connected) {
      Alert.alert('خطأ', 'لسه مش متصل بالسيرفر، استنى ثانية وحاول تاني');
      return;
    }

    cleanupSync();
    setSyncError('');
    setSyncing(true);
    client.subscribe(discoveryTopic);

    const handler = (t, payload) => {
      if (t !== discoveryTopic) return;
      const result = parseBoardDiscovery(payload.toString(), pairingKey);
      cleanupSync();
      setSyncing(false);
      if (!result.ok) {
        setSyncError(result.error);
        return;
      }
      if (result.board.type !== 'switches') {
        setSyncError('رسالة الاكتشاف اللي وصلت مش لبورد لوحة مفاتيح.');
        return;
      }
      const incoming = result.board.devices;
      let addedCount = 0;
      let updatedCount = 0;
      const byTopic = new Map(devices.map((d) => [d.controlTopic, d]));
      const merged = devices.map((d) => {
        const inc = byTopic.get(d.controlTopic) && incoming.find((i) => i.controlTopic === d.controlTopic);
        if (!inc) return d;
        updatedCount += 1;
        return { ...d, name: inc.name, icon: d.iconSource === 'user' ? d.icon : inc.icon, controlType: inc.controlType, statusTopic: inc.statusTopic };
      });
      incoming.forEach((inc) => {
        if (!byTopic.has(inc.controlTopic)) {
          addedCount += 1;
          merged.push({ id: newId(), ...inc, iconSource: 'firmware' });
        }
      });
      persistDevices(merged);
      Alert.alert('تمت المزامنة', `تمت إضافة ${addedCount} مفتاح جديد وتحديث ${updatedCount} مفتاح موجود.`);
    };
    syncHandlerRef.current = handler;
    client.on('message', handler);

    syncTimeoutRef.current = setTimeout(() => {
      cleanupSync();
      setSyncing(false);
      setSyncError('مفيش رد من الفيرموير. اتأكد إنها شغالة ومتصلة وناشرة رسالة الاكتشاف Retained.');
    }, SYNC_TIMEOUT_MS);
  };

  const toggleDevice = (device) => {
    const current = !!deviceState[device.id];
    const next = !current;

    // نغيّر حالة المفتاح الذي اتضغط عليه فقط فورًا. ده يمنع واجهة التطبيق
    // من إظهار كل المفاتيح ON/OFF معًا حتى لو الـFirmware لا يرسل status
    // topic منفصل لكل ريليه. وبعدها الحالة الحقيقية من الـMQTT تصحح العرض.
    setDeviceState((prev) => ({ ...prev, [device.id]: next }));
    client?.publish(device.controlTopic, next ? 'ON' : 'OFF');
  };

  const moveDevice = (device, direction) => client?.publish(device.controlTopic, direction);

  // بروتوكول التايمر (شوف README.md "بروتوكول التايمر"):
  // أمر يتبعت على `<control_topic>/timer/set` كـ JSON، والفيرموير هو اللي بينفذه ويحتفظ بيه.
  const publishTimerCommand = (device, payload) => {
    client?.publish(`${device.controlTopic}/timer/set`, JSON.stringify(payload));
  };

  const startCountdown = (device, minutesStr) => {
    const mins = Math.max(1, parseInt(minutesStr, 10) || 0);
    if (!mins) {
      Alert.alert('خطأ', 'اكتب عدد دقايق صحيح');
      return;
    }
    publishTimerCommand(device, { mode: 'countdown', minutes: mins });
    setTimerModalVisible(false);
  };

  const cancelCountdown = (device) => {
    publishTimerCommand(device, { mode: 'off' });
  };

  const saveSchedule = (device, onTime, offTime, enabled) => {
    if (enabled && (!isValidHHMM(onTime) || !isValidHHMM(offTime))) {
      Alert.alert('خطأ', 'اكتب الوقت بصيغة صحيحة زي 07:00 (24 ساعة)');
      return;
    }
    publishTimerCommand(device, { mode: 'schedule', enabled, on: onTime, off: offTime });
    setTimerModalVisible(false);
  };

  const openTimerModal = (device) => {
    const st = deviceTimerState[device.id];
    setTimerDeviceId(device.id);
    setTimerTab('countdown');
    setCountdownInput(st?.mode === 'countdown' && st.secondsLeft ? String(Math.ceil(st.secondsLeft / 60)) : '30');
    setScheduleOnInput(st?.on || '07:00');
    setScheduleOffInput(st?.off || '22:00');
    setScheduleEnabledInput(!!st?.scheduleEnabled);
    setTimerModalVisible(true);
  };

  // بيحدّث العرض كل ثانية طول ما فيه عد تنازلي شغال، عشان نعرض الوقت المتبقي وهو بينزل
  // بين رسالة وتانية من الفيرموير (interpolation)، مش إنه هو اللي بيتحكم في المفتاح.
  useEffect(() => {
    const hasActive = Object.values(deviceTimerState).some((s) => s.mode === 'countdown');
    if (!hasActive) return undefined;
    const id = setInterval(() => forceTick((t) => t + 1), 1000);
    return () => clearInterval(id);
  }, [deviceTimerState]);

  const getCountdownLabel = (device) => {
    const st = deviceTimerState[device.id];
    if (!st || st.mode !== 'countdown' || st.secondsLeft == null) return null;
    const elapsed = Math.floor((Date.now() - st.receivedAt) / 1000);
    const remaining = st.secondsLeft - elapsed;
    if (remaining <= 0) return null;
    const m = Math.floor(remaining / 60);
    const s = remaining % 60;
    return `${m}:${String(s).padStart(2, '0')}`;
  };

  // زرار الطوارئ وزرار الاختبار مش مفاتيح عادية — الفيرموير بيوزّعهم زي أي
  // مفتاح عادي في رسالة الاكتشاف (control_topic/status_topic/icon) عشان
  // ينضموا للمزامنة تلقائي، بس شكلهم في الآيقونة (emergency-button / bell)
  // بيميّزهم عشان نطلعهم برا الشبكة العادية ونتحكم فيهم من شريط سفلي صغير.
  const emergencyDevice = devices.find((d) => getDeviceIcon(d.icon).isEmergency);
  const testDevice = devices.find((d) => d.icon === 'bell');
  const regularDevices = devices.filter((d) => d !== emergencyDevice && d !== testDevice);
  const emergencyOn = emergencyDevice ? !!deviceState[emergencyDevice.id] : false;

  const allOn = () =>
    regularDevices.forEach((d) => d.controlType !== 'updown' && client?.publish(d.controlTopic, 'ON'));
  const allOff = () =>
    regularDevices.forEach((d) => (d.controlType === 'updown' ? client?.publish(d.controlTopic, 'STOP') : client?.publish(d.controlTopic, 'OFF')));

  // زرار الطوارئ الفعلي — بيبعت ON/OFF على control_topic بتاعه (نفس أي
  // مفتاح toggle عادي)، والفيرموير هو اللي بيشغّل/يوقف الريليهات المحددة
  // له ويرجّع الحالة الحقيقية على status_topic (مش تفاؤلي من الابلكيشن).
  // بنأكد قبل أي تغيير (تفعيل أو إلغاء) لأنه بيأثر على أجهزة فعلية فورًا.
  const handleEmergencyPress = () => {
    if (!emergencyDevice) return;
    const turningOn = !emergencyOn;
    Alert.alert(
      turningOn ? 'تأكيد تفعيل الطوارئ' : 'تأكيد إلغاء الطوارئ',
      turningOn
        ? 'هيتفعل وضع الطوارئ ويشغّل المخارج المحددة له فورًا. متأكد؟'
        : 'هيرجع البورد للوضع الطبيعي ويوقف وضع الطوارئ. متأكد؟',
      [
        { text: 'إلغاء', style: 'cancel' },
        {
          text: turningOn ? 'تفعيل الآن' : 'تأكيد',
          style: turningOn ? 'destructive' : 'default',
          onPress: () => {
            client?.publish(emergencyDevice.controlTopic, turningOn ? 'ON' : 'OFF');
            if (turningOn) {
              notifyLocal('🚨 طوارئ', `تم تفعيل زرار الطوارئ في ${board.name}`);
            }
          },
        },
      ]
    );
  };

  // زرار الاختبار الفعلي — نبضة بس (ON)، والفيرموير بيبعت إشعار ntfy ويرجع
  // OFF لوحده تاني على طول، فمفيش داعي لأي تأكيد أو حالة "شغال" دايمة هنا.
  const sendTest = () => {
    if (!testDevice) return;
    client?.publish(testDevice.controlTopic, 'ON');
    setTestSending(true);
    setTimeout(() => setTestSending(false), 1500);
  };

  const openEditForm = (device) => {
    setEditingId(device.id);
    setFName(device.name);
    setFIcon(device.icon || 'switch');
    setFOnColor(device.onColor || null);
    setFOffColor(device.offColor || null);
    setFormVisible(true);
  };

  const deleteDevice = (id) => {
    Alert.alert('حذف المفتاح', 'متأكد إنك عايز تمسح المفتاح ده؟ (لو الفيرموير لسه بينشره، هيرجع تاني أول مزامنة)', [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'مسح',
        style: 'destructive',
        onPress: () => persistDevices(devices.filter((d) => d.id !== id)),
      },
    ]);
  };

  // تغيير شكل مفتاح واحد بس (من صفحة "تعديل شكل المفاتيح")، من غير ما يلمس
  // أي حاجة تانية في المفتاح (اسمه، ألوانه، توبيكاته).
  const setDeviceIconOnly = (id, icon) => {
    // اختيار المستخدم هو المصدر الأعلى للأيقونة؛ لا تسمح مزامنة الفيرموير
    // باستبداله لاحقًا. نستخدم المرجع الحالي حتى لا نعتمد على state قديم.
    // اختيار أيقونة جاهزة من المكتبة معناه التراجع عن أي صور مخصوصة كانت متحطة (شغال/مطفي).
    const next = devicesRef.current.map((d) => (d.id === id ? { ...d, icon, iconSource: 'user', customImage: null, customImageOn: null, customImageOff: null } : d));
    persistDevices(next);
    FileSystem.deleteAsync(`${DEVICE_IMAGES_DIR}${id}-on.jpg`, { idempotent: true }).catch(() => {});
    FileSystem.deleteAsync(`${DEVICE_IMAGES_DIR}${id}-off.jpg`, { idempotent: true }).catch(() => {});
    FileSystem.deleteAsync(`${DEVICE_IMAGES_DIR}${id}.jpg`, { idempotent: true }).catch(() => {});
    // لا نغلق شاشة الاختيار؛ خلي المستخدم يشوف الأيقونة الجديدة فورًا
    // ويقدر يختار أيقونة أخرى بدون فتح الشاشة من جديد.
    setIconEditDeviceId(id);
  };

  // اختيار صورة حقيقية من معرض الصور بدل أيقونة المفتاح — لحالة "شغال" أو
  // "مطفي" على حدة، عشان الصورة نفسها تبين حالة المفتاح.
  const pickDeviceImageFromLibrary = async (id, state) => {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('مفيش صلاحية', 'لازم تسمح للتطبيق بالدخول على الصور من إعدادات الموبايل الأول');
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 0.7,
    });
    if (result.canceled || !result.assets?.[0]?.uri) return;
    setDeviceImageBusy(true);
    try {
      const saved = await persistPickedDeviceImage(result.assets[0].uri, id, state);
      const field = state === 'on' ? 'customImageOn' : 'customImageOff';
      const next = devicesRef.current.map((d) => (d.id === id ? { ...d, [field]: saved, iconSource: 'user' } : d));
      persistDevices(next);
    } catch (e) {
      Alert.alert('خطأ', 'مقدرناش نحفظ الصورة، جرب تاني');
    } finally {
      setDeviceImageBusy(false);
    }
  };

  // التقاط صورة بالكاميرا بدل أيقونة المفتاح — لحالة "شغال" أو "مطفي".
  const takeDeviceImage = async (id, state) => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      Alert.alert('مفيش صلاحية', 'لازم تسمح للتطبيق باستخدام الكاميرا من إعدادات الموبايل الأول');
      return;
    }
    const result = await ImagePicker.launchCameraAsync({ allowsEditing: true, aspect: [1, 1], quality: 0.7 });
    if (result.canceled || !result.assets?.[0]?.uri) return;
    setDeviceImageBusy(true);
    try {
      const saved = await persistPickedDeviceImage(result.assets[0].uri, id, state);
      const field = state === 'on' ? 'customImageOn' : 'customImageOff';
      const next = devicesRef.current.map((d) => (d.id === id ? { ...d, [field]: saved, iconSource: 'user' } : d));
      persistDevices(next);
    } catch (e) {
      Alert.alert('خطأ', 'مقدرناش نحفظ الصورة، جرب تاني');
    } finally {
      setDeviceImageBusy(false);
    }
  };

  // رجوع لأيقونة المكتبة العادية بدل الصورة المخصوصة — لحالة واحدة بس
  // (شغال أو مطفي)؛ الحالة التانية بتفضل زي ما هي لو متحطة.
  const removeDeviceImage = (id, state) => {
    const field = state === 'on' ? 'customImageOn' : 'customImageOff';
    const next = devicesRef.current.map((d) => (d.id === id ? { ...d, [field]: null, ...(field === 'customImageOff' ? { customImage: null } : {}) } : d));
    persistDevices(next);
    FileSystem.deleteAsync(`${DEVICE_IMAGES_DIR}${id}-${state}.jpg`, { idempotent: true }).catch(() => {});
  };

  const saveForm = () => {
    if (!editingId) return;
    const current = devices.find((d) => d.id === editingId);
    if (!current) return;
    const payload = {
      name: fName.trim() || current.name,
      icon: fIcon,
      iconSource: 'user',
      onColor: current.controlType === 'toggle' ? fOnColor || undefined : undefined,
      offColor: current.controlType === 'toggle' ? fOffColor || undefined : undefined,
    };
    persistDevices(devices.map((d) => (d.id === editingId ? { ...d, ...payload } : d)));
    setFormVisible(false);
  };

  const styles = getStyles(theme);
  const editingDevice = devices.find((d) => d.id === editingId);
  const timerDevice = devices.find((d) => d.id === timerDeviceId);
  const timerDeviceState = timerDevice ? deviceTimerState[timerDevice.id] : null;
  const activeCountdownLabel = timerDevice ? getCountdownLabel(timerDevice) : null;

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.headerRow}>
        <TouchableOpacity onPress={onBack}>
          <Text style={styles.back}>‹ رجوع</Text>
        </TouchableOpacity>
        <Text style={styles.title}>{board.name}</Text>
        <TouchableOpacity onPress={() => setIconSettingsVisible(true)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
          <MaterialCommunityIcons name="cog-outline" size={22} color={theme.textSecondary} />
        </TouchableOpacity>
      </View>

      <View style={styles.statusRow}>
        <View style={[styles.dot, { backgroundColor: connected ? theme.on : theme.off }]} />
        <Text style={styles.statusLabel}>
          {connected ? 'متصل بالسيرفر' : 'جاري الاتصال…'}
          {connected && boardAvailabilityTopic(board)
            ? `  •  البورد: ${boardAvailable === 'online' ? 'أونلاين' : boardAvailable === 'offline' ? 'أوفلاين' : 'غير معروف'}`
            : ''}
        </Text>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 60 }}>
        {regularDevices.length > 0 && (
          <View style={styles.btnRow}>
            <TouchableOpacity style={[styles.smallBtn, styles.onBtn]} onPress={allOn}>
              <Text style={styles.btnText}>تشغيل الكل</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.smallBtn, styles.offBtn]} onPress={allOff}>
              <Text style={styles.btnText}>إيقاف الكل</Text>
            </TouchableOpacity>
          </View>
        )}

        {regularDevices.length === 0 && (
          <Text style={styles.emptyText}>
            مفيش مفاتيح لسه في البورد ده. دوس "🔄 مزامنة من الفيرموير" عشان الفيرموير يبعت المفاتيح تلقائي.
          </Text>
        )}

        <View style={styles.grid}>
          {regularDevices.map((device) => (
            <DeviceCard
              key={device.id}
              device={device}
              theme={theme}
              isOn={!!deviceState[device.id]}
              rawStatus={deviceRawStatus[device.id]}
              countdownLabel={getCountdownLabel(device)}
              scheduleActive={!!deviceTimerState[device.id]?.scheduleEnabled}
              onToggle={() => toggleDevice(device)}
              onUp={() => moveDevice(device, 'UP')}
              onStop={() => moveDevice(device, 'STOP')}
              onDown={() => moveDevice(device, 'DOWN')}
              onOpenTimer={() => openTimerModal(device)}
            />
          ))}
        </View>

        {syncing && (
          <View style={styles.syncRow}>
            <ActivityIndicator color={theme.accent} />
            <Text style={styles.listeningHint}>بيزامن مع الفيرموير…</Text>
          </View>
        )}
        {!!syncError && <Text style={styles.errorText}>⚠ {syncError}</Text>}

        <View style={styles.btnRow}>
          <TouchableOpacity
            style={[styles.addBtn, styles.discoverBtn, { flex: 1 }]}
            onPress={startSync}
            disabled={syncing}
          >
            <Text style={styles.discoverBtnText}>🔄 مزامنة من الفيرموير</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* شريط سفلي صغير — أيقونتين بس: اختبار وطوارئ، منفصلين عن باقي أزرار
          الشاشة عشان يفضلوا واضحين وسهل الوصول لهم من غير ما يتلخبطوا مع
          كروت المفاتيح. بيظهروا بس لو الفيرموير بعتهم في آخر مزامنة. */}
      {(emergencyDevice || testDevice) && (
        <View style={styles.utilityRow}>
          {testDevice && (
            <TouchableOpacity
              style={styles.utilityBtn}
              onPress={sendTest}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            >
              <MaterialCommunityIcons
                name={testSending ? 'bell-ring' : 'bell-ring-outline'}
                size={22}
                color={theme.accent}
              />
              <Text style={[styles.utilityLabel, { color: theme.textSecondary }]}>
                {testSending ? 'جاري الإرسال…' : 'اختبار'}
              </Text>
            </TouchableOpacity>
          )}

          {emergencyDevice && (
            <TouchableOpacity
              style={styles.utilityBtn}
              onPress={handleEmergencyPress}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            >
              <View>
                <MaterialCommunityIcons
                  name="alarm-light-outline"
                  size={22}
                  color={emergencyOn ? EMERGENCY_ON : theme.danger}
                />
                {emergencyOn && <View style={styles.emergencyLiveDot} />}
              </View>
              <Text
                style={[
                  styles.utilityLabel,
                  { color: emergencyOn ? EMERGENCY_ON : theme.textSecondary, fontWeight: emergencyOn ? '700' : '600' },
                ]}
              >
                {emergencyOn ? 'طوارئ نشطة' : 'طوارئ'}
              </Text>
            </TouchableOpacity>
          )}
        </View>
      )}

      {/* مودال تعديل شكل المفتاح — الاسم والأيقونة والألوان بس، مش التوبيكات.
          التوبيكات بتيجي من الفيرموير عن طريق الاكتشاف الموقّع فقط. */}
      <Modal visible={formVisible} transparent animationType="fade" onRequestClose={() => setFormVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <ScrollView keyboardShouldPersistTaps="handled">
              <Text style={styles.modalTitle}>تعديل شكل المفتاح</Text>

              <Text style={styles.label}>اسم المفتاح</Text>
              <TextInput
                style={styles.input}
                value={fName}
                onChangeText={setFName}
                placeholder="لمبة الصالة"
                placeholderTextColor={theme.textMuted}
              />

              <Text style={styles.label}>توبيك التحكم (من الفيرموير — مش قابل للتعديل)</Text>
              <View style={styles.codeBox}>
                <Text style={styles.codeText}>{editingDevice?.controlTopic}</Text>
              </View>

              <Text style={styles.label}>توبيك الحالة (من الفيرموير)</Text>
              <View style={styles.codeBox}>
                <Text style={styles.codeText}>{editingDevice?.statusTopic || editingDevice?.controlTopic}</Text>
              </View>

              {editingDevice?.controlType !== 'updown' && (
                <>
                  <Text style={styles.label}>لون حالة التشغيل (ON)</Text>
                  <ColorPickerRow
                    styles={styles}
                    themeColor={
                      getDeviceIcon(fIcon).isLight
                        ? LIGHT_WARM_ON
                        : getDeviceIcon(fIcon).isEmergency
                        ? EMERGENCY_ON
                        : theme.on
                    }
                    value={fOnColor}
                    onChange={setFOnColor}
                  />

                  <Text style={styles.label}>لون حالة الإيقاف (OFF)</Text>
                  <ColorPickerRow styles={styles} themeColor={theme.off} value={fOffColor} onChange={setFOffColor} />
                </>
              )}

              <Text style={styles.label}>شكل المفتاح</Text>
              <FlatList
                data={REALISTIC_ICON_OPTIONS}
                keyExtractor={(item) => item.id}
                numColumns={4}
                scrollEnabled={false}
                contentContainerStyle={{ marginTop: 4 }}
                renderItem={({ item }) => {
                  const selected = fIcon === item.id;
                  return (
                    <TouchableOpacity
                      style={[styles.iconOption, selected && styles.iconOptionSelected]}
                      onPress={() => setFIcon(item.id)}
                    >
                      <Image source={item.image || getDeviceIconImage(item.id)} style={styles.iconOptionImage} resizeMode="contain" />
                      <Text style={styles.iconOptionLabel} numberOfLines={1}>
                        {item.label}
                      </Text>
                    </TouchableOpacity>
                  );
                }}
              />

              <View style={styles.btnRow}>
                <TouchableOpacity style={[styles.smallBtn, styles.onBtn]} onPress={saveForm}>
                  <Text style={styles.btnText}>حفظ</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.smallBtn, styles.offBtn]} onPress={() => setFormVisible(false)}>
                  <Text style={styles.btnText}>إلغاء</Text>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* صفحة "تعديل شكل المفاتيح" — قايمة كل المفاتيح مع شكلها، تدوس على أي
          واحد فيهم يفتحلك شبكة الأيقونات تختار منها على طول، من غير فورم
          تعديل كامل (اسم/ألوان/توبيكات) عشان محدش يتلخبط. */}
      <Modal
        visible={iconSettingsVisible}
        transparent
        animationType="fade"
        onRequestClose={() => {
          setIconEditDeviceId(null);
          setIconSettingsVisible(false);
        }}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <ScrollView keyboardShouldPersistTaps="handled">
              {iconEditDeviceId ? (
                <>
                  <Text style={styles.modalTitle}>
                    شكل — {devices.find((d) => d.id === iconEditDeviceId)?.name}
                  </Text>

                  {/* اختيار صورتين حقيقيتين بدل أيقونة المفتاح — واحدة للحالة
                      "شغال" وواحدة للحالة "مطفي"، عشان الصورة نفسها تبين حالة
                      المفتاح لحظة ما تشغّله أو تطفيه. */}
                  <Text style={styles.hint}>حط صورة لكل حالة (اختياري) — تقدر تحط صورة واحدة بس وهتتستخدم للحالتين لحد ما تحط التانية.</Text>
                  <View style={styles.deviceImageStatesRow}>
                    {[
                      { key: 'off', label: 'الحالة: مطفي', field: 'customImageOff' },
                      { key: 'on', label: 'الحالة: شغال', field: 'customImageOn' },
                    ].map(({ key, label, field }) => {
                      const current = devices.find((d) => d.id === iconEditDeviceId);
                      const hasImage = !!current?.[field] || (key === 'off' && !!current?.customImage);
                      return (
                        <View key={key} style={styles.deviceImageStateCol}>
                          <Text style={styles.deviceImageStateLabel}>{label}</Text>
                          <Image
                            source={key === 'on' ? deviceImageSource(current, true) : deviceImageSource(current, false)}
                            style={styles.deviceImagePreview}
                            resizeMode="contain"
                          />
                          <TouchableOpacity
                            style={styles.imagePickBtn}
                            onPress={() => pickDeviceImageFromLibrary(iconEditDeviceId, key)}
                            disabled={deviceImageBusy}
                          >
                            <MaterialCommunityIcons name="image-outline" size={14} color={theme.textPrimary} />
                            <Text style={styles.imagePickBtnText}>من المعرض</Text>
                          </TouchableOpacity>
                          <TouchableOpacity
                            style={styles.imagePickBtn}
                            onPress={() => takeDeviceImage(iconEditDeviceId, key)}
                            disabled={deviceImageBusy}
                          >
                            <MaterialCommunityIcons name="camera-outline" size={14} color={theme.textPrimary} />
                            <Text style={styles.imagePickBtnText}>كاميرا</Text>
                          </TouchableOpacity>
                          {hasImage && (
                            <TouchableOpacity
                              style={styles.imagePickBtn}
                              onPress={() => removeDeviceImage(iconEditDeviceId, key)}
                              disabled={deviceImageBusy}
                            >
                              <MaterialCommunityIcons name="close-circle-outline" size={14} color={theme.danger} />
                              <Text style={[styles.imagePickBtnText, { color: theme.danger }]}>إزالة</Text>
                            </TouchableOpacity>
                          )}
                        </View>
                      );
                    })}
                  </View>
                  {deviceImageBusy && <ActivityIndicator color={theme.accent} style={{ marginBottom: 8 }} />}

                  <Text style={styles.hint}>أو اختار شكل جاهز من المكتبة تحت:</Text>
                  <FlatList
                    data={REALISTIC_ICON_OPTIONS}
                    keyExtractor={(item) => item.id}
                    numColumns={4}
                    scrollEnabled={false}
                    contentContainerStyle={{ marginTop: 4 }}
                    renderItem={({ item }) => {
                      const current = devices.find((d) => d.id === iconEditDeviceId);
                      const selected = (current?.icon || 'switch') === item.id;
                      return (
                        <TouchableOpacity
                          style={[styles.iconOption, selected && styles.iconOptionSelected]}
                          onPress={() => setDeviceIconOnly(iconEditDeviceId, item.id)}
                        >
                          <View style={[styles.iconOptionGlass, selected && styles.iconOptionGlassSelected]}>
                            <Image source={item.image || getDeviceIconImage(item.id)} style={styles.iconOptionImageSmall} resizeMode="contain" />
                          </View>
                          <Text style={styles.iconOptionLabel} numberOfLines={1}>
                            {item.label}
                          </Text>
                        </TouchableOpacity>
                      );
                    }}
                  />
                  <View style={styles.btnRow}>
                    <TouchableOpacity style={[styles.smallBtn, styles.offBtn]} onPress={() => setIconEditDeviceId(null)}>
                      <Text style={styles.btnText}>‹ رجوع لقايمة المفاتيح</Text>
                    </TouchableOpacity>
                  </View>
                </>
              ) : (
                <>
                  <Text style={styles.modalTitle}>تعديل المفاتيح</Text>
                  <Text style={styles.hint}>
                    دوس على المفتاح عشان تغيّر شكله، ✏️ للتعديل الكامل (الاسم والألوان)، 🗑 للحذف.
                  </Text>
                  {devices.map((d) => {
                    const iconDef = getDeviceIcon(d.icon);
                    return (
                      <View key={d.id} style={styles.shapeListRow}>
                        <TouchableOpacity
                          style={styles.shapeListMain}
                          onPress={() => setIconEditDeviceId(d.id)}
                        >
                          <View style={styles.shapeListIconWrap}>
                            <Image source={deviceImageSource(d, !!deviceState[d.id])} style={styles.shapeListImage} resizeMode="contain" />
                          </View>
                          <Text style={styles.shapeListName} numberOfLines={1}>
                            {d.name}
                          </Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          style={styles.shapeListAction}
                          onPress={() => {
                            setIconSettingsVisible(false);
                            openEditForm(d);
                          }}
                          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                        >
                          <MaterialCommunityIcons name="pencil-outline" size={18} color={theme.textSecondary} />
                        </TouchableOpacity>
                        <TouchableOpacity
                          style={styles.shapeListAction}
                          onPress={() => deleteDevice(d.id)}
                          hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                        >
                          <MaterialCommunityIcons name="trash-can-outline" size={18} color={theme.danger} />
                        </TouchableOpacity>
                      </View>
                    );
                  })}
                  {devices.length === 0 && (
                    <Text style={styles.emptyText}>مفيش مفاتيح لسه في البورد ده.</Text>
                  )}
                  <View style={styles.btnRow}>
                    <TouchableOpacity style={[styles.smallBtn, styles.offBtn]} onPress={() => setIconSettingsVisible(false)}>
                      <Text style={styles.btnText}>تم</Text>
                    </TouchableOpacity>
                  </View>
                </>
              )}
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* مودال التايمر: عد تنازلي (يقفل بعد مدة) أو جدولة يومية (يشتغل ويقفل في وقت معين) */}
      <Modal visible={timerModalVisible} transparent animationType="fade" onRequestClose={() => setTimerModalVisible(false)}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <ScrollView keyboardShouldPersistTaps="handled">
              <Text style={styles.modalTitle}>تايمر — {timerDevice?.name}</Text>

              <View style={styles.tabRow}>
                <TouchableOpacity
                  style={[styles.tabBtn, timerTab === 'countdown' && styles.tabBtnActive]}
                  onPress={() => setTimerTab('countdown')}
                >
                  <Text style={[styles.tabBtnText, timerTab === 'countdown' && styles.tabBtnTextActive]}>
                    عد تنازلي
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.tabBtn, timerTab === 'schedule' && styles.tabBtnActive]}
                  onPress={() => setTimerTab('schedule')}
                >
                  <Text style={[styles.tabBtnText, timerTab === 'schedule' && styles.tabBtnTextActive]}>
                    جدولة يومية
                  </Text>
                </TouchableOpacity>
              </View>

              {timerTab === 'countdown' ? (
                <>
                  <Text style={styles.label}>هيشتغل المفتاح دلوقتي ويقفل لوحده بعد كام دقيقة؟</Text>
                  <TextInput
                    style={styles.input}
                    value={countdownInput}
                    onChangeText={setCountdownInput}
                    keyboardType="number-pad"
                    placeholder="30"
                    placeholderTextColor={theme.textMuted}
                  />
                  <Text style={styles.hint}>
                    الأمر بيتبعت للفيرموير وهو اللي بيحسب العد التنازلي ويقفل المفتاح — يفضل شغال حتى لو قفلت التطبيق.
                  </Text>

                  {activeCountdownLabel && (
                    <Text style={[styles.hint, { color: theme.accentSoft, marginTop: 8 }]}>
                      متبقي دلوقتي: {activeCountdownLabel}
                    </Text>
                  )}

                  <View style={styles.btnRow}>
                    <TouchableOpacity
                      style={[styles.smallBtn, styles.onBtn]}
                      onPress={() => timerDevice && startCountdown(timerDevice, countdownInput)}
                    >
                      <Text style={styles.btnText}>ابدأ العد التنازلي</Text>
                    </TouchableOpacity>
                    {timerDeviceState?.mode === 'countdown' && (
                      <TouchableOpacity
                        style={[styles.smallBtn, styles.offBtn]}
                        onPress={() => {
                          cancelCountdown(timerDevice);
                          setTimerModalVisible(false);
                        }}
                      >
                        <Text style={styles.btnText}>إلغاء التايمر</Text>
                      </TouchableOpacity>
                    )}
                  </View>
                </>
              ) : (
                <>
                  <TouchableOpacity
                    style={styles.syncRow}
                    onPress={() => setScheduleEnabledInput((v) => !v)}
                  >
                    <MaterialCommunityIcons
                      name={scheduleEnabledInput ? 'toggle-switch' : 'toggle-switch-off-outline'}
                      size={30}
                      color={scheduleEnabledInput ? theme.accent : theme.textMuted}
                    />
                    <Text style={styles.statusLabel}>{scheduleEnabledInput ? 'الجدولة مفعّلة' : 'الجدولة متوقفة'}</Text>
                  </TouchableOpacity>

                  <Text style={styles.label}>وقت التشغيل (24 ساعة، مثال 07:00)</Text>
                  <TextInput
                    style={styles.input}
                    value={scheduleOnInput}
                    onChangeText={setScheduleOnInput}
                    placeholder="07:00"
                    placeholderTextColor={theme.textMuted}
                  />

                  <Text style={styles.label}>وقت الإيقاف (24 ساعة، مثال 22:00)</Text>
                  <TextInput
                    style={styles.input}
                    value={scheduleOffInput}
                    onChangeText={setScheduleOffInput}
                    placeholder="22:00"
                    placeholderTextColor={theme.textMuted}
                  />
                  <Text style={styles.hint}>
                    بيتكرر كل يوم في نفس الميعاد — محسوب جوه الفيرموير نفسه، فمش لازم التطبيق يكون فاتح وقت الميعاد.
                  </Text>

                  <View style={styles.btnRow}>
                    <TouchableOpacity
                      style={[styles.smallBtn, styles.onBtn]}
                      onPress={() =>
                        timerDevice && saveSchedule(timerDevice, scheduleOnInput, scheduleOffInput, scheduleEnabledInput)
                      }
                    >
                      <Text style={styles.btnText}>حفظ</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[styles.smallBtn, styles.offBtn]} onPress={() => setTimerModalVisible(false)}>
                      <Text style={styles.btnText}>إلغاء</Text>
                    </TouchableOpacity>
                  </View>
                </>
              )}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}
// بيحوّل لون hex (بالشكل #rrggbb) لـ rgba بشفافية معينة — مستخدم عشان نعمل
// توهج نيون (خلفية شفافة ملونة حوالين الأيقونة) من غير ما نحتاج مكتبة ألوان.
function hexToRgba(hex, alpha) {
  const clean = (hex || '').replace('#', '');
  if (clean.length !== 6) return `rgba(255,255,255,${alpha})`;
  const r = parseInt(clean.slice(0, 2), 16);
  const g = parseInt(clean.slice(2, 4), 16);
  const b = parseInt(clean.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}

// كارت جهاز واحد — بيدير نبضة الضوء (الـ glow) بنفسه لما يكون شغال، وبيرسم لوحة طلوع/نزول للأجهزة المتحركة
function DeviceCard({
  device,
  theme,
  isOn,
  rawStatus,
  countdownLabel,
  scheduleActive,
  onToggle,
  onUp,
  onStop,
  onDown,
  onOpenTimer,
}) {
  const pulse = useRef(new Animated.Value(0)).current;
  const isUpdown = device.controlType === 'updown';
  const iconDef = getDeviceIcon(device.icon);
  // أيقونات الإضاءة بتضيء أصفر دافئ، وزرار الطوارئ بيضيء أحمر تحذيري ثابت،
  // لما الجهاز يبقى ON — إلا لو المستخدم اختار لون مخصوص بنفسه.
  const onColor =
    device.onColor || (iconDef.isLight ? LIGHT_WARM_ON : iconDef.isEmergency ? EMERGENCY_ON : theme.on);
  const offColor = device.offColor || theme.off;
  const color = isUpdown ? theme.accentSoft : isOn ? onColor : offColor;
  const styles = getStyles(theme);

  useEffect(() => {
    if (isUpdown || !isOn) {
      pulse.setValue(0);
      return undefined;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 900, useNativeDriver: false }),
        Animated.timing(pulse, { toValue: 0, duration: 900, useNativeDriver: false }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [isOn, isUpdown, pulse]);

  const glowOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.55, 1] });
  const glowScale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.08] });

  return (
    <View style={[styles.card, { borderColor: isOn || isUpdown ? theme.accent : theme.border }]}>
      <View style={styles.cardTopRow}>
        {!isUpdown && (
          <TouchableOpacity onPress={onOpenTimer}>
            <MaterialCommunityIcons
              name={countdownLabel || scheduleActive ? 'timer' : 'timer-outline'}
              size={16}
              color={countdownLabel || scheduleActive ? theme.accentSoft : theme.textSecondary}
            />
          </TouchableOpacity>
        )}
      </View>

      <TouchableOpacity
        style={styles.iconWrap}
        onPress={isUpdown ? undefined : onToggle}
        activeOpacity={isUpdown ? 1 : 0.7}
      >
        {isOn && !isUpdown && (
          <Animated.View
            pointerEvents="none"
            style={[
              styles.iconNeonHalo,
              {
                backgroundColor: color,
                shadowColor: color,
                opacity: glowOpacity.interpolate({ inputRange: [0.55, 1], outputRange: [0.22, 0.4] }),
                transform: [{ scale: glowScale.interpolate({ inputRange: [1, 1.08], outputRange: [1, 1.12] }) }],
              },
            ]}
          />
        )}
        <Animated.View
          style={[
            styles.iconGlow,
            {
              borderColor: hexToRgba(color, isOn && !isUpdown ? 0.9 : 0.45),
              backgroundColor: isOn && !isUpdown ? hexToRgba(color, 0.18) : hexToRgba(theme.cardAlt, 0.55),
              shadowColor: color,
              opacity: isOn && !isUpdown ? glowOpacity : 1,
              transform: [{ scale: isOn && !isUpdown ? glowScale : 1 }],
            },
          ]}
        >
          {/* لمعة زجاجية فوق نص الدايرة — بتدي إحساس "كبسولة زجاج مضيئة" بدل
              الشكل المسطح، من غير ما نحتاج أي مكتبة blur خارجية. */}
          <View pointerEvents="none" style={styles.iconGlassShine} />
          <Image source={deviceImageSource(device, isOn && !isUpdown)} style={styles.deviceRealImage} resizeMode="contain" />
        </Animated.View>
      </TouchableOpacity>

      <Text style={styles.deviceName} numberOfLines={1}>
        {device.name}
      </Text>
      <Text style={styles.deviceTopic} numberOfLines={1}>
        {device.controlTopic}
      </Text>

      {!isUpdown && (countdownLabel || scheduleActive) && (
        <Text style={[styles.deviceTopic, { color: theme.accentSoft }]} numberOfLines={1}>
          {countdownLabel ? `⏱ باقي ${countdownLabel}` : '🕐 مجدول يوميًا'}
        </Text>
      )}

      {isUpdown ? (
        <>
          <View style={styles.updownRow}>
            <TouchableOpacity style={[styles.updownBtn, { backgroundColor: theme.accent }]} onPress={onUp}>
              <MaterialCommunityIcons name="chevron-up" size={20} color="#fff" />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.updownBtn, styles.updownStopBtn]} onPress={onStop}>
              <MaterialCommunityIcons name="stop" size={14} color={theme.textSecondary} />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.updownBtn, { backgroundColor: theme.danger }]} onPress={onDown}>
              <MaterialCommunityIcons name="chevron-down" size={20} color="#fff" />
            </TouchableOpacity>
          </View>
          {!!rawStatus && (
            <Text style={styles.deviceTopic} numberOfLines={1}>
              آخر حالة: {rawStatus}
            </Text>
          )}
        </>
      ) : (
        <TouchableOpacity
          style={[styles.pill, { borderColor: color, backgroundColor: isOn ? theme.cardAlt : theme.cardAlt }]}
          onPress={onToggle}
        >
          <View style={[styles.pillDot, { backgroundColor: color }]} />
          <Text style={[styles.pillText, { color }]}>{isOn ? 'ON' : 'OFF'}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

// صف اختيار لون: أول خيار "افتراضي" (لون الثيم)، وبعده باليتة الألوان الجاهزة
function ColorPickerRow({ styles, themeColor, value, onChange }) {
  return (
    <View style={styles.colorRow}>
      <TouchableOpacity
        style={[styles.colorSwatch, { backgroundColor: themeColor }, value === null && styles.colorSwatchSelected]}
        onPress={() => onChange(null)}
      >
        {value === null && <MaterialCommunityIcons name="check" size={14} color="#fff" />}
      </TouchableOpacity>
      {COLOR_SWATCHES.map((c) => (
        <TouchableOpacity
          key={c}
          style={[styles.colorSwatch, { backgroundColor: c }, value === c && styles.colorSwatchSelected]}
          onPress={() => onChange(c)}
        >
          {value === c && <MaterialCommunityIcons name="check" size={14} color="#0f1712" />}
        </TouchableOpacity>
      ))}
    </View>
  );
}

function getStyles(theme) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: theme.bg, padding: 18, paddingTop: 55 },
    headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 },
    back: { color: theme.accentSoft, fontSize: 15 },
    title: { color: theme.textPrimary, fontSize: 18, fontWeight: '700' },
    statusRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 14 },
    dot: { width: 10, height: 10, borderRadius: 5, marginRight: 8 },
    statusLabel: { color: theme.textSecondary, fontSize: 13 },
    btnRow: { flexDirection: 'row', gap: 10, marginBottom: 14 },
    smallBtn: { flex: 1, borderRadius: 10, paddingVertical: 12, alignItems: 'center' },
    onBtn: { backgroundColor: theme.accent },
    offBtn: { backgroundColor: theme.danger },
    emptyText: { color: theme.textSecondary, textAlign: 'center', marginTop: 20, marginBottom: 10, fontSize: 13, lineHeight: 20 },

    utilityRow: {
      flexDirection: 'row',
      justifyContent: 'center',
      alignItems: 'center',
      gap: 48,
      paddingTop: 10,
      paddingBottom: 4,
      borderTopWidth: 1,
      borderTopColor: theme.border,
    },
    utilityBtn: { alignItems: 'center', gap: 2, minWidth: 60 },
    utilityLabel: { fontSize: 11, fontWeight: '600' },
    emergencyLiveDot: {
      position: 'absolute',
      top: -2,
      right: -2,
      width: 8,
      height: 8,
      borderRadius: 4,
      backgroundColor: EMERGENCY_ON,
    },

    grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
    card: {
      backgroundColor: hexToRgba(theme.card, 0.94),
      borderRadius: 20,
      borderWidth: 1,
      borderColor: hexToRgba(theme.accent, 0.5),
      width: '48%',
      padding: 12,
      shadowColor: theme.accent,
      shadowOpacity: 0.28,
      shadowRadius: 14,
      shadowOffset: { width: 0, height: 0 },
      elevation: 5,
      marginBottom: 12,
      alignItems: 'center',
    },
    cardTopRow: { flexDirection: 'row', justifyContent: 'flex-end', width: '100%' },
    iconWrap: { marginTop: 8, marginBottom: 10, alignItems: 'center', justifyContent: 'center' },
    iconNeonHalo: {
      position: 'absolute',
      width: 100,
      height: 100,
      borderRadius: 50,
      shadowOffset: { width: 0, height: 0 },
      shadowOpacity: 1,
      shadowRadius: 20,
      elevation: 10,
    },
    iconGlow: {
      width: 74,
      height: 74,
      borderRadius: 37,
      borderWidth: 1.5,
      alignItems: 'center',
      justifyContent: 'center',
      overflow: 'hidden',
      shadowOpacity: 1,
      shadowRadius: 16,
      shadowOffset: { width: 0, height: 0 },
      elevation: 9,
    },
    // اللمعة الزجاجية: نص بيضاوي شفاف مايل شوية فوق النص العلوي من الدايرة،
    // زي الانعكاس اللي بيبان على زجاج أو معدن مصقول تحت ضوء.
    iconGlassShine: {
      position: 'absolute',
      top: -18,
      left: -6,
      width: 90,
      height: 60,
      borderRadius: 45,
      backgroundColor: 'rgba(255,255,255,0.16)',
      transform: [{ rotate: '-18deg' }],
    },
    deviceName: { color: theme.textPrimary, fontSize: 14, fontWeight: '600', textAlign: 'center' },
    deviceTopic: { color: theme.textMuted, fontSize: 10, marginBottom: 6, textAlign: 'center' },
    pill: {
      flexDirection: 'row',
      alignItems: 'center',
      borderWidth: 1,
      borderRadius: 20,
      paddingHorizontal: 14,
      paddingVertical: 6,
      gap: 6,
      marginTop: 4,
    },
    pillDot: { width: 8, height: 8, borderRadius: 4 },
    pillText: { fontSize: 12, fontWeight: '700' },

    updownRow: { flexDirection: 'row', gap: 8, marginTop: 4, marginBottom: 4 },
    updownBtn: {
      width: 40,
      height: 34,
      borderRadius: 10,
      alignItems: 'center',
      justifyContent: 'center',
    },
    updownStopBtn: { backgroundColor: theme.cardAlt, borderWidth: 1, borderColor: theme.border },

    addBtn: { borderWidth: 1, borderColor: theme.accent, borderRadius: 12, paddingVertical: 14, alignItems: 'center', marginTop: 6 },
    addBtnText: { color: theme.accentSoft, fontWeight: '700', fontSize: 15 },
    discoverBtn: { borderColor: theme.accentSoft },
    discoverBtnText: { color: theme.accentSoft, fontWeight: '700', fontSize: 15 },
    listeningHint: { color: theme.accentSoft, fontSize: 11, marginBottom: 10, textAlign: 'center' },
    syncRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, marginTop: 6, marginBottom: 4 },
    discoveredRow: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: theme.bg,
      borderRadius: 10,
      padding: 10,
      marginBottom: 8,
      borderWidth: 1,
      borderColor: theme.border,
    },
    discoveredRowSelected: { borderColor: theme.accent },
    discoveredTopic: { color: theme.textPrimary, fontSize: 13, fontWeight: '600' },
    discoveredPayload: { color: theme.textSecondary, fontSize: 11, marginTop: 2 },

    tabRow: { flexDirection: 'row', gap: 8, marginBottom: 12 },
    tabBtn: { flex: 1, borderRadius: 10, paddingVertical: 10, alignItems: 'center', backgroundColor: theme.bg, borderWidth: 1, borderColor: theme.border },
    tabBtnActive: { backgroundColor: theme.accent, borderColor: theme.accent },
    tabBtnText: { color: theme.textSecondary, fontSize: 12, fontWeight: '700' },
    tabBtnTextActive: { color: '#fff' },
    codeBox: { backgroundColor: theme.bg, borderRadius: 10, padding: 10, marginBottom: 8, borderWidth: 1, borderColor: theme.border },
    codeText: { color: theme.accentSoft, fontSize: 11, fontFamily: 'monospace' },
    errorText: { color: theme.off, fontSize: 12, marginBottom: 8, textAlign: 'center' },

    colorRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginTop: 4, marginBottom: 4 },
    colorSwatch: {
      width: 30,
      height: 30,
      borderRadius: 15,
      alignItems: 'center',
      justifyContent: 'center',
      borderWidth: 2,
      borderColor: 'transparent',
    },
    colorSwatchSelected: { borderColor: theme.textPrimary },

    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.3)', justifyContent: 'center', padding: 20 },
    modalBox: { backgroundColor: theme.cardAlt, borderRadius: 16, padding: 16, maxHeight: '85%' },
    modalTitle: { color: theme.textPrimary, fontSize: 16, fontWeight: '700', marginBottom: 10, textAlign: 'center' },
    label: { color: theme.textSecondary, fontSize: 12, marginTop: 10, marginBottom: 6 },
    hint: { color: theme.textMuted, fontSize: 10, marginTop: 4 },
    input: { backgroundColor: theme.bg, color: theme.textPrimary, borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10 },
    iconOption: { width: '25%', alignItems: 'center', paddingVertical: 8, paddingHorizontal: 3, borderRadius: 14 },
    iconOptionSelected: { backgroundColor: hexToRgba(theme.on, 0.10), borderWidth: 1, borderColor: theme.on },
    iconOptionGlass: {
      width: 42,
      height: 42,
      borderRadius: 21,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: hexToRgba(theme.cardAlt, 0.6),
      borderWidth: 1,
      borderColor: hexToRgba(theme.border, 0.8),
      overflow: 'hidden',
    },
    iconOptionGlassSelected: {
      backgroundColor: hexToRgba(theme.on, 0.18),
      borderColor: theme.on,
      shadowColor: theme.on,
      shadowOpacity: 0.9,
      shadowRadius: 10,
      shadowOffset: { width: 0, height: 0 },
      elevation: 6,
    },
    iconOptionLabel: { color: theme.textPrimary, fontSize: 9, marginTop: 4, textAlign: 'center', fontWeight: '600' },
    deviceImagePreviewRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      marginTop: 4,
      marginBottom: 10,
    },
    deviceImageStatesRow: {
      flexDirection: 'row',
      justifyContent: 'space-around',
      gap: 12,
      marginTop: 8,
      marginBottom: 10,
    },
    deviceImageStateCol: { alignItems: 'center', flex: 1 },
    deviceImageStateLabel: { color: theme.textSecondary, fontSize: 11, fontWeight: '700', marginBottom: 6, textAlign: 'center' },
    deviceImagePreview: {
      width: 64,
      height: 64,
      borderRadius: 14,
      backgroundColor: hexToRgba(theme.cardAlt, 0.6),
      borderWidth: 1,
      borderColor: hexToRgba(theme.border, 0.8),
      marginBottom: 4,
    },
    imagePickBtn: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 6,
      paddingVertical: 4,
    },
    imagePickBtnText: { color: theme.textPrimary, fontSize: 11, fontWeight: '600' },
    iconOptionImage: { width: 68, height: 68 },
    iconOptionImageSmall: { width: 64, height: 64 },
    shapeListImage: { width: 38, height: 38, borderRadius: 10 },
    deviceRealImage: { width: 94, height: 94, borderRadius: 16 },

    shapeListRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10,
      paddingVertical: 12,
      paddingHorizontal: 4,
      borderBottomWidth: 1,
      borderBottomColor: theme.border,
    },
    shapeListMain: { flex: 1, flexDirection: 'row', alignItems: 'center', gap: 12 },
    shapeListAction: { padding: 6 },
    shapeListIconWrap: {
      width: 38,
      height: 38,
      borderRadius: 19,
      backgroundColor: hexToRgba(theme.cardAlt, 0.6),
      borderWidth: 1,
      borderColor: hexToRgba(theme.border, 0.8),
      alignItems: 'center',
      justifyContent: 'center',
    },
    shapeListName: { flex: 1, color: theme.textPrimary, fontSize: 14, fontWeight: '600' },
  });
}
