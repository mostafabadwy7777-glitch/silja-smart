// تعريف كل الثيمات (الأشكال اللونية) المتاحة في التطبيق.
// كل ثيم بيحدد ألوان الخلفية، الكروت، النصوص، ولون حالتي التشغيل/الإيقاف الافتراضيين.
// أي مفتاح ينفع يستخدم لون مختلف عن الافتراضي (onColor / offColor) لو المستخدم اختار كده بنفسه.

export const THEMES = [
  {
    id: 'silja',
    name: 'أزرق كهربائي',
    bg: '#04061a',
    card: '#0a0f2e',
    cardAlt: '#111a45',
    border: '#2a3a8f',
    textPrimary: '#ffffff',
    textSecondary: '#a6b8ff',
    textMuted: '#5f6fc4',
    accent: '#3d5afe',
    accentSoft: '#5ce1ff',
    on: '#00e6a8',
    off: '#ff3d68',
    danger: '#ff3d68',
    isLight: false,
  },
  {
    id: 'forest',
    name: 'أخضر استوائي',
    bg: '#031810',
    card: '#062b1c',
    cardAlt: '#0a3a24',
    border: '#13603c',
    textPrimary: '#ffffff',
    textSecondary: '#9df0bf',
    textMuted: '#4fa377',
    accent: '#00c853',
    accentSoft: '#c6ff00',
    on: '#b6ff2e',
    off: '#ff5252',
    danger: '#ff5252',
    isLight: false,
  },
  {
    id: 'neon-blue',
    name: 'سماوي نيون',
    bg: '#020a16',
    card: '#051529',
    cardAlt: '#092542',
    border: '#144a78',
    textPrimary: '#ffffff',
    textSecondary: '#84e7ff',
    textMuted: '#3f84ab',
    accent: '#00b8ff',
    accentSoft: '#66ffe0',
    on: '#00ffc6',
    off: '#ff2d6a',
    danger: '#ff2d6a',
    isLight: false,
  },
  {
    id: 'violet',
    name: 'بنفسجي كهربائي',
    bg: '#130921',
    card: '#1f1034',
    cardAlt: '#2a1444',
    border: '#4a2470',
    textPrimary: '#ffffff',
    textSecondary: '#e0bfff',
    textMuted: '#9a76c4',
    accent: '#a742ff',
    accentSoft: '#ff8ae2',
    on: '#ff5ce8',
    off: '#ff5470',
    danger: '#ff5470',
    isLight: false,
  },
  {
    id: 'sunset',
    name: 'غروب ناري',
    bg: '#1d0a05',
    card: '#2e0f08',
    cardAlt: '#3c150b',
    border: '#6b2a14',
    textPrimary: '#fff6ee',
    textSecondary: '#ffb488',
    textMuted: '#c27e51',
    accent: '#ff6b1a',
    accentSoft: '#ffd166',
    on: '#ffc300',
    off: '#ff3860',
    danger: '#ff3860',
    isLight: false,
  },
  {
    id: 'ruby',
    name: 'ياقوت وذهب',
    bg: '#180305',
    card: '#2a0509',
    cardAlt: '#38070c',
    border: '#6b0f18',
    textPrimary: '#fff2f2',
    textSecondary: '#ffa3a3',
    textMuted: '#b8626a',
    accent: '#ff1744',
    accentSoft: '#ffca28',
    on: '#ffd54f',
    off: '#3fd0e0',
    danger: '#ff1744',
    isLight: false,
  },
  {
    id: 'daylight',
    name: 'فاتح نهاري',
    bg: '#f3f7fb',
    card: '#ffffff',
    cardAlt: '#eaf2fb',
    border: '#d7e3f2',
    textPrimary: '#0f1a2b',
    textSecondary: '#42546b',
    textMuted: '#8b9bb2',
    accent: '#0ea5e9',
    accentSoft: '#0d9488',
    on: '#16a34a',
    off: '#e11d48',
    danger: '#dc2626',
    isLight: true,
  },
  {
    id: 'mint-light',
    name: 'فاتح نعناعي',
    bg: '#f2faf6',
    card: '#ffffff',
    cardAlt: '#e6f7ef',
    border: '#cdeee0',
    textPrimary: '#0f2a1f',
    textSecondary: '#3c6b57',
    textMuted: '#8fb3a3',
    accent: '#059669',
    accentSoft: '#0d9488',
    on: '#16a34a',
    off: '#e11d48',
    danger: '#dc2626',
    isLight: true,
  },
  {
    id: 'blush-light',
    name: 'فاتح وردي',
    bg: '#fdf3f6',
    card: '#ffffff',
    cardAlt: '#fbe7ee',
    border: '#f6d0dd',
    textPrimary: '#3a0d1c',
    textSecondary: '#7a3a4e',
    textMuted: '#c48a9c',
    accent: '#e11d74',
    accentSoft: '#c2410c',
    on: '#16a34a',
    off: '#dc2626',
    danger: '#dc2626',
    isLight: true,
  },
  {
    id: 'sand-light',
    name: 'فاتح رملي',
    bg: '#faf6ef',
    card: '#ffffff',
    cardAlt: '#f2e9d8',
    border: '#e6d7b8',
    textPrimary: '#2b2013',
    textSecondary: '#6b5a3c',
    textMuted: '#a8987a',
    accent: '#b45309',
    accentSoft: '#0e7490',
    on: '#16a34a',
    off: '#dc2626',
    danger: '#dc2626',
    isLight: true,
  },
  {
    id: 'graphite-light',
    name: 'فاتح رمادي أنيق',
    bg: '#f5f6f9',
    card: '#ffffff',
    cardAlt: '#edeff4',
    border: '#dde1ea',
    textPrimary: '#171a21',
    textSecondary: '#565d6d',
    textMuted: '#98a0b0',
    accent: '#4338ca',
    accentSoft: '#0891b2',
    on: '#15803d',
    off: '#dc2626',
    danger: '#dc2626',
    isLight: true,
  },
  {
    id: 'gold-light',
    name: 'فاتح أبيض وذهبي',
    bg: '#fbf9f3',
    card: '#ffffff',
    cardAlt: '#f6efdc',
    border: '#e9dcb6',
    textPrimary: '#2b2410',
    textSecondary: '#7a6a3f',
    textMuted: '#b3a377',
    accent: '#b8860b',
    accentSoft: '#0e7490',
    on: '#15803d',
    off: '#dc2626',
    danger: '#dc2626',
    isLight: true,
  },
];

// باليتة ألوان جاهزة يقدر المستخدم يختار منها لكل مفتاح (لون التشغيل ولون الإيقاف بشكل منفصل)
export const COLOR_SWATCHES = [
  '#00e6a8', // أخضر نيون
  '#00d4ff', // سماوي نيون
  '#3d5afe', // أزرق كهربائي
  '#a742ff', // بنفسجي
  '#ff5ce8', // ماجنتا
  '#ff6b1a', // برتقالي ناري
  '#ffd166', // أصفر ذهبي
  '#ff3d68', // وردي أحمر
  '#ff1744', // أحمر ياقوتي
  '#ffffff', // أبيض
];

export const DEFAULT_THEME_ID = 'silja';
export const LIGHT_THEME_ID = 'daylight';

export function getTheme(id) {
  return THEMES.find((t) => t.id === id) || THEMES[0];
}

// ============================================================================
// ثيم مخصص (تحديد ألوان يدوي) — المستخدم يقدر يختار "سطح" (خلفية/كروت/نصوص)
// من أي ثيم جاهز كنقطة بداية، وبعدين يغيّر الألوان الأساسية (accent) والثانوية
// وألوان التشغيل/الإيقاف بنفسه. الشكل الناتج بيتحفظ ويتطبق على كل شاشات
// التطبيق زي أي ثيم عادي، لكنه مش موجود في القايمة الثابتة THEMES فوق —
// بيتخزن لوحده في AsyncStorage (شوف storage.js / ThemeContext.js).
// ============================================================================
export const CUSTOM_THEME_ID = 'custom';

export const DEFAULT_CUSTOM_THEME = {
  id: CUSTOM_THEME_ID,
  name: 'ثيم مخصص',
  isLight: true,
  bg: '#f5f6f9',
  card: '#ffffff',
  cardAlt: '#edeff4',
  border: '#dde1ea',
  textPrimary: '#171a21',
  textSecondary: '#565d6d',
  textMuted: '#98a0b0',
  accent: '#3d5afe',
  accentSoft: '#0891b2',
  on: '#15803d',
  off: '#dc2626',
  danger: '#dc2626',
};
