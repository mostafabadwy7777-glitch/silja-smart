// قائمة الأشكال (الأيقونات) اللي المستخدم يقدر يختار من بينها لكل مفتاح/ريليه.
// كل عنصر بيستخدم مكتبة MaterialCommunityIcons (جزء من @expo/vector-icons).
// شكل الأيقونة نفسه بسيط (outline) لإنها بتاخد لون التشغيل/الإيقاف وتتلبس
// عليها التوهج (glow) من الكارت في SwitchesScreen — نفس ستايل اللوحة الذكية.
// isLight: true = الأيقونة دي شكل إضاءة حقيقي؛ لما الجهاز يبقى ON بتضيء
// بلون أصفر دافئ (زي اللمبة الحقيقية) بدل لون الثيم العادي — شوف
// SwitchesScreen.js -> DeviceCard لمنطق التلوين.
export const DEVICE_ICONS = [
  // ---------------- إضاءة ----------------
  { id: 'lamp', label: 'أباجورة', icon: 'floor-lamp', isLight: true },
  { id: 'ceiling-light', label: 'نجفة / سقف', icon: 'ceiling-light', isLight: true },
  { id: 'led-strip', label: 'شريط ليد زينة', icon: 'led-strip', isLight: true },
  { id: 'led-strip-straight', label: 'شريط ليد مستقيم (أصفر)', icon: 'led-strip-variant', isLight: true },
  { id: 'chandelier', label: 'ثريا', icon: 'chandelier', isLight: true },
  { id: 'bulb', label: 'لمبة عادية', icon: 'lightbulb-outline', isLight: true },
  { id: 'bulb-on', label: 'لمبة (فتيلة مضيئة)', icon: 'lightbulb-on-outline', isLight: true },
  { id: 'spotlight', label: 'سبوت لايت', icon: 'spotlight-beam', isLight: true },
  { id: 'single-spot', label: 'سبوت واحد (داون لايت)', icon: 'spotlight', isLight: true },
  { id: 'twin-spot', label: 'سبوت مجوز (دبل)', icon: 'track-light', isLight: true },
  { id: 'string-lights', label: 'إضاءة زينة', icon: 'string-lights', isLight: true },
  { id: 'wall-sconce', label: 'أباجورة حائط', icon: 'wall-sconce-flat', isLight: true },
  { id: 'lantern', label: 'فانوس', icon: 'lantern-outline', isLight: true },
  { id: 'fence-light', label: 'إضاءة سور / خارجي', icon: 'wall-sconce-round-outline', isLight: true },
  { id: 'floodlight', label: 'كشاف إضاءة', icon: 'light-flood-down', isLight: true },

  // ---------------- غرف / أثاث ----------------
  { id: 'bed', label: 'غرفة نوم', icon: 'bed' },
  { id: 'sofa', label: 'صالة / انتريه', icon: 'sofa' },
  { id: 'curtains', label: 'ستارة', icon: 'curtains' },
  { id: 'blinds', label: 'ستارة/بلايند كهربائي', icon: 'blinds' },

  // ---------------- أماكن / غرف المنزل (لتسمية البورد نفسه) ----------------
  // isPlace: true = الأيقونة دي مكان/غرفة، مخصوصة لاختيار شكل البورد نفسه
  // (شوف EditBoardModal.js) — عشان قايمة اختيار أيقونة البورد تفضل قايمة
  // أماكن بس، منفصلة تمامًا عن أيقونات المفاتيح/الأجهزة جوه البورد.
  { id: 'kitchen', label: 'مطبخ', icon: 'silverware-fork-knife', isPlace: true },
  { id: 'dining-room', label: 'غرفة سفرة', icon: 'table-chair', isPlace: true },
  { id: 'bathroom', label: 'حمام', icon: 'shower', isPlace: true },
  { id: 'office', label: 'مكتب / غرفة مذاكرة', icon: 'desk', isPlace: true },
  { id: 'kids-room', label: 'غرفة أطفال', icon: 'baby-carriage', isPlace: true },
  { id: 'hallway', label: 'ممر / مدخل', icon: 'floor-plan', isPlace: true },
  { id: 'villa-facade', label: 'واجهة فيلا / خارجي', icon: 'home-city', isPlace: true },
  { id: 'terrace', label: 'سطح / تراس', icon: 'umbrella-outline', isPlace: true },
  { id: 'garden-house', label: 'حديقة المنزل', icon: 'flower-tulip-outline', isPlace: true },
  { id: 'storage-room', label: 'مخزن', icon: 'warehouse', isPlace: true },
  { id: 'stairs', label: 'سلم / درج', icon: 'stairs', isPlace: true },
  { id: 'entire-house', label: 'المنزل بالكامل', icon: 'home-city-outline', isPlace: true },
  // أماكن إضافية بتفيد لبوردات مخصوصة (زي بورد الري) لسه برا الغرف التقليدية.
  { id: 'garden-place', label: 'الحديقة', icon: 'tree-outline', isPlace: true },
  { id: 'garage-place', label: 'الجراج', icon: 'garage', isPlace: true },
  { id: 'roof-place', label: 'السطح', icon: 'home-roof', isPlace: true },
  { id: 'basement-place', label: 'البدروم', icon: 'stairs-down', isPlace: true },

  // ---------------- تكييف وتهوية ----------------
  { id: 'ac', label: 'تكييف', icon: 'air-conditioner' },
  { id: 'fan', label: 'مروحة', icon: 'fan' },
  { id: 'heater', label: 'دفاية', icon: 'radiator' },
  { id: 'fireplace', label: 'مدفأة', icon: 'fireplace' },
  { id: 'air-purifier', label: 'منقي هواء', icon: 'air-purifier' },
  { id: 'humidifier', label: 'مرطب هواء', icon: 'air-humidifier' },
  { id: 'thermostat', label: 'ترموستات', icon: 'thermostat' },

  // ---------------- أبواب / بوابات / أقفال ----------------
  { id: 'garage', label: 'باب جراج', icon: 'garage-variant' },
  { id: 'door', label: 'باب', icon: 'door' },
  { id: 'gate', label: 'بوابة', icon: 'gate' },
  { id: 'electric-lock', label: 'كالون كهربي', icon: 'lock-smart' },
  { id: 'door-strike', label: 'فتاحة باب (Strike)', icon: 'door-closed-lock' },
  { id: 'window', label: 'شباك', icon: 'window-closed-variant' },

  // ---------------- أمان ومراقبة ----------------
  { id: 'security', label: 'إنذار / أمان', icon: 'shield-check' },
  { id: 'camera', label: 'كاميرا', icon: 'cctv' },
  { id: 'doorbell', label: 'جرس باب (فيديو)', icon: 'doorbell-video' },
  { id: 'motion-sensor', label: 'حساس حركة', icon: 'motion-sensor' },
  { id: 'smoke', label: 'حساس دخان', icon: 'smoke-detector' },
  { id: 'gas', label: 'حساس غاز', icon: 'gas-cylinder' },
  // isEmergency: true = بتضيء أحمر تحذيري ثابت لما تبقى ON (نشطة)، بغض
  // النظر عن لون الثيم — زي أي زرار طوارئ حقيقي — شوف SwitchesScreen.js.
  { id: 'emergency-button', label: 'زرار طوارئ', icon: 'alarm-light-outline', isEmergency: true },

  // زرار اختبار الإشعارات (ntfy) الجاي من الفيرموير — بيظهر كمفتاح لحظي
  // (نبضة) بيرجع OFF لوحده على طول، مش سويتش هيفضل شغال. الآيدي هنا لازم
  // يفضل 'bell' بالظبط لأنه ده اللي الفيرموير بيبعته في رسالة الاكتشاف.
  { id: 'bell', label: 'زرار اختبار الإشعارات', icon: 'bell-ring-outline' },

  // ---------------- ري / حديقة / مسبح ----------------
  { id: 'irrigation', label: 'ري (عام)', icon: 'sprinkler' },
  { id: 'lawn-sprinkler', label: 'رشاش مياه (نجيلة)', icon: 'sprinkler-variant' },
  { id: 'grass', label: 'نجيلة / حديقة', icon: 'grass' },
  { id: 'greenhouse', label: 'صوبة زراعية', icon: 'greenhouse' },
  { id: 'pool', label: 'مسبح', icon: 'pool' },
  { id: 'water-valve', label: 'محبس مياه', icon: 'pipe-valve' },
  { id: 'water-tank', label: 'خزان مياه', icon: 'water-well' },
  { id: 'water-level', label: 'شاشة مستوى المياه', icon: 'water-percent' },
  { id: 'pump', label: 'موتور مياه', icon: 'pump' },
  { id: 'water-heater', label: 'سخان مياه', icon: 'water-boiler' },

  // ---------------- كهرباء / طاقة ----------------
  { id: 'plug', label: 'مقبس / بلاجة', icon: 'power-socket-eu' },
  { id: 'power', label: 'مصدر كهرباء', icon: 'power-plug-outline' },
  { id: 'energy', label: 'استهلاك طاقة', icon: 'flash' },
  { id: 'solar', label: 'طاقة شمسية', icon: 'solar-power-variant' },
  { id: 'ev-charger', label: 'شاحن سيارة كهربائية', icon: 'ev-station' },
  { id: 'gauge', label: 'عداد', icon: 'gauge' },

  // ---------------- شبكة ----------------
  { id: 'router', label: 'راوتر / شبكة', icon: 'router-wireless' },
  { id: 'wifi', label: 'واي فاي', icon: 'wifi' },

  // ---------------- أجهزة منزلية ----------------
  { id: 'tv', label: 'تلفزيون', icon: 'television' },
  { id: 'tv-lift', label: 'شاشة تلفزيون متحركة (قلاب)', icon: 'arrow-expand-vertical' },
  { id: 'projector-screen', label: 'شاشة عرض', icon: 'projector-screen' },
  { id: 'speaker', label: 'سماعة', icon: 'speaker' },
  { id: 'washing-machine', label: 'غسالة', icon: 'washing-machine' },
  { id: 'dishwasher', label: 'غسالة أطباق', icon: 'dishwasher' },
  { id: 'fridge', label: 'ثلاجة', icon: 'fridge-outline' },
  { id: 'oven', label: 'فرن', icon: 'stove' },
  { id: 'microwave', label: 'ميكروويف', icon: 'microwave' },
  { id: 'kettle', label: 'غلاية', icon: 'kettle' },
  { id: 'coffee-maker', label: 'ماكينة قهوة', icon: 'coffee-maker' },
  { id: 'kitchen-stove', label: 'موقد / بوتاجاز', icon: 'stove' },
  { id: 'robot-vacuum', label: 'مكنسة روبوت', icon: 'robot-vacuum' },
  { id: 'shower', label: 'دش', icon: 'shower' },

  // ---------------- أشكال عامة للمفتاح/الريليه نفسه ----------------
  // ده مخصوص لحالة إن مفيش أيقونة مناسبة للجهاز، أو المستخدم عايز شكل
  // "مفتاح" بسيط بس بأشكال مختلفة بدل نفس الشكل الافتراضي.
  { id: 'switch', label: 'مفتاح عام (كلاسيك)', icon: 'toggle-switch-outline' },
  { id: 'switch-filled', label: 'مفتاح عام (معبّى)', icon: 'toggle-switch' },
  { id: 'wall-switch', label: 'مفتاح حائط', icon: 'light-switch' },
  { id: 'push-button', label: 'زرار ضغط', icon: 'gesture-tap-button' },
  { id: 'relay', label: 'ريليه', icon: 'electric-switch' },
  { id: 'relay-closed', label: 'ريليه (مقفول)', icon: 'electric-switch-closed' },
  { id: 'round-button', label: 'زرار دائري', icon: 'record-circle-outline' },
  { id: 'motor', label: 'موتور / أكتيوتور', icon: 'cog-sync-outline' },
];

export function getDeviceIcon(id) {
  return DEVICE_ICONS.find((d) => d.id === id) || DEVICE_ICONS[DEVICE_ICONS.length - 1];
}

// قايمة أيقونات "الأماكن" بس — مخصوصة لاختيار شكل البورد نفسه (مش المفاتيح
// جواه). شوف EditBoardModal.js.
export const PLACE_ICONS = DEVICE_ICONS.filter((d) => d.isPlace);
