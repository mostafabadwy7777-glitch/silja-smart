import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Platform } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';

// شريط التنقل السفلي — 5 عناصر: الرئيسية / الأجهزة / زرار الإضافة العائم في
// النص / المشاهد / الإعدادات. العنصر النشط بياخد لون accent الثيم الحالي،
// والباقي بلون رمادي باهت. زرار "+" في النص شكله دايرة مرفوعة فوق خط الشريط.
export default function BottomNavBar({ screen, onNavigate, onAddPress }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);

  const isHomeActive = screen === 'boards' || screen === 'board';
  const isScenesActive = screen === 'scenes';
  const isSettingsActive = screen === 'settingsHome' || screen === 'settings' || screen === 'theme' || screen === 'history' || screen === 'backup';

  return (
    <View style={styles.wrap}>
      <View style={styles.bar}>
        <NavItem
          icon="home-variant"
          label="الرئيسية"
          active={isHomeActive}
          theme={theme}
          onPress={() => onNavigate('boards')}
        />
        <NavItem
          icon="chip"
          label="الأجهزة"
          active={false}
          theme={theme}
          onPress={() => onNavigate('boards')}
        />

        <View style={styles.fabSlot}>
          <TouchableOpacity style={styles.fab} activeOpacity={0.85} onPress={onAddPress}>
            <MaterialCommunityIcons name="plus" size={26} color="#fff" />
          </TouchableOpacity>
        </View>

        <NavItem
          icon="weather-night"
          label="المشاهد"
          active={isScenesActive}
          theme={theme}
          onPress={() => onNavigate('scenes')}
        />
        <NavItem
          icon="cog"
          label="الإعدادات"
          active={isSettingsActive}
          theme={theme}
          onPress={() => onNavigate('settingsHome')}
        />
      </View>
    </View>
  );
}

function NavItem({ icon, label, active, theme, onPress }) {
  const color = active ? theme.accent : theme.textMuted;
  return (
    <TouchableOpacity style={styles_.item} activeOpacity={0.7} onPress={onPress}>
      <MaterialCommunityIcons name={icon} size={22} color={color} />
      <Text style={[styles_.label, { color }]} numberOfLines={1}>
        {label}
      </Text>
    </TouchableOpacity>
  );
}

const styles_ = StyleSheet.create({
  item: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 3, paddingTop: 4 },
  label: { fontSize: 10.5, fontWeight: '600' },
});

const getStyles = (theme) =>
  StyleSheet.create({
    wrap: {
      paddingHorizontal: 14,
      paddingBottom: Platform.OS === 'ios' ? 22 : 12,
      backgroundColor: theme.bg,
    },
    bar: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor: theme.card,
      borderRadius: 22,
      borderWidth: 1,
      borderColor: theme.border,
      paddingVertical: 8,
      paddingHorizontal: 6,
      shadowColor: '#000',
      shadowOpacity: 0.25,
      shadowRadius: 10,
      shadowOffset: { width: 0, height: 6 },
      elevation: 10,
    },
    fabSlot: { width: 58, alignItems: 'center' },
    fab: {
      width: 50,
      height: 50,
      borderRadius: 25,
      backgroundColor: theme.accent,
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: -28,
      borderWidth: 4,
      borderColor: theme.bg,
      shadowColor: theme.accent,
      shadowOpacity: 0.5,
      shadowRadius: 8,
      shadowOffset: { width: 0, height: 3 },
      elevation: 8,
    },
  });
