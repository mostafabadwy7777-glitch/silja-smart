import React, { useEffect, useRef, useState } from 'react';
import {
  SafeAreaView,
  ScrollView,
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
  ActivityIndicator,
  Animated,
  StatusBar,
  Modal,
  FlatList,
  Switch,
  Image,
  BackHandler,
} from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';
import { parseBoardDiscovery, boardAvailabilityTopic, parseAvailability } from '../discovery';
import { DEVICE_ICONS, getDeviceIcon } from '../deviceIcons';

const BOARD_TYPE_LABELS = {
  switches: 'لوحة مفاتيح',
  irrigation: 'ري / محابس',
};

// أيقونة رمزية لكل نوع بورد — بتتلبس على الأفاتار الدائري في كارت البورد
const BOARD_TYPE_ICONS = {
  switches: 'view-grid-outline',
  irrigation: 'water-pump',
};

const DISCOVERY_TIMEOUT_MS = 10000;

export default function BoardsListScreen({
  boards,
  onAdd,
  onDelete,
  onOpen,
  onOpenSettings,
  onOpenTheme,
  onOpenScenes,
  onOpenHistory,
  onOpenBackup,
  connected,
  client,
  pairingKey,
  pushEnabled,
  onTogglePush,
  configured,
  onSetBoardIcon,
  addBoardSignal,
}) {
  const { theme, isLight, toggleLightDark } = useTheme();
  const styles = getStyles(theme);
  const [showForm, setShowForm] = useState(false);
  const [deviceId, setDeviceId] = useState('');
  const [discovering, setDiscovering] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  // شاشة الاكتشاف التلقائي الجديدة (شكل الرادار) — قائمة الأجهزة اللي وصلت
  // منها رسالة اكتشاف صحيحة ولسه متضافتش، ومفتاح إظهار فورم الإضافة اليدوية.
  const [discoveredMap, setDiscoveredMap] = useState({});
  const [showManual, setShowManual] = useState(false);
  const boardsRef = useRef(boards);
  useEffect(() => {
    boardsRef.current = boards;
  }, [boards]);
  const [iconPickerBoardId, setIconPickerBoardId] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);
  const [menuVisible, setMenuVisible] = useState(false);
  const menuSlide = useRef(new Animated.Value(1)).current; // 1 = مخفي (خارج الشاشة)، 0 = ظاهر بالكامل

  // فتح/قفل قائمة الدرج الجانبي بحركة انزلاق سلسة من اليمين
  useEffect(() => {
    if (menuOpen) {
      setMenuVisible(true);
      Animated.timing(menuSlide, { toValue: 0, duration: 260, useNativeDriver: true }).start();
    } else if (menuVisible) {
      Animated.timing(menuSlide, { toValue: 1, duration: 220, useNativeDriver: true }).start(({ finished }) => {
        if (finished) setMenuVisible(false);
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [menuOpen]);

  // حالة "توفر" (Availability) كل بورد لوحده — { [boardId]: 'online' | 'offline' | null }
  // null = لسه محددناش (مستنيين أول رسالة Retained من البروكر بعد الاشتراك).
  const [availability, setAvailability] = useState({});

  const timeoutRef = useRef(null);
  const topicRef = useRef(null);
  const handlerRef = useRef(null);

  // نشترك في توبيك الأفيلابيليتي بتاع كل بورد لوحده، عشان نعرف لو بورد معين
  // مقطوع حتى لو الاتصال العام بالسيرفر (البروكر) شغال تمام. لو الاتصال العام
  // اتقطع، بنصفّر الحالة كلها (مش عارفين حالة حد لحد ما نتصل تاني).
  useEffect(() => {
    if (!client || !connected) {
      setAvailability({});
      return undefined;
    }

    const topicToBoardIds = new Map(); // topic -> [boardId, ...] (لو أكتر من بورد نادرًا بيشاركوا نفس التوبيك)
    boards.forEach((b) => {
      const topic = boardAvailabilityTopic(b);
      if (!topic) return;
      if (!topicToBoardIds.has(topic)) topicToBoardIds.set(topic, []);
      topicToBoardIds.get(topic).push(b.id);
    });

    if (topicToBoardIds.size === 0) return undefined;

    setAvailability((prev) => {
      const next = { ...prev };
      boards.forEach((b) => {
        if (boardAvailabilityTopic(b) && !(b.id in next)) next[b.id] = null;
      });
      return next;
    });

    const topics = Array.from(topicToBoardIds.keys());
    topics.forEach((t) => client.subscribe(t));

    const handler = (topic, payload) => {
      const ids = topicToBoardIds.get(topic);
      if (!ids) return;
      const state = parseAvailability(payload.toString());
      if (!state) return;
      setAvailability((prev) => {
        const next = { ...prev };
        ids.forEach((id) => (next[id] = state));
        return next;
      });
    };
    client.on('message', handler);

    return () => {
      client.off('message', handler);
      topics.forEach((t) => client.unsubscribe(t));
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [client, connected, boards.map((b) => `${b.id}:${boardAvailabilityTopic(b)}`).join(',')]);

  const cleanupListener = () => {
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
      timeoutRef.current = null;
    }
    if (client && topicRef.current) {
      if (handlerRef.current) client.off('message', handlerRef.current);
      client.unsubscribe(topicRef.current);
    }
    topicRef.current = null;
    handlerRef.current = null;
  };

  useEffect(() => cleanupListener, []); // eslint-disable-line react-hooks/exhaustive-deps

  // لو المستخدم دوس على زرار "+" في الشريط السفلي (حتى لو مكناش واقفين على
  // شاشة البوردات وقتها)، بنفتح فورم "إضافة بورد جديد" هنا أوتوماتيك.
  // بنتجاهل أول قيمة (0) عشان الفورم متفتحش لوحده أول ما الشاشة تتحمّل.
  useEffect(() => {
    if (addBoardSignal) setShowForm(true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [addBoardSignal]);

  // زرار الموبايل الفيزيقي للرجوع — لو فيه مودال مفتوح فوق شاشة البوردات
  // (فورم الإضافة، الدرج الجانبي، أو اختيار الأيقونة)، بنسكّره الأول بدل ما
  // نسيب الرجوع يودّي لشاشة تانية أو يقفل التطبيق على طول.
  useEffect(() => {
    const onBackPress = () => {
      if (iconPickerBoardId) {
        setIconPickerBoardId(null);
        return true;
      }
      if (showForm) {
        resetForm();
        return true;
      }
      if (menuOpen) {
        setMenuOpen(false);
        return true;
      }
      return false;
    };
    const sub = BackHandler.addEventListener('hardwareBackPress', onBackPress);
    return () => sub.remove();
  }, [iconPickerBoardId, showForm, menuOpen]);

  // بينما شاشة "إضافة بورد / جهاز" مفتوحة، بنستمع على توبيك عام
  // (`+/discovery`) عشان أي بورد شغال وناشر رسالة اكتشاف صحيحة (موقّعة
  // بمفتاح الربط) يظهر أوتوماتيك في القائمة من غير ما تكتب اسمه بنفسك —
  // بالظبط زي شاشة "البحث عن الأجهزة" اللي بتفحص وتسرد كل اللي تلاقيه.
  useEffect(() => {
    if (!showForm || !client || !connected) return undefined;

    const wildcardTopic = '+/discovery';
    client.subscribe(wildcardTopic);
    setDiscoveredMap({});

    const handler = (topic, payload) => {
      if (typeof topic !== 'string' || !topic.endsWith('/discovery')) return;
      const result = parseBoardDiscovery(payload.toString(), pairingKey);
      if (!result.ok) return;
      const board = result.board;
      const key = board.type === 'irrigation' ? board.prefix : board.deviceId;
      if (!key) return;
      const alreadyAdded = boardsRef.current.some((b) =>
        board.type === 'irrigation' ? b.prefix === board.prefix : b.deviceId === board.deviceId
      );
      if (alreadyAdded) return;
      setDiscoveredMap((prev) => ({ ...prev, [key]: { ...board, discoveryTopic: topic } }));
    };
    client.on('message', handler);

    return () => {
      client.off('message', handler);
      client.unsubscribe(wildcardTopic);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showForm, client, connected, pairingKey]);

  const resetForm = () => {
    cleanupListener();
    setDeviceId('');
    setDiscovering(false);
    setErrorMsg('');
    setShowForm(false);
    setShowManual(false);
    setDiscoveredMap({});
  };

  const addDiscoveredBoard = (key) => {
    const board = discoveredMap[key];
    if (!board) return;
    onAdd(board);
    setDiscoveredMap((prev) => {
      const next = { ...prev };
      delete next[key];
      return next;
    });
  };

  const startDiscovery = () => {
    const id = deviceId.trim();
    if (!id) {
      Alert.alert('خطأ', 'لازم تكتب اسم الجهاز (Device ID) اللي ضبطته في الفيرموير');
      return;
    }
    if (!pairingKey) {
      Alert.alert('خطأ', 'لازم تحط مفتاح الربط (Pairing Key) في الإعدادات الأول');
      return;
    }
    if (!client || !connected) {
      Alert.alert('خطأ', 'لسه مش متصل بالسيرفر، استنى ثانية وحاول تاني');
      return;
    }

    cleanupListener();
    setErrorMsg('');

    const topic = `${id}/discovery`;
    topicRef.current = topic;
    client.subscribe(topic);
    setDiscovering(true);

    const handler = (t, payload) => {
      if (t !== topic) return;
      const result = parseBoardDiscovery(payload.toString(), pairingKey);
      cleanupListener();
      setDiscovering(false);
      if (!result.ok) {
        setErrorMsg(result.error);
        return;
      }
      onAdd({ ...result.board, discoveryTopic: topic });
      resetForm();
    };
    handlerRef.current = handler;
    client.on('message', handler);

    timeoutRef.current = setTimeout(() => {
      cleanupListener();
      setDiscovering(false);
      setErrorMsg(
        `مفيش رد من "${id}" لحد دلوقتي. اتأكد إن الفيرموير شغالة، متصلة بنفس البروكر، وناشرة رسالة اكتشاف (يفضل Retained) على "${topic}".`
      );
    }, DISCOVERY_TIMEOUT_MS);
  };

  const cancelDiscovery = () => {
    cleanupListener();
    setDiscovering(false);
    setErrorMsg('');
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} />
      <View style={styles.headerRow}>
        <View style={styles.brandRow}>
          <Image source={require('../assets/icon.png')} style={styles.brandLogo} />
          <View>
            <Text style={styles.eyebrow}>SILJA SMART</Text>
            <Text style={styles.title}>بوردات التحكم</Text>
          </View>
        </View>
        <TouchableOpacity onPress={() => setMenuOpen(true)} style={styles.headerGearBtn} activeOpacity={0.75}>
          <MaterialCommunityIcons name="cog-outline" size={22} color={theme.accentSoft} />
        </TouchableOpacity>
      </View>

      {configured ? (
        <StatusChip theme={theme} styles={styles} connected={connected} />
      ) : (
        <TouchableOpacity style={styles.setupChip} onPress={onOpenSettings} activeOpacity={0.8}>
          <MaterialCommunityIcons name="cog-outline" size={14} color={theme.accentSoft} />
          <Text style={styles.setupChipText}>لسه مفيش سيرفر متظبط — دوس هنا عشان تظبطه</Text>
        </TouchableOpacity>
      )}

      <ScrollView contentContainerStyle={{ paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
        {boards.length > 0 && (
          <View style={styles.sectionRow}>
            <Text style={styles.sectionLabel}>بوردات مضافة</Text>
            <Text style={styles.sectionCount}>{boards.length}</Text>
          </View>
        )}

        {boards.length === 0 && !showForm && (
          <View style={styles.emptyWrap}>
            <View style={styles.emptyIconCircle}>
              <MaterialCommunityIcons name="access-point" size={30} color={theme.accentSoft} />
            </View>
            <Text style={styles.emptyTitle}>مفيش بوردات لسه</Text>
            <Text style={styles.emptyText}>دوس "بورد جديد" تحت عشان تكتشف أول بورد ليك تلقائيًا</Text>
          </View>
        )}

        {boards.map((b) => (
          <BoardCard
            key={b.id}
            board={b}
            theme={theme}
            styles={styles}
            connected={connected}
            availability={connected ? availability[b.id] : null}
            onPress={() => onOpen(b)}
            onEditIcon={() => setIconPickerBoardId(b.id)}
            onDelete={() =>
              Alert.alert('حذف البورد', `متأكد إنك عايز تمسح "${b.name}"؟`, [
                { text: 'إلغاء', style: 'cancel' },
                { text: 'مسح', style: 'destructive', onPress: () => onDelete(b.id) },
              ])
            }
          />
        ))}

        <TouchableOpacity style={styles.addBtn} onPress={() => setShowForm(true)} activeOpacity={0.85}>
          <View style={styles.addBtnIconCircle}>
            <MaterialCommunityIcons name="plus" size={18} color="#fff" />
          </View>
          <Text style={styles.addBtnText}>بورد جديد</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* شاشة "إضافة بورد / جهاز" — رادار بيدور على أي بورد بيبعت رسالة اكتشاف
          صحيحة، وبيسردها أول ما توصل، مع اختيار الإضافة اليدوي لمن يحتاجه. */}
      <Modal visible={showForm} animationType="slide" onRequestClose={resetForm} presentationStyle="fullScreen">
        <SafeAreaView style={styles.discoverContainer}>
          <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} />
          <View style={styles.discoverHeader}>
            <TouchableOpacity onPress={resetForm} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <MaterialCommunityIcons name="arrow-right" size={24} color={theme.textPrimary} />
            </TouchableOpacity>
            <Text style={styles.discoverHeaderTitle}>إضافة بورد / جهاز</Text>
            <View style={{ width: 24 }} />
          </View>

          <ScrollView contentContainerStyle={{ paddingBottom: 40 }} showsVerticalScrollIndicator={false}>
            {!connected || !pairingKey ? (
              <View style={styles.discoverWarnBox}>
                <MaterialCommunityIcons name="alert-circle-outline" size={20} color={theme.danger} />
                <Text style={styles.discoverWarnText}>
                  {!pairingKey
                    ? 'لازم تحط مفتاح الربط (Pairing Key) في الإعدادات قبل ما تبدأ البحث'
                    : 'لسه مش متصل بالسيرفر — استنى ثانية أو راجع الإعدادات'}
                </Text>
              </View>
            ) : (
              <>
                <RadarSearch theme={theme} styles={styles} active={showForm} />
                <Text style={styles.discoverStatusTitle}>جاري البحث عن الأجهزة...</Text>
                <Text style={styles.discoverStatusHint}>
                  تأكد من أن البورد شغّال ومتصل بنفس سيرفر MQTT، وناشر رسالة اكتشاف Retained
                </Text>
              </>
            )}

            <View style={styles.discoverListSection}>
              <Text style={styles.discoverListLabel}>الأجهزة المكتشفة</Text>

              {Object.keys(discoveredMap).length === 0 ? (
                <Text style={styles.discoverEmptyHint}>هتظهر هنا أي أجهزة توصل منها رسالة اكتشاف صحيحة</Text>
              ) : (
                Object.entries(discoveredMap).map(([key, board]) => (
                  <DiscoveredDeviceCard
                    key={key}
                    board={board}
                    theme={theme}
                    styles={styles}
                    onAdd={() => addDiscoveredBoard(key)}
                  />
                ))
              )}
            </View>

            <TouchableOpacity
              style={styles.manualRow}
              onPress={() => setShowManual((v) => !v)}
              activeOpacity={0.8}
            >
              <View style={styles.manualRowIcon}>
                <MaterialCommunityIcons name="pencil-plus-outline" size={18} color={theme.accentSoft} />
              </View>
              <Text style={styles.manualRowText}>إضافة يدوي</Text>
              <MaterialCommunityIcons
                name={showManual ? 'chevron-up' : 'chevron-down'}
                size={18}
                color={theme.textMuted}
              />
            </TouchableOpacity>

            {showManual && (
              <View style={[styles.card, { marginHorizontal: 20 }]}>
                <Text style={styles.label}>اسم الجهاز (Device ID) زي ما ضبطته في الفيرموير</Text>
                <TextInput
                  style={styles.input}
                  value={deviceId}
                  onChangeText={setDeviceId}
                  placeholder="kitchen-esp32-01"
                  placeholderTextColor={theme.textMuted}
                  autoCapitalize="none"
                  editable={!discovering}
                />
                <Text style={styles.hint}>
                  التطبيق هيسمع على "&lt;اسم الجهاز&gt;/discovery" وينتظر رسالة اكتشاف موقّعة من الفيرموير. لو
                  التوقيع مطابق لمفتاح الربط بتاعك، هيتضاف البورد وكل مفاتيحه أوتوماتيك من غير ما تكتب أي توبيك
                  يدوي.
                </Text>

                {discovering && (
                  <View style={styles.discoveringRow}>
                    <ActivityIndicator color={theme.accent} />
                    <Text style={styles.discoveringText}>بيدور على الجهاز…</Text>
                  </View>
                )}

                {!!errorMsg && <Text style={styles.errorText}>⚠ {errorMsg}</Text>}

                <View style={styles.btnRow}>
                  {!discovering ? (
                    <TouchableOpacity
                      style={[styles.smallBtn, styles.onBtn]}
                      onPress={startDiscovery}
                      activeOpacity={0.85}
                    >
                      <Text style={styles.btnText}>ابدأ الاكتشاف</Text>
                    </TouchableOpacity>
                  ) : (
                    <TouchableOpacity
                      style={[styles.smallBtn, styles.dangerBtn]}
                      onPress={cancelDiscovery}
                      activeOpacity={0.85}
                    >
                      <Text style={styles.btnText}>إلغاء الاكتشاف</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            )}
          </ScrollView>
        </SafeAreaView>
      </Modal>

      {/* مودال اختيار شكل (أيقونة) البورد نفسه — منفصل عن أيقونات المفاتيح جوه البورد */}
      <Modal
        visible={!!iconPickerBoardId}
        transparent
        animationType="fade"
        onRequestClose={() => setIconPickerBoardId(null)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalBox}>
            <Text style={styles.modalTitle}>اختار شكل البورد</Text>
            <FlatList
              data={DEVICE_ICONS}
              keyExtractor={(item) => item.id}
              numColumns={5}
              contentContainerStyle={{ marginTop: 4 }}
              renderItem={({ item }) => {
                const board = boards.find((b) => b.id === iconPickerBoardId);
                const selected = board && (board.icon || null) === item.id;
                return (
                  <TouchableOpacity
                    style={[styles.iconOption, selected && styles.iconOptionSelected]}
                    onPress={() => {
                      onSetBoardIcon?.(iconPickerBoardId, item.id);
                      setIconPickerBoardId(null);
                    }}
                  >
                    <MaterialCommunityIcons
                      name={item.icon}
                      size={24}
                      color={selected ? theme.accent : theme.textPrimary}
                    />
                    <Text style={styles.iconOptionLabel} numberOfLines={1}>
                      {item.label}
                    </Text>
                  </TouchableOpacity>
                );
              }}
            />
            <TouchableOpacity
              style={[styles.smallBtn, styles.dangerBtn, { marginTop: 14 }]}
              onPress={() => setIconPickerBoardId(null)}
            >
              <Text style={styles.btnText}>إغلاق</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* الدرج الجانبي (Drawer) — قائمة كاملة الطول بتنزلق من اليمين، بديل شكل البوكس الصغير القديم */}
      <Modal visible={menuVisible} transparent animationType="none" onRequestClose={() => setMenuOpen(false)}>
        <View style={styles.drawerRoot}>
          <TouchableOpacity style={styles.drawerScrim} activeOpacity={1} onPress={() => setMenuOpen(false)} />

          <Animated.View
            style={[
              styles.drawerPanel,
              {
                transform: [
                  {
                    translateX: menuSlide.interpolate({
                      inputRange: [0, 1],
                      outputRange: [0, 340],
                    }),
                  },
                ],
              },
            ]}
          >
            <SafeAreaView style={{ flex: 1 }}>
              <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.drawerScroll}>
                <View style={styles.drawerHeader}>
                  <View style={styles.drawerLogoBadge}>
                    <MaterialCommunityIcons name="home-automation" size={30} color={theme.on} />
                  </View>
                  <Text style={styles.drawerBrandName}>
                    <Text style={{ color: theme.on }}>Silja</Text> Smart
                  </Text>
                  <Text style={styles.drawerBrandSub}>منزلك الذكي، أسهل وأذكى</Text>

                  <TouchableOpacity
                    onPress={() => setMenuOpen(false)}
                    style={styles.drawerCloseBtn}
                    activeOpacity={0.75}
                  >
                    <MaterialCommunityIcons name="close" size={20} color={theme.textSecondary} />
                  </TouchableOpacity>
                </View>

                <View style={styles.drawerSection}>
                  <DrawerRow
                    icon="home-variant-outline"
                    label="الرئيسية"
                    styles={styles}
                    theme={theme}
                    onPress={() => setMenuOpen(false)}
                  />
                  <DrawerRow
                    icon="cog-outline"
                    label="إعدادات الاتصال"
                    styles={styles}
                    theme={theme}
                    onPress={() => {
                      setMenuOpen(false);
                      onOpenSettings();
                    }}
                  />
                  <DrawerRow
                    icon="palette-outline"
                    label="المظهر والثيمات"
                    styles={styles}
                    theme={theme}
                    onPress={() => {
                      setMenuOpen(false);
                      onOpenTheme();
                    }}
                  />
                  <DrawerRow
                    icon="star-four-points-outline"
                    label="المشاهد"
                    styles={styles}
                    theme={theme}
                    onPress={() => {
                      setMenuOpen(false);
                      onOpenScenes();
                    }}
                  />
                  <DrawerRow
                    icon="history"
                    label="سجل الأحداث"
                    styles={styles}
                    theme={theme}
                    onPress={() => {
                      setMenuOpen(false);
                      onOpenHistory();
                    }}
                  />
                  <DrawerRow
                    icon="cloud-upload-outline"
                    label="نسخة احتياطية"
                    styles={styles}
                    theme={theme}
                    onPress={() => {
                      setMenuOpen(false);
                      onOpenBackup();
                    }}
                  />
                </View>

                <View style={styles.drawerDivider} />

                <View style={styles.drawerSection}>
                  <DrawerRow
                    icon={isLight ? 'weather-sunny' : 'weather-night'}
                    label={isLight ? 'وضع نهاري' : 'وضع ليلي'}
                    styles={styles}
                    theme={theme}
                    onPress={toggleLightDark}
                    trailing={<MaterialCommunityIcons name="swap-horizontal" size={17} color={theme.textMuted} />}
                  />
                  <DrawerRow
                    icon={pushEnabled ? 'bell-ring' : 'bell-off-outline'}
                    label="الإشعارات"
                    styles={styles}
                    theme={theme}
                    onPress={onTogglePush}
                    trailing={
                      <Switch
                        value={pushEnabled}
                        onValueChange={onTogglePush}
                        trackColor={{ false: theme.border, true: theme.accent }}
                        thumbColor="#fff"
                      />
                    }
                  />
                </View>
              </ScrollView>
            </SafeAreaView>
          </Animated.View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

// صف واحد جوه الدرج الجانبي — أيقونة جوه مربع مدوّر + اسم + حاجة اختيارية على اليسار (سويتش مثلاً)
function DrawerRow({ icon, label, onPress, styles, theme, trailing }) {
  return (
    <TouchableOpacity style={styles.drawerRow} onPress={onPress} activeOpacity={0.7}>
      <View style={styles.drawerRowIconBox}>
        <MaterialCommunityIcons name={icon} size={20} color={theme.accentSoft} />
      </View>
      <Text style={styles.drawerRowLabel}>{label}</Text>
      {trailing || <MaterialCommunityIcons name="chevron-left" size={18} color={theme.textMuted} />}
    </TouchableOpacity>
  );
}

// شريحة حالة الاتصال بالسيرفر — بتنبض بهدوء لما تكون متصلة، عشان تدي إحساس إن النظام "شغال وحي"
function StatusChip({ theme, styles, connected }) {
  const pulse = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!connected) {
      pulse.setValue(0);
      return undefined;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 1000, useNativeDriver: false }),
        Animated.timing(pulse, { toValue: 0, duration: 1000, useNativeDriver: false }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [connected, pulse]);

  const glowOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.5, 1] });

  return (
    <View style={styles.statusChip}>
      <Animated.View
        style={[
          styles.statusDot,
          { backgroundColor: connected ? theme.on : theme.off, opacity: connected ? glowOpacity : 1 },
        ]}
      />
      <Text style={styles.statusLabel}>{connected ? 'متصل بالسيرفر' : 'جاري الاتصال…'}</Text>
    </View>
  );
}

// كارت بورد واحد — أفاتار دائري بأيقونة البورد (المختارة يدويًا أو الافتراضية حسب نوعه)
// وحلقة بتنبض هادي لما السيرفر متصل. دوس على الأفاتار عشان تغيّر شكل البورد.
function BoardCard({ board, theme, styles, connected, availability, onPress, onDelete, onEditIcon }) {
  const pulse = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!connected) {
      pulse.setValue(0);
      return undefined;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 1400, useNativeDriver: false }),
        Animated.timing(pulse, { toValue: 0, duration: 1400, useNativeDriver: false }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [connected, pulse]);

  const glowOpacity = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.4, 0.9] });
  const metaIcon = board.type === 'switches' ? 'toggle-switch-outline' : 'water-pump';
  const metaText =
    board.type === 'switches' ? `${(board.devices || []).length} مفتاح` : board.prefix;
  const avatarIconName = board.icon ? getDeviceIcon(board.icon).icon : BOARD_TYPE_ICONS[board.type] || 'chip';

  // حالة البورد لوحده (مش السيرفر العام): 'online' | 'offline' | null (لسه مش معروفة)
  const boardDotColor =
    availability === 'online' ? theme.on : availability === 'offline' ? theme.off : theme.textMuted;
  const boardStatusLabel =
    availability === 'online' ? 'البورد متصل' : availability === 'offline' ? 'البورد مقطوع' : 'حالة البورد غير معروفة';

  return (
    <TouchableOpacity style={styles.boardCard} onPress={onPress} activeOpacity={0.8}>
      <TouchableOpacity onPress={onEditIcon} activeOpacity={0.75}>
        <Animated.View
          style={[
            styles.avatarCircle,
            { borderColor: connected ? theme.accent : theme.border, shadowColor: theme.accent, opacity: connected ? glowOpacity : 0.8 },
          ]}
        >
          <MaterialCommunityIcons name={avatarIconName} size={26} color={theme.accentSoft} />
        </Animated.View>
        <View
          style={[styles.availabilityDot, { backgroundColor: boardDotColor, borderColor: theme.card }]}
          accessibilityLabel={boardStatusLabel}
        />
        <View style={styles.editIconBadge}>
          <MaterialCommunityIcons name="pencil" size={11} color="#fff" />
        </View>
      </TouchableOpacity>

      <View style={styles.boardTextWrap}>
        <Text style={styles.boardName} numberOfLines={1}>
          {board.name}
        </Text>
        <View style={styles.boardMetaRow}>
          <View style={styles.typeBadge}>
            <Text style={styles.typeBadgeText}>{BOARD_TYPE_LABELS[board.type] || board.type}</Text>
          </View>
          <View style={styles.metaItem}>
            <MaterialCommunityIcons name={metaIcon} size={12} color={theme.textSecondary} />
            <Text style={styles.boardMeta} numberOfLines={1}>
              {metaText}
            </Text>
          </View>
        </View>
        <Text style={[styles.boardAvailabilityText, { color: boardDotColor }]} numberOfLines={1}>
          {boardStatusLabel}
        </Text>
      </View>

      <TouchableOpacity onPress={onDelete} style={styles.deleteBtn} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
        <MaterialCommunityIcons name="trash-can-outline" size={17} color={theme.textMuted} />
      </TouchableOpacity>

      <MaterialCommunityIcons name="chevron-left" size={20} color={theme.textMuted} />
    </TouchableOpacity>
  );
}

// حلقة رادار نابضة بتتكرر بشكل متتابع (٣ موجات) حوالين دائرة مركزية، بتدي
// إحساس "بيدور دلوقتي" أثناء الاستماع لرسائل الاكتشاف على التوبيك العام.
function RadarSearch({ theme, styles, active }) {
  const waves = useRef([0, 1, 2].map(() => new Animated.Value(0))).current;

  useEffect(() => {
    if (!active) {
      waves.forEach((w) => w.setValue(0));
      return undefined;
    }
    const loops = waves.map((w, i) =>
      Animated.loop(
        Animated.sequence([
          Animated.delay(i * 650),
          Animated.timing(w, { toValue: 1, duration: 1950, useNativeDriver: true }),
        ])
      )
    );
    loops.forEach((l) => l.start());
    return () => loops.forEach((l) => l.stop());
  }, [active, waves]);

  return (
    <View style={styles.radarWrap}>
      {waves.map((w, i) => (
        <Animated.View
          key={i}
          style={[
            styles.radarWave,
            {
              borderColor: theme.accent,
              opacity: w.interpolate({ inputRange: [0, 0.7, 1], outputRange: [0.55, 0.18, 0] }),
              transform: [{ scale: w.interpolate({ inputRange: [0, 1], outputRange: [0.35, 1] }) }],
            },
          ]}
        />
      ))}
      <View style={styles.radarRingOuter} />
      <View style={styles.radarRingInner} />
      <View style={styles.radarCore}>
        <MaterialCommunityIcons name="access-point" size={30} color={theme.accentSoft} />
      </View>
    </View>
  );
}

// كارت جهاز واحد اتلقط من رسائل الاكتشاف العامة، لسه محتاج ضغطة "+" عشان يتضاف فعليًا
function DiscoveredDeviceCard({ board, theme, styles, onAdd }) {
  const subtitle =
    board.type === 'irrigation' ? board.prefix : board.deviceId || `${(board.devices || []).length} مفتاح`;
  return (
    <View style={styles.discoveredCard}>
      <View style={styles.discoveredIconCircle}>
        <MaterialCommunityIcons
          name={board.type === 'irrigation' ? 'water-pump' : 'chip'}
          size={20}
          color={theme.accentSoft}
        />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={styles.discoveredName} numberOfLines={1}>
          {board.name}
        </Text>
        <Text style={styles.discoveredSubtitle} numberOfLines={1}>
          {subtitle}
        </Text>
      </View>
      <TouchableOpacity style={styles.discoveredAddBtn} onPress={onAdd} activeOpacity={0.8}>
        <MaterialCommunityIcons name="plus" size={18} color={theme.accent} />
      </TouchableOpacity>
    </View>
  );
}

function getStyles(theme) {
  return StyleSheet.create({
    container: { flex: 1, backgroundColor: theme.bg, padding: 20, paddingTop: 55 },
    headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
    brandRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
    brandLogo: {
      width: 38,
      height: 38,
      borderRadius: 11,
    },
    eyebrow: {
      color: theme.accentSoft,
      fontSize: 11,
      fontWeight: '700',
      letterSpacing: 1,
      marginBottom: 2,
    },
    title: { color: theme.textPrimary, fontSize: 26, fontWeight: '800', letterSpacing: -0.3 },
    headerGearBtn: {
      width: 40,
      height: 40,
      borderRadius: 20,
      backgroundColor: theme.cardAlt,
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: 2,
    },

    // ------- الدرج الجانبي (Drawer) الجديد -------
    drawerRoot: { flex: 1, flexDirection: 'row-reverse' },
    drawerScrim: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)' },
    drawerPanel: {
      width: '82%',
      maxWidth: 340,
      backgroundColor: theme.bg,
      borderLeftWidth: 1,
      borderLeftColor: theme.border,
      shadowColor: '#000',
      shadowOffset: { width: -6, height: 0 },
      shadowOpacity: 0.35,
      shadowRadius: 24,
      elevation: 16,
    },
    drawerScroll: { paddingBottom: 30 },
    drawerHeader: {
      alignItems: 'center',
      paddingTop: 26,
      paddingBottom: 22,
      paddingHorizontal: 20,
      borderBottomWidth: 1,
      borderBottomColor: theme.border,
    },
    drawerCloseBtn: {
      position: 'absolute',
      top: 14,
      left: 14,
      width: 34,
      height: 34,
      borderRadius: 17,
      backgroundColor: theme.cardAlt,
      alignItems: 'center',
      justifyContent: 'center',
    },
    drawerLogoBadge: {
      width: 62,
      height: 62,
      borderRadius: 20,
      backgroundColor: theme.card,
      borderWidth: 1,
      borderColor: theme.border,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 10,
      shadowColor: theme.on,
      shadowOffset: { width: 0, height: 0 },
      shadowOpacity: 0.5,
      shadowRadius: 12,
      elevation: 6,
    },
    drawerBrandName: { color: theme.textPrimary, fontSize: 20, fontWeight: '800' },
    drawerBrandSub: { color: theme.textMuted, fontSize: 12, marginTop: 3, fontWeight: '600' },
    drawerSection: { paddingHorizontal: 14, paddingTop: 14 },
    drawerRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      paddingVertical: 13,
      paddingHorizontal: 10,
      borderRadius: 14,
    },
    drawerRowIconBox: {
      width: 36,
      height: 36,
      borderRadius: 12,
      backgroundColor: theme.cardAlt,
      borderWidth: 1,
      borderColor: theme.border,
      alignItems: 'center',
      justifyContent: 'center',
    },
    drawerRowLabel: { flex: 1, color: theme.textPrimary, fontSize: 14.5, fontWeight: '700' },
    drawerDivider: { height: 1, backgroundColor: theme.border, marginTop: 10, marginHorizontal: 20, opacity: 0.6 },

    statusChip: {
      flexDirection: 'row',
      alignItems: 'center',
      alignSelf: 'flex-start',
      backgroundColor: theme.cardAlt,
      borderRadius: 20,
      paddingVertical: 6,
      paddingHorizontal: 12,
      marginTop: 14,
      marginBottom: 18,
      gap: 8,
    },
    statusDot: { width: 8, height: 8, borderRadius: 4 },
    statusLabel: { color: theme.textSecondary, fontSize: 12, fontWeight: '600' },

    setupChip: {
      flexDirection: 'row',
      alignItems: 'center',
      alignSelf: 'flex-start',
      backgroundColor: theme.cardAlt,
      borderRadius: 20,
      paddingVertical: 8,
      paddingHorizontal: 14,
      marginTop: 14,
      marginBottom: 18,
      gap: 8,
      borderWidth: 1,
      borderColor: theme.accent,
    },
    setupChipText: { color: theme.accentSoft, fontSize: 12, fontWeight: '600' },

    sectionRow: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 10,
      paddingHorizontal: 2,
    },
    sectionLabel: { color: theme.textMuted, fontSize: 11, fontWeight: '700', letterSpacing: 0.5 },
    sectionCount: {
      color: theme.accentSoft,
      fontSize: 11,
      fontWeight: '700',
      backgroundColor: theme.cardAlt,
      borderRadius: 10,
      paddingHorizontal: 8,
      paddingVertical: 2,
      overflow: 'hidden',
    },

    emptyWrap: { alignItems: 'center', marginTop: 50, marginBottom: 20, paddingHorizontal: 30 },
    emptyIconCircle: {
      width: 72,
      height: 72,
      borderRadius: 36,
      backgroundColor: theme.cardAlt,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 14,
    },
    emptyTitle: { color: theme.textPrimary, fontSize: 15, fontWeight: '700', marginBottom: 6 },
    emptyText: { color: theme.textSecondary, textAlign: 'center', fontSize: 12.5, lineHeight: 19 },

    boardCard: {
      backgroundColor: theme.card,
      borderRadius: 22,
      paddingVertical: 14,
      paddingHorizontal: 16,
      marginBottom: 12,
      flexDirection: 'row',
      alignItems: 'center',
      gap: 14,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 6 },
      shadowOpacity: 0.12,
      shadowRadius: 14,
      elevation: 3,
    },
    avatarCircle: {
      width: 56,
      height: 56,
      borderRadius: 28,
      borderWidth: 1.5,
      backgroundColor: theme.cardAlt,
      alignItems: 'center',
      justifyContent: 'center',
      shadowOffset: { width: 0, height: 0 },
      shadowOpacity: 0.8,
      shadowRadius: 8,
      elevation: 3,
    },
    availabilityDot: {
      position: 'absolute',
      bottom: -1,
      right: -1,
      width: 14,
      height: 14,
      borderRadius: 7,
      borderWidth: 2,
    },
    boardTextWrap: { flex: 1 },
    boardName: { color: theme.textPrimary, fontSize: 15.5, fontWeight: '700', marginBottom: 5 },
    boardAvailabilityText: { fontSize: 10.5, fontWeight: '600', marginTop: 3 },
    boardMetaRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
    typeBadge: {
      backgroundColor: theme.cardAlt,
      borderRadius: 8,
      paddingHorizontal: 7,
      paddingVertical: 2,
    },
    typeBadgeText: { color: theme.accentSoft, fontSize: 10, fontWeight: '700' },
    metaItem: { flexDirection: 'row', alignItems: 'center', gap: 3 },
    boardMeta: { color: theme.textSecondary, fontSize: 11.5 },
    deleteBtn: { padding: 4 },

    card: {
      backgroundColor: theme.card,
      borderRadius: 20,
      padding: 18,
      marginTop: 6,
      marginBottom: 12,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 6 },
      shadowOpacity: 0.12,
      shadowRadius: 14,
      elevation: 3,
    },
    formHeaderRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 4 },
    formHeaderIcon: {
      width: 32,
      height: 32,
      borderRadius: 16,
      backgroundColor: theme.cardAlt,
      alignItems: 'center',
      justifyContent: 'center',
    },
    formHeaderTitle: { color: theme.textPrimary, fontSize: 15, fontWeight: '700' },
    label: { color: theme.textSecondary, fontSize: 12, marginTop: 12, marginBottom: 6 },
    hint: { color: theme.textMuted, fontSize: 11, marginTop: 10, lineHeight: 17 },
    input: {
      backgroundColor: theme.cardAlt,
      color: theme.textPrimary,
      borderRadius: 10,
      paddingHorizontal: 12,
      paddingVertical: 10,
    },
    discoveringRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 14 },
    discoveringText: { color: theme.accentSoft, fontSize: 12 },
    errorText: { color: theme.danger, fontSize: 12, marginTop: 12, lineHeight: 18 },
    btnRow: { flexDirection: 'row', gap: 10, marginTop: 16 },
    smallBtn: { flex: 1, borderRadius: 10, paddingVertical: 12, alignItems: 'center' },
    onBtn: { backgroundColor: theme.accent },
    dangerBtn: { backgroundColor: theme.danger },
    btnText: { color: '#fff', fontWeight: '600', fontSize: 13 },

    addBtn: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 10,
      backgroundColor: theme.accent,
      borderRadius: 20,
      paddingVertical: 16,
      marginTop: 8,
      shadowColor: theme.accent,
      shadowOffset: { width: 0, height: 8 },
      shadowOpacity: 0.3,
      shadowRadius: 16,
      elevation: 4,
    },
    addBtnIconCircle: {
      width: 22,
      height: 22,
      borderRadius: 11,
      backgroundColor: 'rgba(255,255,255,0.25)',
      alignItems: 'center',
      justifyContent: 'center',
    },
    addBtnText: { color: '#fff', fontWeight: '700', fontSize: 15 },

    modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', padding: 20 },
    modalBox: { backgroundColor: theme.cardAlt, borderRadius: 16, padding: 16, maxHeight: '85%' },
    modalTitle: { color: theme.textPrimary, fontSize: 16, fontWeight: '700', marginBottom: 10, textAlign: 'center' },
    iconOption: { width: '20%', alignItems: 'center', paddingVertical: 10, borderRadius: 10 },
    iconOptionSelected: { backgroundColor: theme.bg },
    iconOptionLabel: { color: theme.textSecondary, fontSize: 8, marginTop: 4, textAlign: 'center' },

    // ------- شاشة إضافة بورد / جهاز (رادار) -------
    discoverContainer: { flex: 1, backgroundColor: theme.bg },
    discoverHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingHorizontal: 20,
      paddingTop: 16,
      paddingBottom: 10,
    },
    discoverHeaderTitle: { color: theme.textPrimary, fontSize: 17, fontWeight: '800' },
    discoverWarnBox: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 10,
      backgroundColor: theme.cardAlt,
      borderRadius: 14,
      borderWidth: 1,
      borderColor: theme.danger,
      padding: 14,
      marginHorizontal: 20,
      marginTop: 24,
    },
    discoverWarnText: { color: theme.textSecondary, fontSize: 12.5, flex: 1, lineHeight: 19 },

    radarWrap: {
      width: 220,
      height: 220,
      alignSelf: 'center',
      alignItems: 'center',
      justifyContent: 'center',
      marginTop: 28,
      marginBottom: 10,
    },
    radarWave: {
      position: 'absolute',
      width: 220,
      height: 220,
      borderRadius: 110,
      borderWidth: 1.5,
    },
    radarRingOuter: {
      position: 'absolute',
      width: 170,
      height: 170,
      borderRadius: 85,
      borderWidth: 1,
      borderColor: theme.border,
    },
    radarRingInner: {
      position: 'absolute',
      width: 110,
      height: 110,
      borderRadius: 55,
      borderWidth: 1,
      borderColor: theme.border,
    },
    radarCore: {
      width: 64,
      height: 64,
      borderRadius: 32,
      backgroundColor: theme.card,
      borderWidth: 1.5,
      borderColor: theme.accent,
      alignItems: 'center',
      justifyContent: 'center',
      shadowColor: theme.accent,
      shadowOffset: { width: 0, height: 0 },
      shadowOpacity: 0.6,
      shadowRadius: 14,
      elevation: 6,
    },
    discoverStatusTitle: {
      color: theme.textPrimary,
      fontSize: 16,
      fontWeight: '800',
      textAlign: 'center',
      marginTop: 4,
    },
    discoverStatusHint: {
      color: theme.textMuted,
      fontSize: 11.5,
      textAlign: 'center',
      marginTop: 8,
      paddingHorizontal: 30,
      lineHeight: 17,
    },

    discoverListSection: { marginTop: 30, paddingHorizontal: 20 },
    discoverListLabel: { color: theme.textMuted, fontSize: 12, fontWeight: '700', marginBottom: 12 },
    discoverEmptyHint: { color: theme.textMuted, fontSize: 12, lineHeight: 18 },
    discoveredCard: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      backgroundColor: theme.card,
      borderRadius: 16,
      padding: 14,
      marginBottom: 10,
    },
    discoveredIconCircle: {
      width: 42,
      height: 42,
      borderRadius: 21,
      backgroundColor: theme.cardAlt,
      alignItems: 'center',
      justifyContent: 'center',
    },
    discoveredName: { color: theme.textPrimary, fontSize: 14.5, fontWeight: '700' },
    discoveredSubtitle: { color: theme.textMuted, fontSize: 11.5, marginTop: 2 },
    discoveredAddBtn: {
      width: 34,
      height: 34,
      borderRadius: 17,
      borderWidth: 1.5,
      borderColor: theme.accent,
      alignItems: 'center',
      justifyContent: 'center',
    },

    manualRow: {
      flexDirection: 'row',
      alignItems: 'center',
      gap: 12,
      marginHorizontal: 20,
      marginTop: 22,
      paddingVertical: 14,
      paddingHorizontal: 4,
      borderTopWidth: 1,
      borderTopColor: theme.border,
    },
    manualRowIcon: {
      width: 34,
      height: 34,
      borderRadius: 17,
      backgroundColor: theme.cardAlt,
      alignItems: 'center',
      justifyContent: 'center',
    },
    manualRowText: { flex: 1, color: theme.textPrimary, fontSize: 14, fontWeight: '700' },

    editIconBadge: {
      position: 'absolute',
      top: -2,
      left: -2,
      width: 20,
      height: 20,
      borderRadius: 10,
      backgroundColor: theme.accent,
      alignItems: 'center',
      justifyContent: 'center',
      borderWidth: 2,
      borderColor: theme.card,
    },
  });
}
