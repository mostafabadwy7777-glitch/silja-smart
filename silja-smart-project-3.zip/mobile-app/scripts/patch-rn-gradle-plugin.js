/**
 * Runs AFTER `npm install`. Patches @react-native/gradle-plugin's
 * build.gradle.kts to drop its use of `serviceOf<ModuleRegistry>()`, an API
 * Gradle removed in 8.10+. RN 0.74.5 ships a gradle-plugin version that
 * still uses it, which breaks the build with:
 *   "Unresolved reference: serviceOf"
 * The removed block is test-only tooling classpath wiring, safe to drop
 * for a release build. See: facebook/react-native#54020
 */
const fs = require("fs");
const path = require("path");

const candidates = [
  path.join(
    __dirname,
    "..",
    "node_modules",
    "@react-native",
    "gradle-plugin",
    "react-native-gradle-plugin",
    "build.gradle.kts"
  ),
  path.join(
    __dirname,
    "..",
    "node_modules",
    "@react-native",
    "gradle-plugin",
    "build.gradle.kts"
  ),
];

let patched = false;

for (const filePath of candidates) {
  if (!fs.existsSync(filePath)) continue;

  let content = fs.readFileSync(filePath, "utf8");
  if (!content.includes("serviceOf")) {
    console.log(`${filePath} has no serviceOf usage, nothing to patch.`);
    continue;
  }

  content = content.replace(
    /import org\.gradle\.configurationcache\.extensions\.serviceOf\n/,
    ""
  );

  content = content.replace(
    /\n\s*testRuntimeOnly\(\s*\n\s*files\(\s*\n\s*serviceOf<ModuleRegistry>\(\)[\s\S]*?\)\s*\)\s*\n/,
    "\n"
  );

  fs.writeFileSync(filePath, content);
  console.log(`Patched serviceOf out of ${filePath}`);
  patched = true;
}

if (!patched) {
  console.warn(
    "Could not find @react-native/gradle-plugin build.gradle.kts to patch."
  );
}
