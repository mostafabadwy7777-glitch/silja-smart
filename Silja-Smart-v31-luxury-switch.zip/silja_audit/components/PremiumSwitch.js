import React, { useEffect, useRef } from 'react';
import { Animated, Easing, TouchableWithoutFeedback, View, Text, StyleSheet } from 'react-native';

// سويتش Premium Glass بثلاثة أشكال: مربع، مدور، و ON/OFF.
const TRACK_WIDTH = 46;
const TRACK_HEIGHT = 26;
const THUMB_SIZE = 20;
const PADDING = 3;

export default function PremiumSwitch({
  value,
  onValueChange,
  theme,
  activeColor,
  disabled = false,
  size = 1,
  shape = 'round',
}) {
  const anim = useRef(new Animated.Value(value ? 1 : 0)).current;
  const onTint = activeColor || theme?.accent || '#10d9b0';
  const offTint = theme?.border || '#cbd5e1';

  useEffect(() => {
    Animated.timing(anim, {
      toValue: value ? 1 : 0,
      duration: 180,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: false,
    }).start();
  }, [value, anim]);

  // الحجم الفعلي يتغير مع size بدل عمل transform على الحاوية؛
  // كده السويتش لا يخرج بصريًا خارج الكارت ولا يزاحم النص.
  const sw = TRACK_WIDTH * size;
  const sh = TRACK_HEIGHT * size;
  const thumb = THUMB_SIZE * size;
  const pad = PADDING * size;
  const travel = sw - thumb - pad * 2;
  const translateX = anim.interpolate({ inputRange: [0, 1], outputRange: [0, travel] });
  const trackColor = anim.interpolate({ inputRange: [0, 1], outputRange: [offTint, onTint] });
  const glowOpacity = anim.interpolate({ inputRange: [0, 1], outputRange: [0.04, 0.62] });
  const rimOpacity = anim.interpolate({ inputRange: [0, 1], outputRange: [0.24, 0.95] });

  const radius = shape === 'square' ? 6 : TRACK_HEIGHT / 2;

  return (
    <TouchableWithoutFeedback onPress={() => !disabled && onValueChange && onValueChange(!value)} disabled={disabled}>
      <View style={[styles.hitBox, { width: sw, height: sh + 6, opacity: disabled ? 0.45 : 1, direction: 'ltr' }]}>
        {shape === 'text' ? (
          <View style={[styles.textTrack, { width: sw, height: sh, borderColor: value ? onTint : '#d7e0ea', backgroundColor: value ? onTint : offTint, borderRadius: radius * size }]}>
            <View style={[styles.textThumb, { width: 22 * size, height: 20 * size, left: 2 * size, top: 2 * size, backgroundColor: '#ffffff', borderRadius: 5 * size, transform: [{ translateX: value ? travel : 0 }] }]} />
            <Text style={[styles.stateText, { color: value ? '#ffffff' : '#64748b', left: value ? 5 * size : 28 * size, top: 6 * size, fontSize: Math.max(7, 8 * size) }]}>{value ? 'ON' : 'OFF'}</Text>
          </View>
        ) : (
          <>
            <Animated.View pointerEvents="none" style={[styles.glow, { width: sw + 2 * size, height: sh + 2 * size, backgroundColor: onTint, opacity: glowOpacity, shadowColor: onTint, shadowOpacity: 1, shadowRadius: 16 * size, shadowOffset: { width: 0, height: 0 }, borderWidth: 1 * size, borderColor: onTint, borderRadius: radius * size }]} />
            <Animated.View style={[styles.track, { width: sw, height: sh, padding: pad, backgroundColor: trackColor, borderColor: value ? onTint : '#536173', borderRadius: radius * size, borderWidth: 1.5 * size, shadowColor: value ? onTint : '#000000', shadowOpacity: value ? 0.95 : 0.48, shadowRadius: value ? 13 * size : 5 * size, shadowOffset: { width: 0, height: 1 * size }, elevation: value ? 9 : 4 }]}>
              <View pointerEvents="none" style={[styles.trackSheen, { borderRadius: radius * size, opacity: 0.62 }]} />
              <Animated.View pointerEvents="none" style={[styles.rim, { borderRadius: radius * size, borderColor: value ? '#ffffff' : '#91a0b2', opacity: rimOpacity }]} />
              <Animated.View style={[styles.thumb, { width: thumb, height: thumb, borderRadius: shape === 'square' ? 5 * size : thumb / 2, transform: [{ translateX }], backgroundColor: value ? '#ffffff' : '#dce4ee', borderWidth: 1.2 * size, borderColor: value ? '#ffffff' : '#9eacbd', shadowColor: value ? onTint : '#101820', shadowOpacity: value ? 1 : 0.42, shadowRadius: value ? 10 * size : 4 * size, shadowOffset: { width: 0, height: 1 * size }, elevation: 6 }]}>
                <View pointerEvents="none" style={[styles.thumbShine, { borderRadius: thumb / 2 }]} />
                <View style={[styles.thumbDot, { width: 5 * size, height: 5 * size, borderRadius: 2.5 * size, backgroundColor: value ? onTint : '#8998aa' }]} />
              </Animated.View>
            </Animated.View>
          </>
        )}
      </View>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  hitBox: { alignItems: 'center', justifyContent: 'center', overflow: 'visible' },
  track: { width: TRACK_WIDTH, height: TRACK_HEIGHT, borderWidth: 1, padding: PADDING, justifyContent: 'center', alignItems: 'flex-start', overflow: 'hidden', direction: 'ltr', backgroundColor: '#101722' },
  trackSheen: { position: 'absolute', left: 2, right: 2, top: 1, height: '43%', backgroundColor: '#ffffff', opacity: 0.18 },
  rim: { position: 'absolute', left: 2, right: 2, top: 2, bottom: 2, borderWidth: 0.7 },
  thumb: { width: THUMB_SIZE, height: THUMB_SIZE, backgroundColor: '#ffffff', alignItems: 'center', justifyContent: 'center', shadowOffset: { width: 0, height: 1 }, shadowRadius: 3, elevation: 3 },
  thumbDot: { width: 5, height: 5, borderRadius: 2.5 },
  thumbShine: { position: 'absolute', top: 1, left: 2, right: 2, height: '35%', backgroundColor: '#ffffff', opacity: 0.9 },
  glow: { position: 'absolute', width: TRACK_WIDTH - 4, height: TRACK_HEIGHT - 4, shadowOffset: { width: 0, height: 0 }, shadowRadius: 9, elevation: 0 },
  textTrack: { borderWidth: 1, justifyContent: 'center', overflow: 'hidden', position: 'relative', direction: 'ltr' },
  textThumb: { position: 'absolute', shadowColor: '#000', shadowOpacity: 0.12, shadowRadius: 3, elevation: 2 },
  stateText: { position: 'absolute', top: 5, fontSize: 8, fontWeight: '800' },
});
