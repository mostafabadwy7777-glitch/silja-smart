// قائمة الأشكال (الأيقونات) اللي المستخدم يقدر يختار من بينها لكل مفتاح/ريليه.
// كل عنصر بيستخدم مكتبة MaterialCommunityIcons (جزء من @expo/vector-icons).
// شكل الأيقونة نفسه بسيط (outline) لإنها بتاخد لون التشغيل/الإيقاف وتتلبس
// عليها التوهج (glow) من الكارت في SwitchesScreen — نفس ستايل اللوحة الذكية.
// isLight: true = الأيقونة دي شكل إضاءة حقيقي؛ لما الجهاز يبقى ON بتضيء
// بلون أصفر دافئ (زي اللمبة الحقيقية) بدل لون الثيم العادي — شوف
// SwitchesScreen.js -> DeviceCard لمنطق التلوين.
export const DEVICE_ICONS = [
  // ---------------- إضاءة ----------------
  { id: 'lamp', label: 'أباجورة', icon: 'floor-lamp', isLight: true },
  { id: 'ceiling-light', label: 'نجفة / سقف', icon: 'ceiling-light', isLight: true },
  { id: 'led-strip', label: 'شريط ليد زينة', icon: 'led-strip', isLight: true },
  { id: 'led-strip-straight', label: 'شريط ليد مستقيم (أصفر)', icon: 'led-strip-variant', isLight: true },
  { id: 'chandelier', label: 'ثريا', icon: 'chandelier', isLight: true },
  { id: 'bulb', label: 'لمبة عادية', icon: 'lightbulb-outline', isLight: true },
  { id: 'bulb-on', label: 'لمبة (فتيلة مضيئة)', icon: 'lightbulb-on-outline', isLight: true },
  { id: 'spotlight', label: 'سبوت لايت', icon: 'spotlight-beam', isLight: true },
  { id: 'single-spot', label: 'سبوت واحد (داون لايت)', icon: 'spotlight', isLight: true },
  { id: 'twin-spot', label: 'سبوت مجوز (دبل)', icon: 'track-light', isLight: true },
  { id: 'string-lights', label: 'إضاءة زينة', icon: 'string-lights', isLight: true },
  { id: 'wall-sconce', label: 'أباجورة حائط', icon: 'wall-sconce-flat', isLight: true },
  { id: 'lantern', label: 'فانوس', icon: 'lantern-outline', isLight: true },
  { id: 'fence-light', label: 'إضاءة سور / خارجي', icon: 'wall-sconce-round-outline', isLight: true },
  { id: 'floodlight', label: 'كشاف إضاءة', icon: 'light-flood-down', isLight: true },

  // ---------------- مكتبة صور واقعية إضافية ----------------
  { id: 'real-chandelier3', label: 'نجفة فاخرة', icon: 'chandelier', isLight: true },
  { id: 'real-spotlight3', label: 'سبوت لايت', icon: 'spotlight-beam', isLight: true },
  { id: 'real-ceiling3', label: 'إضاءة سقف', icon: 'ceiling-light', isLight: true },
  { id: 'real-lamp3', label: 'أباجورة', icon: 'floor-lamp', isLight: true },
  { id: 'real-bulb3', label: 'لمبة ديكور', icon: 'lightbulb-on-outline', isLight: true },
  { id: 'real-ledstrip3', label: 'شريط LED', icon: 'led-strip-variant', isLight: true },
  { id: 'real-lantern3', label: 'فانوس جداري', icon: 'lantern-outline', isLight: true },
  { id: 'real-floodlight3', label: 'كشاف خارجي', icon: 'light-flood-down', isLight: true },
  { id: 'real-walllight3', label: 'إضاءة حائط', icon: 'wall-sconce-flat', isLight: true },
  { id: 'real-pendant3', label: 'نجفة معلقة', icon: 'ceiling-light-multiple-outline', isLight: true },
  { id: 'real-tracklight3', label: 'إضاءة مسار', icon: 'track-light', isLight: true },
  { id: 'real-outdoorlight3', label: 'مصباح خارجي', icon: 'wall-sconce-round-outline', isLight: true },
  { id: 'real-ceilingfan3', label: 'مروحة سقف', icon: 'ceiling-fan', isLight: false },
  { id: 'real-fan3', label: 'مروحة', icon: 'fan', isLight: false },
  { id: 'real-exhaustfan3', label: 'شفاط', icon: 'fan-chevron-up', isLight: false },
  { id: 'real-airpurifier3', label: 'منقي هواء', icon: 'air-purifier', isLight: false },
  { id: 'real-ac3', label: 'تكييف', icon: 'air-conditioner', isLight: false },
  { id: 'real-fanwall3', label: 'مروحة حائط', icon: 'fan', isLight: false },
  { id: 'real-electricgate3', label: 'باب كهربائي', icon: 'gate', isLight: false },
  { id: 'real-villaGate3', label: 'بوابة منزل', icon: 'gate', isLight: false },
  { id: 'real-garageDoor3', label: 'باب جراج', icon: 'garage-variant', isLight: false },
  { id: 'real-basementDoor3', label: 'باب قبو', icon: 'door', isLight: false },
  { id: 'real-electriclock3', label: 'قفل كهربائي', icon: 'lock-smart', isLight: false },
  { id: 'real-smartlock3', label: 'قفل ذكي', icon: 'lock-check-outline', isLight: false },
  { id: 'real-waterpump3', label: 'مضخة مياه', icon: 'pump', isLight: false },
  { id: 'real-gardenSprinkler3', label: 'رشاش حديقة', icon: 'sprinkler-variant', isLight: false },
  { id: 'real-irrigation3', label: 'نظام ري', icon: 'sprinkler', isLight: false },
  { id: 'real-waterTap3', label: 'محبس مياه', icon: 'pipe-valve', isLight: false },
  { id: 'real-motor3', label: 'موتور', icon: 'cog-sync-outline', isLight: false },
  { id: 'real-waterHeater3', label: 'سخان مياه', icon: 'water-boiler', isLight: false },
  { id: 'real-tv3', label: 'تلفزيون', icon: 'television', isLight: false },
  { id: 'real-receiver3', label: 'ريسيفر', icon: 'audio-video', isLight: false },
  { id: 'real-computer3', label: 'كمبيوتر', icon: 'desktop-classic', isLight: false },
  { id: 'real-router3', label: 'راوتر', icon: 'router-wireless', isLight: false },
  { id: 'real-speakers3', label: 'مكبر صوت', icon: 'speaker', isLight: false },
  { id: 'real-camera3', label: 'كاميرا', icon: 'cctv', isLight: false },
  { id: 'real-socket3', label: 'مقبس كهرباء', icon: 'power-socket-eu', isLight: false },
  { id: 'real-relay3', label: 'ريليه', icon: 'electric-switch', isLight: false },
  { id: 'real-smartcontroller3', label: 'متحكم ذكي', icon: 'chip', isLight: false },
  { id: 'real-motionsensor3', label: 'حساس حركة', icon: 'motion-sensor', isLight: false },
  { id: 'real-alarm3', label: 'إنذار', icon: 'alarm-light-outline', isLight: false },
  { id: 'real-bell3', label: 'جرس', icon: 'bell-ring-outline', isLight: false },

  // ---------------- غرف / أثاث ----------------
  { id: 'bed', label: 'غرفة نوم', icon: 'bed' },
  { id: 'sofa', label: 'صالة / انتريه', icon: 'sofa' },
  { id: 'curtains', label: 'ستارة', icon: 'curtains' },
  { id: 'blinds', label: 'ستارة/بلايند كهربائي', icon: 'blinds' },

  // ---------------- أماكن / غرف المنزل (لتسمية البورد نفسه) ----------------
  // isPlace: true = الأيقونة دي مكان/غرفة، مخصوصة لاختيار شكل البورد نفسه
  // (شوف EditBoardModal.js) — عشان قايمة اختيار أيقونة البورد تفضل قايمة
  // أماكن بس، منفصلة تمامًا عن أيقونات المفاتيح/الأجهزة جوه البورد.
  { id: 'kitchen', label: 'مطبخ', icon: 'silverware-fork-knife', isPlace: true },
  { id: 'dining-room', label: 'غرفة سفرة', icon: 'table-chair', isPlace: true },
  { id: 'bathroom', label: 'حمام', icon: 'shower', isPlace: true },
  { id: 'office', label: 'مكتب / غرفة مذاكرة', icon: 'desk', isPlace: true },
  { id: 'kids-room', label: 'غرفة أطفال', icon: 'baby-carriage', isPlace: true },
  { id: 'hallway', label: 'ممر / مدخل', icon: 'floor-plan', isPlace: true },
  { id: 'villa-facade', label: 'واجهة فيلا / خارجي', icon: 'home-city', isPlace: true },
  { id: 'terrace', label: 'سطح / تراس', icon: 'umbrella-outline', isPlace: true },
  { id: 'garden-house', label: 'حديقة المنزل', icon: 'flower-tulip-outline', isPlace: true },
  { id: 'storage-room', label: 'مخزن', icon: 'warehouse', isPlace: true },
  { id: 'stairs', label: 'سلم / درج', icon: 'stairs', isPlace: true },
  { id: 'entire-house', label: 'المنزل بالكامل', icon: 'home-city-outline', isPlace: true },
  // أماكن إضافية بتفيد لبوردات مخصوصة (زي بورد الري) لسه برا الغرف التقليدية.
  { id: 'garden-place', label: 'الحديقة', icon: 'tree-outline', isPlace: true },
  { id: 'garage-place', label: 'الجراج', icon: 'garage', isPlace: true },
  { id: 'roof-place', label: 'السطح', icon: 'home-roof', isPlace: true },
  { id: 'basement-place', label: 'البدروم', icon: 'stairs-down', isPlace: true },

  // ---------------- تكييف وتهوية ----------------
  { id: 'ac', label: 'تكييف', icon: 'air-conditioner' },
  { id: 'fan', label: 'مروحة', icon: 'fan' },
  { id: 'heater', label: 'دفاية', icon: 'radiator' },
  { id: 'fireplace', label: 'مدفأة', icon: 'fireplace' },
  { id: 'air-purifier', label: 'منقي هواء', icon: 'air-purifier' },
  { id: 'humidifier', label: 'مرطب هواء', icon: 'air-humidifier' },
  { id: 'thermostat', label: 'ترموستات', icon: 'thermostat' },

  // ---------------- أبواب / بوابات / أقفال ----------------
  { id: 'garage', label: 'باب جراج', icon: 'garage-variant' },
  { id: 'door', label: 'باب', icon: 'door' },
  { id: 'gate', label: 'بوابة', icon: 'gate' },
  { id: 'electric-lock', label: 'كالون كهربي', icon: 'lock-smart' },
  { id: 'door-strike', label: 'فتاحة باب (Strike)', icon: 'door-closed-lock' },
  { id: 'window', label: 'شباك', icon: 'window-closed-variant' },

  // ---------------- أمان ومراقبة ----------------
  { id: 'security', label: 'إنذار / أمان', icon: 'shield-check' },
  { id: 'camera', label: 'كاميرا', icon: 'cctv' },
  { id: 'doorbell', label: 'جرس باب (فيديو)', icon: 'doorbell-video' },
  { id: 'motion-sensor', label: 'حساس حركة', icon: 'motion-sensor' },
  { id: 'smoke', label: 'حساس دخان', icon: 'smoke-detector' },
  { id: 'gas', label: 'حساس غاز', icon: 'gas-cylinder' },
  // isEmergency: true = بتضيء أحمر تحذيري ثابت لما تبقى ON (نشطة)، بغض
  // النظر عن لون الثيم — زي أي زرار طوارئ حقيقي — شوف SwitchesScreen.js.
  { id: 'emergency-button', label: 'زرار طوارئ', icon: 'alarm-light-outline', isEmergency: true },

  // زرار اختبار الإشعارات (ntfy) الجاي من الفيرموير — بيظهر كمفتاح لحظي
  // (نبضة) بيرجع OFF لوحده على طول، مش سويتش هيفضل شغال. الآيدي هنا لازم
  // يفضل 'bell' بالظبط لأنه ده اللي الفيرموير بيبعته في رسالة الاكتشاف.
  { id: 'bell', label: 'زرار اختبار الإشعارات', icon: 'bell-ring-outline' },

  // ---------------- ري / حديقة / مسبح ----------------
  { id: 'irrigation', label: 'ري (عام)', icon: 'sprinkler' },
  { id: 'lawn-sprinkler', label: 'رشاش مياه (نجيلة)', icon: 'sprinkler-variant' },
  { id: 'grass', label: 'نجيلة / حديقة', icon: 'grass' },
  { id: 'greenhouse', label: 'صوبة زراعية', icon: 'greenhouse' },
  { id: 'pool', label: 'مسبح', icon: 'pool' },
  { id: 'water-valve', label: 'محبس مياه', icon: 'pipe-valve' },
  { id: 'water-tank', label: 'خزان مياه', icon: 'water-well' },
  { id: 'water-level', label: 'شاشة مستوى المياه', icon: 'water-percent' },
  { id: 'pump', label: 'موتور مياه', icon: 'pump' },
  { id: 'water-heater', label: 'سخان مياه', icon: 'water-boiler' },

  // ---------------- كهرباء / طاقة ----------------
  { id: 'plug', label: 'مقبس / بلاجة', icon: 'power-socket-eu' },
  { id: 'power', label: 'مصدر كهرباء', icon: 'power-plug-outline' },
  { id: 'energy', label: 'استهلاك طاقة', icon: 'flash' },
  { id: 'solar', label: 'طاقة شمسية', icon: 'solar-power-variant' },
  { id: 'ev-charger', label: 'شاحن سيارة كهربائية', icon: 'ev-station' },
  { id: 'gauge', label: 'عداد', icon: 'gauge' },

  // ---------------- شبكة ----------------
  { id: 'router', label: 'راوتر / شبكة', icon: 'router-wireless' },
  { id: 'wifi', label: 'واي فاي', icon: 'wifi' },

  // ---------------- أجهزة منزلية ----------------
  { id: 'tv', label: 'تلفزيون', icon: 'television' },
  { id: 'tv-lift', label: 'شاشة تلفزيون متحركة (قلاب)', icon: 'arrow-expand-vertical' },
  { id: 'projector-screen', label: 'شاشة عرض', icon: 'projector-screen' },
  { id: 'speaker', label: 'سماعة', icon: 'speaker' },
  { id: 'washing-machine', label: 'غسالة', icon: 'washing-machine' },
  { id: 'dishwasher', label: 'غسالة أطباق', icon: 'dishwasher' },
  { id: 'fridge', label: 'ثلاجة', icon: 'fridge-outline' },
  { id: 'oven', label: 'فرن', icon: 'stove' },
  { id: 'microwave', label: 'ميكروويف', icon: 'microwave' },
  { id: 'kettle', label: 'غلاية', icon: 'kettle' },
  { id: 'coffee-maker', label: 'ماكينة قهوة', icon: 'coffee-maker' },
  { id: 'kitchen-stove', label: 'موقد / بوتاجاز', icon: 'stove' },
  { id: 'robot-vacuum', label: 'مكنسة روبوت', icon: 'robot-vacuum' },
  { id: 'shower', label: 'دش', icon: 'shower' },

  // ---------------- أشكال عامة للمفتاح/الريليه نفسه ----------------
  // ده مخصوص لحالة إن مفيش أيقونة مناسبة للجهاز، أو المستخدم عايز شكل
  // "مفتاح" بسيط بس بأشكال مختلفة بدل نفس الشكل الافتراضي.
  { id: 'switch', label: 'مفتاح عام (كلاسيك)', icon: 'toggle-switch-outline' },
  { id: 'switch-filled', label: 'مفتاح عام (معبّى)', icon: 'toggle-switch' },
  { id: 'wall-switch', label: 'مفتاح حائط', icon: 'light-switch' },
  { id: 'push-button', label: 'زرار ضغط', icon: 'gesture-tap-button' },
  { id: 'relay', label: 'ريليه', icon: 'electric-switch' },
  { id: 'relay-closed', label: 'ريليه (مقفول)', icon: 'electric-switch-closed' },
  { id: 'round-button', label: 'زرار دائري', icon: 'record-circle-outline' },
  { id: 'motor', label: 'موتور / أكتيوتور', icon: 'cog-sync-outline' },
];

export function getDeviceIcon(id) {
  return DEVICE_ICONS.find((d) => d.id === id) || DEVICE_ICONS[DEVICE_ICONS.length - 1];
}

// قايمة أيقونات "الأماكن" بس — مخصوصة لاختيار شكل البورد نفسه (مش المفاتيح
// جواه). شوف EditBoardModal.js.
export const PLACE_ICONS = DEVICE_ICONS.filter((d) => d.isPlace);

// صور واقعية نظيفة للأجهزة — بدون إطار الكارت أو النصوص أو نقاط الواجهة.
// كل صورة PNG شفافة وتستخدم في كروت المفاتيح وفي شاشة اختيار الأيقونة.
export const DEVICE_ICON_IMAGES = {
  chandelier: require('./assets/real_clean/chandelier.png'),
  'ceiling-light': require('./assets/real_clean/ceiling.png'),
  lamp: require('./assets/real_clean/lamp.png'),
  lantern: require('./assets/real_clean/lantern.png'),
  gate: require('./assets/real_clean/electricgate.png'),
  pump: require('./assets/real_clean/pump.png'),
  fan: require('./assets/real_clean/fan.png'),
  'lawn-sprinkler': require('./assets/real_clean/sprinkler.png'),
  irrigation: require('./assets/real_clean/irrigation.png'),
  sprinkler: require('./assets/real_clean/sprinkler.png'),
  emergency: require('./assets/real_clean/emergency_clean.png'),
  shield: require('./assets/real_clean/shield_clean.png'),
  board: require('./assets/real_clean/smartcontroller.png'),
  relayboard: require('./assets/real_clean/relay.png'),
  'real-chandelier3': require('./assets/real_clean/chandelier.png'),
  'real-spotlight3': require('./assets/real_clean/spotlight.png'),
  'real-ceiling3': require('./assets/real_clean/ceiling.png'),
  'real-lamp3': require('./assets/real_clean/lamp.png'),
  'real-bulb3': require('./assets/real_clean/bulb.png'),
  'real-ledstrip3': require('./assets/real_clean/ledstrip.png'),
  'real-lantern3': require('./assets/real_clean/lantern.png'),
  'real-floodlight3': require('./assets/real_clean/spotlight2.png'),
  'real-walllight3': require('./assets/real_clean/walllight.png'),
  'real-pendant3': require('./assets/real_clean/pendant.png'),
  'real-tracklight3': require('./assets/real_clean/ceiling.png'),
  'real-outdoorlight3': require('./assets/real_clean/outdoorlight.png'),
  'real-ceilingfan3': require('./assets/real_clean/ceilingfan.png'),
  'real-fan3': require('./assets/real_clean/fan.png'),
  'real-exhaustfan3': require('./assets/real_clean/exhaustfan.png'),
  'real-airpurifier3': require('./assets/real_clean/ac.png'),
  'real-ac3': require('./assets/real_clean/ac.png'),
  'real-fanwall3': require('./assets/real_clean/fanwall.png'),
  'real-electricgate3': require('./assets/real_clean/electricgate.png'),
  'real-villaGate3': require('./assets/real_clean/villagate.png'),
  'real-garageDoor3': require('./assets/real_clean/garage.png'),
  'real-basementDoor3': require('./assets/real_clean/basementdoor.png'),
  'real-electriclock3': require('./assets/real_clean/lock.png'),
  'real-smartlock3': require('./assets/real_clean/smartlock.png'),
  'real-waterpump3': require('./assets/real_clean/pump.png'),
  'real-gardenSprinkler3': require('./assets/real_clean/sprinkler.png'),
  'real-irrigation3': require('./assets/real_clean/irrigation.png'),
  'real-waterTap3': require('./assets/real_clean/tap.png'),
  'real-motor3': require('./assets/real_clean/motor.png'),
  'real-waterHeater3': require('./assets/real_clean/waterheater.png'),
  'real-tv3': require('./assets/real_clean/tv.png'),
  'real-receiver3': require('./assets/real_clean/receiver.png'),
  'real-computer3': require('./assets/real_clean/computer.png'),
  'real-router3': require('./assets/real_clean/router.png'),
  'real-speakers3': require('./assets/real_clean/speakers.png'),
  'real-camera3': require('./assets/real_clean/camera.png'),
  'real-socket3': require('./assets/real_clean/socket.png'),
  'real-relay3': require('./assets/real_clean/relay.png'),
  'real-smartcontroller3': require('./assets/real_clean/computer.png'),
  'real-motionsensor3': require('./assets/real_clean/motionsensor.png'),
  'real-alarm3': require('./assets/real_clean/alarm.png'),
  'real-bell3': require('./assets/real_clean/bell.png'),
};

// المكتبة الواقعية التي تظهر للمستخدم عند تغيير شكل المفتاح.
// أيقونات فيكتور نضيفة (نفس مكتبة MaterialCommunityIcons) بدل صور مقصوصة،
// عشان تبان واضحة ومتسقة على أي حجم وأي خلفية.
export const REALISTIC_ICON_OPTIONS = [
  { id: 'real-chandelier3', label: 'نجفة فاخرة', icon: 'chandelier', isLight: true, category: 'إضاءة' },
  { id: 'real-spotlight3', label: 'سبوت لايت', icon: 'spotlight-beam', isLight: true, category: 'إضاءة' },
  { id: 'real-ceiling3', label: 'إضاءة سقف', icon: 'ceiling-light', isLight: true, category: 'إضاءة' },
  { id: 'real-lamp3', label: 'أباجورة', icon: 'floor-lamp', isLight: true, category: 'إضاءة' },
  { id: 'real-bulb3', label: 'لمبة LED', icon: 'lightbulb-on-outline', isLight: true, category: 'إضاءة' },
  { id: 'real-ledstrip3', label: 'شريط LED', icon: 'led-strip-variant', isLight: true, category: 'إضاءة' },
  { id: 'real-lantern3', label: 'فانوس جداري', icon: 'lantern-outline', isLight: true, category: 'إضاءة' },
  { id: 'real-floodlight3', label: 'كشاف خارجي', icon: 'light-flood-down', isLight: true, category: 'إضاءة' },
  { id: 'real-walllight3', label: 'إضاءة حائط', icon: 'wall-sconce-flat', isLight: true, category: 'إضاءة' },
  { id: 'real-pendant3', label: 'نجفة معلقة', icon: 'ceiling-light-multiple-outline', isLight: true, category: 'إضاءة' },
  { id: 'real-tracklight3', label: 'إضاءة مسار', icon: 'track-light', isLight: true, category: 'إضاءة' },
  { id: 'real-outdoorlight3', label: 'مصباح خارجي', icon: 'wall-sconce-round-outline', isLight: true, category: 'إضاءة' },
  { id: 'real-ceilingfan3', label: 'مروحة سقف', icon: 'ceiling-fan', category: 'تهوية' },
  { id: 'real-fan3', label: 'مروحة', icon: 'fan', category: 'تهوية' },
  { id: 'real-fanwall3', label: 'مروحة حائط', icon: 'fan', category: 'تهوية' },
  { id: 'real-exhaustfan3', label: 'شفاط', icon: 'fan-chevron-up', category: 'تهوية' },
  { id: 'real-ac3', label: 'تكييف', icon: 'air-conditioner', category: 'تهوية' },
  { id: 'real-airpurifier3', label: 'منقي هواء', icon: 'air-purifier', category: 'تهوية' },
  { id: 'real-electricgate3', label: 'باب كهربائي', icon: 'gate', category: 'أبواب' },
  { id: 'real-villaGate3', label: 'بوابة منزل', icon: 'gate', category: 'أبواب' },
  { id: 'real-garageDoor3', label: 'باب جراج', icon: 'garage-variant', category: 'أبواب' },
  { id: 'real-basementDoor3', label: 'باب قبو', icon: 'door', category: 'أبواب' },
  { id: 'real-smartlock3', label: 'قفل ذكي', icon: 'lock-check-outline', category: 'أبواب' },
  { id: 'real-electriclock3', label: 'قفل كهربائي', icon: 'lock-smart', category: 'أبواب' },
  { id: 'real-waterpump3', label: 'مضخة مياه', icon: 'pump', category: 'مياه وري' },
  { id: 'real-gardenSprinkler3', label: 'رشاش حديقة', icon: 'sprinkler-variant', category: 'مياه وري' },
  { id: 'real-irrigation3', label: 'نظام ري', icon: 'sprinkler', category: 'مياه وري' },
  { id: 'real-waterTap3', label: 'محبس مياه', icon: 'pipe-valve', category: 'مياه وري' },
  { id: 'real-motor3', label: 'موتور', icon: 'cog-sync-outline', category: 'مياه وري' },
  { id: 'real-waterHeater3', label: 'سخان مياه', icon: 'water-boiler', category: 'مياه وري' },
  { id: 'real-tv3', label: 'تلفزيون', icon: 'television', category: 'منزل' },
  { id: 'real-receiver3', label: 'ريسيفر', icon: 'audio-video', category: 'منزل' },
  { id: 'real-computer3', label: 'كمبيوتر', icon: 'desktop-classic', category: 'منزل' },
  { id: 'real-router3', label: 'راوتر', icon: 'router-wireless', category: 'منزل' },
  { id: 'real-speakers3', label: 'مكبر صوت', icon: 'speaker', category: 'منزل' },
  { id: 'real-camera3', label: 'كاميرا', icon: 'cctv', category: 'أمان' },
  { id: 'real-socket3', label: 'مقبس كهرباء', icon: 'power-socket-eu', category: 'كهرباء' },
  { id: 'real-relay3', label: 'ريليه', icon: 'electric-switch', category: 'كهرباء' },
  { id: 'real-motionsensor3', label: 'حساس حركة', icon: 'motion-sensor', category: 'أمان' },
  { id: 'real-alarm3', label: 'إنذار', icon: 'alarm-light-outline', category: 'أمان' },
  { id: 'real-bell3', label: 'جرس', icon: 'bell-ring-outline', category: 'أمان' },
  { id: 'real-smartcontroller3', label: 'متحكم ذكي', icon: 'chip', category: 'كهرباء' },
];

function imageFor(id) {
  const direct = DEVICE_ICON_IMAGES[id];
  if (direct) return direct;
  const d = getDeviceIcon(id);
  if (d?.isEmergency) return DEVICE_ICON_IMAGES.emergency;
  if (d?.isLight) return DEVICE_ICON_IMAGES.lamp;
  if (id.includes('gate') || id === 'door' || id === 'garage' || id === 'electric-lock' || id === 'door-strike' || id === 'window') return DEVICE_ICON_IMAGES.gate;
  if (id.includes('pump') || id.includes('motor') || id.includes('water-')) return DEVICE_ICON_IMAGES.pump;
  if (id.includes('sprinkler') || id === 'grass' || id === 'greenhouse' || id === 'irrigation') return DEVICE_ICON_IMAGES.sprinkler;
  if (id === 'fan' || id === 'air-purifier' || id === 'humidifier' || id === 'ac') return DEVICE_ICON_IMAGES.fan;
  if (id === 'security' || id === 'smoke' || id === 'gas' || id === 'motion-sensor' || id === 'camera' || id === 'doorbell') return DEVICE_ICON_IMAGES.shield;
  if (id === 'relay' || id === 'relay-closed' || id === 'switch' || id === 'switch-filled' || id === 'wall-switch' || id === 'push-button' || id === 'round-button') return DEVICE_ICON_IMAGES.relayboard;
  return DEVICE_ICON_IMAGES.board;
}

export function getDeviceIconImage(id) {
  return imageFor(id);
}
