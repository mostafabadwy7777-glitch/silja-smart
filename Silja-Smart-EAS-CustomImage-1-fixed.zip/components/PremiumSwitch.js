import React, { useEffect, useRef } from 'react';
import { Animated, Easing, TouchableWithoutFeedback, View, StyleSheet } from 'react-native';

// ============================================================================
// سويتش فاخر مخصص — بديل لعنصر <Switch> الافتراضي بتاع النظام (اللي شكله
// مختلف بين آيفون وأندرويد ومش متماشي مع هوية التطبيق). فيه شكلين (shape):
//
//   - 'pill'   (الافتراضي): مسار بيضاوي كامل الاستدارة، كرة بيضاء دائرية.
//   - 'square' : مسار وكرة بحواف مربّعة ناعمة (rounded-square) — إحساس
//                تقني/عصري أكتر، مناسب لكروت "المفاتيح الذكية".
//
// في الحالتين: حركة ناعمة للكرة من الشمال لليمين، وتوهج خفيف حوالين المسار
// لما يكون شغال — بنفس فكرة "الهالة الضوئية" المستخدمة في باقي كروت التطبيق.
//
// الاستخدام مطابق لعنصر Switch الأصلي تقريبًا:
//   <PremiumSwitch value={bool} onValueChange={fn} theme={theme} />
//   <PremiumSwitch value={bool} onValueChange={fn} theme={theme} shape="square" />
// وممكن تحدد لون التشغيل بنفسك (افتراضيًا theme.accent):
//   <PremiumSwitch value={bool} onValueChange={fn} theme={theme} activeColor={theme.on} />
// ============================================================================

const TRACK_WIDTH = 52;
const TRACK_HEIGHT = 30;
const THUMB_SIZE = 24;
const THUMB_PADDING = (TRACK_HEIGHT - THUMB_SIZE) / 2;
const TRAVEL = TRACK_WIDTH - THUMB_SIZE - THUMB_PADDING * 2;

export default function PremiumSwitch({
  value,
  onValueChange,
  theme,
  activeColor,
  disabled = false,
  size = 1,
  shape = 'pill',
}) {
  const anim = useRef(new Animated.Value(value ? 1 : 0)).current;
  const onTint = activeColor || theme?.accent || '#d9b34c';
  const offTint = theme?.border || '#3a3a44';
  const thumbTint = '#ffffff';
  const isSquare = shape === 'square';
  const trackRadius = isSquare ? 9 : TRACK_HEIGHT / 2;
  const thumbRadius = isSquare ? 6 : THUMB_SIZE / 2;

  useEffect(() => {
    Animated.timing(anim, {
      toValue: value ? 1 : 0,
      duration: 220,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: false,
    }).start();
  }, [value]);

  const translateX = anim.interpolate({ inputRange: [0, 1], outputRange: [0, TRAVEL] });
  const trackColor = anim.interpolate({ inputRange: [0, 1], outputRange: [offTint, onTint] });
  const glowOpacity = anim.interpolate({ inputRange: [0, 1], outputRange: [0, 0.85] });

  return (
    <TouchableWithoutFeedback
      onPress={() => !disabled && onValueChange && onValueChange(!value)}
      disabled={disabled}
    >
      <View style={{ transform: [{ scale: size }], opacity: disabled ? 0.45 : 1 }}>
        {/* هالة توهج ناعمة خلف المسار، بتظهر بس وهو شغال */}
        <Animated.View
          pointerEvents="none"
          style={[
            styles.glow,
            {
              backgroundColor: onTint,
              opacity: glowOpacity,
              shadowColor: onTint,
              borderRadius: trackRadius,
            },
          ]}
        />
        <Animated.View
          style={[
            styles.track,
            { backgroundColor: trackColor, borderColor: onTint, borderRadius: trackRadius },
          ]}
        >
          <Animated.View
            style={[
              styles.thumb,
              {
                backgroundColor: thumbTint,
                borderRadius: thumbRadius,
                transform: [{ translateX }],
                shadowColor: value ? onTint : '#000',
                shadowOpacity: value ? 0.9 : 0.3,
              },
            ]}
          />
        </Animated.View>
      </View>
    </TouchableWithoutFeedback>
  );
}

const styles = StyleSheet.create({
  track: {
    width: TRACK_WIDTH,
    height: TRACK_HEIGHT,
    borderWidth: 1,
    padding: THUMB_PADDING,
    justifyContent: 'center',
  },
  thumb: {
    width: THUMB_SIZE,
    height: THUMB_SIZE,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 5,
    elevation: 4,
  },
  glow: {
    position: 'absolute',
    top: 2,
    left: 4,
    right: 4,
    bottom: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowRadius: 10,
    elevation: 0,
  },
});
