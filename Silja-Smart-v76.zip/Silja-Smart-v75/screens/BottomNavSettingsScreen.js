import React, { useRef, useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, StyleSheet, PanResponder } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useTheme } from '../ThemeContext';
import { FONTS } from '../fonts';
import ScreenBackground from '../components/ScreenBackground';
import ScreenHeader from '../components/ScreenHeader';
import { navBarAlpha } from '../colorUtils';

// اختصارات سريعة لقيم شائعة (الشريط نفسه بيغطي كل المستويات من 0 لـ 100)
const OPACITY_PRESETS = [
  { value: 0, label: '0%' },
  { value: 0.3, label: '30%' },
  { value: 0.6, label: '60%' },
  { value: 0.88, label: '88%' },
  { value: 1, label: '100%' },
];

// شريط تحكم (Slider) مخصوص: سحب أو لمسة في أي مكان، كل المستويات من 0% لـ 100% بخطوة 1%.
// direction: 'ltr' عشان الصفر دايمًا على الشمال حتى لو واجهة التطبيق RTL.
function OpacitySlider({ value, onChange, onCommit, onDragState, theme }) {
  const [w, setW] = useState(0);
  const wRef = useRef(0);
  const valRef = useRef(value);
  valRef.current = value;
  const cb = useRef({});
  cb.current = { onChange, onCommit, onDragState };
  const startX = useRef(0);
  const setFromX = (x) => {
    if (!wRef.current) return;
    const v = Math.round(Math.max(0, Math.min(1, x / wRef.current)) * 100) / 100;
    valRef.current = v;
    cb.current.onChange(v);
  };
  const pan = useRef(PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: () => true,
    onPanResponderTerminationRequest: () => false,
    onPanResponderGrant: (e) => { startX.current = e.nativeEvent.locationX; cb.current.onDragState(true); setFromX(startX.current); },
    onPanResponderMove: (e, g) => setFromX(startX.current + g.dx),
    onPanResponderRelease: () => { cb.current.onDragState(false); cb.current.onCommit(valRef.current); },
    onPanResponderTerminate: () => { cb.current.onDragState(false); cb.current.onCommit(valRef.current); },
  })).current;
  const pos = Math.max(0, Math.min(1, value)) * w;
  return (
    <View
      {...pan.panHandlers}
      onLayout={(e) => { const nw = e.nativeEvent.layout.width; wRef.current = nw; setW(nw); }}
      style={{ direction: 'ltr', height: 44, justifyContent: 'center' }}
    >
      <View pointerEvents="none" style={{ height: 10, borderRadius: 5, backgroundColor: theme.border, overflow: 'hidden' }}>
        <View style={{ width: pos, height: 10, backgroundColor: theme.accent }} />
      </View>
      <View
        pointerEvents="none"
        style={{
          position: 'absolute', left: pos - 15, width: 30, height: 30, borderRadius: 15, backgroundColor: theme.accent, borderWidth: 3, borderColor: theme.card,
          shadowColor: theme.accent, shadowOpacity: 0.8, shadowRadius: 8, shadowOffset: { width: 0, height: 0 }, elevation: 4,
        }}
      />
    </View>
  );
}

// أشكال الشريط: كلها زجاجية بلون الثيم، ومضيئة عند التاب النشط
const STYLE_OPTIONS = [
  { id: 'classic', name: 'مع الثيم (زجاج)' },
  { id: 'orbs', name: 'دوائر مضيئة' },
  { id: 'pill', name: 'كبسولة متمددة' },
  { id: 'neon', name: 'نيون بشعاع' },
  { id: 'bubble', name: 'فقاعة طايرة' },
];
const PREVIEW_ICONS = ['home-variant-outline', 'devices', 'weather-night', 'dots-grid'];

// معاينة مصغّرة للشكل: شريط زجاجي فيه 4 أيقونات والتاني نشط ومضيء
function StylePreview({ id, theme }) {
  const accent = theme.accent;
  const dark = !theme.isLight;
  const idle = dark ? 'rgba(255,255,255,0.5)' : 'rgba(20,30,45,0.5)';
  const lit = dark ? '#FFFFFF' : accent;
  const glow = { shadowColor: accent, shadowOpacity: 0.9, shadowRadius: 7, shadowOffset: { width: 0, height: 0 } };
  const cell = (i) => {
    const active = i === 1;
    const color = active ? lit : idle;
    const icon = <MaterialCommunityIcons name={PREVIEW_ICONS[i]} size={14} color={color} />;
    if (id === 'orbs') {
      return <View key={i} style={[{ width: 26, height: 26, borderRadius: 13, borderWidth: 1, alignItems: 'center', justifyContent: 'center', borderColor: active ? accent : 'rgba(128,128,128,0.25)', backgroundColor: active ? `${accent}44` : 'rgba(128,128,128,0.08)' }, active && glow]}>{icon}</View>;
    }
    if (id === 'pill') {
      return <View key={i} style={[{ flexDirection: 'row', alignItems: 'center', gap: 3, height: 24, paddingHorizontal: active ? 8 : 3, borderRadius: 12, borderWidth: active ? 1 : 0, borderColor: accent, backgroundColor: active ? `${accent}44` : 'transparent' }, active && glow]}>{icon}{active && <View style={{ width: 14, height: 3, borderRadius: 2, backgroundColor: lit }} />}</View>;
    }
    if (id === 'neon') {
      return (
        <View key={i} style={{ width: 28, height: 36, alignItems: 'center', justifyContent: 'center' }}>
          {active && <LinearGradient colors={[`${accent}66`, `${accent}00`]} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />}
          {active && <View style={[{ position: 'absolute', top: 0, width: 16, height: 3, borderRadius: 2, backgroundColor: accent }, glow]} />}
          {icon}
        </View>
      );
    }
    if (id === 'bubble') {
      return (
        <View key={i} style={{ width: 28, height: 24, alignItems: 'center', justifyContent: 'center' }}>
          <View style={[{ alignItems: 'center', justifyContent: 'center' }, active && { transform: [{ translateY: -9 }] }]}>
            {active && <View style={[{ position: 'absolute', width: 26, height: 26, borderRadius: 13, backgroundColor: accent, borderWidth: 1, borderColor: 'rgba(255,255,255,0.5)' }, glow]} />}
            <MaterialCommunityIcons name={PREVIEW_ICONS[i]} size={14} color={active ? '#FFFFFF' : idle} />
          </View>
        </View>
      );
    }
    // classic
    return <View key={i} style={[{ width: 24, height: 24, borderRadius: 8, borderWidth: 1, alignItems: 'center', justifyContent: 'center', borderColor: active ? accent : 'rgba(128,128,128,0.2)', backgroundColor: active ? `${accent}28` : 'transparent' }]}>{icon}</View>;
  };
  return (
    <View
      style={{
        width: '100%', height: 40, borderRadius: 14, borderWidth: 1, borderColor: `${accent}66`, backgroundColor: dark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.04)',
        flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', paddingHorizontal: 4, overflow: id === 'bubble' ? 'visible' : 'hidden',
      }}
    >
      {[0, 1, 2, 3].map(cell)}
    </View>
  );
}

export default function BottomNavSettingsScreen({ onBack }) {
  const [dragging, setDragging] = useState(false);
  const { theme, bottomNavOpacity, setBottomNavOpacity, bottomNavStyle = 'classic', setBottomNavStyle = () => {}, bottomNavSize = 'compact', bottomNavLift = 12, setBottomNavSize = () => {}, setBottomNavLift = () => {} } = useTheme();

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.bg }]}> 
      <ScrollView scrollEnabled={!dragging} showsVerticalScrollIndicator={false} contentContainerStyle={styles.content}>
        <ScreenHeader title="شريط الأيقونات" onBack={onBack} />
        <Text style={[styles.subtitle, { color: theme.textSecondary }]}>تحكم في شفافية الشريط السفلي وتدريج ألوانه. التغيير يظهر فورًا.</Text>

        <View style={[styles.box, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={styles.head}>
            <View style={[styles.iconBox, { backgroundColor: `${theme.accent}18` }]}><MaterialCommunityIcons name="arrow-expand-vertical" size={21} color={theme.accent} /></View>
            <View style={{ flex: 1 }}><Text style={[styles.boxTitle, { color: theme.textPrimary }]}>حجم الشريط وارتفاعه</Text><Text style={[styles.boxSub, { color: theme.textSecondary }]}>صغّر الشريط وارفعه عن حافة الشاشة حسب راحتك.</Text></View>
          </View>
          <View style={styles.row}>
            {[{id:'compact',name:'صغير وأنيق'},{id:'standard',name:'متوسط'},{id:'large',name:'كبير'}].map(opt => { const selected = bottomNavSize === opt.id; return <TouchableOpacity key={opt.id} onPress={() => setBottomNavSize(opt.id)} style={[styles.sizeOption,{backgroundColor:theme.cardAlt,borderColor:selected?theme.accent:theme.border}]}><Text style={[styles.gradientName,{color:theme.textPrimary}]}>{opt.name}</Text><MaterialCommunityIcons name={selected?'check-circle':'circle-outline'} size={17} color={selected?theme.accent:theme.border}/></TouchableOpacity>; })}
          </View>
          <Text style={[styles.boxSub,{color:theme.textSecondary,marginTop:12,marginBottom:8}]}>المسافة من أسفل الشاشة</Text>
          <View style={styles.row}>
            {[{v:0,l:'قريب'},{v:12,l:'مرفوع'},{v:22,l:'مرتفع'}].map(opt => { const selected = bottomNavLift === opt.v; return <TouchableOpacity key={opt.v} onPress={() => setBottomNavLift(opt.v)} style={[styles.liftOption,{backgroundColor:theme.cardAlt,borderColor:selected?theme.accent:theme.border}]}><Text style={[styles.label,{color:theme.textPrimary}]}>{opt.l}</Text><Text style={[styles.name,{color:theme.textSecondary}]}>{opt.v===0?'':`${opt.v}px`}</Text></TouchableOpacity>; })}
          </View>
        </View>

        <View style={[styles.box, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={styles.head}>
            <View style={[styles.iconBox, { backgroundColor: `${theme.accent}18` }]}><MaterialCommunityIcons name="blur" size={21} color={theme.accent} /></View>
            <View style={{ flex: 1 }}><Text style={[styles.boxTitle, { color: theme.textPrimary }]}>شفافية الشريط</Text><Text style={[styles.boxSub, { color: theme.textSecondary }]}>اختار مقدار ظهور الخلفية من خلال الزجاج.</Text></View>
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 2 }}>
            <Text style={{ color: theme.accent, fontSize: 26, fontWeight: '800' }}>{Math.round(bottomNavOpacity * 100)}%</Text>
            <Text style={[styles.boxSub, { color: theme.textSecondary }]}>{bottomNavOpacity >= 0.995 ? 'معتم بالكامل' : bottomNavOpacity <= 0.005 ? 'زجاج كامل (شفاف)' : 'اسحب لتغيير الشفافية'}</Text>
          </View>
          <OpacitySlider theme={theme} value={bottomNavOpacity} onChange={(v) => setBottomNavOpacity(v, false)} onCommit={(v) => setBottomNavOpacity(v, true)} onDragState={setDragging} />
          <View style={[styles.row, { marginTop: 8 }]}>
            {OPACITY_PRESETS.map(o => {
              const selected = Math.abs(bottomNavOpacity - o.value) < 0.005;
              return (
                <TouchableOpacity key={o.value} onPress={() => setBottomNavOpacity(o.value)} style={[styles.liftOption, { backgroundColor: theme.cardAlt, borderColor: selected ? theme.accent : theme.border }]}>
                  <Text style={[styles.label, { color: selected ? theme.accent : theme.textPrimary, marginTop: 0 }]}>{o.label}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
          {/* معاينة: الشريط فوق خلفية متدرجة بنفس كثافته الفعلية */}
          <View style={{ marginTop: 12, height: 54, borderRadius: 16, overflow: 'hidden', justifyContent: 'center' }}>
            <LinearGradient colors={[theme.accent, theme.accentSoft || theme.accent, theme.cardAlt]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
            <View style={{ marginHorizontal: 12, height: 34, borderRadius: 17, borderWidth: 1, borderColor: `${theme.accent}88`, backgroundColor: theme.isLight ? `rgba(250,248,242,${navBarAlpha(bottomNavOpacity)})` : `rgba(12,13,15,${navBarAlpha(bottomNavOpacity)})` }} />
          </View>
        </View>

        <View style={[styles.box, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={styles.head}>
            <View style={[styles.iconBox, { backgroundColor: `${theme.accent}18` }]}><MaterialCommunityIcons name="gradient-horizontal" size={21} color={theme.accent} /></View>
            <View style={{ flex: 1 }}><Text style={[styles.boxTitle, { color: theme.textPrimary }]}>تدريج ألوان الشريط</Text><Text style={[styles.boxSub, { color: theme.textSecondary }]}>كل الأشكال زجاجية ومضيئة بلون الثيم. التغيير يظهر فورًا.</Text></View>
          </View>
          <View style={styles.gradientGrid}>
            {STYLE_OPTIONS.map(g => {
              const selected = bottomNavStyle === g.id;
              return (
                <TouchableOpacity key={g.id} onPress={() => setBottomNavStyle(g.id)} style={[styles.gradientCard, { backgroundColor: theme.cardAlt, borderColor: selected ? theme.accent : theme.border, paddingTop: 16 }, selected && { shadowColor: theme.accent, shadowOpacity: 0.35, shadowRadius: 10, shadowOffset: { width: 0, height: 0 } }]}>
                  <StylePreview id={g.id} theme={theme} />
                  <Text style={[styles.gradientName, { color: theme.textPrimary }]}>{g.name}</Text>
                  <MaterialCommunityIcons name={selected ? 'check-circle' : 'circle-outline'} size={18} color={selected ? theme.accent : theme.border} />
                </TouchableOpacity>
              );
            })}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 18, paddingTop: 36 },
  content: { paddingBottom: 130 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  title: { fontSize: 23, fontWeight: '800', fontFamily: FONTS.display },
  back: { fontSize: 15, fontWeight: '800' },
  subtitle: { fontSize: 12, lineHeight: 19, textAlign: 'right', marginBottom: 16 },
  box: { borderRadius: 20, borderWidth: 1, padding: 15, marginBottom: 14 },
  head: { flexDirection: 'row', alignItems: 'center', gap: 11, marginBottom: 14 },
  iconBox: { width: 42, height: 42, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  boxTitle: { fontSize: 16, fontWeight: '800', textAlign: 'right' },
  boxSub: { fontSize: 11.5, lineHeight: 17, textAlign: 'right', marginTop: 2 },
  row: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  opacity: { flex: 1, minWidth: 58, minHeight: 78, borderRadius: 15, borderWidth: 1.2, alignItems: 'center', justifyContent: 'center', paddingVertical: 8 },
  label: { fontSize: 11, fontWeight: '800', marginTop: 3 },
  name: { fontSize: 9, marginTop: 1 },
  styleRow: { flexDirection: 'row', alignItems: 'center', gap: 11, borderRadius: 16, borderWidth: 1.2, padding: 11, marginBottom: 9 },
  styleIcon: { width: 40, height: 40, borderRadius: 13, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  gradientGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 9 },
  sizeOption: { flexGrow: 1, minWidth: '30%', borderRadius: 14, borderWidth: 1.2, padding: 11, alignItems: 'center', gap: 6 },
  liftOption: { flex: 1, borderRadius: 14, borderWidth: 1.2, padding: 9, alignItems: 'center', gap: 3 },
  gradientCard: { width: '48%', minWidth: 132, flexGrow: 1, borderRadius: 17, borderWidth: 1.2, padding: 10, alignItems: 'center', gap: 7 },
  preview: { width: '100%', height: 38, borderRadius: 12 },
  gradientName: { fontSize: 12, fontWeight: '800' },
});
