// تدرجات جاهزة لخلفيات الغرف. كل غرفة ملهاش اختيار بتاخد واحد تلقائي من اسمها (ثابت دايمًا لنفس الاسم).
export const ROOM_GRADIENTS = [
  { id: 'sunset', name: 'غروب', colors: ['#F2994A', '#E5547A', '#5B3A8E'] },
  { id: 'ocean', name: 'محيط', colors: ['#2BB5C8', '#2F6FD0', '#16225E'] },
  { id: 'forest', name: 'غابة', colors: ['#7CC68B', '#2E8B6B', '#0F3B33'] },
  { id: 'dusk', name: 'شفق', colors: ['#9A7BE0', '#5A4BC4', '#1C1F4F'] },
  { id: 'rose', name: 'وردي', colors: ['#F4A6C0', '#D9628F', '#5C1F3F'] },
  { id: 'amber', name: 'كهرمان', colors: ['#F7C85A', '#D98A2B', '#5A3512'] },
  { id: 'aurora', name: 'أورورا', colors: ['#5BE3B0', '#3B8FD9', '#4B2A8A'] },
  { id: 'slate', name: 'رمادي', colors: ['#8FA3B8', '#4A5A6E', '#1A212B'] },
];

export function gradientById(id) {
  return ROOM_GRADIENTS.find((g) => g.id === id) || null;
}

export function autoGradientFor(name) {
  let h = 0;
  const str = String(name || '');
  for (let i = 0; i < str.length; i += 1) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return ROOM_GRADIENTS[h % ROOM_GRADIENTS.length];
}

// اسم ملف ثابت وآمن لصورة غرفة (الأسماء العربية مش بتنفع في المسارات).
export function roomFileKey(name) {
  let h = 5381;
  const str = String(name || '');
  for (let i = 0; i < str.length; i += 1) h = ((h * 33) ^ str.charCodeAt(i)) >>> 0;
  return h.toString(36);
}
