// كارت زجاجي أعلى الرئيسية: حلقة مضيئة بعدد المفاتيح الشغالة، وساعات تشغيل النهارده،
// والبوردات المتصلة وحالة السيرفر. الحلقة بتتنفّس لما فيه حاجة شغالة (وبتقف مع "حركة أقل").
import React, { useEffect, useMemo, useRef } from 'react';
import { View, Text, Animated, Easing } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useTheme, useMotionActive } from '../ThemeContext';
import { withAlpha } from '../colorUtils';
import { useRuntimeStats, deviceIndex, formatRuntime } from '../runtimeTracker';

export default function HomeGlassSummary({ boards = [], activeSwitches = 0, totalSwitches = 0, onlineBoards = 0, totalBoards = 0, connected = false }) {
  const { theme } = useTheme();
  const motion = useMotionActive();
  const statsFor = useRuntimeStats();
  const { list } = useMemo(() => deviceIndex(boards), [boards]);
  const todaySeconds = list.reduce((sum, x) => sum + (statsFor(x.device).today || 0), 0);

  const dark = !theme.isLight;
  const accent = activeSwitches > 0 ? theme.on || theme.accent : theme.accent;
  const breath = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!activeSwitches || !motion) { breath.stopAnimation(); breath.setValue(activeSwitches ? 0.5 : 0); return undefined; }
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(breath, { toValue: 1, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(breath, { toValue: 0, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [activeSwitches, motion, breath]);

  const row = (icon, label, value, color) => (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginVertical: 5 }}>
      <View style={{ width: 28, height: 28, borderRadius: 10, alignItems: 'center', justifyContent: 'center', backgroundColor: withAlpha(color, 0.16) }}>
        <MaterialCommunityIcons name={icon} size={16} color={color} />
      </View>
      <Text style={{ flex: 1, color: theme.textSecondary, fontSize: 12, textAlign: 'right' }} numberOfLines={1}>{label}</Text>
      <Text style={{ color: theme.textPrimary, fontSize: 13.5, fontWeight: '800' }}>{value}</Text>
    </View>
  );

  return (
    <View style={{ marginBottom: 14, borderRadius: 26, overflow: 'hidden', borderWidth: 1.2, borderColor: withAlpha(accent, 0.45), shadowColor: accent, shadowOpacity: activeSwitches ? 0.35 : 0.12, shadowRadius: 16, shadowOffset: { width: 0, height: 0 } }}>
      <LinearGradient
        colors={[withAlpha(accent, dark ? 0.2 : 0.16), withAlpha(theme.card, 0.85), withAlpha(accent, dark ? 0.06 : 0.05)]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={{ flexDirection: 'row', alignItems: 'center', gap: 14, padding: 14 }}
      >
        {/* لمعة زجاجية */}
        <LinearGradient pointerEvents="none" colors={['rgba(255,255,255,0.14)', 'rgba(255,255,255,0)']} start={{ x: 0, y: 0 }} end={{ x: 0.5, y: 0.6 }} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
        <View style={{ flex: 1 }}>
          {row('clock-outline', 'ساعات تشغيل النهارده', formatRuntime(todaySeconds), theme.accentSoft || accent)}
          {row('access-point', 'بوردات متصلة', `${onlineBoards}/${totalBoards}`, onlineBoards > 0 || totalBoards === 0 ? theme.on : theme.off)}
          {row(connected ? 'server-network' : 'server-network-off', 'السيرفر', connected ? 'متصل' : 'مقطوع', connected ? theme.on : theme.off)}
        </View>
        <View style={{ width: 104, height: 104, alignItems: 'center', justifyContent: 'center' }}>
          <Animated.View
            pointerEvents="none"
            style={{
              position: 'absolute', width: 104, height: 104, borderRadius: 52, backgroundColor: accent,
              opacity: breath.interpolate({ inputRange: [0, 1], outputRange: [0.08, 0.26] }),
              transform: [{ scale: breath.interpolate({ inputRange: [0, 1], outputRange: [0.92, 1.06] }) }],
            }}
          />
          <View
            style={{
              width: 88, height: 88, borderRadius: 44, borderWidth: 3, alignItems: 'center', justifyContent: 'center',
              borderColor: activeSwitches ? accent : withAlpha(theme.textMuted, 0.35), backgroundColor: withAlpha(theme.card, 0.6),
              shadowColor: accent, shadowOpacity: activeSwitches ? 0.9 : 0, shadowRadius: 12, shadowOffset: { width: 0, height: 0 },
            }}
          >
            <Text style={{ color: activeSwitches ? accent : theme.textPrimary, fontSize: 30, fontWeight: '800', lineHeight: 34 }}>{activeSwitches}</Text>
            <Text style={{ color: theme.textSecondary, fontSize: 10.5, fontWeight: '700' }}>من {totalSwitches} شغال</Text>
          </View>
        </View>
      </LinearGradient>
    </View>
  );
}
