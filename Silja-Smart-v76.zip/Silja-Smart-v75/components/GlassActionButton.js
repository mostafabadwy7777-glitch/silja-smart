// زرار زجاجي (كبسولة) بنفس لغة بقية التطبيق: خلفية شفافة بتدرج لوني خفيف + لمعة علوية + حدود مضيئة،
// وأيقونة جوه دايرة زجاجية. tone="solid" بيدي نسخة مليانة بلون الزرار (للإجراء الأساسي زي "تشغيل الكل")،
// والافتراضي نسخة شفافة (للإجراء التاني زي "إيقاف الكل").
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { withAlpha, readableOn } from '../colorUtils';

export default function GlassActionButton({ theme, label, icon, color, solid = false, disabled = false, onPress, style }) {
  const dark = !theme.isLight;
  const fg = solid ? readableOn(color) : (dark ? '#FFFFFF' : color);
  return (
    <TouchableOpacity
      onPress={onPress}
      disabled={disabled}
      activeOpacity={0.85}
      style={[{
        flex: 1, height: 56, borderRadius: 28, overflow: 'hidden', justifyContent: 'center',
        borderWidth: 1.3, borderColor: withAlpha(color, solid ? 0.95 : 0.6),
        backgroundColor: solid ? withAlpha(color, 0.9) : withAlpha(theme.card, dark ? 0.55 : 0.75),
        shadowColor: color, shadowOpacity: solid ? 0.45 : 0.22, shadowRadius: solid ? 14 : 10, shadowOffset: { width: 0, height: solid ? 3 : 2 }, elevation: solid ? 5 : 2,
        opacity: disabled ? 0.5 : 1,
      }, style]}
    >
      <LinearGradient pointerEvents="none" colors={solid ? [withAlpha(color, 0.95), withAlpha(color, 0.7)] : [withAlpha(color, 0.2), withAlpha(color, 0.05)]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
      <LinearGradient pointerEvents="none" colors={[`rgba(255,255,255,${solid ? 0.38 : dark ? 0.2 : 0.5})`, 'rgba(255,255,255,0)']} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 0.6 }} style={StyleSheet.absoluteFill} />
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 9 }}>
        <View style={{ width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center', borderWidth: 1.2, borderColor: solid ? 'rgba(255,255,255,0.55)' : withAlpha(color, 0.7), backgroundColor: solid ? 'rgba(255,255,255,0.22)' : withAlpha(color, 0.18) }}>
          <MaterialCommunityIcons name={icon} size={19} color={solid ? fg : color} />
        </View>
        <Text style={{ color: fg, fontSize: 14.5, fontWeight: '800' }}>{label}</Text>
      </View>
    </TouchableOpacity>
  );
}
