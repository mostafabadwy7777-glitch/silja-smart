// أيقونة واي فاي بتطلّع موجات: الأقواس بتظهر واحدورا التاني لحد قوة الإشارة الحقيقية،
// وفي هالة بتتمدد وتتلاشى من الأيقونة كأنها تردد طالع. أنيميشن native خفيف.
// level: 1..4 (من rssiInfo)، color: لون الإشارة. الأيقونة الأساسية بتفضل باهتة كخلفية.
import React, { useEffect, useRef } from 'react';
import { View, Animated, Easing } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useMotionActive } from '../ThemeContext';

export default function SignalWaves({ level = 4, color = '#2DE0A8', size = 13, duration = 2200, active: activeProp = true }) {
  const motion = useMotionActive();
  const active = activeProp && motion;
  const L = Math.max(1, Math.min(4, level));
  const t = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!active) { t.stopAnimation(); t.setValue(0.9); return undefined; }
    t.setValue(0);
    const loop = Animated.loop(
      Animated.timing(t, { toValue: 1, duration, easing: Easing.linear, useNativeDriver: true })
    );
    loop.start();
    return () => loop.stop();
  }, [active, duration, t]);

  const box = size + 4;
  const layers = [];
  for (let k = 1; k <= L; k += 1) {
    const a = k / (L + 1);
    layers.push(
      <Animated.View
        key={k}
        style={{
          position: 'absolute',
          opacity: t.interpolate({ inputRange: [0, Math.max(0, a - 0.08), a, 0.9, 1], outputRange: [0, 0, 1, 1, 0] }),
        }}
      >
        <MaterialCommunityIcons name={`wifi-strength-${k}`} size={size} color={color} />
      </Animated.View>
    );
  }

  return (
    <View style={{ width: box, height: box, alignItems: 'center', justifyContent: 'center' }}>
      {active && (
        <Animated.View
          pointerEvents="none"
          style={{
            position: 'absolute', width: box, height: box, borderRadius: box / 2, borderWidth: 1.2, borderColor: color,
            opacity: t.interpolate({ inputRange: [0, 0.15, 1], outputRange: [0, 0.45, 0] }),
            transform: [{ scale: t.interpolate({ inputRange: [0, 1], outputRange: [0.7, 2.1] }) }],
          }}
        />
      )}
      <View style={{ position: 'absolute', opacity: 0.28 }}>
        <MaterialCommunityIcons name={`wifi-strength-${L}`} size={size} color={color} />
      </View>
      {layers}
    </View>
  );
}
