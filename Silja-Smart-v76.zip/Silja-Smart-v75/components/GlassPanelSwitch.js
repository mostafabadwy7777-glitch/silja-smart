// لوحة زجاجية متدرجة (Gradient Panel): مفتاح واحد كبير بلمعة زجاجية.
// شغال = تدرج مضيء بلون الجهاز + توهج + لمعة وشرطة مضيئة تحت. مطفي = لوحة غامقة خافتة بدون توهج.
// الحركة زي مفتاح الحائط: اللوحة بتتقلب بحركة ثلاثية الأبعاد (Spring) وبتتضغط لما تتطفي.
// الحركة بتقف مع "حركة أقل".
import React, { useEffect, useRef } from 'react';
import { View, Animated, Easing } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import DeviceGlyph from './DeviceGlyph';
import { withAlpha, mixHex } from '../colorUtils';
import { useMotionActive } from '../ThemeContext';

export default function GlassPanelSwitch({ isOn, onColor, theme, width = 150, pending = false, icon = null, showIcon = false }) {
  const height = Math.round(width * 1.28);
  const tilt = useRef(new Animated.Value(isOn ? 1 : 0)).current;
  const breath = useRef(new Animated.Value(0)).current;
  const motion = useMotionActive();

  useEffect(() => {
    Animated.spring(tilt, { toValue: isOn ? 1 : 0, friction: 6, tension: 140, useNativeDriver: true }).start();
  }, [isOn, tilt]);

  useEffect(() => {
    if (!isOn || !motion) { breath.stopAnimation(); breath.setValue(isOn ? 0.5 : 0); return undefined; }
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(breath, { toValue: 1, duration: 1900, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(breath, { toValue: 0, duration: 1900, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [isOn, motion, breath]);

  const dark = !theme.isLight;
  const frameR = Math.round(width * 0.16);
  const pad = Math.max(5, Math.round(width * 0.04));
  const innerR = frameR - pad + 2;

  // تدرج مضيء: غامق من فوق وفاتح من تحت (زي الصورة)
  const litColors = [mixHex(onColor, '#000000', 0.38), onColor, mixHex(onColor, '#FFFFFF', 0.28)];
  const offColors = dark ? ['#1B2230', '#232B3A', '#2A3344'] : ['#C9D0DB', '#D8DEE8', '#E6EAF1'];
  const frameColors = isOn
    ? [withAlpha(onColor, 0.55), withAlpha(onColor, 0.2)]
    : (dark ? ['#202734', '#10151D'] : ['#FFFFFF', '#D5DAE3']);

  const rot = tilt.interpolate({ inputRange: [0, 1], outputRange: ['7deg', '-3deg'] });
  const scale = tilt.interpolate({ inputRange: [0, 1], outputRange: [0.975, 1] });
  const pillBg = isOn ? 'rgba(255,255,255,0.92)' : (dark ? 'rgba(255,255,255,0.22)' : 'rgba(20,30,45,0.25)');

  return (
    <View style={{ width: width + 24, height: height + 24, alignItems: 'center', justifyContent: 'center' }}>
      {isOn && (
        <Animated.View
          pointerEvents="none"
          style={{
            position: 'absolute', width: width + 22, height: height + 22, borderRadius: frameR + 8, backgroundColor: onColor,
            opacity: breath.interpolate({ inputRange: [0, 1], outputRange: [0.12, 0.3] }),
          }}
        />
      )}
      <Animated.View style={{ width, height, opacity: pending ? 0.65 : 1, transform: [{ perspective: 700 }, { rotateX: rot }, { scale }] }}>
        <LinearGradient
          colors={frameColors}
          style={{
            flex: 1, borderRadius: frameR, padding: pad, borderWidth: 1.5,
            borderColor: isOn ? withAlpha(onColor, 0.7) : (dark ? 'rgba(255,255,255,0.10)' : 'rgba(0,0,0,0.12)'),
            shadowColor: onColor, shadowOpacity: isOn ? 0.6 : 0, shadowRadius: isOn ? 16 : 0, shadowOffset: { width: 0, height: 0 },
          }}
        >
          <View style={{ flex: 1, borderRadius: innerR, overflow: 'hidden', borderWidth: 1.5, borderColor: isOn ? 'rgba(255,255,255,0.45)' : (dark ? 'rgba(255,255,255,0.08)' : 'rgba(255,255,255,0.8)') }}>
            <LinearGradient colors={isOn ? litColors : offColors} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 1 }} style={{ flex: 1, alignItems: 'center', justifyContent: 'flex-end' }}>
              {/* لمعة زجاجية قطرية من الركن العلوي */}
              <LinearGradient
                pointerEvents="none"
                colors={[`rgba(255,255,255,${isOn ? 0.34 : 0.10})`, 'rgba(255,255,255,0)']}
                start={{ x: 0, y: 0 }}
                end={{ x: 0.55, y: 0.6 }}
                style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}
              />
              {/* أيقونة الجهاز (لو الخيار مفعّل) بدل الشرطة: معبّية ومضيئة وهي شغالة، فاضية وخافتة وهي مطفية */}
              {showIcon && icon ? (
                <View style={{ marginBottom: Math.round(height * 0.06) }}>
                  <DeviceGlyph icon={icon} size={Math.round(width * 0.3)} color={isOn ? '#FFFFFF' : (dark ? 'rgba(255,255,255,0.4)' : 'rgba(20,30,45,0.45)')} isOn={isOn} glow={false} />
                </View>
              ) : (
              <View
                style={{
                  width: Math.round(width * 0.2), height: Math.max(5, Math.round(width * 0.04)), borderRadius: 4, marginBottom: Math.round(height * 0.07),
                  backgroundColor: pillBg,
                  shadowColor: '#FFFFFF', shadowOpacity: isOn ? 0.9 : 0, shadowRadius: isOn ? 6 : 0, shadowOffset: { width: 0, height: 0 },
                }}
              />
              )}
            </LinearGradient>
          </View>
        </LinearGradient>
      </Animated.View>
    </View>
  );
}
