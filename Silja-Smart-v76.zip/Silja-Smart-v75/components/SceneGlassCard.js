// كارت مشهد زجاجي: نفس لغة اللوحة الزجاجية (تدرج شفاف + لمعة علوية + حدود مضيئة) مع أيقونة كبيرة،
// ولما المشهد يتفعّل بيتوهج بلون "التشغيل": هالة حوالين الأيقونة بتنبض، موجة بتتمدد، وغلاف لوني بيخفت بعد كام ثانية.
import React, { useEffect, useRef, useState } from 'react';
import { View, Text, Animated, Easing, StyleSheet } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useMotionActive } from '../ThemeContext';
import { withAlpha, readableOn } from '../colorUtils';

const LIT_MS = 4200; // مدة التوهج بعد التفعيل
const ICON = 68;

export default function SceneGlassCard({ theme, name, icon, meta, schedule, connected, running, ran, onPress, onEdit, onDelete }) {
  const motion = useMotionActive();
  const color = theme.on || theme.accent;
  const [lit, setLit] = useState(false);
  const litAnim = useRef(new Animated.Value(0)).current;
  const pulse = useRef(new Animated.Value(0)).current;
  const ripple = useRef(new Animated.Value(0)).current;
  const pop = useRef(new Animated.Value(1)).current;
  const litTimer = useRef(null);

  // لما المشهد يتشغّل: ابدأ التوهج + الموجة + نبضة صغيرة على الأيقونة، وبعد LIT_MS اخفّت.
  useEffect(() => {
    if (!ran) return undefined;
    setLit(true);
    ripple.setValue(0);
    pop.setValue(0.82);
    Animated.spring(pop, { toValue: 1, friction: 4, tension: 120, useNativeDriver: true }).start();
    Animated.timing(ripple, { toValue: 1, duration: 900, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
    // المؤقت في ref: الـ ran بيرجع false بعد ~1.3 ثانية، ومينفعش ده يلغي مؤقت الإطفاء
    clearTimeout(litTimer.current);
    litTimer.current = setTimeout(() => setLit(false), LIT_MS);
    return undefined;
  }, [ran, ripple, pop]);
  useEffect(() => () => clearTimeout(litTimer.current), []);

  const glowing = lit || !!running;
  useEffect(() => {
    Animated.timing(litAnim, { toValue: glowing ? 1 : 0, duration: glowing ? 350 : 900, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
    if (!glowing || !motion) { pulse.stopAnimation(); pulse.setValue(glowing ? 0.5 : 0); return undefined; }
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(pulse, { toValue: 1, duration: 900, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(pulse, { toValue: 0, duration: 900, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [glowing, motion, litAnim, pulse]);

  const dark = !theme.isLight;
  const edge = dark ? 'rgba(255,255,255,0.20)' : withAlpha(theme.accent, 0.32);

  return (
    <View
      style={{
        borderRadius: 26, marginBottom: 15, overflow: 'hidden', borderWidth: 1.3, borderColor: glowing ? withAlpha(color, 0.9) : edge,
        backgroundColor: withAlpha(theme.card, dark ? 0.6 : 0.72),
        shadowColor: glowing ? color : '#000', shadowOpacity: glowing ? 0.55 : 0.16, shadowRadius: glowing ? 18 : 12, shadowOffset: { width: 0, height: glowing ? 0 : 5 }, elevation: glowing ? 7 : 3,
      }}
    >
      <LinearGradient pointerEvents="none" colors={[withAlpha(theme.accent, 0.16), withAlpha(theme.accentSoft || theme.accent, 0.04)]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
      <LinearGradient pointerEvents="none" colors={[`rgba(255,255,255,${dark ? 0.2 : 0.55})`, 'rgba(255,255,255,0)']} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 0.55 }} style={StyleSheet.absoluteFill} />
      {/* غلاف التوهج */}
      <Animated.View pointerEvents="none" style={[StyleSheet.absoluteFill, { backgroundColor: color, opacity: Animated.multiply(litAnim, pulse.interpolate({ inputRange: [0, 1], outputRange: [0.08, 0.22] })) }]} />

      <TouchableOpacity activeOpacity={0.85} onPress={onPress} disabled={!connected || !!running} style={{ flexDirection: 'row', alignItems: 'center', padding: 16, gap: 14 }}>
        <View style={{ width: ICON + 14, height: ICON + 14, alignItems: 'center', justifyContent: 'center' }}>
          {/* موجة التفعيل + الهالة */}
          <Animated.View pointerEvents="none" style={{ position: 'absolute', width: ICON, height: ICON, borderRadius: ICON / 2, borderWidth: 2, borderColor: color, opacity: ripple.interpolate({ inputRange: [0, 0.2, 1], outputRange: [0, 0.8, 0] }), transform: [{ scale: ripple.interpolate({ inputRange: [0, 1], outputRange: [1, 1.7] }) }] }} />
          <Animated.View pointerEvents="none" style={{ position: 'absolute', width: ICON + 14, height: ICON + 14, borderRadius: (ICON + 14) / 2, backgroundColor: color, opacity: Animated.multiply(litAnim, pulse.interpolate({ inputRange: [0, 1], outputRange: [0.22, 0.5] })), transform: [{ scale: pulse.interpolate({ inputRange: [0, 1], outputRange: [0.92, 1.12] }) }] }} />
          <Animated.View style={{ width: ICON, height: ICON, borderRadius: ICON / 2, overflow: 'hidden', alignItems: 'center', justifyContent: 'center', borderWidth: 1.4, borderColor: glowing ? withAlpha(color, 0.95) : withAlpha(theme.accentSoft || theme.accent, 0.55), transform: [{ scale: pop }] }}>
            <LinearGradient colors={glowing ? [withAlpha(color, 0.5), withAlpha(color, 0.18)] : [withAlpha(theme.accentSoft || theme.accent, 0.22), withAlpha(theme.accentSoft || theme.accent, 0.06)]} start={{ x: 0.2, y: 0 }} end={{ x: 0.8, y: 1 }} style={StyleSheet.absoluteFill} />
            <LinearGradient pointerEvents="none" colors={['rgba(255,255,255,0.45)', 'rgba(255,255,255,0)']} start={{ x: 0, y: 0 }} end={{ x: 0.7, y: 0.8 }} style={StyleSheet.absoluteFill} />
            <MaterialCommunityIcons name={icon} size={36} color={glowing ? (dark ? '#FFFFFF' : color) : (theme.accentSoft || theme.accent)} />
          </Animated.View>
        </View>

        <View style={{ flex: 1 }}>
          <Text style={{ color: theme.textPrimary, fontSize: 16.5, fontWeight: '800', textAlign: 'right' }} numberOfLines={1}>{name}</Text>
          <Text style={{ color: theme.textMuted, fontSize: 11.5, marginTop: 3, textAlign: 'right' }} numberOfLines={1}>{meta}</Text>
          {!!schedule && <Text style={{ color: theme.accentSoft || theme.accent, fontSize: 11.5, marginTop: 2, textAlign: 'right' }} numberOfLines={1}>⏰ {schedule}</Text>}
        </View>

        <View style={{ width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center', borderWidth: 1.2, borderColor: connected ? withAlpha(glowing ? color : (theme.accentSoft || theme.accent), 0.8) : theme.border, backgroundColor: glowing ? color : withAlpha(theme.accentSoft || theme.accent, connected ? 0.2 : 0.06) }}>
          <MaterialCommunityIcons name={glowing && !running ? 'check' : 'play'} size={22} color={glowing ? readableOn(color) : connected ? (theme.accentSoft || theme.accent) : theme.textMuted} />
        </View>
      </TouchableOpacity>

      <View style={{ flexDirection: 'row', paddingHorizontal: 8, paddingBottom: 4, borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: dark ? 'rgba(255,255,255,0.12)' : theme.border }}>
        <TouchableOpacity onPress={onEdit} style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 10, gap: 6 }}>
          <MaterialCommunityIcons name="pencil-outline" size={16} color={theme.textSecondary} />
          <Text style={{ color: theme.textSecondary, fontSize: 12, fontWeight: '600' }}>تعديل</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={onDelete} style={{ flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 10, gap: 6 }}>
          <MaterialCommunityIcons name="trash-can-outline" size={16} color={theme.danger} />
          <Text style={{ color: theme.danger, fontSize: 12, fontWeight: '600' }}>مسح</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
