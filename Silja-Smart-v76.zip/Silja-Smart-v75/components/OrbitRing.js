// خط ملوّن بيلف حوالين حواف أيقونة دايرية (ثيم "Orbit Neon").
// من غير أي مكتبة جديدة: دايرة فيها مربع متدرّج بيلف (native driver)،
// وقرص داخلي معتم بيغطي النص ويسيب بس سمك الخط على الحافة.
// الأيقونة (children) بتتحط فوق ومش بتتقص، فأي badge برا الدايرة يفضل ظاهر.
import React, { useEffect, useRef } from 'react';
import { View, Animated, Easing, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { withAlpha } from '../colorUtils';
import { useMotionActive } from '../ThemeContext';

export default function OrbitRing({
  size = 38,
  thickness = 2,
  colors = ['#2DE0A8', '#3B9DFF'],
  innerColor = '#0F1E36',
  tint,                 // لون شفاف خفيف فوق القرص الداخلي (اختياري)
  duration = 3600,      // زمن لفة كاملة بالمللي ثانية
  phase = 0,            // 0..1 — نقطة بداية مختلفة لكل دايرة عشان مايلفّوش متزامنين
  active = true,
  style,
  children,
}) {
  const spin = useRef(new Animated.Value(0)).current;
  const motion = useMotionActive();
  const run = active && motion;

  useEffect(() => {
    if (!run) { spin.stopAnimation(); return undefined; }
    spin.setValue(0);
    const loop = Animated.loop(
      Animated.timing(spin, { toValue: 1, duration, easing: Easing.linear, useNativeDriver: true })
    );
    loop.start();
    return () => loop.stop();
  }, [run, duration, spin]);

  const rotate = spin.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const list = colors && colors.length ? colors : ['#2DE0A8'];
  const [c1, c2] = [list[0], list[1] || list[0]];
  // لونين: خط منوّر بيتلاشى في النص. 3 ألوان أو أكتر: كل الألوان متوزعة على الحلقة كلها.
  const many = list.length > 2;
  const gradColors = many ? [...list, list[0]] : [c2, withAlpha(c2, 0), withAlpha(c1, 0), c1];
  const gradLocations = many ? gradColors.map((_, i) => i / (gradColors.length - 1)) : [0, 0.38, 0.62, 1];
  const inner = size - thickness * 2;

  return (
    <View style={[{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }, style]}>
      <View
        pointerEvents="none"
        style={[StyleSheet.absoluteFill, { borderRadius: size / 2, overflow: 'hidden', backgroundColor: withAlpha(c1, many ? 0.3 : 0.18) }]}
      >
        <View style={{ width: size, height: size, transform: [{ rotate: `${Math.round(phase * 360)}deg` }] }}>
          <Animated.View style={{ width: size, height: size, transform: [{ rotate }] }}>
            <LinearGradient
              colors={gradColors}
              locations={gradLocations}
              start={{ x: 0, y: 0.5 }}
              end={{ x: 1, y: 0.5 }}
              style={StyleSheet.absoluteFill}
            />
          </Animated.View>
        </View>
        <View
          style={{
            position: 'absolute', left: thickness, top: thickness, width: inner, height: inner,
            borderRadius: inner / 2, backgroundColor: innerColor, overflow: 'hidden',
          }}
        >
          {!!tint && <View style={[StyleSheet.absoluteFill, { backgroundColor: tint }]} />}
        </View>
      </View>
      {children}
    </View>
  );
}


// إطار مستطيل (كارت الرئيسية / كروت البوردات): خط ملوّن بيلف حوالين حافة الكارت.
// بيلف الكارت من برا (padding = سمك الخط) فمش بيمس شكل الكارت جوّه.
// لو cfg فاضي بيرجّع الكارت زي ما هو من غير أي لف.
export function OrbitFrame({ cfg, radius = 22, thickness = 2.2, style, children }) {
  const [box, setBox] = React.useState({ w: 0, h: 0 });
  const spin = useRef(new Animated.Value(0)).current;
  const on = !!cfg;
  const motion = useMotionActive();
  const duration = cfg ? cfg.duration : 3600;

  useEffect(() => {
    if (!on || !motion) { spin.stopAnimation(); return undefined; }
    spin.setValue(0);
    const loop = Animated.loop(
      Animated.timing(spin, { toValue: 1, duration: duration * 1.6, easing: Easing.linear, useNativeDriver: true })
    );
    loop.start();
    return () => loop.stop();
  }, [on, motion, duration, spin]);

  if (!on) return <>{children}</>;

  const list = cfg.colors && cfg.colors.length ? cfg.colors : ['#2DE0A8'];
  const c1 = list[0];
  const c2 = list[1] || list[0];
  const many = list.length > 2;
  const gradColors = many ? [...list, list[0]] : [c2, withAlpha(c2, 0), withAlpha(c1, 0), c1];
  const gradLocations = many ? gradColors.map((_, i) => i / (gradColors.length - 1)) : [0, 0.38, 0.62, 1];
  const rotate = spin.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const side = Math.ceil(Math.hypot(box.w, box.h)) + 4;

  return (
    <View
      onLayout={(e) => setBox({ w: e.nativeEvent.layout.width, h: e.nativeEvent.layout.height })}
      style={[{ borderRadius: radius + thickness, padding: thickness, overflow: 'hidden', backgroundColor: withAlpha(c1, many ? 0.3 : 0.18) }, style]}
    >
      {box.w > 0 && (
        <Animated.View
          pointerEvents="none"
          style={{ position: 'absolute', width: side, height: side, left: (box.w - side) / 2, top: (box.h - side) / 2, transform: [{ rotate }] }}
        >
          <LinearGradient colors={gradColors} locations={gradLocations} start={{ x: 0, y: 0.5 }} end={{ x: 1, y: 0.5 }} style={StyleSheet.absoluteFill} />
        </Animated.View>
      )}
      {children}
    </View>
  );
}
