// مفتاح حائط ذكي (Rocker) من نصفين: النصف العلوي = ON والسفلي = OFF.
// النصف الشغال بيتنوّر بلون الجهاز (تدرج + توهج + حدود مضيئة) وعليه أيقونة الجهاز اللي اخترتها،
// والنصف التاني خافت وعليه نفس الأيقونة (شكل الأيقونة الفاضي) مع كلمة OFF.
// لما تغيّر أيقونة الجهاز، الأيقونة بتتبدّل تلقائي في النصفين. الحركة بتقف مع "حركة أقل".
import React, { useEffect, useRef } from 'react';
import { View, Text, Animated, Easing } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import DeviceGlyph from './DeviceGlyph';
import { withAlpha } from '../colorUtils';
import { useMotionActive } from '../ThemeContext';

export default function WallRocker({ isOn, onColor, theme, icon = 'lightbulb-outline', width = 84, pending = false }) {
  const height = Math.round(width * 2.0);
  const tilt = useRef(new Animated.Value(isOn ? 1 : 0)).current;
  const breath = useRef(new Animated.Value(0)).current;
  const motion = useMotionActive();

  useEffect(() => {
    Animated.spring(tilt, { toValue: isOn ? 1 : 0, friction: 7, tension: 150, useNativeDriver: true }).start();
  }, [isOn, tilt]);

  useEffect(() => {
    if (!isOn || !motion) { breath.stopAnimation(); breath.setValue(isOn ? 0.5 : 0); return undefined; }
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(breath, { toValue: 1, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(breath, { toValue: 0, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [isOn, motion, breath]);

  const dark = !theme.isLight;
  const frame = dark ? ['#202734', '#10151D'] : ['#FFFFFF', '#DDE2EA'];
  const muted = dark ? 'rgba(255,255,255,0.42)' : 'rgba(20,30,45,0.45)';
  const pad = Math.max(4, Math.round(width * 0.06));
  const gap = Math.max(2, Math.round(width * 0.03));
  const panelH = Math.round((height - pad * 2 - gap) / 2);
  const panelR = Math.round(width * 0.2);
  const iconSize = Math.round(width * 0.36);
  const fontSize = Math.max(9, Math.round(width * 0.17));
  const rot = tilt.interpolate({ inputRange: [0, 1], outputRange: ['5deg', '-5deg'] });

  const litColors = [withAlpha(onColor, 0.95), withAlpha(onColor, 0.55)];
  const raisedColors = dark ? ['rgba(255,255,255,0.14)', 'rgba(255,255,255,0.05)'] : ['rgba(255,255,255,1)', 'rgba(255,255,255,0.6)'];
  const sunkColors = dark ? ['rgba(0,0,0,0.42)', 'rgba(0,0,0,0.26)'] : ['rgba(0,0,0,0.10)', 'rgba(0,0,0,0.05)'];
  const edge = dark ? 'rgba(255,255,255,0.10)' : 'rgba(0,0,0,0.10)';

  // نصف المفتاح: lit = مضيء بلون الجهاز، raised = بارز وخافت (OFF الشغال)، غير كده = غاطس
  const renderPanel = (kind, label, glyphOn) => {
    const lit = kind === 'lit';
    const colors = lit ? litColors : kind === 'raised' ? raisedColors : sunkColors;
    const fg = lit ? '#FFFFFF' : muted;
    return (
      <View
        style={{
          height: panelH, borderRadius: panelR, overflow: 'hidden', borderWidth: lit ? 1.5 : 1,
          borderColor: lit ? withAlpha(onColor, 0.95) : edge,
        }}
      >
        <LinearGradient colors={colors} style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <DeviceGlyph icon={icon} size={iconSize} color={fg} isOn={glyphOn} glow={false} />
          <Text style={{ marginTop: Math.round(width * 0.05), fontSize, fontWeight: '800', letterSpacing: 0.5, color: fg }}>{label}</Text>
        </LinearGradient>
      </View>
    );
  };

  return (
    <View style={{ width: width + 28, height: height + 28, alignItems: 'center', justifyContent: 'center' }}>
      {isOn && (
        <Animated.View
          pointerEvents="none"
          style={{
            position: 'absolute', width: width + 26, height: height + 26, borderRadius: panelR + 10, backgroundColor: onColor,
            opacity: breath.interpolate({ inputRange: [0, 1], outputRange: [0.10, 0.26] }),
          }}
        />
      )}
      <LinearGradient
        colors={frame}
        start={{ x: 0.2, y: 0 }}
        end={{ x: 0.8, y: 1 }}
        style={{
          width, height, borderRadius: panelR + 4, padding: pad, borderWidth: 1.5,
          borderColor: isOn ? withAlpha(onColor, 0.55) : edge, opacity: pending ? 0.65 : 1,
          shadowColor: onColor, shadowOpacity: isOn ? 0.55 : 0, shadowRadius: isOn ? 14 : 0, shadowOffset: { width: 0, height: 0 },
        }}
      >
        <Animated.View style={{ flex: 1, transform: [{ perspective: 600 }, { rotateX: rot }] }}>
          {renderPanel(isOn ? 'lit' : 'sunk', 'ON', true)}
          <View style={{ height: gap }} />
          {renderPanel(isOn ? 'sunk' : 'raised', 'OFF', false)}
        </Animated.View>
      </LinearGradient>
    </View>
  );
}
