// منحنى زجاجي ناعم (بدل الأعمدة): خط منحني متدرّج بتعبئة شفافة تحته، شبكة خفيفة، ونقطة مضيئة على
// القيمة المختارة (دوس أو اسحب على الرسم). مبني بـ View بس (من غير مكتبة SVG) عشان مفيش تبعيات جديدة:
// المنحنى بيتقسّم لقطع صغيرة متدوّرة، والتعبئة شرايط رفيعة. الاستيفاء monotone فمش بيطلع تحت الصفر ولا يعدّي القمم.
import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, Animated, Easing, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { withAlpha } from '../colorUtils';

const STEP = 4; // px بين كل عينة على المنحنى
const PAD_X = 14;
const PAD_TOP = 18;
const PAD_BOTTOM = 8;

// Fritsch–Carlson monotone cubic: بيرجّع دالة y(x) على نقاط متساوية البعد
function monotone(ys) {
  const n = ys.length;
  if (n === 1) return () => ys[0];
  const d = []; for (let i = 0; i < n - 1; i += 1) d.push(ys[i + 1] - ys[i]);
  const m = new Array(n);
  m[0] = d[0]; m[n - 1] = d[n - 2];
  for (let i = 1; i < n - 1; i += 1) m[i] = d[i - 1] * d[i] <= 0 ? 0 : (d[i - 1] + d[i]) / 2;
  for (let i = 0; i < n - 1; i += 1) {
    if (d[i] === 0) { m[i] = 0; m[i + 1] = 0; continue; }
    const a = m[i] / d[i]; const b = m[i + 1] / d[i]; const h = Math.hypot(a, b);
    if (h > 3) { const t = 3 / h; m[i] = t * a * d[i]; m[i + 1] = t * b * d[i]; }
  }
  return (u) => { // u في [0, n-1]
    const i = Math.min(n - 2, Math.max(0, Math.floor(u)));
    const t = u - i; const t2 = t * t; const t3 = t2 * t;
    return (2 * t3 - 3 * t2 + 1) * ys[i] + (t3 - 2 * t2 + t) * m[i] + (-2 * t3 + 3 * t2) * ys[i + 1] + (t3 - t2) * m[i + 1];
  };
}

export default function GlassCurveChart({ data = [], color = '#48CFC0', theme, height = 190, formatValue = (v) => String(v), formatLabel = (d) => d.label, labelEvery = 1 }) {
  const [w, setW] = useState(0);
  const [sel, setSel] = useState(null);
  const reveal = useRef(new Animated.Value(0)).current;
  const dark = !theme.isLight;

  const n = data.length;
  const max = Math.max(1e-9, ...data.map((d) => d.value));
  const top = max * 1.15;
  const innerW = Math.max(1, w - PAD_X * 2);
  const innerH = height - PAD_TOP - PAD_BOTTOM;
  const xAt = (i) => PAD_X + (n <= 1 ? innerW / 2 : (i / (n - 1)) * innerW);
  const yAt = (v) => PAD_TOP + innerH - (Math.max(0, v) / top) * innerH;

  useEffect(() => {
    reveal.setValue(0);
    Animated.timing(reveal, { toValue: 1, duration: 800, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  }, [reveal, data.length, w]);

  const geo = useMemo(() => {
    if (w <= 0 || n === 0) return { segs: [], strips: [] };
    const f = monotone(data.map((d) => d.value));
    const pts = [];
    const count = Math.max(2, Math.ceil(innerW / STEP));
    for (let k = 0; k <= count; k += 1) {
      const u = n <= 1 ? 0 : (k / count) * (n - 1);
      pts.push({ x: PAD_X + (k / count) * innerW, y: yAt(Math.max(0, f(u))) });
    }
    const segs = []; const strips = [];
    for (let k = 0; k < pts.length - 1; k += 1) {
      const a = pts[k]; const b = pts[k + 1];
      const len = Math.hypot(b.x - a.x, b.y - a.y) + 0.6;
      segs.push({ cx: (a.x + b.x) / 2, cy: (a.y + b.y) / 2, len, ang: Math.atan2(b.y - a.y, b.x - a.x) });
      const yy = (a.y + b.y) / 2;
      strips.push({ x: a.x, y: yy, h: PAD_TOP + innerH - yy });
    }
    return { segs, strips };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data, w, height]);

  const onTouch = (e) => {
    if (n === 0 || w <= 0) return;
    const x = e.nativeEvent.locationX;
    const i = n <= 1 ? 0 : Math.round(((x - PAD_X) / innerW) * (n - 1));
    setSel(Math.max(0, Math.min(n - 1, i)));
  };

  const active = sel == null ? n - 1 : sel;
  const act = data[active];
  const gridVals = [0.25, 0.5, 0.75, 1].map((r) => r * top);

  return (
    <View style={{ borderRadius: 24, overflow: 'hidden', borderWidth: 1.2, borderColor: dark ? 'rgba(255,255,255,0.18)' : withAlpha(color, 0.3), backgroundColor: withAlpha(theme.card, dark ? 0.6 : 0.75) }}>
      <LinearGradient pointerEvents="none" colors={[withAlpha(color, 0.16), withAlpha(color, 0.03)]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
      <LinearGradient pointerEvents="none" colors={[`rgba(255,255,255,${dark ? 0.18 : 0.5})`, 'rgba(255,255,255,0)']} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 0.5 }} style={StyleSheet.absoluteFill} />

      {/* القيمة المختارة */}
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', paddingHorizontal: 16, paddingTop: 14 }}>
        <Text style={{ color: theme.textMuted, fontSize: 11.5 }}>{act ? formatLabel(act, true) : ''}</Text>
        <Text style={{ color: theme.textPrimary, fontSize: 18, fontWeight: '800' }}>{act ? formatValue(act.value) : '—'}</Text>
      </View>

      <View
        style={{ height, direction: 'ltr' }}
        onLayout={(e) => setW(e.nativeEvent.layout.width)}
        onStartShouldSetResponder={() => true}
        onResponderGrant={onTouch}
        onResponderMove={onTouch}
        onResponderRelease={() => setSel(null)}
        onResponderTerminate={() => setSel(null)}
      >
        {w > 0 && gridVals.map((v, i) => (
          <View key={i} pointerEvents="none" style={{ position: 'absolute', left: PAD_X, right: PAD_X, top: yAt(v), height: StyleSheet.hairlineWidth, backgroundColor: dark ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.1)' }} />
        ))}

        <Animated.View pointerEvents="none" style={[StyleSheet.absoluteFill, { opacity: reveal, transform: [{ translateY: reveal.interpolate({ inputRange: [0, 1], outputRange: [10, 0] }) }] }]}>
          {/* تعبئة زجاجية تحت المنحنى */}
          {geo.strips.map((s, i) => (
            <View key={`f${i}`} style={{ position: 'absolute', left: s.x, top: s.y, width: STEP + 0.6, height: s.h, backgroundColor: withAlpha(color, 0.16) }} />
          ))}
          {/* توهج ناعم ورا الخط */}
          {geo.segs.map((s, i) => (
            <View key={`g${i}`} style={{ position: 'absolute', left: s.cx - s.len / 2, top: s.cy - 5, width: s.len, height: 10, borderRadius: 5, backgroundColor: withAlpha(color, 0.18), transform: [{ rotate: `${s.ang}rad` }] }} />
          ))}
          {/* الخط نفسه */}
          {geo.segs.map((s, i) => (
            <View key={`l${i}`} style={{ position: 'absolute', left: s.cx - s.len / 2, top: s.cy - 1.5, width: s.len, height: 3, borderRadius: 1.5, backgroundColor: color, transform: [{ rotate: `${s.ang}rad` }] }} />
          ))}
          {/* نقاط البيانات */}
          {w > 0 && n <= 14 && data.map((d, i) => (
            <View key={`p${i}`} style={{ position: 'absolute', left: xAt(i) - 3, top: yAt(d.value) - 3, width: 6, height: 6, borderRadius: 3, backgroundColor: dark ? 'rgba(255,255,255,0.85)' : '#fff', borderWidth: 1.2, borderColor: color }} />
          ))}
        </Animated.View>

        {/* المؤشر المختار: خط رأسي + نقطة مضيئة */}
        {w > 0 && !!act && (
          <View pointerEvents="none" style={StyleSheet.absoluteFill}>
            <View style={{ position: 'absolute', left: xAt(active) - 0.5, top: PAD_TOP - 6, bottom: PAD_BOTTOM, width: 1, backgroundColor: withAlpha(color, 0.45) }} />
            <View style={{ position: 'absolute', left: xAt(active) - 12, top: yAt(act.value) - 12, width: 24, height: 24, borderRadius: 12, backgroundColor: withAlpha(color, 0.28) }} />
            <View style={{ position: 'absolute', left: xAt(active) - 6, top: yAt(act.value) - 6, width: 12, height: 12, borderRadius: 6, backgroundColor: '#fff', borderWidth: 3, borderColor: color }} />
          </View>
        )}
      </View>

      <View style={{ flexDirection: 'row', paddingHorizontal: PAD_X - 6, paddingBottom: 12, direction: 'ltr' }}>
        {data.map((d, i) => (
          <Text key={d.key || i} numberOfLines={1} style={{ flex: 1, textAlign: 'center', fontSize: 10, color: i === active ? theme.textPrimary : theme.textMuted, fontWeight: i === active ? '800' : '500' }}>
            {i % labelEvery === 0 || i === n - 1 ? formatLabel(d, false) : ''}
          </Text>
        ))}
      </View>
    </View>
  );
}
