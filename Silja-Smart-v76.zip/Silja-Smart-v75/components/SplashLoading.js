import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Animated, Easing, StatusBar } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { loadThemeId, loadCustomTheme } from '../storage';
import { getTheme, CUSTOM_THEME_ID, DEFAULT_CUSTOM_THEME } from '../theme';
import { withAlpha } from '../colorUtils';

// شاشة التشغيل: حلقة مضيئة بلون الثيم المحفوظ بتلف وتنبض في النص.
// الشاشة بتتركّب مرة واحدة فوق التطبيق كله (overlay) وبتفضل ثابتة لحد ما التطبيق يبقى جاهز
// (ready=true)، وساعتها الحلقة بتتمدد وتتلاشى والشاشة بتبهت وتكشف الشاشة الرئيسية اللي تحتها
// بحركة ناعمة، وبعدها بتنادي onFinish عشان تتشال. الألوان بتتقرأ من التخزين مباشرة لأن
// ThemeProvider لسه مش متاح وقت ما الشاشة دي بتظهر.
const SIZE = 132;
const MIN_SHOW_MS = 1100; // أقل مدة عرض عشان الحركة متتقطعش لو التحميل خلص بسرعة

export default function SplashLoading({ fontsReady = false, ready = false, onExitStart, onFinish }) {
  const [colors, setColors] = useState({ bg: '#0A0B0D', accent: '#D6B36A', isLight: false });
  const [themeLoaded, setThemeLoaded] = useState(false);
  const mountedAt = useRef(Date.now()).current;

  const spin = useRef(new Animated.Value(0)).current;
  const breathe = useRef(new Animated.Value(0)).current;
  const intro = useRef(new Animated.Value(0)).current; // ظهور الحلقة أول مرة
  const exit = useRef(new Animated.Value(0)).current; // 0 → 1 أثناء التحوّل للرئيسية
  const exiting = useRef(false);

  useEffect(() => {
    let alive = true;
    (async () => {
      try {
        const [id, custom] = await Promise.all([loadThemeId(), loadCustomTheme()]);
        const t = id === CUSTOM_THEME_ID ? { ...DEFAULT_CUSTOM_THEME, ...(custom || {}) } : getTheme(id);
        if (alive && t) setColors({ bg: t.bg, accent: t.accent, isLight: !!t.isLight });
      } catch (_) {}
      if (alive) setThemeLoaded(true);
    })();
    return () => { alive = false; };
  }, []);

  useEffect(() => {
    const spinLoop = Animated.loop(Animated.timing(spin, { toValue: 1, duration: 2600, easing: Easing.linear, useNativeDriver: true }));
    const breatheLoop = Animated.loop(Animated.sequence([
      Animated.timing(breathe, { toValue: 1, duration: 1500, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(breathe, { toValue: 0, duration: 1500, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    spinLoop.start();
    breatheLoop.start();
    Animated.timing(intro, { toValue: 1, duration: 700, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
    return () => { spinLoop.stop(); breatheLoop.stop(); };
  }, [spin, breathe, intro]);

  useEffect(() => {
    if (!ready) return undefined;
    const wait = Math.max(0, MIN_SHOW_MS - (Date.now() - mountedAt));
    const t = setTimeout(() => {
      if (exiting.current) return;
      exiting.current = true;
      if (onExitStart) onExitStart(); // بنكشف الشاشة الرئيسية تحت الحلقة في نفس لحظة بداية التحوّل
      Animated.timing(exit, { toValue: 1, duration: 750, easing: Easing.inOut(Easing.cubic), useNativeDriver: true }).start(() => {
        if (onFinish) onFinish();
      });
    }, wait);
    return () => clearTimeout(t);
  }, [ready, exit, mountedAt, onExitStart, onFinish]);

  const { bg, accent, isLight } = colors;
  const rotate = spin.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const glowScale = breathe.interpolate({ inputRange: [0, 1], outputRange: [0.92, 1.12] });
  const glowOpacity = breathe.interpolate({ inputRange: [0, 1], outputRange: [0.22, 0.46] });

  // أثناء الخروج: الحلقة بتكبر وتختفي، المحتوى بيبهت، والخلفية كلها بتشفّ (بالترتيب).
  const ringScale = exit.interpolate({ inputRange: [0, 1], outputRange: [1, 4.2] });
  const contentOpacity = exit.interpolate({ inputRange: [0, 0.45, 1], outputRange: [1, 0, 0] });
  const rootOpacity = exit.interpolate({ inputRange: [0, 0.35, 1], outputRange: [1, 1, 0] });
  const rootScale = exit.interpolate({ inputRange: [0, 1], outputRange: [1, 1.06] });

  const titleFont = fontsReady ? { fontFamily: 'ElMessiri_700Bold' } : null;
  const titleColor = isLight ? '#1B1F24' : '#F4F1EA';
  const subColor = isLight ? '#5B636B' : '#A9A59B';

  return (
    <Animated.View
      pointerEvents={ready && exiting.current ? 'none' : 'auto'}
      style={[StyleSheet.absoluteFill, styles.root, { backgroundColor: bg, opacity: rootOpacity, transform: [{ scale: rootScale }] }]}
    >
      <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} />
      <LinearGradient
        pointerEvents="none"
        colors={[withAlpha(accent, 0.0), withAlpha(accent, themeLoaded ? 0.1 : 0), withAlpha(accent, 0.0)]}
        start={{ x: 0.5, y: 0 }}
        end={{ x: 0.5, y: 1 }}
        style={StyleSheet.absoluteFill}
      />

      <Animated.View style={[styles.center, { opacity: Animated.multiply(intro, contentOpacity) }]}>
        <View style={styles.ringWrap}>
          {/* توهج ناعم ورا الحلقة (دوائر شفافة متداخلة بدل ظل عشان يظهر زي بعض على أندرويد وiOS) */}
          <Animated.View pointerEvents="none" style={[styles.glowOuter, { backgroundColor: accent, opacity: glowOpacity, transform: [{ scale: glowScale }] }]} />
          <Animated.View pointerEvents="none" style={[styles.glowInner, { backgroundColor: accent, opacity: glowOpacity, transform: [{ scale: glowScale }] }]} />

          {/* الحلقة الثابتة الخافتة + الخط المضيء اللي بيلف عليها */}
          <Animated.View style={{ position: 'absolute', transform: [{ scale: ringScale }] }}>
            <View style={[styles.ringBase, { borderColor: withAlpha(accent, 0.22) }]} />
            <Animated.View style={[styles.ringArc, { borderTopColor: accent, borderRightColor: withAlpha(accent, 0.55), transform: [{ rotate }] }]} />
          </Animated.View>

          <MaterialCommunityIcons name="home-variant-outline" size={46} color={accent} />
        </View>
        <Text style={[styles.title, titleFont, { color: titleColor }]}>Silja Smart</Text>
        <Text style={[styles.tagline, { color: subColor }]}>Your Smart Home</Text>
      </Animated.View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  root: { alignItems: 'center', justifyContent: 'center', zIndex: 9999, elevation: 9999 },
  center: { alignItems: 'center' },
  ringWrap: { width: SIZE, height: SIZE, alignItems: 'center', justifyContent: 'center', marginBottom: 26 },
  glowOuter: { position: 'absolute', width: SIZE + 56, height: SIZE + 56, borderRadius: (SIZE + 56) / 2, opacity: 0.2 },
  glowInner: { position: 'absolute', width: SIZE + 18, height: SIZE + 18, borderRadius: (SIZE + 18) / 2, opacity: 0.2 },
  ringBase: { width: SIZE, height: SIZE, borderRadius: SIZE / 2, borderWidth: 3 },
  ringArc: { position: 'absolute', top: 0, left: 0, width: SIZE, height: SIZE, borderRadius: SIZE / 2, borderWidth: 3, borderColor: 'transparent' },
  title: { fontSize: 32, fontWeight: '800', letterSpacing: 0.4 },
  tagline: { fontSize: 13.5, marginTop: 6, letterSpacing: 0.9 },
});
