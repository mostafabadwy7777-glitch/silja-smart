import React, { useState } from 'react';
import { Modal, View, Text, StyleSheet } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import { showAlert } from './PremiumAlert';
import { useTheme } from '../ThemeContext';
import { ROOM_GRADIENTS, roomFileKey } from './roomBackgrounds';

const DIR = FileSystem.documentDirectory + 'room-images/';

// نافذة اختيار خلفية الغرفة: تدرج لوني جاهز، أو صورة من المعرض/الكاميرا، أو الرجوع للتلقائي.
export default function RoomBackgroundModal({ visible, roomName, current, onClose, onChange }) {
  const { theme } = useTheme();
  const [busy, setBusy] = useState(false);

  const pickGradient = (id) => { onChange({ type: 'gradient', id }); onClose(); };
  const reset = () => { onChange(null); onClose(); };

  const handle = async (launcher, permFn, permMsg) => {
    const perm = await permFn();
    if (!perm.granted) { showAlert('مفيش صلاحية', permMsg); return; }
    const result = await launcher();
    if (result.canceled || !result.assets?.[0]?.uri) return;
    setBusy(true);
    try {
      await FileSystem.makeDirectoryAsync(DIR, { intermediates: true }).catch(() => {});
      // اسم جديد في كل مرة عشان الصورة تتحدّث فورًا (بدل كاش الصورة القديمة على نفس المسار)
      const dest = `${DIR}${roomFileKey(roomName)}-${Date.now()}.jpg`;
      await FileSystem.copyAsync({ from: result.assets[0].uri, to: dest });
      if (current?.type === 'image' && current.uri) await FileSystem.deleteAsync(current.uri, { idempotent: true }).catch(() => {});
      onChange({ type: 'image', uri: dest });
      onClose();
    } catch (e) {
      showAlert('خطأ', 'مقدرناش نحفظ الصورة، جرب تاني');
    } finally {
      setBusy(false);
    }
  };

  const pickFromLibrary = () => handle(
    () => ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, aspect: [3, 2], quality: 0.7 }),
    ImagePicker.requestMediaLibraryPermissionsAsync,
    'لازم تسمح للتطبيق بالدخول على الصور من إعدادات الموبايل الأول'
  );
  const takePhoto = () => handle(
    () => ImagePicker.launchCameraAsync({ allowsEditing: true, aspect: [3, 2], quality: 0.7 }),
    ImagePicker.requestCameraPermissionsAsync,
    'لازم تسمح للتطبيق باستخدام الكاميرا من إعدادات الموبايل الأول'
  );

  const activeId = current?.type === 'gradient' ? current.id : null;

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.overlay}>
        <View style={[styles.box, { backgroundColor: theme.card, borderColor: theme.border }]}>
          <View style={styles.headerRow}>
            <TouchableOpacity onPress={onClose} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
              <MaterialCommunityIcons name="close" size={20} color={theme.textMuted} />
            </TouchableOpacity>
            <Text style={[styles.title, { color: theme.textPrimary }]} numberOfLines={1}>خلفية {roomName}</Text>
          </View>

          <Text style={[styles.label, { color: theme.textSecondary }]}>تدرج لوني</Text>
          <View style={styles.grid}>
            {ROOM_GRADIENTS.map((g) => (
              <TouchableOpacity key={g.id} onPress={() => pickGradient(g.id)} style={[styles.swatchWrap, { borderColor: activeId === g.id ? theme.accent : 'transparent' }]}>
                <LinearGradient colors={g.colors} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.swatch}>
                  <Text style={styles.swatchText}>{g.name}</Text>
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={[styles.label, { color: theme.textSecondary }]}>أو صورة</Text>
          <View style={styles.actions}>
            <TouchableOpacity style={[styles.btn, { backgroundColor: theme.cardAlt, borderColor: theme.border }]} onPress={pickFromLibrary} disabled={busy}>
              <MaterialCommunityIcons name="image-outline" size={17} color={theme.accentSoft} />
              <Text style={[styles.btnText, { color: theme.textSecondary }]}>من المعرض</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.btn, { backgroundColor: theme.cardAlt, borderColor: theme.border }]} onPress={takePhoto} disabled={busy}>
              <MaterialCommunityIcons name="camera-outline" size={17} color={theme.accentSoft} />
              <Text style={[styles.btnText, { color: theme.textSecondary }]}>كاميرا</Text>
            </TouchableOpacity>
          </View>

          {!!current && (
            <TouchableOpacity style={styles.resetBtn} onPress={reset} disabled={busy}>
              <MaterialCommunityIcons name="restore" size={16} color={theme.textMuted} />
              <Text style={[styles.btnText, { color: theme.textMuted }]}>رجوع للتلقائي</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', alignItems: 'center', justifyContent: 'center', padding: 24 },
  box: { width: '100%', maxWidth: 380, borderRadius: 22, borderWidth: 1, padding: 18 },
  headerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  title: { fontSize: 16, fontWeight: '800', flexShrink: 1 },
  label: { fontSize: 12, fontWeight: '700', textAlign: 'right', marginTop: 8, marginBottom: 8 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, justifyContent: 'flex-end' },
  swatchWrap: { width: '23%', borderRadius: 14, borderWidth: 2, padding: 1.5 },
  swatch: { height: 52, borderRadius: 12, alignItems: 'center', justifyContent: 'flex-end', paddingBottom: 4 },
  swatchText: { color: '#fff', fontSize: 10.5, fontWeight: '800', textShadowColor: 'rgba(0,0,0,0.5)', textShadowRadius: 3 },
  actions: { flexDirection: 'row', gap: 10 },
  btn: { flex: 1, flexDirection: 'row', gap: 6, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderRadius: 12, paddingVertical: 11 },
  btnText: { fontSize: 13, fontWeight: '700' },
  resetBtn: { flexDirection: 'row', gap: 6, alignItems: 'center', justifyContent: 'center', marginTop: 14, paddingVertical: 8 },
});
