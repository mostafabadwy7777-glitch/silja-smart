// بلاطات الغرف في الرئيسية: لكل غرفة خلفية (صورة أو تدرج لون) خلف الكارت، وبتتوهج بلون "شغال" لما فيها مفتاح شغال.
// ضغطة مطوّلة (أو زرار الصورة الصغير) = تغيير خلفية الغرفة.
// دوسة على البلاطة = فتح شاشة الأجهزة، وزرار الباور = إطفاء الغرفة (بتأكيد). بتختفي لو مفيش غرف متحددة.
import React, { useEffect, useRef, useState } from 'react';
import { View, Text, Image, StyleSheet, Animated, Easing } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import TouchableOpacity from './AnimatedTouchable';
import { useTheme, useMotionActive } from '../ThemeContext';
import { withAlpha } from '../colorUtils';
import { getDeviceIcon } from '../deviceIcons';
import { showAlert } from './PremiumAlert';
import { showToast } from './Toast';
import { pressFeedback, sentFeedback, errorFeedback } from '../feedback';
import { loadRoomBgs, saveRoomBgs } from '../storage';
import { gradientById, autoGradientFor } from './roomBackgrounds';
import RoomBackgroundModal from './RoomBackgroundModal';
import FadeInView from './FadeInView';

function RoomTile({ theme, name, total, on, bg, onPress, onOff, onEditBg }) {
  const motion = useMotionActive();
  const lit = on > 0;
  const color = theme.on || theme.accent;
  const glow = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!lit || !motion) { glow.stopAnimation(); glow.setValue(lit ? 0.5 : 0); return undefined; }
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(glow, { toValue: 1, duration: 1700, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(glow, { toValue: 0, duration: 1700, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [lit, motion, glow]);

  // نعومة التحوّل بين "مطفية" و"فيها شغال": الطبقة المعتمة بتخف والغلاف الملوّن بيظهر بدل القفزة المفاجئة
  const litAnim = useRef(new Animated.Value(lit ? 1 : 0)).current;
  useEffect(() => {
    Animated.timing(litAnim, { toValue: lit ? 1 : 0, duration: 450, easing: Easing.out(Easing.cubic), useNativeDriver: true }).start();
  }, [lit, litAnim]);

  const grad = bg?.type === 'gradient' ? (gradientById(bg.id) || autoGradientFor(name)) : autoGradientFor(name);
  const hasImage = bg?.type === 'image' && !!bg.uri;
  const textColor = '#FFFFFF';
  const shadow = { textShadowColor: 'rgba(0,0,0,0.55)', textShadowRadius: 4, textShadowOffset: { width: 0, height: 1 } };

  return (
    <TouchableOpacity
      onPress={onPress}
      onLongPress={onEditBg}
      activeOpacity={0.88}
      style={{
        width: '100%', borderRadius: 22, overflow: 'hidden', borderWidth: 1.4, borderColor: lit ? withAlpha(color, 0.85) : theme.border,
        shadowColor: color, shadowOpacity: lit ? 0.55 : 0, shadowRadius: 14, shadowOffset: { width: 0, height: 0 }, elevation: lit ? 6 : 0,
      }}
    >
      {/* الخلفية: صورة الغرفة أو تدرج لوني */}
      {hasImage
        ? <Image source={{ uri: bg.uri }} resizeMode="cover" style={StyleSheet.absoluteFill} />
        : <LinearGradient colors={grad.colors} start={{ x: 0.1, y: 0 }} end={{ x: 0.9, y: 1 }} style={StyleSheet.absoluteFill} />}
      {/* تعتيم للقراءة: بيخف لما فيها جهاز شغال فالخلفية "تنوّر" */}
      <Animated.View pointerEvents="none" style={[StyleSheet.absoluteFill, { backgroundColor: theme.isLight ? 'rgba(20,24,30,0.42)' : 'rgba(6,8,12,0.58)', opacity: litAnim.interpolate({ inputRange: [0, 1], outputRange: [1, 0.45] }) }]} />
      <LinearGradient pointerEvents="none" colors={['rgba(0,0,0,0)', 'rgba(0,0,0,0.55)']} start={{ x: 0.5, y: 0.35 }} end={{ x: 0.5, y: 1 }} style={StyleSheet.absoluteFill} />
      {/* توهج لون "التشغيل" فوق الخلفية بينبض لما فيها جهاز شغال */}
      <Animated.View pointerEvents="none" style={[StyleSheet.absoluteFill, { backgroundColor: color, opacity: Animated.multiply(litAnim, glow.interpolate({ inputRange: [0, 1], outputRange: [0.10, 0.30] })) }]} />
      <LinearGradient pointerEvents="none" colors={[`rgba(255,255,255,${lit ? 0.28 : 0.14})`, 'rgba(255,255,255,0)']} start={{ x: 0, y: 0 }} end={{ x: 0.6, y: 0.7 }} style={StyleSheet.absoluteFill} />

      <View style={{ padding: 12, minHeight: 112, justifyContent: 'space-between' }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <TouchableOpacity
            onPress={onOff}
            disabled={!lit}
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            style={{ width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: lit ? withAlpha(color, 0.9) : 'rgba(255,255,255,0.3)', backgroundColor: lit ? withAlpha(color, 0.3) : 'rgba(0,0,0,0.25)', opacity: lit ? 1 : 0.6 }}
          >
            <MaterialCommunityIcons name="power" size={16} color={lit ? '#FFFFFF' : 'rgba(255,255,255,0.75)'} />
          </TouchableOpacity>
          <View style={{ width: 40, height: 40, alignItems: 'center', justifyContent: 'center' }}>
            {lit && <Animated.View pointerEvents="none" style={{ position: 'absolute', width: 40, height: 40, borderRadius: 20, backgroundColor: color, opacity: glow.interpolate({ inputRange: [0, 1], outputRange: [0.25, 0.55] }), transform: [{ scale: glow.interpolate({ inputRange: [0, 1], outputRange: [0.9, 1.25] }) }] }} />}
            <MaterialCommunityIcons name={lit ? 'home-lightbulb' : 'home-outline'} size={24} color={textColor} />
          </View>
        </View>
        <View style={{ flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', marginTop: 8 }}>
          <TouchableOpacity
            onPress={onEditBg}
            hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            style={{ width: 26, height: 26, borderRadius: 13, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(0,0,0,0.3)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.25)' }}
          >
            <MaterialCommunityIcons name="image-edit-outline" size={14} color="rgba(255,255,255,0.9)" />
          </TouchableOpacity>
          <View style={{ flex: 1, marginLeft: 8 }}>
            <Text numberOfLines={1} style={[{ color: textColor, fontSize: 14.5, fontWeight: '800', textAlign: 'right' }, shadow]}>{name}</Text>
            <Text style={[{ color: lit ? '#FFFFFF' : 'rgba(255,255,255,0.78)', fontSize: 11.5, fontWeight: '700', textAlign: 'right', marginTop: 2 }, shadow]}>{lit ? `${on} شغال من ${total}` : `${total} جهاز • مطفية`}</Text>
          </View>
        </View>
      </View>
    </TouchableOpacity>
  );
}

export default function HomeRooms({ boards = [], switchStates = {}, client, connected, onOpenDevices }) {
  const { theme } = useTheme();
  const [roomBgs, setRoomBgs] = useState({});
  const [editing, setEditing] = useState(null); // اسم الغرفة اللي بتتغيّر خلفيتها
  useEffect(() => { loadRoomBgs().then(setRoomBgs).catch(() => {}); }, []);
  const changeBg = (room, value) => {
    setRoomBgs((prev) => {
      const next = { ...prev };
      if (value) next[room] = value; else delete next[room];
      saveRoomBgs(next).catch(() => {});
      return next;
    });
  };
  const devices = boards.filter((b) => b.type !== 'irrigation').flatMap((b) => b.devices || []);
  const names = Array.from(new Set(devices.map((d) => String(d.room || '').trim()).filter(Boolean)));
  if (!names.length) return null;

  const rooms = names.map((name) => {
    const items = devices.filter((d) => String(d.room || '').trim() === name);
    const on = items.filter((d) => switchStates[d.statusTopic || d.controlTopic] === true).length;
    return { name, items, on };
  });

  const turnOff = (room) => {
    const targets = room.items.filter((d) => d.controlTopic && !getDeviceIcon(d.icon)?.isEmergency && d.icon !== 'bell');
    if (!targets.length) return;
    if (!client || !connected) { showAlert('الاتصال غير متاح', 'لا يمكن إطفاء الغرفة الآن. اتأكد إن التطبيق متصل بالسيرفر وحاول تاني.'); return; }
    showAlert(`إطفاء ${room.name}`, `هيتم إيقاف ${targets.length} مفتاح في الغرفة دي. متأكد؟`, [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'إطفاء الغرفة',
        style: 'destructive',
        onPress: () => {
          pressFeedback();
          let pending = targets.length; let failed = 0;
          const done = () => {
            pending -= 1;
            if (pending > 0) return;
            if (failed > 0) { errorFeedback(); showAlert('إطفاء الغرفة', `فشل إرسال ${failed} من ${targets.length} أمر. راجع الاتصال وحاول تاني.`); }
            else { sentFeedback(); showToast(`تم إرسال أمر إطفاء ${room.name}`); }
          };
          targets.forEach((d) => {
            try {
              client.publish(d.controlTopic, d.controlType === 'updown' ? 'STOP' : 'OFF', { qos: 1 }, (error) => { if (error) failed += 1; done(); });
            } catch (_) { failed += 1; done(); }
          });
        },
      },
    ]);
  };

  return (
    <View style={{ marginBottom: 14 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
        <Text style={{ color: theme.textMuted, fontSize: 12, fontWeight: '700' }}>{rooms.length}</Text>
        <Text style={{ color: theme.textPrimary, fontSize: 16, fontWeight: '800' }}>الغرف</Text>
      </View>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', rowGap: 10 }}>
        {rooms.map((r, i) => (
          <FadeInView key={r.name} delay={120 + Math.min(i, 8) * 80} style={{ width: '48%' }}>
          <RoomTile key={r.name} theme={theme} name={r.name} total={r.items.length} on={r.on} bg={roomBgs[r.name]} onPress={onOpenDevices} onOff={() => turnOff(r)} onEditBg={() => setEditing(r.name)} />
          </FadeInView>
        ))}
      </View>
      <RoomBackgroundModal
        visible={!!editing}
        roomName={editing || ''}
        current={editing ? roomBgs[editing] : null}
        onClose={() => setEditing(null)}
        onChange={(v) => editing && changeBg(editing, v)}
      />
    </View>
  );
}
