// حلقات ضوء بتتمدد وتتلاشى بهدوء (موجة) — بتستخدم في دايرة الري، وشاشة التحميل،
// والحالات الفاضية. الأنيميشن كله native فمش بيتقل على الأداء.
import React, { useEffect, useRef } from 'react';
import { View, Animated, Easing } from 'react-native';
import { useMotionActive } from '../ThemeContext';

export default function PulseRings({ active: activeProp = true, color = '#D6B36A', size = 120, rings = 3, duration = 2800, maxScale = 1.7, style }) {
  const motion = useMotionActive();
  const active = activeProp && motion;
  const vals = useRef(Array.from({ length: rings }, () => new Animated.Value(0))).current;

  useEffect(() => {
    if (!active) {
      vals.forEach((v) => { v.stopAnimation(); v.setValue(0); });
      return undefined;
    }
    const loops = [];
    const timers = vals.map((v, i) => setTimeout(() => {
      const loop = Animated.loop(
        Animated.sequence([
          Animated.timing(v, { toValue: 1, duration, easing: Easing.out(Easing.quad), useNativeDriver: true }),
          Animated.timing(v, { toValue: 0, duration: 0, useNativeDriver: true }),
        ])
      );
      loops.push(loop);
      loop.start();
    }, (duration / rings) * i));
    return () => { timers.forEach(clearTimeout); loops.forEach((l) => l.stop()); };
  }, [active, duration, rings, vals]);

  return (
    <View pointerEvents="none" style={[{ position: 'absolute', width: size, height: size, alignItems: 'center', justifyContent: 'center' }, style]}>
      {vals.map((v, i) => (
        <Animated.View
          key={i}
          style={{
            position: 'absolute', width: size, height: size, borderRadius: size / 2, borderWidth: 1.5, borderColor: color,
            opacity: v.interpolate({ inputRange: [0, 0.15, 1], outputRange: [0, 0.5, 0] }),
            transform: [{ scale: v.interpolate({ inputRange: [0, 1], outputRange: [1, maxScale] }) }],
          }}
        />
      ))}
    </View>
  );
}
