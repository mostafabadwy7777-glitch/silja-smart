import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated, Easing } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { withAlpha } from '../colorUtils';
import { useMotionActive } from '../ThemeContext';

/** A compact, theme-aware glass status banner. `connected` means the MQTT client is
 * connected to the broker; it does not claim that every board is online. */
export default function ConnectionStatusBanner({ theme, connected, title, detail, style }) {
  const motion = useMotionActive();
  const color = (connected ? theme.on : theme.off) || theme.accent;
  const dark = !theme.isLight;
  const defaultTitle = connected ? 'متصل بالسيرفر' : 'غير متصل بالسيرفر';
  const defaultDetail = connected
    ? 'الأوامر متاحة؛ حالة كل بورد تُعرض بشكل منفصل.'
    : 'أوامر التحكم متوقفة حتى يرجع الاتصال. الحالات المعروضة قد تكون قديمة.';

  // نقطة الحالة بتنبض لما متصل (وبتقف مع "حركة أقل")
  const pulse = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!connected || !motion) { pulse.stopAnimation(); pulse.setValue(0); return undefined; }
    const loop = Animated.loop(Animated.timing(pulse, { toValue: 1, duration: 1800, easing: Easing.out(Easing.quad), useNativeDriver: true }));
    loop.start();
    return () => loop.stop();
  }, [connected, motion, pulse]);

  return (
    <View accessibilityRole="summary" style={[styles.wrap, { backgroundColor: withAlpha(theme.card, dark ? 0.55 : 0.75), borderColor: withAlpha(color, 0.5) }, style]}>
      <LinearGradient pointerEvents="none" colors={[withAlpha(color, 0.2), withAlpha(color, 0.04)]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
      <LinearGradient pointerEvents="none" colors={[`rgba(255,255,255,${dark ? 0.16 : 0.45})`, 'rgba(255,255,255,0)']} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 0.7 }} style={StyleSheet.absoluteFill} />
      <View style={[styles.iconWrap, { backgroundColor: withAlpha(color, 0.18), borderColor: withAlpha(color, 0.55) }]}>
        <MaterialCommunityIcons name={connected ? 'lan-connect' : 'lan-disconnect'} size={16} color={color} />
      </View>
      <View style={styles.copy}>
        <Text style={[styles.title, { color }]}>{title || defaultTitle}</Text>
        {!!(detail || defaultDetail) && <Text numberOfLines={2} style={[styles.detail, { color: theme.textSecondary }]}>{detail || defaultDetail}</Text>}
      </View>
      <View style={styles.dotWrap}>
        {connected && <Animated.View pointerEvents="none" style={[styles.dotHalo, { backgroundColor: color, opacity: pulse.interpolate({ inputRange: [0, 1], outputRange: [0.55, 0] }), transform: [{ scale: pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 2.6] }) }] }]} />}
        <View style={[styles.dot, { backgroundColor: color }]} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flexDirection: 'row', alignItems: 'center', gap: 10, borderWidth: 1.2, borderRadius: 22, overflow: 'hidden', paddingHorizontal: 12, paddingVertical: 8, marginBottom: 14 },
  iconWrap: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center', borderWidth: 1 },
  copy: { flex: 1 },
  title: { fontSize: 12.5, fontWeight: '900', textAlign: 'right' },
  detail: { fontSize: 10.5, lineHeight: 15, textAlign: 'right', marginTop: 1 },
  dotWrap: { width: 14, height: 14, alignItems: 'center', justifyContent: 'center' },
  dotHalo: { position: 'absolute', width: 8, height: 8, borderRadius: 4 },
  dot: { width: 8, height: 8, borderRadius: 4 },
});
