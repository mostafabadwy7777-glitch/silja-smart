// لازم يتحط أول سطر في الملف - قبل أي استيراد تاني، خصوصًا قبل "mqtt" -
// عشان يجهز Buffer/process قبل ما مكتبة mqtt تحاول تستخدمهم (شوف الشرح
// بالتفصيل جوه polyfills.js). من غيره التطبيق بيعمل crash فوري.
import './polyfills';

import React, { useEffect, useRef, useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, TextInput, StyleSheet, StatusBar, BackHandler, ActivityIndicator, AppState } from 'react-native';
import TouchableOpacity from './components/AnimatedTouchable';
import { useFonts, ElMessiri_400Regular, ElMessiri_600SemiBold, ElMessiri_700Bold } from '@expo-google-fonts/el-messiri';
import { Cairo_400Regular, Cairo_500Medium, Cairo_600SemiBold, Cairo_700Bold } from '@expo-google-fonts/cairo';
import mqtt from 'mqtt';
import * as LocalAuthentication from 'expo-local-authentication';
import {
  DEFAULT_SETTINGS,
  loadSettings,
  saveSettings,
  loadBoards,
  saveBoards,
  loadPairingKey,
  savePairingKey,
  loadScenes,
  saveScenes,
  loadPushEnabled,
  savePushEnabled,
  loadBiometricEnabled,
  saveBiometricEnabled,
  hasPin,
  loadAutoLockSec,
  loadOrCreateInstallId,
  newId,
} from './storage';
import { ThemeProvider, useTheme } from './ThemeContext';
import { registerForPushNotificationsAsync, unregisterPushNotifications } from './notifications';
import { patchClientSubscriptions } from './mqttSubs';
import BoardsListScreen from './screens/BoardsListScreen';
import DevicesScreen from './screens/DevicesScreen';
import SwitchesScreen from './screens/SwitchesScreen';
import IrrigationScreen from './screens/IrrigationScreen';
import ThemeScreen from './screens/ThemeScreen';
import SwitchDisplaySettingsScreen from './screens/SwitchDisplaySettingsScreen';
import BottomNavSettingsScreen from './screens/BottomNavSettingsScreen';
import ScenesScreen from './screens/ScenesScreen';
import HistoryScreen from './screens/HistoryScreen';
import ActivityScreen from './screens/ActivityScreen';
import AlertsScreen from './screens/AlertsScreen';
import TimersScreen from './screens/TimersScreen';
import { useTimers } from './timers';
import BoardHealthScreen from './screens/BoardHealthScreen';
import { useBoardHealth } from './boardHealth';
import { usePowerOutages } from './powerOutages';
import { useBoardInfo } from './boardInfo';
import PowerReportScreen from './screens/PowerReportScreen';
import PresenceSimScreen from './screens/PresenceSimScreen';
import { usePresenceConfig } from './presenceSim';
import { DEFAULT_ALERT_SETTINGS, loadAlertSettings, saveAlertSettings, loadAlertLog, saveAlertLog, useAlertsMonitor } from './alerts';
import BackupScreen from './screens/BackupScreen';
import LockScreen from './screens/LockScreen';
import ScreenHeader from './components/ScreenHeader';
import SettingsHomeScreen from './screens/SettingsHomeScreen';
import ManualBoardScreen from './screens/ManualBoardScreen';
import BottomNavBar from './components/BottomNavBar';
import SplashLoading from './components/SplashLoading';
import ScreenTransition from './components/ScreenTransition';
import SideMenu from './components/SideMenu';
import AlertHost, { showAlert } from './components/PremiumAlert';
import ToastHost from './components/Toast';
import { useSceneScheduler } from './sceneScheduler';
import { initLastKnown, attachLastKnown } from './lastKnown';
import { DEFAULT_CITY, loadWeatherCity, subscribeWeatherCity } from './weather';
import { initRuntimeTracker, setRuntimeOnline, attachRuntimeTracker, runtimeTopicsFor, noteAppCommand } from './runtimeTracker';

export default function App() {
  // بنحمّل خطوط العناوين (El Messiri) والنصوص (Cairo) قبل ما نعرض أي حاجة —
  // عشان النصوص متطلعش أول ثانية بخط النظام الافتراضي وبعدين "تقفز" لخط
  // التطبيق، اللي بيدي إحساس رخيص. اللون هنا ثابت (مش من الثيم) لأن الثيم
  // نفسه لسه مش متاح قبل ما ThemeProvider يتحمّل.
  const [fontsLoaded] = useFonts({
    ElMessiri_400Regular,
    ElMessiri_600SemiBold,
    ElMessiri_700Bold,
    Cairo_400Regular,
    Cairo_500Medium,
    Cairo_600SemiBold,
    Cairo_700Bold,
  });

  // شاشة التشغيل (الحلقة المضيئة) بتتركّب مرة واحدة فوق كل حاجة وبتفضل لحد ما
  // التطبيق يجهز، وبعدين بتتحوّل بحركة ناعمة للشاشة الرئيسية (شوف SplashLoading).
  const [bootReady, setBootReady] = useState(false); // التطبيق حمّل بياناته
  const [reveal, setReveal] = useState(false); // الحلقة بدأت تختفي → اعرض الرئيسية
  const [splashGone, setSplashGone] = useState(false);
  const onBootReady = React.useCallback(() => setBootReady(true), []);
  const onSplashExitStart = React.useCallback(() => setReveal(true), []);
  const onSplashFinish = React.useCallback(() => setSplashGone(true), []);

  return (
    <View style={{ flex: 1, backgroundColor: '#0A0B0D' }}>
      {fontsLoaded && (
        <ThemeProvider>
          <AppErrorBoundary>
            <AppInner show={reveal} onReady={onBootReady} />
          </AppErrorBoundary>
          <ToastHost />
          <AlertHost />
        </ThemeProvider>
      )}
      {!splashGone && (
        <SplashLoading
          fontsReady={fontsLoaded}
          ready={fontsLoaded && bootReady}
          onExitStart={onSplashExitStart}
          onFinish={onSplashFinish}
        />
      )}
    </View>
  );
}

// ---------- شبكة أمان: Error Boundary عام حوالين التطبيق كله ----------
// لو حصل أي كراش غير متوقع في أي شاشة (بدل ما التطبيق يقفل من غير رجعة
// ويفضل يكرر نفس الكراش كل ما يتفتح لأن الإعدادات اللي سببته لسه محفوظة)،
// الشاشة دي بتظهر بدل الشاشة البيضاء/السودة، وبتدي المستخدم خيار "مسح بيانات
// الاتصال" عشان يرجع يفتح التطبيق بشكل طبيعي ويصلح الإعدادات من الأول.
class AppErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }

  static getDerivedStateFromError(error) {
    return { error };
  }

  componentDidCatch(error, info) {
    console.log('App crashed:', error?.message, info?.componentStack);
  }

  handleResetConnection = async () => {
    try {
      await saveSettings(DEFAULT_SETTINGS);
      await savePairingKey('');
    } catch (e) {
      // تجاهل — حتى لو فشل المسح، زرار "حاول تاني" تحت لسه هيسمح بمحاولة تانية
    }
    this.setState({ error: null });
  };

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: '#050b1a', padding: 24, justifyContent: 'center' }}>
        <Text style={{ color: '#fff', fontSize: 18, fontWeight: '700', textAlign: 'center', marginBottom: 10 }}>
          حصلت مشكلة غير متوقعة
        </Text>
        <Text style={{ color: '#8fb0d9', fontSize: 13, textAlign: 'center', marginBottom: 20 }}>
          {this.state.error?.message || 'خطأ غير معروف'}
        </Text>
        <TouchableOpacity
          onPress={() => this.setState({ error: null })}
          style={{ backgroundColor: '#2f7fd6', borderRadius: 12, paddingVertical: 14, alignItems: 'center', marginBottom: 10 }}
        >
          <Text style={{ color: '#fff', fontWeight: '600' }}>حاول تاني</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={this.handleResetConnection}
          style={{ borderColor: '#c0392b', borderWidth: 1, borderRadius: 12, paddingVertical: 14, alignItems: 'center' }}
        >
          <Text style={{ color: '#ff8a8a', fontWeight: '600' }}>مسح بيانات الاتصال بالسيرفر وإعادة المحاولة</Text>
        </TouchableOpacity>
      </SafeAreaView>
    );
  }
}

function AppInner({ show = true, onReady }) {
  const { theme, isLight, toggleLightDark } = useTheme();
  // حالة الصفحة الجانبية (الدرج) — بقت مركزية هنا عشان زرار "الإعدادات" في
  // الشريط السفلي يقدر يفتحها من أي شاشة فيها الشريط، مش من شاشة البوردات
  // بس زي الأول.
  const [menuOpen, setMenuOpen] = useState(false);
  // زر الترس يفتح صفحة الإعدادات الرئيسية مباشرة بدل فتح درج فوق الشاشة
  // حتى لا يظهر للمستخدم كأن الصفحة اتكررت أو اتراكبت.
  const openMenu = () => {
    setMenuOpen(false);
    setActiveBoard(null);
    goToTab('settingsHome');
  };
  const closeMenu = () => setMenuOpen(false);
  const [settings, setSettings] = useState(DEFAULT_SETTINGS);
  const [pairingKey, setPairingKey] = useState('');
  const [boards, setBoards] = useState([]);
  const [scenes, setScenes] = useState([]);
  const [pushEnabled, setPushEnabled] = useState(false);
  // التنبيهات: إعدادات + سجل محلي (آخر 200). alertsLogRef نسخة موازية عشان
  // التنبيهات المتتالية السريعة متضيعش بعض.
  const [alertSettings, setAlertSettings] = useState(DEFAULT_ALERT_SETTINGS);
  const [alertsLog, setAlertsLog] = useState([]);
  const alertsLogRef = useRef([]);
  const [biometricEnabled, setBiometricEnabled] = useState(false);
  const [pinEnabled, setPinEnabled] = useState(false);
  const [unlocked, setUnlocked] = useState(false);

  // قفل تلقائي: لو التطبيق قعد في الخلفية أكتر من المدة المختارة (الإعدادات > القفل التلقائي)
  // بنرجّع شاشة القفل. بنقرا الـ PIN من التخزين وقت الرجوع عشان لو اتفعّل أثناء الجلسة.
  const backgroundedAtRef = useRef(null);
  const biometricRef = useRef(false);
  biometricRef.current = biometricEnabled;
  useEffect(() => {
    const sub = AppState.addEventListener('change', async (state) => {
      if (state === 'background') {
        backgroundedAtRef.current = Date.now();
      } else if (state === 'active' && backgroundedAtRef.current) {
        const away = Date.now() - backgroundedAtRef.current;
        backgroundedAtRef.current = null;
        try {
          const [sec, pinNow] = await Promise.all([loadAutoLockSec(), hasPin()]);
          setPinEnabled(pinNow);
          if ((biometricRef.current || pinNow) && sec >= 0 && away >= sec * 1000) setUnlocked(false);
        } catch (_) {}
      }
    });
    return () => sub.remove();
  }, []);
  const [ready, setReady] = useState(false);
  useEffect(() => { if (ready && onReady) onReady(); }, [ready, onReady]);
  // معرّف اتصال ثابت لكل تثبيت للتطبيق (بيتحفظ محليًا مرة واحدة) — بنستخدمه
  // كـ clientId في MQTT بدل ما نولّد واحد عشوائي كل مرة نفتح التطبيق. ده
  // بيخلي البروكر يتعرف على نفس "الجهاز" باستمرار، وبيمنع إن جلسة قديمة
  // (من فتحة سابقة) تفضل شغالة بتوقيت زيادة عند البروكر أثناء ما إحنا
  // بنحاول نتصل تاني بمعرّف جديد كل مرة.
  const [mqttClientId, setMqttClientId] = useState(null);
  useEffect(() => {
    let mounted = true;
    loadOrCreateInstallId()
      .then((id) => { if (mounted) setMqttClientId('silja-' + id); })
      .catch((error) => {
        console.warn('[Silja Smart] تعذر إنشاء معرّف التثبيت:', error?.message);
        // معرّف مؤقت يسمح باستمرار التطبيق إذا تعذّر التخزين؛ لا يُحفظ ولا
        // يُستخدم إلا لهذه الجلسة.
        if (mounted) setMqttClientId('silja-session-' + Date.now().toString(36));
      });
    return () => { mounted = false; };
  }, []);
  // مكدس الشاشات (Navigation Stack) — بدل ما نحتفظ باسم شاشة واحدة بس، بنحتفظ
  // بتاريخ كامل لكل الشاشات اللي دخلناها بالترتيب. "الشاشة الحالية" هي آخر
  // عنصر في المكدس. ده اللي بيخلينا نقدر نرجّع زرار الموبايل الفيزيقي (أو أي
  // زرار "رجوع" في التطبيق) للصفحة اللي قبلها بالظبط، مش نرمي المستخدم برّه
  // التطبيق أو نرجّعه دايمًا لشاشة البوردات.
  const [screenStack, setScreenStack] = useState(['boards']);
  const screen = screenStack[screenStack.length - 1]; // settings | settingsHome | boards | board | theme | scenes | history | backup | alerts | timers | boardHealth | presence
  // اتجاه التنقل (فتح شاشة فوق / رجوع / تبديل تبويب) — بيحدد شكل أنيميشن الدخول في ScreenTransition.
  const prevStackRef = useRef(screenStack);
  const navMode = screenStack.length > prevStackRef.current.length ? 'push' : screenStack.length < prevStackRef.current.length ? 'pop' : 'tab';
  useEffect(() => { prevStackRef.current = screenStack; }, [screenStack]);
  const [activeBoard, setActiveBoard] = useState(null);
  const [connected, setConnected] = useState(false);
  const [mqttError, setMqttError] = useState('');
  // بيتحول لـ true كل ما المستخدم يدوس على زرار "+" في الشريط السفلي، عشان
  // شاشة البوردات تفتح فورم "إضافة بورد جديد" أوتوماتيك حتى لو مكناش أصلاً
  // واقفين على شاشة البوردات وقت الدوسة. شاشة البوردات هي اللي بترجّعه false
  // تاني أول ما تستهلكه (شوف onAddBoardSignalHandled) — عشان لو الشاشة
  // اتقفلت وفتحت تاني بعدين (تنقل عادي، مش ضغطة "+" جديدة) الفورم متفتحش
  // لوحده تاني من غير سبب.
  const [addBoardSignal, setAddBoardSignal] = useState(false);

  const clientRef = useRef(null);

  // بيضيف شاشة جديدة فوق المكدس (تنقل "للقدام" — زي فتح صفحة تفصيلية من شاشة
  // تانية). لو نفس الشاشة أصلاً فوق المكدس، مش بنكررها.
  const pushScreen = (name) => {
    setScreenStack((prev) => (prev[prev.length - 1] === name ? prev : [...prev, name]));
  };

  // بيرجع خطوة واحدة للخلف في المكدس (زرار "رجوع" أو زرار الموبايل
  // الفيزيقي). لو إحنا أصلاً واقفين على أول شاشة في المكدس، ملوش تأثير هنا —
  // القرار وقتها (تسكير التطبيق ولا لأ) بياخده الـ BackHandler تحت.
  const popScreen = () => {
    setScreenStack((prev) => (prev.length > 1 ? prev.slice(0, -1) : prev));
  };

  // بيمسح المكدس كله ويبدأ من شاشة واحدة جديدة — ده اللي بنستخدمه لما ندوس
  // على تبويب في الشريط السفلي (زي التبديل بين تابات: مش تراكم فوق بعض).
  const goToTab = (name) => {
    setScreenStack([name]);
  };

  // زرار الموبايل الفيزيقي للرجوع (Android) — لو فيه أكتر من شاشة في
  // المكدس، بنرجع خطوة للخلف بدل ما نسيب النظام يقفل التطبيق. لو إحنا أصلاً
  // على أول شاشة (يعني على تبويب رئيسي)، بنسيب السلوك الافتراضي (تصغير/قفل
  // التطبيق) يشتغل زي أي تطبيق تاني.
  useEffect(() => {
    const onBackPress = () => {
      if (screenStack.length > 1) {
        popScreen();
        return true;
      }
      return false;
    };
    const sub = BackHandler.addEventListener('hardwareBackPress', onBackPress);
    return () => sub.remove();
  }, [screenStack]);

  // ---------- تحميل البيانات المحفوظة ----------
  // بيرجع true لو فيه إعدادات سيرفر + مفتاح ربط محفوظين (يعني التطبيق "مظبوط").
  const loadAllFromStorage = async () => {
    const savedSettings = await loadSettings();
    const savedBoards = await loadBoards();
    const savedPairingKey = await loadPairingKey();
    const savedScenes = await loadScenes();
    const savedPushEnabled = await loadPushEnabled();
    const savedBiometricEnabled = await loadBiometricEnabled();
    const savedPinEnabled = await hasPin();
    const savedAlertSettings = await loadAlertSettings();
    const savedAlertLog = await loadAlertLog();
    const configured = !!(savedSettings && savedPairingKey);
    if (savedSettings) setSettings(savedSettings);
    setPairingKey(savedPairingKey);
    setBoards(savedBoards);
    setScenes(savedScenes);
    setPushEnabled(savedPushEnabled);
    setBiometricEnabled(savedBiometricEnabled);
    setPinEnabled(savedPinEnabled);
    setAlertSettings(savedAlertSettings);
    alertsLogRef.current = savedAlertLog;
    setAlertsLog(savedAlertLog);
    return configured;
  };

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        await loadAllFromStorage();
      } catch (error) {
        console.warn('[Silja Smart] تعذر تحميل بعض الإعدادات المحفوظة:', error?.message);
        showAlert('تنبيه التخزين', 'تعذر تحميل بعض البيانات المحفوظة. جرّب فتح النسخة الاحتياطية أو إعادة تشغيل التطبيق.');
      } finally {
        // لا نترك التطبيق على شاشة فارغة إلى الأبد بسبب فشل قراءة التخزين.
        if (mounted) setReady(true);
      }
    })();
    return () => { mounted = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // التطبيق دايمًا بيفتح على صفحة البوردات (الشاشة الرئيسية)، سواء السيرفر
  // متظبط أو لسه لأ. لو لسه مفيش سيرفر محفوظ، الصفحة نفسها بتوضح كده وبتوجّه
  // المستخدم لأيقونة الترس (⚙️) فوق عشان يدخل الإعدادات.
  const isConfigured = !!(settings.host && pairingKey);

  // بعد استيراد نسخة احتياطية، نعيد تحميل كل حاجة من التخزين المحلي على طول
  // (بدل ما نستنى إعادة تشغيل التطبيق) ونرجع لشاشة البوردات أو الإعدادات
  // حسب لو فيه سيرفر ومفتاح ربط اتحفظوا في النسخة اللي اتستوردت.
  const handleBackupImported = async () => {
    await loadAllFromStorage();
    setActiveBoard(null);
    goToTab('boards');
  };

  // ---------- اتصال MQTT واحد مشترك لكل البوردات ----------
  // ملحوظة مهمة: بنحسب "shouldConnect" لوحده بدل ما نحط "screen" مباشرة في
  // قايمة الاعتماديات تحت. لو حطينا "screen" هناك، كان الاتصال بيتقفل
  // بالكامل (client.end) ويتفتح من جديد (اتصال TCP/MQTT كامل من الصفر) في
  // كل مرة تتنقل بين أي شاشتين (فتح بورد، رجوع، فتح المشاهد، إلخ) — مش بس
  // لما تدخل/تخرج من شاشة الإعدادات. ده كان بيخلي الاتصال يحس إنه "بطيء"
  // طول الوقت مش بس أول ما تفتح التطبيق. دلوقتي الاتصال بيفضل شغال طول ما
  // إحنا مش واقفين على شاشة الإعدادات، وبيتقفل/يتفتح بس لما نضبط سيرفر
  // جديد فعلاً أو ندخل/نخرج من شاشة الإعدادات.
  const shouldConnect = ready && screen !== 'settings' && !!settings.host && !!mqttClientId;

  useEffect(() => {
    if (!shouldConnect) return undefined;

    let client;
    try {
      // تشخيص مؤقت: لو mqtt.connect نفسها مش دالة (مشكلة استيراد/بناء
      // المكتبة) بنكتشف ده فورًا برسالة واضحة بدل TypeError غامضة.
      if (typeof mqtt.connect !== 'function') {
        throw new Error(
          `mqtt.connect مش موجودة كدالة (typeof = ${typeof mqtt.connect}). ` +
          `مشكلة في استيراد مكتبة mqtt نفسها، مش في بيانات الاتصال.`
        );
      }
      const url = `${settings.protocol}://${settings.host}:${settings.port}${settings.path}`;
      client = mqtt.connect(url, {
        clientId: mqttClientId,
        username: settings.username || undefined,
        password: settings.password || undefined,
        reconnectPeriod: 3000,
        connectTimeout: 8000,
      });
    } catch (err) {
      // لو mqtt.connect() نفسها رمت استثناء (زي رابط سيرفر مكتوب غلط) كانت
      // بتقفل التطبيق فورًا من غير أي رسالة، وبما إن الإعدادات بتفضل محفوظة
      // كان بيرجع يكرر نفس الكراش كل ما التطبيق يتفتح. دلوقتي بنمسكها هنا
      // بدل ما نسيبها توقع التطبيق، ونوري المستخدم رسالة يقدر يرجع بيها
      // لشاشة الإعدادات ويصلح البيانات.
      // ملحوظة تشخيصية مؤقتة: بنطبع الـ stack كمان في الـ console (مش في
      // الـ Alert عشان ميبقاش طويل قوي على الشاشة) عشان نعرف بالظبط أي
      // سطر/دالة جوه mqtt.js هي اللي وقعت.
      console.log('MQTT connect() threw:', err?.message);
      console.log('MQTT connect() stack:', err?.stack);
      setConnected(false);
      showAlert(
        'تعذر الاتصال بالسيرفر',
        `فيه مشكلة في بيانات الاتصال (تأكد من الـ Host والـ Port والـ Protocol):\n${err?.message || err}\n\n(شوف الـ console/logcat للتفاصيل الكاملة)`
      );
      return undefined;
    }

    patchClientSubscriptions(client);
    // بنعلّم أي أمر التطبيق بيبعته (مفتاح/مشهد/مؤقت...) عشان سجل الحركة يفرّق "من التطبيق" عن "من برا التطبيق".
    const rawPublish = client.publish.bind(client);
    client.publish = (topic, ...rest) => {
      try { noteAppCommand(topic); } catch (_) {}
      return rawPublish(topic, ...rest);
    };
    clientRef.current = client;

    client.on('connect', () => {
      setConnected(true);
      setMqttError('');
      // كل ما نتصل (أو نعيد الاتصال)، لو الإشعارات مفعّلة نعيد نشر التوكن Retained
      // عشان سيرفر الإشعارات يفضل عارفه حتى لو البروكر أعاد تشغيل أو مسح الحالة.
      if (pushEnabled) registerForPushNotificationsAsync(client);
    });
    client.on('reconnect', () => setConnected(false));
    client.on('close', () => setConnected(false));
    client.on('error', (err) => {
      // كانت بتتسجل في الـ console بس ومحدش بيشوفها في التطبيق نفسه، فلو
      // فيه مشكلة حقيقية (سيرفر غلط، بورت مقفول، إلخ) المستخدم كان بيفضل
      // شايف "جاري الاتصال…" للأبد من غير أي فكرة عن السبب.
      console.log('MQTT error:', err?.message);
      setConnected(false);
      setMqttError(err?.message || 'خطأ غير معروف في الاتصال');
    });

    return () => {
      try {
        client.end(true);
      } catch (err) {
        // تجاهل أي استثناء وقت قفل الاتصال — مش المفروض يوقف التطبيق
        console.log('MQTT end() threw:', err?.message);
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shouldConnect, settings, mqttClientId]);

  // ---------- عدّاد ساعات التشغيل (محلي) ----------
  useEffect(() => { initRuntimeTracker(); initLastKnown(); }, []);
  const runtimeTopicsKey = runtimeTopicsFor(boards).sort().join('|');
  useEffect(() => {
    const client = clientRef.current;
    if (!connected || !client) { setRuntimeOnline(false); return undefined; }
    setRuntimeOnline(true);
    return attachRuntimeTracker(client, boards);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connected, runtimeTopicsKey]);

  // آخر حالة معروفة لكل مفتاح (بتتعرض بعلامة "قديمة" لما الاتصال يقطع).
  useEffect(() => {
    const client = clientRef.current;
    if (!connected || !client) return undefined;
    return attachLastKnown(client, boards);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [connected, runtimeTopicsKey]);

  // ---------- جدولة المشاهد ----------
  const [weatherCity, setWeatherCity] = useState(DEFAULT_CITY);
  useEffect(() => {
    let alive = true;
    loadWeatherCity().then((c) => { if (alive && c) setWeatherCity(c); }).catch(() => {});
    const unsub = subscribeWeatherCity((c) => { if (c) setWeatherCity(c); });
    return () => { alive = false; if (typeof unsub === 'function') unsub(); };
  }, []);
  const { config: presenceConfig, setConfig: setPresenceConfig } = usePresenceConfig();
  const { serverOnline: schedulerServerOnline } = useSceneScheduler({
    client: clientRef.current,
    connected,
    scenes,
    city: weatherCity,
    presence: presenceConfig,
  });

  // ---------- المؤقتات ----------
  const { timers, addTimer, cancelTimer } = useTimers({ client: clientRef.current, connected });

  // ---------- التنبيهات ----------
  const pushAlertEntry = (entry) => {
    const next = [entry, ...alertsLogRef.current].slice(0, 200);
    alertsLogRef.current = next;
    setAlertsLog(next);
    saveAlertLog(next).catch(() => {});
  };
  const changeAlertSettings = (next) => {
    setAlertSettings(next);
    saveAlertSettings(next).catch(() => {});
  };
  const markAlertsRead = () => {
    if (!alertsLogRef.current.some((a) => !a.read)) return;
    const next = alertsLogRef.current.map((a) => (a.read ? a : { ...a, read: true }));
    alertsLogRef.current = next;
    setAlertsLog(next);
    saveAlertLog(next).catch(() => {});
  };
  const clearAlerts = () => {
    alertsLogRef.current = [];
    setAlertsLog([]);
    saveAlertLog([]).catch(() => {});
  };
  const { stats: boardHealth, recordAvailability, reset: resetBoardHealth } = useBoardHealth();
  const { outages: powerOutages, resetOutages } = usePowerOutages(clientRef.current, connected, boards);
  const boardInfo = useBoardInfo(clientRef.current, connected, boards);
  useAlertsMonitor({
    client: clientRef.current,
    connected,
    boards,
    settings: alertSettings,
    onAlert: pushAlertEntry,
    onAvailability: recordAvailability,
  });
  const unreadAlerts = alertsLog.filter((a) => !a.read).length;

  const persistSettings = async (s) => {
    setSettings(s);
    await saveSettings(s);
  };

  const persistPairingKey = async (k) => {
    setPairingKey(k);
    await savePairingKey(k);
  };

  const persistBoards = async (list) => {
    setBoards(list);
    await saveBoards(list);
  };

  const persistScenes = async (list) => {
    setScenes(list);
    await saveScenes(list);
  };

  const togglePush = async () => {
    if (pushEnabled) {
      await unregisterPushNotifications(clientRef.current);
      setPushEnabled(false);
      await savePushEnabled(false);
      return;
    }
    const res = await registerForPushNotificationsAsync(clientRef.current);
    if (!res.ok) {
      showAlert('الإشعارات', res.error || 'حصل خطأ');
      return;
    }
    setPushEnabled(true);
    await savePushEnabled(true);
    showAlert(
      'اتفعّلت',
      'التوكن اتنشر على البروكر. لازم سيرفر الإشعارات (server/) يكون شغال عشان الإشعارات توصلك فعليًا وقت التطبيق مقفول.'
    );
  };

  // تفعيل/تعطيل حماية فتح التطبيق بالبصمة (إصبع أو وجه). قبل ما نفعّلها بنتأكد
  // إن الموبايل فيه حساس بصمة أصلاً وإن فيه بصمة متسجلة عليه، وإلا التفعيل
  // مش هيبقى له أي معنى (ولا هيقدر يتحقق منه أبدًا).
  const toggleBiometric = async () => {
    if (biometricEnabled) {
      setBiometricEnabled(false);
      await saveBiometricEnabled(false);
      return;
    }
    const hasHardware = await LocalAuthentication.hasHardwareAsync();
    if (!hasHardware) {
      showAlert('غير متاح', 'الموبايل ده مفيهوش حساس بصمة إصبع أو بصمة وجه');
      return;
    }
    const isEnrolled = await LocalAuthentication.isEnrolledAsync();
    if (!isEnrolled) {
      showAlert('لازم تسجّل بصمة الأول', 'روح إعدادات الموبايل وسجّل بصمة إصبع أو بصمة وجه، وبعدين رجع فعّل الحماية دي');
      return;
    }
    setBiometricEnabled(true);
    await saveBiometricEnabled(true);
  };

  // زرار "رجوع" الظاهر جوه شاشات زي المشاهد/المظهر/السجل — لو فيه شاشة قبلها
  // في المكدس بيرجعلها، ولو إحنا أصلاً واقفين على تبويب رئيسي (زي "المشاهد"
  // لما بيتفتح من الشريط السفلي مباشرة) بيوديك لشاشة البوردات بدل ما يسيبك
  // واقف في مكانك من غير أي تأثير.
  const handleBack = () => (screenStack.length > 1 ? popScreen() : goToTab('boards'));

  // التنقل من الشريط السفلي — بيقفل أي بورد مفتوح ويودّي على الشاشة المطلوبة
  // (كتبديل تاب، مش تراكم فوق المكدس)
  const handleNavigate = (target) => {
    setActiveBoard(null);
    goToTab(target);
  };

  // زرار "+" في النص — يودّي على شاشة البوردات (لو مكناش واقفين عليها) ويفتح
  // فورم "إضافة بورد جديد" فيها على طول
  const handleAddPress = () => {
    setActiveBoard(null);
    goToTab('boards');
    setAddBoardSignal(true);
  };

  const addBoard = (board) => persistBoards([...boards, { ...board, id: newId() }]);
  const deleteBoard = (id) => persistBoards(boards.filter((b) => b.id !== id));
  const updateBoard = (updated) => {
    setActiveBoard(updated);
    persistBoards(boards.map((b) => (b.id === updated.id ? updated : b)));
  };
  const updateBoardMeta = (id, patch) => persistBoards(boards.map((b) => (b.id === id ? { ...b, ...patch } : b)));

  // ---------- شاشة القفل بالبصمة ----------
  // بتفضل شغالة قبل أي حاجة تانية طول ما الحماية مفعّلة ولسه محصلش تحقق ناجح
  // في الجلسة دي (unlocked بيتصفّر تاني كل ما التطبيق يتقفل ويتفتح من الأول).
  // لحد ما شاشة التشغيل تبدأ تختفي بنرجّع null (الاتصال والتحميل شغالين في الخلفية عادي).
  if (!ready || !show) return null;
  if ((biometricEnabled || pinEnabled) && !unlocked) {
    return <LockScreen pinEnabled={pinEnabled} biometricEnabled={biometricEnabled} onUnlocked={() => setUnlocked(true)} />;
  }

  // ---------- شاشة إعدادات الاتصال ----------
  if (screen === 'settings') {
    return (
      <>
      <View style={{ flex: 1, backgroundColor: theme.bg }}>
      <ScreenTransition key={screen} mode={navMode}><SafeAreaView style={[styles.container, { flex: 1, backgroundColor: theme.bg }]}>
        <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} />
        <ScrollView contentContainerStyle={{ paddingBottom: 170 }} keyboardShouldPersistTaps="handled">
          <ScreenHeader title="إعدادات الاتصال بالسيرفر" onBack={() => popScreen()} />
          <Text style={[styles.hint, { color: theme.textSecondary }]}>
            بيانات البروكر (WebSocket) دي بتتشارك بين كل البوردات. كل بورد بعد كده بيتضاف تلقائي عن طريق الاكتشاف من الفيرموير.
          </Text>

          <Field label="Protocol" value={settings.protocol} onChange={(v) => setSettings({ ...settings, protocol: v })} placeholder="ws أو wss" />
          <Field label="Host" value={settings.host} onChange={(v) => setSettings({ ...settings, host: v })} placeholder="broker.example.com" />
          <Field label="WebSocket Port" value={settings.port} onChange={(v) => setSettings({ ...settings, port: v })} placeholder="8884" keyboardType="numeric" />
          <Field label="Path" value={settings.path} onChange={(v) => setSettings({ ...settings, path: v })} placeholder="/mqtt" />
          <Field label="Username" value={settings.username} onChange={(v) => setSettings({ ...settings, username: v })} />
          <Field label="Password" value={settings.password} onChange={(v) => setSettings({ ...settings, password: v })} secure />

          <View style={{ height: 8 }} />
          <Text style={[styles.title, { color: theme.textPrimary, fontSize: 16 }]}>مفتاح الربط (Pairing Key)</Text>
          <Field
            label="Pairing Key"
            value={pairingKey}
            onChange={setPairingKey}
            secure
          />

          <TouchableOpacity
            style={[styles.primaryBtn, { backgroundColor: theme.accent }]}
            onPress={async () => {
              if (!settings.host) {
                showAlert('خطأ', 'لازم تدخل عنوان السيرفر (Host)');
                return;
              }
              if (!pairingKey.trim()) {
                showAlert('خطأ', 'لازم تحط مفتاح ربط (Pairing Key) عشان الاكتشاف يشتغل بأمان');
                return;
              }
              await persistSettings(settings);
              await persistPairingKey(pairingKey.trim());
              popScreen();
            }}
          >
            <Text style={styles.btnText}>حفظ ومتابعة</Text>
          </TouchableOpacity>
        </ScrollView>
      </SafeAreaView></ScreenTransition>
      <BottomNavBar
        screen={screen}
        onNavigate={handleNavigate}
        onAddPress={handleAddPress}
        onSettingsPress={openMenu}
        menuOpen={menuOpen}
      />
      </View>
      <SideMenu
        visible={menuOpen}
        onClose={closeMenu}
        theme={theme}
        isLight={isLight}
        toggleLightDark={toggleLightDark}
        pushEnabled={pushEnabled}
        onTogglePush={togglePush}
        biometricEnabled={biometricEnabled}
        onToggleBiometric={toggleBiometric}
        onOpenSettings={() => pushScreen('settings')}
        onOpenTheme={() => pushScreen('theme')}
        onOpenScenes={() => pushScreen('scenes')}
        onOpenHistory={() => pushScreen('history')}
        onOpenBackup={() => pushScreen('backup')}
        onOpenSwitchSettings={() => pushScreen('switchDisplay')}
        onOpenBottomNavSettings={() => pushScreen('bottomNavSettings')}
      />
      </>
    );
  }

  // ---------- شاشة الأجهزة المستقلة ----------
  // تبويب الأجهزة لا يعرض الصفحة الرئيسية مرة أخرى؛ يعرض قائمة كل الأجهزة
  // المرتبطة بالبوردات بشكل مستقل.
  if (screen === 'devices') {
    return (
      <>
      <View style={{ flex: 1, backgroundColor: theme.bg }}>
        <ScreenTransition key={screen} mode={navMode}>
          <DevicesScreen
            boards={boards}
            client={clientRef.current}
            connected={connected}
            onOpenBoard={(b) => { setActiveBoard(b); pushScreen('board'); }}
            onBack={handleBack}
          />
        </ScreenTransition>
        <BottomNavBar
          screen={screen}
          onNavigate={handleNavigate}
          onAddPress={handleAddPress}
          onSettingsPress={openMenu}
          menuOpen={menuOpen}
        />
      </View>
      <SideMenu
        visible={menuOpen}
        onClose={closeMenu}
        theme={theme}
        isLight={isLight}
        toggleLightDark={toggleLightDark}
        pushEnabled={pushEnabled}
        onTogglePush={togglePush}
        biometricEnabled={biometricEnabled}
        onToggleBiometric={toggleBiometric}
        onOpenSettings={() => pushScreen('settings')}
        onOpenTheme={() => pushScreen('theme')}
        onOpenScenes={() => pushScreen('scenes')}
        onOpenHistory={() => pushScreen('history')}
        onOpenBackup={() => pushScreen('backup')}
        onOpenSwitchSettings={() => pushScreen('switchDisplay')}
        onOpenBottomNavSettings={() => pushScreen('bottomNavSettings')}
      />
      </>
    );
  }

  // ---------- إعدادات المفاتيح (منفصلة عن الثيمات) ----------
  if (screen === 'switchDisplay') {
    return (
      <>
      <View style={{ flex: 1, backgroundColor: theme.bg }}>
        <ScreenTransition key={screen} mode={navMode}>
          <SwitchDisplaySettingsScreen onBack={handleBack} />
        </ScreenTransition>
        <BottomNavBar
          screen={screen}
          onNavigate={handleNavigate}
          onAddPress={handleAddPress}
          onSettingsPress={openMenu}
          menuOpen={menuOpen}
        />
      </View>
      <SideMenu
        visible={menuOpen}
        onClose={closeMenu}
        theme={theme}
        isLight={isLight}
        toggleLightDark={toggleLightDark}
        pushEnabled={pushEnabled}
        onTogglePush={togglePush}
        biometricEnabled={biometricEnabled}
        onToggleBiometric={toggleBiometric}
        onOpenSettings={() => pushScreen('settings')}
        onOpenTheme={() => pushScreen('theme')}
        onOpenScenes={() => pushScreen('scenes')}
        onOpenHistory={() => pushScreen('history')}
        onOpenBackup={() => pushScreen('backup')}
        onOpenSwitchSettings={() => pushScreen('switchDisplay')}
        onOpenBottomNavSettings={() => pushScreen('bottomNavSettings')}
      />
      </>
    );
  }

  // ---------- شاشة الثيمات / المظهر ----------
  if (screen === 'theme') {
    return (
      <>
      <View style={{ flex: 1, backgroundColor: theme.bg }}>
        <ScreenTransition key={screen} mode={navMode}>
          <ThemeScreen onBack={handleBack} />
        </ScreenTransition>
        <BottomNavBar
          screen={screen}
          onNavigate={handleNavigate}
          onAddPress={handleAddPress}
          onSettingsPress={openMenu}
          menuOpen={menuOpen}
        />
      </View>
      <SideMenu
        visible={menuOpen}
        onClose={closeMenu}
        theme={theme}
        isLight={isLight}
        toggleLightDark={toggleLightDark}
        pushEnabled={pushEnabled}
        onTogglePush={togglePush}
        biometricEnabled={biometricEnabled}
        onToggleBiometric={toggleBiometric}
        onOpenSettings={() => pushScreen('settings')}
        onOpenTheme={() => pushScreen('theme')}
        onOpenScenes={() => pushScreen('scenes')}
        onOpenHistory={() => pushScreen('history')}
        onOpenBackup={() => pushScreen('backup')}
        onOpenSwitchSettings={() => pushScreen('switchDisplay')}
        onOpenBottomNavSettings={() => pushScreen('bottomNavSettings')}
      />
      </>
    );
  }

  // ---------- شاشة المشاهد (Scenes/Groups) ----------
  if (screen === 'scenes') {
    return (
      <>
      <View style={{ flex: 1, backgroundColor: theme.bg }}>
        <ScreenTransition key={screen} mode={navMode}>
          <ScenesScreen
            boards={boards}
            scenes={scenes}
            onSaveScenes={persistScenes}
            client={clientRef.current}
            connected={connected}
            weatherCity={weatherCity}
            schedulerServerOnline={schedulerServerOnline}
            onOpenPresence={() => pushScreen('presence')}
            onBack={handleBack}
          />
        </ScreenTransition>
        <BottomNavBar
          screen={screen}
          onNavigate={handleNavigate}
          onAddPress={handleAddPress}
          onSettingsPress={openMenu}
          menuOpen={menuOpen}
        />
      </View>
      <SideMenu
        visible={menuOpen}
        onClose={closeMenu}
        theme={theme}
        isLight={isLight}
        toggleLightDark={toggleLightDark}
        pushEnabled={pushEnabled}
        onTogglePush={togglePush}
        biometricEnabled={biometricEnabled}
        onToggleBiometric={toggleBiometric}
        onOpenSettings={() => pushScreen('settings')}
        onOpenTheme={() => pushScreen('theme')}
        onOpenScenes={() => pushScreen('scenes')}
        onOpenHistory={() => pushScreen('history')}
        onOpenBackup={() => pushScreen('backup')}
        onOpenSwitchSettings={() => pushScreen('switchDisplay')}
        onOpenBottomNavSettings={() => pushScreen('bottomNavSettings')}
      />
      </>
    );
  }

  // ---------- إعدادات شريط الأيقونات السفلي ----------
  if (screen === 'bottomNavSettings') {
    return (
      <>
      <View style={{ flex: 1, backgroundColor: theme.bg }}>
        <ScreenTransition key={screen} mode={navMode}>
          <BottomNavSettingsScreen onBack={handleBack} />
        </ScreenTransition>
        <BottomNavBar
          screen={screen}
          onNavigate={handleNavigate}
          onAddPress={handleAddPress}
          onSettingsPress={openMenu}
          menuOpen={menuOpen}
        />
      </View>
      <SideMenu
        visible={menuOpen}
        onClose={closeMenu}
        theme={theme}
        isLight={isLight}
        toggleLightDark={toggleLightDark}
        pushEnabled={pushEnabled}
        onTogglePush={togglePush}
        biometricEnabled={biometricEnabled}
        onToggleBiometric={toggleBiometric}
        onOpenSettings={() => pushScreen('settings')}
        onOpenTheme={() => pushScreen('theme')}
        onOpenScenes={() => pushScreen('scenes')}
        onOpenHistory={() => pushScreen('history')}
        onOpenBackup={() => pushScreen('backup')}
        onOpenSwitchSettings={() => pushScreen('switchDisplay')}
        onOpenBottomNavSettings={() => pushScreen('bottomNavSettings')}
      />
      </>
    );
  }

  // ---------- شاشة الإعدادات الرئيسية (تبويب "الإعدادات" في الشريط السفلي) ----------
  if (screen === 'settingsHome') {
    return (
      <>
      <View style={{ flex: 1, backgroundColor: theme.bg }}>
        <ScreenTransition key={screen} mode={navMode}>
          <SettingsHomeScreen
            connected={connected}
            configured={isConfigured}
            themeName={theme.name}
            onOpenConnection={() => pushScreen('settings')}
            onOpenTheme={() => pushScreen('theme')}
            onOpenSwitchSettings={() => pushScreen('switchDisplay')}
            onOpenBottomNavSettings={() => pushScreen('bottomNavSettings')}
            onOpenHistory={() => pushScreen('history')}
            onOpenBackup={() => pushScreen('backup')}
            onOpenManualBoard={() => pushScreen('manualBoard')}
            pushEnabled={pushEnabled}
            onTogglePush={togglePush}
            biometricEnabled={biometricEnabled}
            onToggleBiometric={toggleBiometric}
          />
        </ScreenTransition>
        <BottomNavBar
          screen={screen}
          onNavigate={handleNavigate}
          onAddPress={handleAddPress}
          onSettingsPress={openMenu}
          menuOpen={menuOpen}
        />
      </View>
      <SideMenu
        visible={menuOpen}
        onClose={closeMenu}
        theme={theme}
        isLight={isLight}
        toggleLightDark={toggleLightDark}
        pushEnabled={pushEnabled}
        onTogglePush={togglePush}
        biometricEnabled={biometricEnabled}
        onToggleBiometric={toggleBiometric}
        onOpenSettings={() => pushScreen('settings')}
        onOpenTheme={() => pushScreen('theme')}
        onOpenScenes={() => pushScreen('scenes')}
        onOpenHistory={() => pushScreen('history')}
        onOpenBackup={() => pushScreen('backup')}
        onOpenSwitchSettings={() => pushScreen('switchDisplay')}
        onOpenBottomNavSettings={() => pushScreen('bottomNavSettings')}
      />
      </>
    );
  }

  // ---------- شاشة التنبيهات ----------
  if (screen === 'alerts') {
    return (
      <>
      <View style={{ flex: 1, backgroundColor: theme.bg }}>
        <ScreenTransition key={screen} mode={navMode}>
          <AlertsScreen
            alerts={alertsLog}
            settings={alertSettings}
            connected={connected}
            onChangeSettings={changeAlertSettings}
            onMarkAllRead={markAlertsRead}
            onClear={clearAlerts}
            onOpenHealth={() => pushScreen('boardHealth')}
            onBack={handleBack}
          />
        </ScreenTransition>
        <BottomNavBar
          screen={screen}
          onNavigate={handleNavigate}
          onAddPress={handleAddPress}
          onSettingsPress={openMenu}
          menuOpen={menuOpen}
        />
      </View>
      <SideMenu
        visible={menuOpen}
        onClose={closeMenu}
        theme={theme}
        isLight={isLight}
        toggleLightDark={toggleLightDark}
        pushEnabled={pushEnabled}
        onTogglePush={togglePush}
        biometricEnabled={biometricEnabled}
        onToggleBiometric={toggleBiometric}
        onOpenSettings={() => pushScreen('settings')}
        onOpenTheme={() => pushScreen('theme')}
        onOpenScenes={() => pushScreen('scenes')}
        onOpenHistory={() => pushScreen('history')}
        onOpenBackup={() => pushScreen('backup')}
        onOpenSwitchSettings={() => pushScreen('switchDisplay')}
        onOpenBottomNavSettings={() => pushScreen('bottomNavSettings')}
      />
      </>
    );
  }

  // ---------- شاشة المؤقتات ----------
  if (screen === 'timers') {
    return (
      <>
      <View style={{ flex: 1, backgroundColor: theme.bg }}>
        <ScreenTransition key={screen} mode={navMode}>
          <TimersScreen
            boards={boards}
            timers={timers}
            onAddTimer={addTimer}
            onCancelTimer={cancelTimer}
            connected={connected}
            onBack={handleBack}
          />
        </ScreenTransition>
        <BottomNavBar
          screen={screen}
          onNavigate={handleNavigate}
          onAddPress={handleAddPress}
          onSettingsPress={openMenu}
          menuOpen={menuOpen}
        />
      </View>
      <SideMenu
        visible={menuOpen}
        onClose={closeMenu}
        theme={theme}
        isLight={isLight}
        toggleLightDark={toggleLightDark}
        pushEnabled={pushEnabled}
        onTogglePush={togglePush}
        biometricEnabled={biometricEnabled}
        onToggleBiometric={toggleBiometric}
        onOpenSettings={() => pushScreen('settings')}
        onOpenTheme={() => pushScreen('theme')}
        onOpenScenes={() => pushScreen('scenes')}
        onOpenHistory={() => pushScreen('history')}
        onOpenBackup={() => pushScreen('backup')}
        onOpenSwitchSettings={() => pushScreen('switchDisplay')}
        onOpenBottomNavSettings={() => pushScreen('bottomNavSettings')}
      />
      </>
    );
  }

  // ---------- شاشة تقرير الكهربا ----------
  if (screen === 'powerReport') {
    return (
      <>
      <View style={{ flex: 1, backgroundColor: theme.bg }}>
        <ScreenTransition key={screen} mode={navMode}>
          <PowerReportScreen boards={boards} outages={powerOutages} stats={boardHealth} onBack={handleBack} />
        </ScreenTransition>
        <BottomNavBar
          screen={screen}
          onNavigate={handleNavigate}
          onAddPress={handleAddPress}
          onSettingsPress={openMenu}
          menuOpen={menuOpen}
        />
      </View>
      </>
    );
  }

  // ---------- شاشة صحة البوردات ----------
  if (screen === 'boardHealth') {
    return (
      <>
      <View style={{ flex: 1, backgroundColor: theme.bg }}>
        <ScreenTransition key={screen} mode={navMode}>
          <BoardHealthScreen
            boards={boards}
            stats={boardHealth}
            outages={powerOutages}
            info={boardInfo}
            connected={connected}
            onReset={() => { resetBoardHealth(); resetOutages(); }}
            onOpenReport={() => pushScreen('powerReport')}
            onBack={handleBack}
          />
        </ScreenTransition>
        <BottomNavBar
          screen={screen}
          onNavigate={handleNavigate}
          onAddPress={handleAddPress}
          onSettingsPress={openMenu}
          menuOpen={menuOpen}
        />
      </View>
      <SideMenu
        visible={menuOpen}
        onClose={closeMenu}
        theme={theme}
        isLight={isLight}
        toggleLightDark={toggleLightDark}
        pushEnabled={pushEnabled}
        onTogglePush={togglePush}
        biometricEnabled={biometricEnabled}
        onToggleBiometric={toggleBiometric}
        onOpenSettings={() => pushScreen('settings')}
        onOpenTheme={() => pushScreen('theme')}
        onOpenScenes={() => pushScreen('scenes')}
        onOpenHistory={() => pushScreen('history')}
        onOpenBackup={() => pushScreen('backup')}
        onOpenSwitchSettings={() => pushScreen('switchDisplay')}
        onOpenBottomNavSettings={() => pushScreen('bottomNavSettings')}
      />
      </>
    );
  }

  // ---------- شاشة محاكاة التواجد ----------
  if (screen === 'presence') {
    return (
      <>
      <View style={{ flex: 1, backgroundColor: theme.bg }}>
        <ScreenTransition key={screen} mode={navMode}>
          <PresenceSimScreen
            boards={boards}
            config={presenceConfig}
            onChange={setPresenceConfig}
            connected={connected}
            weatherCity={weatherCity}
            schedulerServerOnline={schedulerServerOnline}
            onBack={handleBack}
          />
        </ScreenTransition>
        <BottomNavBar
          screen={screen}
          onNavigate={handleNavigate}
          onAddPress={handleAddPress}
          onSettingsPress={openMenu}
          menuOpen={menuOpen}
        />
      </View>
      <SideMenu
        visible={menuOpen}
        onClose={closeMenu}
        theme={theme}
        isLight={isLight}
        toggleLightDark={toggleLightDark}
        pushEnabled={pushEnabled}
        onTogglePush={togglePush}
        biometricEnabled={biometricEnabled}
        onToggleBiometric={toggleBiometric}
        onOpenSettings={() => pushScreen('settings')}
        onOpenTheme={() => pushScreen('theme')}
        onOpenScenes={() => pushScreen('scenes')}
        onOpenHistory={() => pushScreen('history')}
        onOpenBackup={() => pushScreen('backup')}
        onOpenSwitchSettings={() => pushScreen('switchDisplay')}
        onOpenBottomNavSettings={() => pushScreen('bottomNavSettings')}
      />
      </>
    );
  }

  // ---------- شاشة سجل الأحداث (History) ----------
  if (screen === 'history') {
    return (
      <>
      <View style={{ flex: 1, backgroundColor: theme.bg }}>
        <ScreenTransition key={screen} mode={navMode}>
          <HistoryScreen client={clientRef.current} connected={connected} onBack={handleBack} />
        </ScreenTransition>

      </View>
      <SideMenu
        visible={menuOpen}
        onClose={closeMenu}
        theme={theme}
        isLight={isLight}
        toggleLightDark={toggleLightDark}
        pushEnabled={pushEnabled}
        onTogglePush={togglePush}
        biometricEnabled={biometricEnabled}
        onToggleBiometric={toggleBiometric}
        onOpenSettings={() => pushScreen('settings')}
        onOpenTheme={() => pushScreen('theme')}
        onOpenScenes={() => pushScreen('scenes')}
        onOpenHistory={() => pushScreen('history')}
        onOpenBackup={() => pushScreen('backup')}
        onOpenSwitchSettings={() => pushScreen('switchDisplay')}
        onOpenBottomNavSettings={() => pushScreen('bottomNavSettings')}
      />
      </>
    );
  }

  // ---------- شاشة النسخة الاحتياطية (تصدير/استيراد) ----------
  if (screen === 'backup') {
    return (
      <>
      <View style={{ flex: 1, backgroundColor: theme.bg }}>
        <ScreenTransition key={screen} mode={navMode}>
          <BackupScreen onBack={handleBack} onImported={handleBackupImported} />
        </ScreenTransition>
        <BottomNavBar
          screen={screen}
          onNavigate={handleNavigate}
          onAddPress={handleAddPress}
          onSettingsPress={openMenu}
          menuOpen={menuOpen}
        />
      </View>
      <SideMenu
        visible={menuOpen}
        onClose={closeMenu}
        theme={theme}
        isLight={isLight}
        toggleLightDark={toggleLightDark}
        pushEnabled={pushEnabled}
        onTogglePush={togglePush}
        biometricEnabled={biometricEnabled}
        onToggleBiometric={toggleBiometric}
        onOpenSettings={() => pushScreen('settings')}
        onOpenTheme={() => pushScreen('theme')}
        onOpenScenes={() => pushScreen('scenes')}
        onOpenHistory={() => pushScreen('history')}
        onOpenBackup={() => pushScreen('backup')}
        onOpenSwitchSettings={() => pushScreen('switchDisplay')}
        onOpenBottomNavSettings={() => pushScreen('bottomNavSettings')}
      />
      </>
    );
  }

  // ---------- شاشة إضافة بورد يدوي (توبيكات بدون رسالة اكتشاف موقّعة) ----------
  if (screen === 'manualBoard') {
    return (
      <>
      <View style={{ flex: 1, backgroundColor: theme.bg }}>
        <ScreenTransition key={screen} mode={navMode}>
          <ManualBoardScreen
            boards={boards}
            onBack={handleBack}
            onAdded={(board) => {
              addBoard(board);
              goToTab('boards');
            }}
          />
        </ScreenTransition>
        <BottomNavBar
          screen={screen}
          onNavigate={handleNavigate}
          onAddPress={handleAddPress}
          onSettingsPress={openMenu}
          menuOpen={menuOpen}
        />
      </View>
      <SideMenu
        visible={menuOpen}
        onClose={closeMenu}
        theme={theme}
        isLight={isLight}
        toggleLightDark={toggleLightDark}
        pushEnabled={pushEnabled}
        onTogglePush={togglePush}
        biometricEnabled={biometricEnabled}
        onToggleBiometric={toggleBiometric}
        onOpenSettings={() => pushScreen('settings')}
        onOpenTheme={() => pushScreen('theme')}
        onOpenScenes={() => pushScreen('scenes')}
        onOpenHistory={() => pushScreen('history')}
        onOpenBackup={() => pushScreen('backup')}
        onOpenSwitchSettings={() => pushScreen('switchDisplay')}
        onOpenBottomNavSettings={() => pushScreen('bottomNavSettings')}
      />
      </>
    );
  }

  // ---------- شاشة التحكم في بورد واحد ----------
  if (screen === 'board' && activeBoard) {
    const Screen = activeBoard.type === 'irrigation' ? IrrigationScreen : SwitchesScreen;
    return (
      <>
      <View style={{ flex: 1, backgroundColor: theme.bg }}>
        <ScreenTransition key={screen} mode={navMode}>
          <Screen
            board={activeBoard}
            client={clientRef.current}
            connected={connected}
            pairingKey={pairingKey}
            onUpdateBoard={updateBoard}
            onBack={() => {
              setActiveBoard(null);
              handleBack();
            }}
          />
        </ScreenTransition>
        <BottomNavBar
          screen={screen}
          onNavigate={handleNavigate}
          onAddPress={handleAddPress}
          onSettingsPress={openMenu}
          menuOpen={menuOpen}
        />
      </View>
      <SideMenu
        visible={menuOpen}
        onClose={closeMenu}
        theme={theme}
        isLight={isLight}
        toggleLightDark={toggleLightDark}
        pushEnabled={pushEnabled}
        onTogglePush={togglePush}
        biometricEnabled={biometricEnabled}
        onToggleBiometric={toggleBiometric}
        onOpenSettings={() => pushScreen('settings')}
        onOpenTheme={() => pushScreen('theme')}
        onOpenScenes={() => pushScreen('scenes')}
        onOpenHistory={() => pushScreen('history')}
        onOpenBackup={() => pushScreen('backup')}
        onOpenSwitchSettings={() => pushScreen('switchDisplay')}
        onOpenBottomNavSettings={() => pushScreen('bottomNavSettings')}
      />
      </>
    );
  }

  // ---------- شاشة التحركات (جدول زمني / شغال دلوقتي / سجل الحركة) ----------
  if (screen === 'activity') {
    return (
      <>
      <View style={{ flex: 1, backgroundColor: theme.bg }}>
        <ScreenTransition key={screen} mode={navMode}>
          <ActivityScreen boards={boards} client={clientRef.current} connected={connected} onBack={handleBack} />
        </ScreenTransition>
        <BottomNavBar
          screen={screen}
          onNavigate={handleNavigate}
          onAddPress={handleAddPress}
          onSettingsPress={openMenu}
          menuOpen={menuOpen}
        />
      </View>
      <SideMenu
        visible={menuOpen}
        onClose={closeMenu}
        theme={theme}
        isLight={isLight}
        toggleLightDark={toggleLightDark}
        pushEnabled={pushEnabled}
        onTogglePush={togglePush}
        biometricEnabled={biometricEnabled}
        onToggleBiometric={toggleBiometric}
        onOpenSettings={() => pushScreen('settings')}
        onOpenTheme={() => pushScreen('theme')}
        onOpenScenes={() => pushScreen('scenes')}
        onOpenHistory={() => pushScreen('history')}
        onOpenBackup={() => pushScreen('backup')}
        onOpenSwitchSettings={() => pushScreen('switchDisplay')}
        onOpenBottomNavSettings={() => pushScreen('bottomNavSettings')}
      />
      </>
    );
  }

  // ---------- شاشة قائمة البوردات (تبويب "الرئيسية"/"الأجهزة" في الشريط السفلي) ----------
  return (
    <>
    <View style={{ flex: 1, backgroundColor: theme.bg }}>
      <ScreenTransition key={screen} mode={navMode}>
        <BoardsListScreen
          serverHost={settings.host}
          boards={boards}
          scenes={scenes}
          connected={connected}
          mqttError={mqttError}
          client={clientRef.current}
          pairingKey={pairingKey}
          onAdd={addBoard}
          onDelete={deleteBoard}
          onOpen={(b) => {
            setActiveBoard(b);
            pushScreen('board');
          }}
          onOpenSettings={() => pushScreen('settings')}
          onOpenTheme={() => pushScreen('theme')}
          onOpenScenes={() => pushScreen('scenes')}
          onOpenDevices={() => pushScreen('devices')}
          onOpenAlerts={() => pushScreen('alerts')}
          onOpenTimers={() => pushScreen('timers')}
          onOpenActivity={() => pushScreen('activity')}
          activeTimers={timers.length}
          unreadAlerts={unreadAlerts}
          recentAlerts={alertsLog}
          boardStats={boardHealth}
          onOpenHistory={() => pushScreen('history')}
          onOpenBackup={() => pushScreen('backup')}
          onOpenManualBoard={() => pushScreen('manualBoard')}
          pushEnabled={pushEnabled}
          onTogglePush={togglePush}
          configured={isConfigured}
          onUpdateBoardMeta={updateBoardMeta}
          addBoardSignal={addBoardSignal}
          onAddBoardSignalHandled={() => setAddBoardSignal(false)}
        />
      </ScreenTransition>
      <BottomNavBar
        screen={screen}
        onNavigate={handleNavigate}
        onAddPress={handleAddPress}
        onSettingsPress={openMenu}
        menuOpen={menuOpen}
      />
    </View>
    <SideMenu
      visible={menuOpen}
      onClose={closeMenu}
      theme={theme}
      isLight={isLight}
      toggleLightDark={toggleLightDark}
      pushEnabled={pushEnabled}
      onTogglePush={togglePush}
      biometricEnabled={biometricEnabled}
      onToggleBiometric={toggleBiometric}
      onOpenSettings={() => pushScreen('settings')}
      onOpenTheme={() => pushScreen('theme')}
      onOpenScenes={() => pushScreen('scenes')}
      onOpenHistory={() => pushScreen('history')}
      onOpenBackup={() => pushScreen('backup')}
    />
    </>
  );
}

function Field({ label, value, onChange, placeholder, secure, keyboardType }) {
  const { theme } = useTheme();
  return (
    <View style={{ marginBottom: 12 }}>
      <Text style={[styles.label, { color: theme.textSecondary }]}>{label}</Text>
      <TextInput
        style={[styles.input, { backgroundColor: theme.cardAlt, color: theme.textPrimary }]}
        value={value}
        onChangeText={onChange}
        placeholder={placeholder}
        placeholderTextColor={theme.textMuted}
        secureTextEntry={secure}
        keyboardType={keyboardType}
        autoCapitalize="none"
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 18, paddingTop: 55 },
  backRow: { alignSelf: 'flex-start', marginBottom: 14 },
  backText: { fontSize: 14, fontWeight: '600' },
  title: { fontSize: 22, fontWeight: '700', marginBottom: 6 },
  hint: { fontSize: 12, marginBottom: 16 },
  label: { fontSize: 12, marginBottom: 6 },
  input: { borderRadius: 10, paddingHorizontal: 12, paddingVertical: 10 },
  primaryBtn: { borderRadius: 12, paddingVertical: 14, alignItems: 'center', marginTop: 10 },
  btnText: { color: '#fff', fontWeight: '600', fontSize: 13 },
});
