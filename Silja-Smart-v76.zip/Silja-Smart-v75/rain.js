// توقعات المطر لحماية الري — من Open-Meteo (نفس مصدر الطقس، من غير مفتاح API).
// بنقرا احتمال المطر الأقصى النهارده وبكرة + كمية المطر + هل بتمطر دلوقتي.
// لو مفيش نت بنرجّع آخر قراءة محفوظة (لو أقل من 3 ساعات) بدل ما نخفي الحماية.
import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { DEFAULT_CITY, loadWeatherCity, subscribeWeatherCity } from './weather';

const REFRESH_MS = 30 * 60 * 1000;
const CACHE_MAX_AGE_MS = 3 * 60 * 60 * 1000;

export async function fetchRainForecast(city) {
  const url = `https://api.open-meteo.com/v1/forecast?latitude=${city.lat}&longitude=${city.lon}`
    + '&current=precipitation,weather_code&daily=precipitation_probability_max,precipitation_sum&timezone=auto&forecast_days=2';
  const res = await fetch(url);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const data = await res.json();
  const d = data && data.daily;
  const c = data && data.current;
  if (!d || !Array.isArray(d.precipitation_probability_max)) throw new Error('bad payload');
  const code = c ? c.weather_code : 0;
  return {
    probToday: Number(d.precipitation_probability_max[0]) || 0,
    mmToday: Number(d.precipitation_sum && d.precipitation_sum[0]) || 0,
    probTomorrow: Number(d.precipitation_probability_max[1]) || 0,
    nowRaining: (c && Number(c.precipitation) > 0) || (code >= 51 && code <= 67) || (code >= 80 && code <= 82) || code >= 95,
    ts: Date.now(),
  };
}

// بيرجّع null لحد ما توصل أول قراءة (أو لو مفيش نت ومفيش كاش).
export function useRainForecast() {
  const [rain, setRain] = useState(null);
  const [city, setCity] = useState(DEFAULT_CITY);

  useEffect(() => {
    loadWeatherCity().then(setCity);
    return subscribeWeatherCity((c) => { setRain(null); setCity(c); });
  }, []);

  useEffect(() => {
    let alive = true;
    const key = `silja_rain_${city.lat.toFixed(2)}_${city.lon.toFixed(2)}`;
    const load = async () => {
      try {
        const r = await fetchRainForecast(city);
        if (!alive) return;
        setRain(r);
        AsyncStorage.setItem(key, JSON.stringify(r)).catch(() => {});
      } catch (_) {
        try {
          const raw = await AsyncStorage.getItem(key);
          const c = raw ? JSON.parse(raw) : null;
          if (alive && c && Date.now() - c.ts < CACHE_MAX_AGE_MS) setRain((cur) => cur || c);
        } catch (_e) {}
      }
    };
    load();
    const t = setInterval(load, REFRESH_MS);
    return () => { alive = false; clearInterval(t); };
  }, [city]);

  return rain;
}
