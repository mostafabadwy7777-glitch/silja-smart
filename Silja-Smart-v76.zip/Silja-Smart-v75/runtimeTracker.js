// عدّاد ساعات التشغيل لكل مفتاح — بيتحسب محليًا من تغيّر حالات ON/OFF اللي بتوصل
// من البورد على MQTT، ومتخزن على الجهاز (AsyncStorage) آخر ~5 أسابيع.
//
// ملاحظات مهمة على دقة الحساب (تقريبي — للاستهلاك التقريبي مش للفواتير):
// - بيتحسب بس وقت ما التطبيق مفتوح ومتصل بالسيرفر. الوقت اللي التطبيق فيه مقفول أو
//   في الخلفية أو منقطع عن السيرفر مش بيتحسب (لأننا مش شايفين الحالة وقتها).
// - لما التطبيق يرجع يتصل، حالة ON الـ Retained بتبدأ العدّ من لحظة وصولها.
import { useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { AppState } from 'react-native';

const KEY = 'silja_runtime_v1';
const KEEP_DAYS = 35;
const FLUSH_MS = 60 * 1000;
const SAVE_DEBOUNCE_MS = 4000;

let days = {}; // { [topic]: { 'YYYY-MM-DD': seconds } }
let onSince = {}; // { [topic]: ms } — المفاتيح اللي بتتحسب دلوقتي
let isOn = {}; // { [topic]: boolean } — آخر حالة معروفة
let online = false; // متصل بالسيرفر
let foreground = AppState.currentState !== 'background';
let loaded = false;
let loadPromise = null;
let saveTimer = null;
let flushTimer = null;
let appStateSub = null;
const listeners = new Set();

// ---------- سجل الحركة والجدول الزمني ----------
// periods: فترات التشغيل اللي اتشافت فعلًا (التطبيق مفتوح ومتصل) لكل مفتاح — { [topic]: [[startMs, endMs], ...] }
// events: كل تغيّر حالة اتشاف لايف { ts, topic, on, src } — src = 'app' لو التطبيق نفسه بعت الأمر قبلها بثواني، وإلا 'ext'
//         (مفتاح الحيطة / جدولة السيرفر / تطبيق تاني...). التغيّر اللي بيوصل أول مرة بعد الاتصال بيتاخد كخط أساس مش حدث.
const ACT_KEY = 'silja_activity_v1';
const KEEP_PERIOD_DAYS = 8;
const MAX_EVENTS = 500;
const APP_CMD_WINDOW_MS = 20000;
let periods = {};
let openP = {}; // { [topic]: startMs } فترة شغالة دلوقتي
let events = [];
const baselined = new Set();
const appCmdAt = {}; // { [controlTopic]: ms }
let controlsOf = {}; // { [statusTopic]: [controlTopic, ...] }

export function noteAppCommand(topic) {
  if (topic) appCmdAt[topic] = Date.now();
}

function openPeriod(topic, now) {
  if (!openP[topic]) openP[topic] = now;
}

function closePeriod(topic, now) {
  const s = openP[topic];
  if (!s) return;
  delete openP[topic];
  if (now - s < 1000) return;
  const list = periods[topic] || (periods[topic] = []);
  const last = list[list.length - 1];
  if (last && s - last[1] < 3000) last[1] = now;
  else list.push([s, now]);
  scheduleSave();
}

function recordEvent(topic, on, now) {
  const cmds = controlsOf[topic] || [topic];
  const src = cmds.some((c) => now - (appCmdAt[c] || 0) < APP_CMD_WINDOW_MS) ? 'app' : 'ext';
  events = events.concat([{ ts: now, topic, on, src }]);
  if (events.length > MAX_EVENTS) events = events.slice(events.length - MAX_EVENTS);
  scheduleSave();
}

const pad = (n) => String(n).padStart(2, '0');
export const dayKey = (ms) => {
  const d = new Date(ms);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
};
const startOfNextDay = (ms) => {
  const d = new Date(ms);
  return new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1).getTime();
};

// بيقسّم الفترة [from, to] على أيام (بالتوقيت المحلي) ويرجّع ثواني كل يوم.
function splitByDay(from, to) {
  const out = {};
  let cur = from;
  let guard = 0;
  while (cur < to && guard < 40) {
    const next = Math.min(startOfNextDay(cur), to);
    const k = dayKey(cur);
    out[k] = (out[k] || 0) + (next - cur) / 1000;
    cur = next;
    guard += 1;
  }
  return out;
}

function addInterval(topic, from, to) {
  if (!(to > from)) return;
  const part = splitByDay(from, to);
  const mine = days[topic] || (days[topic] = {});
  Object.keys(part).forEach((k) => { mine[k] = (mine[k] || 0) + part[k]; });
}

function notify() {
  listeners.forEach((fn) => { try { fn(); } catch (_) {} });
}

function prune() {
  const cutoff = dayKey(Date.now() - KEEP_DAYS * 86400000);
  Object.keys(days).forEach((t) => {
    Object.keys(days[t]).forEach((k) => { if (k < cutoff) delete days[t][k]; });
    if (Object.keys(days[t]).length === 0) delete days[t];
  });
  const pCut = Date.now() - KEEP_PERIOD_DAYS * 86400000;
  Object.keys(periods).forEach((t) => {
    periods[t] = periods[t].filter((x) => x[1] >= pCut);
    if (periods[t].length === 0) delete periods[t];
  });
  const eCut = Date.now() - 14 * 86400000;
  events = events.filter((e) => e.ts >= eCut);
}

function scheduleSave() {
  if (saveTimer) return;
  saveTimer = setTimeout(() => {
    saveTimer = null;
    prune();
    AsyncStorage.setItem(KEY, JSON.stringify({ v: 1, days })).catch(() => {});
    AsyncStorage.setItem(ACT_KEY, JSON.stringify({ v: 1, periods, open: openP, events, savedAt: Date.now() })).catch(() => {});
  }, SAVE_DEBOUNCE_MS);
}

function ensureLoaded() {
  if (loaded) return Promise.resolve();
  if (!loadPromise) {
    loadPromise = Promise.all([AsyncStorage.getItem(KEY), AsyncStorage.getItem(ACT_KEY)])
      .then(([raw, act]) => {
        if (raw) {
          const parsed = JSON.parse(raw);
          if (parsed && parsed.days && typeof parsed.days === 'object') days = parsed.days;
        }
        if (act) {
          const a = JSON.parse(act);
          if (a && a.periods && typeof a.periods === 'object') periods = a.periods;
          if (a && Array.isArray(a.events)) events = a.events;
          // فترات كانت شغالة لما التطبيق اتقفل: بنقفلها عند آخر حفظ (آخر لحظة أكيدين منها).
          if (a && a.open && typeof a.open === 'object' && a.savedAt) {
            Object.keys(a.open).forEach((t) => {
              const s0 = a.open[t];
              if (a.savedAt - s0 >= 1000) (periods[t] || (periods[t] = [])).push([s0, a.savedAt]);
            });
          }
        }
      })
      .catch(() => {})
      .then(() => { loaded = true; });
  }
  return loadPromise;
}

// بيحسّب الفترة الجارية لحد دلوقتي في الأيام المخزنة، ويكمّل العدّ.
function flush(now = Date.now()) {
  let any = false;
  Object.keys(onSince).forEach((t) => {
    addInterval(t, onSince[t], now);
    onSince[t] = now;
    any = true;
  });
  if (any) scheduleSave();
}

function counting() {
  return online && foreground;
}

function applyActivity(now = Date.now()) {
  if (counting()) {
    // رجّع العدّ للمفاتيح اللي آخر حالة معروفة ليها ON.
    Object.keys(isOn).forEach((t) => {
      if (isOn[t]) {
        if (!onSince[t]) onSince[t] = now;
        openPeriod(t, now);
      }
    });
  } else {
    Object.keys(openP).forEach((t) => closePeriod(t, now));
    baselined.clear();
    // وقّف العدّ (مع حفظ الوقت اللي فات).
    Object.keys(onSince).forEach((t) => addInterval(t, onSince[t], now));
    onSince = {};
    scheduleSave();
  }
  notify();
}

function handleState(topic, on) {
  const now = Date.now();
  const prev = isOn[topic];
  isOn[topic] = on;
  const first = !baselined.has(topic);
  baselined.add(topic);
  if (on) {
    if (counting() && !onSince[topic]) onSince[topic] = now;
    if (counting()) openPeriod(topic, now);
  } else {
    if (onSince[topic]) {
      addInterval(topic, onSince[topic], now);
      delete onSince[topic];
      scheduleSave();
    }
    closePeriod(topic, now);
  }
  if (!first && prev !== undefined && prev !== on && counting()) recordEvent(topic, on, now);
  notify();
}

function parseOnOff(payload) {
  const raw = String(payload).trim();
  let value = raw.toUpperCase();
  try {
    const data = JSON.parse(raw);
    if (data && typeof data === 'object') value = String(data.state ?? data.status ?? data.value ?? data.on ?? '').toUpperCase();
  } catch (_) {}
  if (value === 'ON' || value === '1' || value === 'TRUE') return true;
  if (value === 'OFF' || value === '0' || value === 'FALSE') return false;
  return null;
}

// توبيكات الحالة للمفاتيح العادية (بدون الستائر اللي ملهاش ON/OFF).
export function runtimeTopicsFor(boards = []) {
  const set = new Set();
  boards.forEach((b) => (b.devices || []).forEach((d) => {
    if (d.controlType === 'updown') return;
    const t = d.statusTopic || d.controlTopic;
    if (t) set.add(t);
  }));
  return Array.from(set);
}

// بتتنادى مرة واحدة من App.js: بتحمّل المخزّن وبتراقب نزول التطبيق للخلفية.
export function initRuntimeTracker() {
  ensureLoaded();
  if (!appStateSub) {
    appStateSub = AppState.addEventListener('change', (state) => {
      foreground = state !== 'background';
      applyActivity();
    });
  }
  if (!flushTimer) {
    flushTimer = setInterval(() => { if (counting()) flush(); notify(); }, FLUSH_MS);
  }
}

export function setRuntimeOnline(value) {
  if (online === !!value) return;
  online = !!value;
  applyActivity();
}

// بتشترك في توبيكات الحالة وتسمع التغييرات. بترجّع دالة إلغاء.
export function attachRuntimeTracker(client, boards) {
  if (!client) return () => {};
  const topics = runtimeTopicsFor(boards);
  const topicSet = new Set(topics);
  controlsOf = {};
  boards.forEach((b) => (b.devices || []).forEach((d) => {
    const st = d.statusTopic || d.controlTopic;
    if (!st || !d.controlTopic) return;
    (controlsOf[st] || (controlsOf[st] = [])).push(d.controlTopic);
  }));
  topics.forEach((t) => { try { client.subscribe(t); } catch (_) {} });
  const handler = (topic, payload) => {
    if (!topicSet.has(topic)) return;
    const on = parseOnOff(payload);
    if (on === null) return;
    ensureLoaded().then(() => handleState(topic, on));
  };
  client.on('message', handler);
  return () => {
    client.off('message', handler);
    topics.forEach((t) => { try { client.unsubscribe(t); } catch (_) {} });
  };
}

// إحصائيات مفتاح: ثواني النهارده وآخر 7 أيام (شاملة النهارده).
export function getRuntimeStats(device, now = Date.now()) {
  const topic = device && (device.statusTopic || device.controlTopic);
  if (!topic) return { today: 0, week: 0 };
  const mine = days[topic] || {};
  const extra = onSince[topic] ? splitByDay(onSince[topic], now) : {};
  const todayKey = dayKey(now);
  let today = 0;
  let week = 0;
  for (let i = 0; i < 7; i += 1) {
    const k = dayKey(now - i * 86400000);
    const s = (mine[k] || 0) + (extra[k] || 0);
    week += s;
    if (k === todayKey) today = s;
  }
  return { today, week };
}

// سلسلة يومية لمنحنى الاستهلاك: مجموع ثواني التشغيل لكل المفاتيح المطلوبة (topics) في آخر `count` يوم
// (الأقدم أولًا، شاملة النهارده). تقريبي من ساعات التشغيل المسجّلة، مش قياس واط.
export function getDailyRuntimeSeries(topics = [], count = 7, now = Date.now()) {
  const n = Math.max(1, Math.min(KEEP_DAYS, count));
  const extras = {};
  topics.forEach((t) => { if (onSince[t]) extras[t] = splitByDay(onSince[t], now); });
  const out = [];
  for (let i = n - 1; i >= 0; i -= 1) {
    const ms = now - i * 86400000;
    const k = dayKey(ms);
    let seconds = 0;
    topics.forEach((t) => { seconds += ((days[t] || {})[k] || 0) + ((extras[t] || {})[k] || 0); });
    out.push({ key: k, ts: ms, seconds });
  }
  return out;
}
export const RUNTIME_KEEP_DAYS = KEEP_DAYS;

export function formatRuntime(seconds) {
  const total = Math.round(seconds || 0);
  if (total <= 0) return '0';
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  if (h > 0) return m > 0 ? `${h}س ${m}د` : `${h}س`;
  if (m > 0) return `${m}د`;
  return '<1د';
}

export function runtimeLabel(stats) {
  return `اليوم ${formatRuntime(stats.today)} · الأسبوع ${formatRuntime(stats.week)}`;
}

// هوك: بيعيد رسم الشاشة لما الحالة تتغير وكل 30 ثانية (عشان العدّ الجاري يتحدّث).
export function useRuntimeStats() {
  const [, setTick] = useState(0);
  useEffect(() => {
    ensureLoaded().then(() => setTick((n) => n + 1));
    const fn = () => setTick((n) => n + 1);
    listeners.add(fn);
    const id = setInterval(fn, 30000);
    return () => { listeners.delete(fn); clearInterval(id); };
  }, []);
  return (device) => getRuntimeStats(device);
}

// فهرس المفاتيح العادية (من غير الستائر) بتوبيك الحالة: { list: [{ key, device, board }], byTopic }
export function deviceIndex(boards = []) {
  const list = [];
  const byTopic = {};
  boards.forEach((b) => {
    if (b.type === 'irrigation') return;
    (b.devices || []).forEach((d) => {
      if (d.controlType === 'updown') return;
      const key = d.statusTopic || d.controlTopic;
      if (!key || byTopic[key]) return;
      const item = { key, device: d, board: b };
      byTopic[key] = item;
      list.push(item);
    });
  });
  return { list, byTopic };
}

// هوك: لقطة من سجل الحركة (فترات + أحداث + شغال دلوقتي)، بتتحدّث مع كل تغيّر وكل 30 ثانية.
export function useActivity() {
  const [, setTick] = useState(0);
  useEffect(() => {
    ensureLoaded().then(() => setTick((n) => n + 1));
    const fn = () => setTick((n) => n + 1);
    listeners.add(fn);
    const id = setInterval(fn, 30000);
    return () => { listeners.delete(fn); clearInterval(id); };
  }, []);
  return { periods, open: openP, events, isOn, now: Date.now() };
}
