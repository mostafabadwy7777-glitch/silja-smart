// أدوات ألوان صغيرة مشتركة — بتخلّي النصوص/الأيقونات فوق أي لون (أزرار، شريط، سويتش)
// مقروءة في كل الثيمات بدل ما نثبّت لون أسود أو أبيض.
export function hexToRgb(hex) {
  const m = /^#?([0-9a-f]{6})$/i.exec(String(hex || ''));
  if (!m) return null;
  const n = parseInt(m[1], 16);
  return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
}

export function withAlpha(hex, a) {
  const c = hexToRgb(hex);
  return c ? `rgba(${c.r},${c.g},${c.b},${Math.max(0, Math.min(1, a))})` : hex;
}

// لون النص/الأيقونة المناسب فوق خلفية بلون معيّن: بنقارن تباين WCAG مع الغامق ومع
// الأبيض ونختار الأوضح (القاعدة القديمة كانت بتدّي أبيض فوق ألوان متوسطة زي
// البرتقالي والأصفر فالكتابة كانت بتبان باهتة).
function relLum(c) {
  const f = (v) => {
    const x = v / 255;
    return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4);
  };
  return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b);
}

export function readableOn(hex) {
  const c = hexToRgb(hex);
  if (!c) return '#FFFFFF';
  const L = relLum(c);
  const darkL = relLum(hexToRgb('#10161C'));
  const contrastWhite = 1.05 / (L + 0.05);
  const contrastDark = (L + 0.05) / (darkL + 0.05);
  return contrastDark >= contrastWhite ? '#10161C' : '#FFFFFF';
}

// مزج لونين (t = 0 يرجّع a، t = 1 يرجّع b) — بنستخدمه عشان نطلّع ألوان محايدة
// (زي لون السويتش وهو مطفي) من نفس عيلة ألوان الثيم بدل رمادي ثابت.
export function mixHex(a, b, t = 0.5) {
  const A = hexToRgb(a);
  const B = hexToRgb(b);
  if (!A || !B) return a;
  const k = Math.max(0, Math.min(1, t));
  const ch = (x, y) => Math.round(x * (1 - k) + y * k).toString(16).padStart(2, '0');
  return `#${ch(A.r, B.r)}${ch(A.g, B.g)}${ch(A.b, B.b)}`;
}

// كثافة خلفية شريط التنقل من قيمة الشفافية المختارة (0..1): لحد 88% زجاج شفاف زي ما كان،
// ومن 88% لـ 100% بتزيد لحد معتم بالكامل.
export function navBarAlpha(o) {
  const v = Math.max(0, Math.min(1, Number(o) || 0));
  return v <= 0.88 ? v * 0.6 : 0.528 + ((v - 0.88) / 0.12) * 0.472;
}
