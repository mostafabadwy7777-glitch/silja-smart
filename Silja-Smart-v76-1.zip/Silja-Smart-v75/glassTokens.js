// ألوان "زجاج" مشتركة للكروت في الشاشات الفرعية: خلفية شفافة وحدود فاتحة بدل الكارت المعتم.
import { withAlpha } from './colorUtils';

// معامل الشفافية العام من شريط "شفافية الزجاج" في شاشة المظهر.
// المستوى 0.5 (الافتراضي) = المعامل 1 = الشكل الحالي بالظبط. أقل = أعتم، أكتر = أشفّ.
export const glassFactor = (theme) => {
  const t = Number.isFinite(theme && theme.glassLevel) ? theme.glassLevel : 0.5;
  return 1.6 - 1.2 * t; // 0 → 1.6 ، 0.5 → 1 ، 1 → 0.4
};
export const glassAlpha = (theme, base) => Math.max(0.05, Math.min(0.97, base * glassFactor(theme)));

export const gc = (theme, a = 0.55) => withAlpha(theme.card, glassAlpha(theme, theme.isLight ? 0.78 : a));
export const gb = (theme) => (theme.isLight ? theme.border : 'rgba(255,255,255,0.16)');
