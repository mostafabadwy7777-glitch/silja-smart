import React, { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { AppState } from 'react-native';
import { DEFAULT_THEME_ID, LIGHT_THEME_ID, CUSTOM_THEME_ID, DEFAULT_CUSTOM_THEME, getTheme } from './theme';
import {
  loadThemeId,
  saveThemeId,
  loadLastDarkThemeId,
  saveLastDarkThemeId,
  loadCustomTheme,
  saveCustomTheme,
  loadBottomNavOpacity,
  saveBottomNavOpacity,
  loadBottomNavGradient,
  saveBottomNavGradient,
  loadBottomNavSize, saveBottomNavSize, loadBottomNavLift, saveBottomNavLift,
  loadBottomNavStyle, saveBottomNavStyle,
  loadAppBg, saveAppBg, loadAppBgDim, saveAppBgDim, DEFAULT_APP_BG_DIM,
  loadOrbitSettings, saveOrbitSettings, DEFAULT_ORBIT_SETTINGS,
  loadGlassLevel, saveGlassLevel, DEFAULT_GLASS_LEVEL,
  loadTimeSky, saveTimeSky, loadDensity, saveDensity,
} from './storage';

// true = التبويب/الشاشة اللي الكومبوننت فيها ظاهرة حاليًا. TabPane بيحطها false للتبويبات المخفية
// فالحركات والمؤقتات الزخرفية بتقف فيها لحد ما التبويب يتفتح تاني (توفير بطارية).
export const PaneActiveContext = createContext(true);
export function usePaneActive() {
  return useContext(PaneActiveContext);
}

const ORBIT_DURATIONS = { slow: 6500, normal: 3600, fast: 2000 };

const ThemeContext = createContext({
  theme: getTheme(DEFAULT_THEME_ID),
  themeId: DEFAULT_THEME_ID,
  isLight: false,
  customTheme: DEFAULT_CUSTOM_THEME,
  setThemeId: () => {},
  toggleLightDark: () => {},
  updateCustomColor: () => {},
  applyCustomBase: () => {},
  resetCustomTheme: () => {},
  bottomNavOpacity: 0.90,
  bottomNavGradient: 'theme',
  bottomNavSize: 'compact', bottomNavLift: 12, setBottomNavSize: () => {}, setBottomNavLift: () => {},
  bottomNavStyle: 'classic', setBottomNavStyle: () => {},
  setBottomNavOpacity: () => {},
  setBottomNavGradient: () => {},
  appBg: null, appBgDim: 0.55, setAppBg: () => {}, setAppBgDim: () => {},
  orbitSettings: DEFAULT_ORBIT_SETTINGS, setOrbitSettings: () => {},
  motionActive: true,
  glassLevel: DEFAULT_GLASS_LEVEL, setGlassLevel: () => {},
  timeSky: false, setTimeSky: () => {},
  density: 'comfortable', setDensity: () => {},
});

export function ThemeProvider({ children }) {
  const [themeId, setThemeIdState] = useState(DEFAULT_THEME_ID);
  const [lastDarkThemeId, setLastDarkThemeId] = useState(DEFAULT_THEME_ID);
  const [customTheme, setCustomThemeState] = useState(DEFAULT_CUSTOM_THEME);
  const [bottomNavOpacity, setBottomNavOpacityState] = useState(0.90);
  const [bottomNavGradient, setBottomNavGradientState] = useState('theme');
  const [bottomNavSize, setBottomNavSizeState] = useState('compact');
  const [bottomNavLift, setBottomNavLiftState] = useState(12);
  const [bottomNavStyle, setBottomNavStyleState] = useState('classic');
  const [appBg, setAppBgState] = useState(null);
  const [appBgDim, setAppBgDimState] = useState(DEFAULT_APP_BG_DIM);
  const [orbitSettings, setOrbitSettingsState] = useState(DEFAULT_ORBIT_SETTINGS);
  const [glassLevel, setGlassLevelState] = useState(DEFAULT_GLASS_LEVEL);
  const [timeSky, setTimeSkyState] = useState(false);
  const [density, setDensityState] = useState('comfortable');
  // الحركة بتقف لوحدها لما التطبيق يروح الخلفية، أو لو المستخدم اختار "حركة أقل".
  const [appActive, setAppActive] = useState(AppState.currentState === 'active');
  useEffect(() => {
    const sub = AppState.addEventListener('change', (st) => setAppActive(st === 'active'));
    return () => sub.remove();
  }, []);
  const motionActive = appActive && orbitSettings.motion !== 'reduced';

  useEffect(() => {
    loadAppBg().then(setAppBgState).catch(() => {});
    loadAppBgDim().then(setAppBgDimState).catch(() => {});
    loadOrbitSettings().then(setOrbitSettingsState).catch(() => {});
    loadGlassLevel().then(setGlassLevelState).catch(() => {});
    loadTimeSky().then(setTimeSkyState).catch(() => {});
    loadDensity().then(setDensityState).catch(() => {});
  }, []);

  useEffect(() => {
    (async () => {
      const [saved, savedLastDark, savedCustom, savedBottomNavOpacity, savedBottomNavGradient, savedBottomNavSize, savedBottomNavLift, savedBottomNavStyle] = await Promise.all([
        loadThemeId(),
        loadLastDarkThemeId(),
        loadCustomTheme(),
        loadBottomNavOpacity(),
        loadBottomNavGradient(),
        loadBottomNavSize(), loadBottomNavLift(), loadBottomNavStyle(),
      ]);
      if (saved) setThemeIdState(saved);
      if (savedLastDark) setLastDarkThemeId(savedLastDark);
      if (savedCustom) setCustomThemeState({ ...DEFAULT_CUSTOM_THEME, ...savedCustom });
      if (Number.isFinite(savedBottomNavOpacity)) setBottomNavOpacityState(savedBottomNavOpacity);
      if (savedBottomNavGradient) setBottomNavGradientState(savedBottomNavGradient);
      if (savedBottomNavSize) setBottomNavSizeState(savedBottomNavSize);
      if (savedBottomNavStyle) setBottomNavStyleState(savedBottomNavStyle);
      if (Number.isFinite(savedBottomNavLift)) setBottomNavLiftState(savedBottomNavLift);
    })();
  }, []);

  // بيرجع شكل الثيم الكامل لأي id: ثيم جاهز من القايمة الثابتة، أو الثيم
  // المخصص (آخر ألوان حفظها المستخدم بنفسه) لو الid بتاعه "custom".
  const resolveTheme = (id) => (id === CUSTOM_THEME_ID ? customTheme : getTheme(id));

  const setThemeId = async (id) => {
    setThemeIdState(id);
    await saveThemeId(id);
    // أي ثيم غامق (سواء جاهز أو مخصص) بيتسجل كـ"آخر ثيم غامق" عشان نرجعله
    // لما نطفي الوضع النهاري بزرار التبديل السريع.
    if (!resolveTheme(id).isLight) {
      setLastDarkThemeId(id);
      await saveLastDarkThemeId(id);
    }
  };

  // تبديل سريع بين الوضع الغامق (آخر ثيم غامق كان مختار) والوضع النهاري.
  const toggleLightDark = async () => {
    if (resolveTheme(themeId).isLight) {
      await setThemeId(lastDarkThemeId || DEFAULT_THEME_ID);
    } else {
      await setThemeId(LIGHT_THEME_ID);
    }
  };

  // تعديل لون واحد بس في الثيم المخصص (زي اللون الأساسي أو لون التشغيل)
  // وحفظه فورًا. لو الثيم المخصص مش مفعّل حاليًا، بيتفعّل تلقائيًا عشان
  // المستخدم يشوف أثر التعديل على كل شاشات التطبيق على طول.
  const updateCustomColor = async (key, value) => {
    const next = { ...customTheme, [key]: value };
    setCustomThemeState(next);
    await saveCustomTheme(next);
    if (themeId !== CUSTOM_THEME_ID) {
      await setThemeId(CUSTOM_THEME_ID);
    }
  };

  // بداية سريعة: نسخ "سطح" ثيم جاهز (خلفية/كروت/حدود/نصوص) كنقطة انطلاق
  // للثيم المخصص، من غير ما نلمس الألوان الأساسية (accent/on/off) اللي
  // المستخدم يكون غيّرها بنفسه بالفعل.
  const applyCustomBase = async (baseId) => {
    const base = getTheme(baseId);
    const next = {
      ...customTheme,
      isLight: !!base.isLight,
      bg: base.bg,
      card: base.card,
      cardAlt: base.cardAlt,
      border: base.border,
      textPrimary: base.textPrimary,
      textSecondary: base.textSecondary,
      textMuted: base.textMuted,
    };
    setCustomThemeState(next);
    await saveCustomTheme(next);
    if (themeId !== CUSTOM_THEME_ID) {
      await setThemeId(CUSTOM_THEME_ID);
    }
  };

  // persist=false أثناء سحب الشريط (معاينة فورية من غير كتابة على التخزين في كل حركة)
  const setBottomNavOpacity = async (value, persist = true) => {
    const n = Number(value);
    const safe = Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0.90;
    setBottomNavOpacityState(safe);
    if (persist) await saveBottomNavOpacity(safe);
  };

  const setBottomNavGradient = async (id) => {
    setBottomNavGradientState(id);
    await saveBottomNavGradient(id);
  };

  const setBottomNavStyle = async (value) => { setBottomNavStyleState(value); await saveBottomNavStyle(value); };
  const setBottomNavSize = async (value) => { const safe = ['compact','standard','large'].includes(value) ? value : 'compact'; setBottomNavSizeState(safe); await saveBottomNavSize(safe); };
  const setBottomNavLift = async (value) => { const n = Number(value); const safe = Number.isFinite(n) ? Math.max(0,Math.min(24,n)) : 12; setBottomNavLiftState(safe); await saveBottomNavLift(safe); };

  const setAppBg = async (uri) => { setAppBgState(uri || null); await saveAppBg(uri || null); };
  const setAppBgDim = async (v) => { const n = Math.max(0, Math.min(1, Number(v) || 0)); setAppBgDimState(n); await saveAppBgDim(n); };

  // persist=false أثناء سحب الشريط (معاينة فورية من غير كتابة على التخزين في كل حركة)
  const setGlassLevel = async (value, persist = true) => {
    const n = Number(value);
    const safe = Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : DEFAULT_GLASS_LEVEL;
    setGlassLevelState(safe);
    if (persist) await saveGlassLevel(safe);
  };

  const setDensity = async (v) => { const safe = v === 'compact' ? 'compact' : 'comfortable'; setDensityState(safe); await saveDensity(safe); };
  const setTimeSky = async (on) => { setTimeSkyState(!!on); await saveTimeSky(!!on); };

  const setOrbitSettings = async (patch) => {
    const next = { ...orbitSettings, ...patch };
    setOrbitSettingsState(next);
    await saveOrbitSettings(next);
  };

  const resetCustomTheme = async () => {
    setCustomThemeState(DEFAULT_CUSTOM_THEME);
    await saveCustomTheme(DEFAULT_CUSTOM_THEME);
  };

  const baseTheme = resolveTheme(themeId);
  // الخط اللي بيلف حوالين الأيقونات: 'off' بيقفله، 'on' بيشغّله في أي ثيم،
  // 'auto' بيمشي على الثيم (Orbit Neon بس). الألوان والسرعة من إعدادات المستخدم.
  const theme = useMemo(() => {
    const { mode, colors, speed, hero, boards } = orbitSettings;
    const base = baseTheme.orbit || { colors: [baseTheme.accent, baseTheme.accentSoft || baseTheme.accent], duration: ORBIT_DURATIONS.normal };
    const custom = Array.isArray(colors) && colors.length >= 2;
    const hasSpeed = speed && speed !== 'normal';
    const cfg = {
      colors: custom ? colors : base.colors,
      custom,
      duration: hasSpeed ? ORBIT_DURATIONS[speed] : base.duration,
    };
    const { orbit: _drop, ...rest } = baseTheme;
    const out = { ...rest, glassLevel, density };
    // الخط حوالين الأيقونات
    if (mode === 'on' || (mode === 'auto' && baseTheme.orbit)) out.orbit = cfg;
    // الخط حوالين الكروت الكبيرة (مستقل عن الأيقونات)
    if (hero || boards) out.orbitFrame = { ...cfg, hero: !!hero, boards: !!boards };
    return out;
  }, [baseTheme, orbitSettings, glassLevel, density]);
  const isLight = !!theme.isLight;

  return (
    <ThemeContext.Provider
      value={{
        theme,
        themeId,
        isLight,
        customTheme,
        setThemeId,
        toggleLightDark,
        updateCustomColor,
        applyCustomBase,
        resetCustomTheme,
        bottomNavOpacity,
        bottomNavGradient, bottomNavSize, bottomNavLift, setBottomNavSize, setBottomNavLift,
        bottomNavStyle, setBottomNavStyle,
        setBottomNavOpacity,
        setBottomNavGradient,
        appBg, appBgDim, setAppBg, setAppBgDim,
        orbitSettings, setOrbitSettings, motionActive,
        glassLevel, setGlassLevel,
        timeSky, setTimeSky,
        density, setDensity,
      }}
    >
      {children}
    </ThemeContext.Provider>
  );
}

// Hook بسيط عشان أي شاشة تاخد الثيم الحالي وتقدر تغيّره
export function useTheme() {
  return useContext(ThemeContext);
}

// true = الحركات الزخرفية (الخط اللي بيلف، الموجات، النبض) شغالة.
export function useMotionActive() {
  const paneActive = useContext(PaneActiveContext);
  return useContext(ThemeContext).motionActive !== false && paneActive !== false;
}
