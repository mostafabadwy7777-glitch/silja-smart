import React, { useEffect, useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, StyleSheet } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { FONTS } from '../fonts';
import { useTheme } from '../ThemeContext';
import ConnectionStatusBanner from '../components/ConnectionStatusBanner';
import ScreenBackground from '../components/ScreenBackground';
import ScreenHeader from '../components/ScreenHeader';
import EmptyState from '../components/EmptyState';
import { showAlert } from '../components/PremiumAlert';
import { formatDuration, formatRange } from '../powerOutages';
import { formatUptime } from '../boardInfo';
import { dayMonthTime } from '../numfmt';
import { gc, gb } from '../glassTokens';

const DAY = 24 * 60 * 60 * 1000;

function fmtTime(ms) {
  try {
    return dayMonthTime(ms);
  } catch (_) {
    return new Date(ms).toISOString().slice(0, 16).replace('T', ' ');
  }
}

function ago(ts, now) {
  if (!ts) return 'لسه ماتسجلش';
  const s = Math.max(0, Math.floor((now - ts) / 1000));
  if (s < 60) return 'من لحظات';
  const m = Math.floor(s / 60);
  if (m < 60) return `من ${m} دقيقة`;
  const h = Math.floor(m / 60);
  if (h < 24) return `من ${h} ساعة`;
  const d = Math.floor(h / 24);
  return `من ${d} يوم`;
}

export default function BoardHealthScreen({ boards = [], stats = {}, outages = {}, info = {}, connected, onReset, onOpenReport, onBack }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 30000);
    return () => clearInterval(id);
  }, []);

  const confirmReset = () =>
    showAlert('تصفير السجل', 'هيتم مسح آخر ظهور وعدد الانقطاعات وسجل قطع الكهربا لكل البوردات. متأكد؟', [
      { text: 'إلغاء', style: 'cancel' },
      { text: 'تصفير', style: 'destructive', onPress: onReset },
    ]);

  const statusOf = (st) => {
    if (!connected) return { color: theme.textMuted, label: 'غير معروف', icon: 'server-network-off' };
    if (st && st.state === 'online') return { color: theme.on, label: 'متصل', icon: 'check-circle' };
    if (st && st.state === 'offline') return { color: theme.off, label: 'مقطوع', icon: 'close-circle' };
    return { color: theme.textMuted, label: 'بنتأكد...', icon: 'lan-connect' };
  };

  return (
    <SafeAreaView style={styles.safe}>
      <ScreenBackground theme={theme} />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <ScreenHeader title="صحة البوردات" onBack={onBack} />

        <ConnectionStatusBanner
          theme={theme}
          connected={!!connected}
          detail={connected ? 'الانقطاعات بتتعد طول ما التطبيق مفتوح ومتصل بس.' : 'مفيش اتصال — مش هتتسجل بيانات جديدة لحد ما الاتصال يرجع.'}
        />

        {!!onOpenReport && boards.length > 0 && (
          <TouchableOpacity style={styles.reportLink} onPress={onOpenReport} activeOpacity={0.8}>
            <MaterialCommunityIcons name="chevron-left" size={22} color={theme.textMuted} />
            <View style={{ flex: 1 }}>
              <Text style={styles.reportTitle}>⚡ تقرير الكهربا</Text>
              <Text style={styles.reportSub}>ملخص الشهر، جدول آخر 7 أيام، وتصدير السجل</Text>
            </View>
          </TouchableOpacity>
        )}

        {boards.length === 0 ? (
          <EmptyState icon="heart-pulse" title="مفيش بوردات" text="ضيف بورد وهتظهر صحته هنا." />
        ) : (
          boards.map((b) => {
            const st = stats[b.id];
            const status = statusOf(st);
            const drops = (st && st.drops) || [];
            const last24 = drops.filter((t) => now - t < DAY).length;
            const lastSeenText = st && st.state === 'online' && connected ? 'دلوقتي' : ago(st && st.lastSeen, now);
            return (
              <View key={b.id} style={styles.card}>
                <View style={styles.headRow}>
                  <View style={[styles.pill, { borderColor: status.color }]}>
                    <MaterialCommunityIcons name={status.icon} size={13} color={status.color} />
                    <Text style={[styles.pillText, { color: status.color }]}>{status.label}</Text>
                  </View>
                  <Text style={styles.name} numberOfLines={1}>{b.name || 'بورد بدون اسم'}</Text>
                </View>
                <View style={styles.statsRow}>
                  <View style={styles.stat}>
                    <Text style={styles.statValue}>{drops.length}</Text>
                    <Text style={styles.statLabel}>إجمالي الانقطاعات</Text>
                  </View>
                  <View style={styles.stat}>
                    <Text style={styles.statValue}>{last24}</Text>
                    <Text style={styles.statLabel}>آخر 24 ساعة</Text>
                  </View>
                  <View style={styles.stat}>
                    <Text style={[styles.statValue, { fontSize: 14 }]} numberOfLines={1}>{lastSeenText}</Text>
                    <Text style={styles.statLabel}>آخر ظهور</Text>
                  </View>
                </View>
                {info[b.id] && connected && (
                  <View style={styles.outBox}>
                    <Text style={styles.outTitle}>📡 معلومات الشبكة</Text>
                    {[
                      ['IP', info[b.id].ip],
                      ['الشبكة', info[b.id].ssid],
                      ['الإشارة', typeof info[b.id].rssi === 'number' ? `${info[b.id].rssi} dBm` : null],
                      ['MAC', info[b.id].mac],
                      ['مدة التشغيل', typeof info[b.id].uptime === 'number' ? formatUptime(info[b.id].uptime) : null],
                    ].filter((r) => r[1]).map(([k, v]) => (
                      <View key={k} style={styles.outRow}>
                        <Text style={styles.outTime} numberOfLines={1}>{String(v)}</Text>
                        <Text style={styles.outDur2}>{k}</Text>
                      </View>
                    ))}
                  </View>
                )}
                {(outages[b.id] || []).length > 0 && (
                  <View style={styles.outBox}>
                    <Text style={styles.outTitle}>⚡ قطع الكهربا (تقريبي ±دقيقة)</Text>
                    {(outages[b.id] || []).slice(0, 8).map((o) => (
                      <View key={o.start} style={styles.outRow}>
                        <Text style={styles.outDur}>{formatDuration(o.dur)}</Text>
                        <Text style={styles.outTime} numberOfLines={3}>{formatRange(o.start, o.end)}</Text>
                      </View>
                    ))}
                  </View>
                )}
              </View>
            );
          })
        )}

        {boards.length > 0 && (
          <TouchableOpacity style={styles.resetBtn} onPress={confirmReset} activeOpacity={0.8}>
            <MaterialCommunityIcons name="restore" size={16} color={theme.off} />
            <Text style={styles.resetText}>تصفير السجل</Text>
          </TouchableOpacity>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const getStyles = (theme) =>
  StyleSheet.create({
    safe: { flex: 1, backgroundColor: theme.bg },
    content: { paddingHorizontal: 20, paddingTop: 48, paddingBottom: 130 },
    card: { backgroundColor: gc(theme), borderColor: gb(theme), borderWidth: 1, borderRadius: 20, padding: 14, marginBottom: 12 },
    headRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10, marginBottom: 12 },
    name: { flex: 1, fontSize: 15, fontWeight: '800', color: theme.textPrimary, fontFamily: FONTS.bodyBold, textAlign: 'right' },
    pill: { flexDirection: 'row', alignItems: 'center', gap: 5, borderWidth: 1, borderRadius: 12, paddingHorizontal: 9, paddingVertical: 4 },
    pillText: { fontSize: 11.5, fontWeight: '800' },
    statsRow: { flexDirection: 'row', gap: 8 },
    stat: { flex: 1, backgroundColor: theme.cardAlt, borderRadius: 14, paddingVertical: 10, paddingHorizontal: 6, alignItems: 'center' },
    statValue: { fontSize: 20, fontWeight: '800', color: theme.textPrimary },
    statLabel: { fontSize: 10.5, color: theme.textMuted, marginTop: 3, textAlign: 'center' },
    outBox: { marginTop: 12, backgroundColor: theme.cardAlt, borderRadius: 14, padding: 10 },
    outTitle: { fontSize: 12, fontWeight: '800', color: theme.textPrimary, textAlign: 'right', marginBottom: 6 },
    outRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 8, paddingVertical: 4 },
    outDur: { fontSize: 12.5, fontWeight: '800', color: theme.off },
    outTime: { flex: 1, fontSize: 11.5, color: theme.textMuted, textAlign: 'left' },
    reportLink: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: gc(theme), borderColor: gb(theme), borderWidth: 1, borderRadius: 18, padding: 14, marginBottom: 12 },
    reportTitle: { fontSize: 14, fontWeight: '800', color: theme.textPrimary, textAlign: 'right' },
    reportSub: { fontSize: 11.5, color: theme.textMuted, textAlign: 'right', marginTop: 2 },
    outDur2: { fontSize: 12, fontWeight: '800', color: theme.textPrimary },
    resetBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 12, marginTop: 6 },
    resetText: { fontSize: 13, fontWeight: '800', color: theme.off },
  });
