import React, { useMemo, useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, StyleSheet } from 'react-native';
import TouchableOpacity from '../components/AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';
import ScreenBackground from '../components/ScreenBackground';
import ScreenHeader from '../components/ScreenHeader';
import EmptyState from '../components/EmptyState';
import { showAlert } from '../components/PremiumAlert';
import { showToast } from '../components/Toast';
import { getDeviceIcon } from '../deviceIcons';
import { useActivity, deviceIndex, formatRuntime } from '../runtimeTracker';
import { clock12, shortDateTime, dayMonth } from '../numfmt';
import { gc, gb } from '../glassTokens';

const DAY = 24 * 60 * 60 * 1000;
const TABS = [
  ['timeline', 'الجدول الزمني', 'chart-timeline'],
  ['now', 'شغال دلوقتي', 'flash'],
  ['log', 'سجل الحركة', 'history'],
];
const LOG_FILTERS = [['all', 'الكل'], ['app', 'من التطبيق'], ['ext', 'من برا التطبيق']];
const HOUR_TICKS = ['0', '6', '12', '18', '24'];

const startOfDay = (ms) => {
  const d = new Date(ms);
  return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
};
const dayName = (off, ms) => (off === 0 ? 'النهارده' : off === 1 ? 'أمس' : dayMonth(ms));

// فترات التشغيل (المقفولة + الجارية) لمفتاح واحد، مقصوصة على [from, to].
function segmentsFor(act, topic, from, to) {
  const segs = [];
  (act.periods[topic] || []).forEach(([s, e]) => {
    const a = Math.max(s, from);
    const b = Math.min(e, to);
    if (b > a) segs.push([a, b]);
  });
  const o = act.open[topic];
  if (o) {
    const a = Math.max(o, from);
    const b = Math.min(act.now, to);
    if (b > a) segs.push([a, b]);
  }
  return segs;
}

export default function ActivityScreen({ boards = [], client, connected, onBack }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);
  const act = useActivity();
  const [tab, setTab] = useState('timeline');
  const [dayOff, setDayOff] = useState(0);
  const [logFilter, setLogFilter] = useState('all');
  const { list, byTopic } = useMemo(() => deviceIndex(boards), [boards]);

  // ---------- الجدول الزمني ----------
  const dayStart = startOfDay(act.now - dayOff * DAY);
  const dayEnd = dayStart + DAY;
  const rows = list
    .map((x) => {
      const segs = segmentsFor(act, x.key, dayStart, dayEnd);
      const total = segs.reduce((n, [a, b]) => n + (b - a), 0);
      return { ...x, segs, total };
    })
    .filter((r) => r.total > 0)
    .sort((a, b) => b.total - a.total);
  const idleCount = list.length - rows.length;
  const grandTotal = rows.reduce((n, r) => n + r.total, 0);

  const renderTimeline = () => (
    <>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.chipsRow}>
        {[0, 1, 2, 3, 4, 5, 6].map((off) => (
          <TouchableOpacity key={off} style={[styles.chip, dayOff === off && styles.chipOn]} onPress={() => setDayOff(off)} activeOpacity={0.8}>
            <Text style={[styles.chipText, dayOff === off && styles.chipTextOn]}>{dayName(off, act.now - off * DAY)}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <View style={styles.summaryCard}>
        <View style={styles.summaryCol}>
          <Text style={styles.summaryValue}>{rows.length}</Text>
          <Text style={styles.summaryLabel}>جهاز اشتغل</Text>
        </View>
        <View style={styles.summaryDivider} />
        <View style={styles.summaryCol}>
          <Text style={styles.summaryValue}>{formatRuntime(grandTotal / 1000)}</Text>
          <Text style={styles.summaryLabel}>إجمالي التشغيل</Text>
        </View>
      </View>

      {rows.length === 0 ? (
        <EmptyState icon="chart-timeline" title="مفيش نشاط مسجّل" text="بيتسجل طول ما التطبيق مفتوح ومتصل. افتح التطبيق وشغّل أي مفتاح وهيظهر هنا." />
      ) : (
        rows.map((r) => (
          <View key={r.key} style={styles.tlCard}>
            <View style={styles.tlHead}>
              <Text style={styles.tlTotal}>{formatRuntime(r.total / 1000)}</Text>
              <View style={{ flex: 1 }}>
                <Text numberOfLines={1} style={styles.tlName}>{r.device.name || 'مفتاح'}</Text>
                <Text numberOfLines={1} style={styles.tlBoard}>{r.board.name || 'بورد'}</Text>
              </View>
              <MaterialCommunityIcons name={getDeviceIcon(r.device.icon).icon} size={22} color={theme.accentSoft} />
            </View>
            <View style={styles.bar}>
              {r.segs.map(([a, b], i) => (
                <View
                  key={i}
                  style={[styles.seg, { left: `${((a - dayStart) / DAY) * 100}%`, width: `${Math.max(0.8, ((b - a) / DAY) * 100)}%` }]}
                />
              ))}
            </View>
          </View>
        ))
      )}

      {rows.length > 0 && (
        <View style={styles.axis}>
          {HOUR_TICKS.map((t) => <Text key={t} style={styles.axisText}>{t}</Text>)}
        </View>
      )}
      {idleCount > 0 && rows.length > 0 ? <Text style={styles.note}>{idleCount} جهاز تاني مااشتغلش في اليوم ده.</Text> : null}
      <Text style={styles.note}>الأوقات تقريبية: بتتسجل بس وقت ما التطبيق مفتوح ومتصل بالسيرفر.</Text>
    </>
  );

  // ---------- شغال دلوقتي ----------
  const onNow = list
    .filter((x) => act.isOn[x.key])
    .map((x) => ({ ...x, since: act.open[x.key] || null }))
    .sort((a, b) => (a.since || act.now) - (b.since || act.now));

  const send = (x) => {
    if (!connected || !client) { showAlert('الاتصال غير متاح', 'اتأكد إن التطبيق متصل بالسيرفر وحاول تاني.'); return; }
    if (!x.device.controlTopic) return;
    client.publish(x.device.controlTopic, 'OFF', { qos: 1 }, (err) => {
      if (err) showAlert('فشل إرسال الأمر', 'راجع الاتصال وحاول تاني.');
      else showToast('تم الإرسال');
    });
  };
  const offAll = () => {
    if (!connected || !client) { showAlert('الاتصال غير متاح', 'اتأكد إن التطبيق متصل بالسيرفر وحاول تاني.'); return; }
    showAlert('إطفاء الكل', `هيتم إطفاء ${onNow.length} مفتاح شغال. متأكد؟`, [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'إطفاء الكل',
        style: 'destructive',
        onPress: () => {
          onNow.forEach((x) => { if (x.device.controlTopic) client.publish(x.device.controlTopic, 'OFF', { qos: 1 }); });
          showToast('تم إرسال أمر إطفاء الكل');
        },
      },
    ]);
  };

  const renderNow = () => (
    <>
      {onNow.length === 0 ? (
        <EmptyState icon="flash-off-outline" title="مفيش حاجة شغالة" text={connected ? 'كل المفاتيح مطفية دلوقتي.' : 'مفيش اتصال بالسيرفر — الحالة مش محدثة.'} />
      ) : (
        <>
          <View style={styles.nowHead}>
            <TouchableOpacity style={styles.offAllBtn} onPress={offAll} activeOpacity={0.8}>
              <MaterialCommunityIcons name="power" size={16} color={theme.off || '#E5484D'} />
              <Text style={[styles.offAllText, { color: theme.off || '#E5484D' }]}>إطفاء الكل</Text>
            </TouchableOpacity>
            <Text style={styles.nowCount}>{onNow.length} شغال دلوقتي</Text>
          </View>
          {onNow.map((x) => (
            <View key={x.key} style={styles.nowRow}>
              <TouchableOpacity onPress={() => send(x)} style={styles.rowOffBtn} activeOpacity={0.8}>
                <MaterialCommunityIcons name="power" size={18} color={theme.off || '#E5484D'} />
              </TouchableOpacity>
              <View style={{ flex: 1 }}>
                <Text numberOfLines={1} style={styles.nowName}>{x.device.name || 'مفتاح'}</Text>
                <Text numberOfLines={1} style={styles.nowSub}>
                  {x.board.name || 'بورد'}
                  {x.since ? `  •  بقاله ${formatRuntime((act.now - x.since) / 1000)} (من ${clock12(x.since)})` : ''}
                </Text>
              </View>
              <View style={styles.nowIcon}>
                <MaterialCommunityIcons name={getDeviceIcon(x.device.icon).icon} size={22} color={theme.on} />
              </View>
            </View>
          ))}
        </>
      )}
    </>
  );

  // ---------- سجل الحركة ----------
  const logItems = act.events
    .filter((e) => byTopic[e.topic] && (logFilter === 'all' || e.src === logFilter))
    .slice()
    .reverse()
    .slice(0, 200);

  const renderLog = () => {
    let lastDay = '';
    return (
      <>
        <View style={styles.chipsRowStatic}>
          {LOG_FILTERS.map(([k, label]) => (
            <TouchableOpacity key={k} style={[styles.chip, logFilter === k && styles.chipOn]} onPress={() => setLogFilter(k)} activeOpacity={0.8}>
              <Text style={[styles.chipText, logFilter === k && styles.chipTextOn]}>{label}</Text>
            </TouchableOpacity>
          ))}
        </View>
        {logItems.length === 0 ? (
          <EmptyState icon="history" title="مفيش حركة مسجّلة" text="أي مفتاح يتشغل أو يتقفل وانت فاتح التطبيق هيتسجل هنا، مع معرفة مين اللي عمله." />
        ) : (
          logItems.map((e, i) => {
            const x = byTopic[e.topic];
            const off = Math.floor((startOfDay(act.now) - startOfDay(e.ts)) / DAY);
            const label = dayName(off, e.ts);
            const header = label !== lastDay;
            lastDay = label;
            return (
              <View key={`${e.ts}-${e.topic}-${i}`}>
                {header ? <Text style={styles.dayHeader}>{label}</Text> : null}
                <View style={styles.logRow}>
                  <View style={{ alignItems: 'flex-start', minWidth: 62 }}>
                    <Text style={styles.logTime}>{clock12(e.ts)}</Text>
                    <View style={[styles.srcBadge, e.src === 'app' && styles.srcBadgeApp]}>
                      <MaterialCommunityIcons name={e.src === 'app' ? 'cellphone' : 'light-switch'} size={11} color={e.src === 'app' ? theme.accentSoft : theme.textSecondary} />
                      <Text style={[styles.srcText, e.src === 'app' && { color: theme.accentSoft }]}>{e.src === 'app' ? 'التطبيق' : 'برا التطبيق'}</Text>
                    </View>
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text numberOfLines={1} style={styles.logName}>{x.device.name || 'مفتاح'}</Text>
                    <Text numberOfLines={1} style={[styles.logState, { color: e.on ? theme.on : theme.textMuted }]}>
                      {e.on ? 'اتشغّل' : 'اتقفل'}  •  {x.board.name || 'بورد'}
                    </Text>
                  </View>
                  <View style={[styles.logIcon, { borderColor: e.on ? theme.on : theme.border }]}>
                    <MaterialCommunityIcons name={getDeviceIcon(x.device.icon).icon} size={20} color={e.on ? theme.on : theme.textSecondary} />
                  </View>
                </View>
              </View>
            );
          })
        )}
        <Text style={styles.note}>"برا التطبيق" = مفتاح الحيطة أو جدولة السيرفر أو موبايل تاني. بيتسجل بس وقت ما التطبيق مفتوح.</Text>
      </>
    );
  };

  return (
    <SafeAreaView style={styles.safe}>
      <ScreenBackground theme={theme} />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <ScreenHeader title="التحركات" onBack={onBack} />
        <View style={styles.tabs}>
          {TABS.map(([k, label, icon]) => (
            <TouchableOpacity key={k} style={[styles.tab, tab === k && styles.tabOn]} onPress={() => setTab(k)} activeOpacity={0.8}>
              <MaterialCommunityIcons name={icon} size={16} color={tab === k ? theme.accent : theme.textMuted} />
              <Text style={[styles.tabText, tab === k && styles.tabTextOn]} numberOfLines={1}>{label}</Text>
            </TouchableOpacity>
          ))}
        </View>
        {tab === 'timeline' ? renderTimeline() : tab === 'now' ? renderNow() : renderLog()}
      </ScrollView>
    </SafeAreaView>
  );
}

function getStyles(theme) {
  const card = { backgroundColor: gc(theme), borderRadius: 18, borderWidth: 1, borderColor: gb(theme) };
  return StyleSheet.create({
    safe: { flex: 1, backgroundColor: theme.bg },
    content: { paddingHorizontal: 20, paddingTop: 48, paddingBottom: 130 },
    tabs: { flexDirection: 'row', gap: 8, marginTop: 6, marginBottom: 14 },
    tab: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 5, paddingVertical: 10, borderRadius: 14, borderWidth: 1, borderColor: gb(theme), backgroundColor: gc(theme) },
    tabOn: { borderColor: theme.accent, backgroundColor: theme.cardAlt },
    tabText: { color: theme.textMuted, fontSize: 12, fontWeight: '700' },
    tabTextOn: { color: theme.textPrimary },
    chipsRow: { gap: 8, paddingBottom: 12, flexDirection: 'row' },
    chipsRowStatic: { flexDirection: 'row', gap: 8, paddingBottom: 12 },
    chip: { paddingVertical: 8, paddingHorizontal: 14, borderRadius: 999, borderWidth: 1, borderColor: gb(theme), backgroundColor: gc(theme) },
    chipOn: { borderColor: theme.accent, backgroundColor: theme.cardAlt },
    chipText: { color: theme.textSecondary, fontSize: 12.5, fontWeight: '700' },
    chipTextOn: { color: theme.textPrimary },
    summaryCard: { ...card, flexDirection: 'row', alignItems: 'center', paddingVertical: 14, marginBottom: 12 },
    summaryCol: { flex: 1, alignItems: 'center' },
    summaryDivider: { width: 1, height: 34, backgroundColor: theme.border },
    summaryValue: { color: theme.textPrimary, fontSize: 22, fontWeight: '800' },
    summaryLabel: { color: theme.textSecondary, fontSize: 11.5, marginTop: 2 },
    tlCard: { ...card, padding: 12, marginBottom: 10 },
    tlHead: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 10 },
    tlName: { color: theme.textPrimary, fontSize: 14, fontWeight: '800', textAlign: 'right' },
    tlBoard: { color: theme.textSecondary, fontSize: 11.5, textAlign: 'right', marginTop: 1 },
    tlTotal: { color: theme.on, fontSize: 13, fontWeight: '800' },
    bar: { height: 12, borderRadius: 6, backgroundColor: theme.cardAlt, overflow: 'hidden', direction: 'ltr' },
    seg: { position: 'absolute', top: 0, bottom: 0, borderRadius: 6, backgroundColor: theme.on },
    axis: { flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 4, marginBottom: 6, direction: 'ltr' },
    axisText: { color: theme.textMuted, fontSize: 10.5 },
    note: { color: theme.textSecondary, fontSize: 11.5, textAlign: 'right', marginTop: 8, lineHeight: 17 },
    nowHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
    nowCount: { color: theme.textPrimary, fontSize: 14, fontWeight: '800' },
    offAllBtn: { flexDirection: 'row', alignItems: 'center', gap: 5, paddingVertical: 7, paddingHorizontal: 12, borderRadius: 999, borderWidth: 1, borderColor: gb(theme), backgroundColor: gc(theme) },
    offAllText: { fontSize: 12.5, fontWeight: '800' },
    nowRow: { ...card, flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, marginBottom: 8 },
    nowName: { color: theme.textPrimary, fontSize: 14, fontWeight: '800', textAlign: 'right' },
    nowSub: { color: theme.textSecondary, fontSize: 11.5, textAlign: 'right', marginTop: 2 },
    nowIcon: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: theme.on, backgroundColor: theme.cardAlt },
    rowOffBtn: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', borderWidth: 1, borderColor: gb(theme), backgroundColor: theme.cardAlt },
    dayHeader: { color: theme.textSecondary, fontSize: 12, fontWeight: '800', textAlign: 'right', marginTop: 10, marginBottom: 6 },
    logRow: { ...card, flexDirection: 'row', alignItems: 'center', gap: 12, padding: 11, marginBottom: 7 },
    logTime: { color: theme.textPrimary, fontSize: 12.5, fontWeight: '800' },
    logName: { color: theme.textPrimary, fontSize: 14, fontWeight: '800', textAlign: 'right' },
    logState: { fontSize: 12, textAlign: 'right', marginTop: 2 },
    logIcon: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', borderWidth: 1, backgroundColor: theme.cardAlt },
    srcBadge: { flexDirection: 'row', alignItems: 'center', gap: 3, marginTop: 4, paddingVertical: 2, paddingHorizontal: 6, borderRadius: 999, backgroundColor: theme.cardAlt },
    srcBadgeApp: { backgroundColor: theme.cardAlt },
    srcText: { color: theme.textSecondary, fontSize: 9.5, fontWeight: '700' },
  });
}
