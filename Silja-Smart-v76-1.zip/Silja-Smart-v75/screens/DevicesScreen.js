import React, { useEffect, useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, TextInput, StyleSheet } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import TouchableOpacity from '../components/AnimatedTouchable';
import { useTheme } from '../ThemeContext';
import { getDeviceIcon } from '../deviceIcons';
import { boardAvailabilityTopic, parseAvailability } from '../discovery';
import { useBoardRssi, rssiInfo } from '../boardRssi';
import ConnectionStatusBanner from '../components/ConnectionStatusBanner';
import { FONTS } from '../fonts';
import ScreenBackground from '../components/ScreenBackground';
import { readableOn } from '../colorUtils';
import { LinearGradient } from 'expo-linear-gradient';
import DeviceGlyph from '../components/DeviceGlyph';
import EmptyState from '../components/EmptyState';
import { showAlert } from '../components/PremiumAlert';
import { showToast } from '../components/Toast';
import { useLastKnown, formatAge } from '../lastKnown';
import { pressFeedback, sentFeedback, errorFeedback } from '../feedback';
import FadeInView from '../components/FadeInView';
import { loadRoomBgs } from '../storage';
import { gradientById, autoGradientFor } from '../components/roomBackgrounds';

export default function DevicesScreen({ boards = [], client, connected = false, onOpenBoard, onBack }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);
  const devices = boards.flatMap((board) => (board.devices || []).map((device) => ({ ...device, board })));
  const [availability, setAvailability] = useState({});
  const [states, setStates] = useState({});
  const rssiMap = useBoardRssi(client, connected, boards); // قوة الواي فاي لكل بورد
  const getKnown = useLastKnown(); // آخر حالة معروفة لما الحالة الحية مش متاحة
  const [selected, setSelected] = useState(null);
  // لون كل غرفة (نفس تدرج خلفية الغرفة في الرئيسية) بيتحط كلمسة خفيفة ورا كروت الغرفة.
  const [roomBgs, setRoomBgs] = useState({});
  useEffect(() => { loadRoomBgs().then(setRoomBgs).catch(() => {}); }, []);
  const roomTint = (room) => {
    if (!room) return null;
    const bg = roomBgs[room];
    const grad = bg && bg.type === 'gradient' ? (gradientById(bg.id) || autoGradientFor(room)) : autoGradientFor(room);
    return grad.colors[1];
  };
  // حالة البورد: availability الصريحة أولًا، وإلا لو وصلت أي حالة من مفاتيحه يبقى متصل فعلًا.
  const boardState = (board) => {
    const a = availability[boardAvailabilityTopic(board)];
    if (a === 'offline') return 'offline';
    if (a === 'online') return 'online';
    return (board.devices || []).some((d) => states[d.statusTopic || d.controlTopic] !== undefined) ? 'online' : null;
  };
  // الفلتر: 'all' | 'room:<اسم الغرفة>' | 'none' (بدون غرفة) | 'board:<id>' (لو مفيش غرف متحددة)
  const [filterKey, setFilterKey] = useState('all');
  const [query, setQuery] = useState('');
  const q = query.trim().toLowerCase();
  const roomOf = (device) => String(device.room || '').trim();
  const rooms = Array.from(new Set(devices.map(roomOf).filter(Boolean)));
  const hasRooms = rooms.length > 0;
  const hasUnassigned = devices.some((d) => !roomOf(d));
  const matchesFilter = (device) => {
    if (filterKey === 'all') return true;
    if (filterKey === 'none') return !roomOf(device);
    if (filterKey.startsWith('room:')) return roomOf(device) === filterKey.slice(5);
    if (filterKey.startsWith('board:')) return String(device.board.id) === filterKey.slice(6);
    return true;
  };
  const visibleDevices = devices
    .filter(matchesFilter)
    .filter((device) => !q || String(device.name || '').toLowerCase().includes(q) || String(device.board?.name || '').toLowerCase().includes(q) || roomOf(device).toLowerCase().includes(q));
  // تجميع المعروض حسب الغرفة (الغرف الأول بترتيب ظهورها، وبعدها "بدون غرفة").
  const groups = hasRooms
    ? [...rooms, ''].map((room) => ({ room, items: visibleDevices.filter((d) => roomOf(d) === room) })).filter((g) => g.items.length > 0)
    : [];

  // إطفاء كل مفاتيح الغرفة (حتى لو على أكتر من بورد). الستائر بتتوقف، والطوارئ/الجرس مش بيتلمسوا.
  const turnOffRoom = (room, items) => {
    const targets = items.filter((d) => d.controlTopic && !getDeviceIcon(d.icon)?.isEmergency && d.icon !== 'bell');
    if (targets.length === 0) return;
    if (!client || !connected) {
      showAlert('الاتصال غير متاح', 'لا يمكن إطفاء الغرفة الآن. اتأكد إن التطبيق متصل بالسيرفر وحاول تاني.');
      return;
    }
    showAlert(`إطفاء ${room}`, `هيتم إيقاف ${targets.length} مفتاح في الغرفة دي (والستائر هتتوقف). متأكد؟`, [
      { text: 'إلغاء', style: 'cancel' },
      {
        text: 'إطفاء الغرفة',
        style: 'destructive',
        onPress: () => {
          if (!client || !connected) {
            showAlert('الاتصال غير متاح', 'لا يمكن إطفاء الغرفة الآن. اتأكد إن التطبيق متصل بالسيرفر وحاول تاني.');
            return;
          }
          pressFeedback();
          let pending = targets.length;
          let failed = 0;
          const done = () => {
            pending -= 1;
            if (pending > 0) return;
            if (failed > 0) { errorFeedback(); showAlert('إطفاء الغرفة', `فشل إرسال ${failed} من ${targets.length} أمر. راجع الاتصال وحاول تاني.`); }
            else { sentFeedback(); showToast(`تم إرسال أمر إطفاء ${room}`); }
          };
          targets.forEach((d) => {
            try {
              client.publish(d.controlTopic, d.controlType === 'updown' ? 'STOP' : 'OFF', { qos: 1 }, (error) => {
                if (error) failed += 1;
                done();
              });
            } catch (_) { failed += 1; done(); }
          });
        },
      },
    ]);
  };

  useEffect(() => {
    if (!client || !connected) { setAvailability({}); return undefined; }
    const topics = boards.map(boardAvailabilityTopic).filter(Boolean);
    topics.forEach((t) => client.subscribe(t));
    const handler = (topic, payload) => {
      const state = parseAvailability(payload.toString());
      if (state) setAvailability((prev) => ({ ...prev, [topic]: state }));
    };
    client.on('message', handler);
    return () => { client.off('message', handler); topics.forEach((t) => client.unsubscribe(t)); };
  }, [client, connected, boards]);

  useEffect(() => {
    if (!client || !connected) { setStates({}); return undefined; }
    const topics = Array.from(new Set(devices.map((d) => d.statusTopic || d.controlTopic).filter(Boolean)));
    topics.forEach((t) => client.subscribe(t));
    const handler = (topic, payload) => {
      const raw = payload.toString().trim();
      let value = raw.toUpperCase();
      try { const data = JSON.parse(raw); value = String(data.state ?? data.status ?? data.value ?? data.on ?? '').toUpperCase(); } catch (_) {}
      if (value === 'ON' || value === '1' || value === 'TRUE') setStates((p) => ({ ...p, [topic]: true }));
      if (value === 'OFF' || value === '0' || value === 'FALSE') setStates((p) => ({ ...p, [topic]: false }));
    };
    client.on('message', handler);
    return () => { client.off('message', handler); topics.forEach((t) => client.unsubscribe(t)); };
  }, [client, connected, boards, devices.length]);

  const renderCard = (device) => {
    const meta = getDeviceIcon(device.icon);
    const availabilityState = boardState(device.board);
    const sig = availabilityState === 'online' ? rssiInfo(rssiMap[device.board.id], theme) : null;
    const topic = device.statusTopic || device.controlTopic;
    const liveStatus = states[topic];
    // لو الحالة الحية مش موجودة (انقطاع الاتصال أو لسه ماوصلتش) بنعرض آخر حالة معروفة بعلامة "قديمة".
    const known = typeof liveStatus === 'boolean' || device.controlType === 'updown' ? undefined : getKnown(topic);
    const isStale = !!known;
    const status = typeof liveStatus === 'boolean' ? liveStatus : known ? known.on : undefined;
    const statusColor = isStale ? theme.textMuted : status === true ? theme.on : status === false ? theme.off : theme.textMuted;
    return (
      <TouchableOpacity key={`${device.board.id}-${device.id}`} onPress={() => setSelected(device)} style={[styles.card, status === true && { borderColor: theme.accentSoft }]}>
        <LinearGradient
          pointerEvents="none"
          colors={[status === true ? `${theme.accentSoft}2E` : `${theme.accentSoft}12`, 'transparent']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, borderRadius: 22 }}
        />
        <View style={[styles.iconBox, { borderColor: status === true ? theme.accentSoft : `${theme.accent}55`, backgroundColor: status === true ? `${theme.accentSoft}1F` : theme.cardAlt }]}>
          <DeviceGlyph icon={meta?.icon || 'light-switch'} size={26} color={status === true ? theme.accentSoft : theme.textSecondary} isOn={status === true} />
        </View>
        <View style={styles.info}>
          <Text style={styles.name} numberOfLines={1}>{device.name || 'جهاز بدون اسم'}</Text>
          <Text style={styles.board} numberOfLines={1}>{device.board.name || 'البورد'}{device.board.ip ? `  •  ${device.board.ip}` : ''}</Text>
          <View style={styles.statusRow}>
            <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
            <Text style={[styles.statusText, { color: statusColor }]}>{status === true ? 'يعمل' : status === false ? 'متوقف' : 'غير معروف'}{isStale ? ` ⚠ قديمة · ${formatAge(known.ts)}` : ''}</Text>
            <Text style={styles.sep}>•</Text>
            <Text style={[styles.statusText, { color: availabilityState === 'online' ? (sig ? sig.color : theme.on) : availabilityState === 'offline' ? theme.off : theme.textMuted }]}>{availabilityState === 'online' ? (sig ? `البورد متصل · واي فاي ${sig.label}` : 'البورد متصل') : availabilityState === 'offline' ? 'البورد غير متصل' : connected ? 'بانتظار رد البورد' : 'غير متصل بالسيرفر'}</Text>
          </View>
        </View>
        <MaterialCommunityIcons name="chevron-left" size={22} color={theme.textMuted} />
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={styles.safe}>
      <ScreenBackground theme={theme} />
      <ScrollView contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <TouchableOpacity onPress={onBack} style={styles.back} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
            <MaterialCommunityIcons name="chevron-right" size={26} color={theme.accentSoft} />
          </TouchableOpacity>
          <Text style={styles.title}>الأجهزة</Text>
          <View style={styles.back} />
        </View>

        <ConnectionStatusBanner theme={theme} connected={connected} detail={connected ? 'حالة كل بورد وجهاز تظهر بشكل منفصل.' : undefined} />

        {devices.length > 0 && (
          <View style={styles.searchBox}>
            <MaterialCommunityIcons name="magnify" size={19} color={theme.textMuted} />
            <TextInput
              style={styles.searchInput}
              value={query}
              onChangeText={setQuery}
              placeholder="بحث عن جهاز..."
              placeholderTextColor={theme.textMuted}
              textAlign="right"
            />
          </View>
        )}

        {devices.length > 0 && (
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.roomFilters}>
            <TouchableOpacity onPress={() => setFilterKey('all')} style={[styles.roomChip, filterKey === 'all' && styles.roomChipActive]}>
              <MaterialCommunityIcons name="view-grid-outline" size={15} color={filterKey === 'all' ? readableOn(theme.accent) : theme.textSecondary} />
              <Text style={[styles.roomChipText, filterKey === 'all' && styles.roomChipTextActive]}>كل الأجهزة</Text>
            </TouchableOpacity>
            {hasRooms ? (
              <>
                {rooms.map((room) => {
                  const key = `room:${room}`;
                  const active = filterKey === key;
                  return (
                    <TouchableOpacity key={key} onPress={() => setFilterKey(key)} style={[styles.roomChip, active && styles.roomChipActive]}>
                      <MaterialCommunityIcons name="door" size={15} color={active ? readableOn(theme.accent) : theme.textSecondary} />
                      <Text style={[styles.roomChipText, active && styles.roomChipTextActive]} numberOfLines={1}>{room}</Text>
                    </TouchableOpacity>
                  );
                })}
                {hasUnassigned && (
                  <TouchableOpacity onPress={() => setFilterKey('none')} style={[styles.roomChip, filterKey === 'none' && styles.roomChipActive]}>
                    <MaterialCommunityIcons name="help-circle-outline" size={15} color={filterKey === 'none' ? readableOn(theme.accent) : theme.textSecondary} />
                    <Text style={[styles.roomChipText, filterKey === 'none' && styles.roomChipTextActive]}>بدون غرفة</Text>
                  </TouchableOpacity>
                )}
              </>
            ) : (
              boards.map((board) => {
                const key = `board:${board.id}`;
                const active = filterKey === key;
                return (
                  <TouchableOpacity key={key} onPress={() => setFilterKey(key)} style={[styles.roomChip, active && styles.roomChipActive]}>
                    <MaterialCommunityIcons name="home-outline" size={15} color={active ? readableOn(theme.accent) : theme.textSecondary} />
                    <Text style={[styles.roomChipText, active && styles.roomChipTextActive]} numberOfLines={1}>{board.name || 'غرفة'}</Text>
                  </TouchableOpacity>
                );
              })
            )}
          </ScrollView>
        )}

        {devices.length === 0 ? (
          <EmptyState icon="devices" title="لا توجد أجهزة" text="أضف بوردًا ثم أضف المفاتيح والأجهزة الخاصة به." />
        ) : visibleDevices.length === 0 ? (
          <EmptyState icon="home-search-outline" title="لا توجد أجهزة هنا" text="اختار غرفة تانية أو اعرض كل الأجهزة." actionLabel="عرض كل الأجهزة" onAction={() => { setFilterKey('all'); setQuery(''); }} />
        ) : (
          hasRooms ? groups.map((g, gi) => {
            const onCount = g.items.filter((d) => states[d.statusTopic || d.controlTopic] === true).length;
            const tint = roomTint(g.room);
            return (
              <FadeInView key={`room-${g.room || 'none'}`} delay={Math.min(gi, 6) * 90} distance={14}>
              <View style={[styles.roomSection, tint && { borderRadius: 22, borderWidth: 1, borderColor: `${tint}40`, padding: 10, overflow: 'hidden', marginBottom: 12 }]}>
                {!!tint && <LinearGradient pointerEvents="none" colors={[`${tint}${theme.isLight ? '1F' : '2B'}`, `${tint}08`]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />}
                <View style={styles.roomHeader}>
                  <View style={styles.roomHeaderInfo}>
                    <Text style={styles.roomTitle} numberOfLines={1}>{g.room || 'بدون غرفة'}</Text>
                    <Text style={styles.roomMeta}>{g.items.length} جهاز{onCount > 0 ? `  •  ${onCount} شغال` : ''}</Text>
                  </View>
                  {!!g.room && (
                    <TouchableOpacity onPress={() => turnOffRoom(g.room, g.items)} style={[styles.roomOffBtn, { borderColor: theme.accentSoft }]}>
                      <MaterialCommunityIcons name="power" size={15} color={theme.accentSoft} />
                      <Text style={[styles.roomOffText, { color: theme.accentSoft }]}>إطفاء الغرفة</Text>
                    </TouchableOpacity>
                  )}
                </View>
                {g.items.map(renderCard)}
              </View>
              </FadeInView>
            );
          }) : visibleDevices.map(renderCard)
        )}

      </ScrollView>
      {selected && (
        <View style={styles.overlay}>
          <TouchableOpacity style={styles.overlayBg} onPress={() => setSelected(null)} />
          <View style={styles.modal}>
            <LinearGradient pointerEvents="none" colors={[`${theme.accent}30`, `${theme.accent}08`]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
            <LinearGradient pointerEvents="none" colors={[theme.isLight ? 'rgba(255,255,255,0.6)' : 'rgba(255,255,255,0.16)', 'rgba(255,255,255,0)']} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 0.45 }} style={StyleSheet.absoluteFill} />
            <View style={styles.modalIcon}><MaterialCommunityIcons name={getDeviceIcon(selected.icon)?.icon || 'light-switch'} size={32} color={theme.accent} /></View>
            <Text style={styles.modalTitle}>{selected.name || 'جهاز بدون اسم'}</Text>
            <Text style={styles.modalBoard}>{selected.board.name || 'البورد'}</Text>
            <View style={styles.detailRow}><Text style={styles.detailLabel}>حالة البورد</Text><Text style={[styles.detailValue, { color: boardState(selected.board) === 'online' ? theme.on : boardState(selected.board) === 'offline' ? theme.off : theme.textMuted }]}>{boardState(selected.board) === 'online' ? 'متصل' : boardState(selected.board) === 'offline' ? 'غير متصل' : connected ? 'بانتظار رد البورد' : 'غير متصل بالسيرفر'}</Text></View>
            <View style={styles.detailRow}><Text style={styles.detailLabel}>حالة الجهاز</Text><Text style={[styles.detailValue, { color: states[selected.statusTopic || selected.controlTopic] === true ? theme.on : states[selected.statusTopic || selected.controlTopic] === false ? theme.textSecondary : theme.textMuted }]}>{states[selected.statusTopic || selected.controlTopic] === true ? 'ON' : states[selected.statusTopic || selected.controlTopic] === false ? 'OFF' : 'غير معروفة'}</Text></View>
            <TouchableOpacity style={[styles.openBoardBtn, { backgroundColor: theme.accent }]} onPress={() => { setSelected(null); onOpenBoard?.(selected.board); }}><Text style={styles.openBoardText}>فتح البورد والتحكم</Text></TouchableOpacity>
            <TouchableOpacity style={styles.closeBtn} onPress={() => setSelected(null)}><Text style={styles.closeText}>إغلاق</Text></TouchableOpacity>
          </View>
        </View>
      )}
    </SafeAreaView>
  );
}

const getStyles = (theme) => { const cp = theme.density === 'compact'; return StyleSheet.create({
  safe: { flex: 1, backgroundColor: theme.bg },
  content: { paddingHorizontal: 20, paddingTop: 18, paddingBottom: 132 },
  back: { width: 36, height: 36, alignItems: 'center', justifyContent: 'center' },
  backText: { color: theme.textSecondary, fontSize: 15 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16, paddingBottom: 4 },
  searchBox: { flexDirection: 'row', alignItems: 'center', gap: 8, height: 50, borderRadius: 18, paddingHorizontal: 14, marginBottom: 12, backgroundColor: theme.card, borderWidth: 1, borderColor: theme.border },
  searchInput: { flex: 1, color: theme.textPrimary, fontSize: 13.5, paddingVertical: 0 },
  headerIcon: { width: 52, height: 52, borderRadius: 18, alignItems: 'center', justifyContent: 'center', backgroundColor: `${theme.accent}18`, borderWidth: 1, borderColor: `${theme.accent}45` },
  title: { color: theme.textPrimary, fontSize: 20, fontWeight: '800', fontFamily: FONTS.display, textAlign: 'center' },
  subtitle: { color: theme.textSecondary, fontSize: 12, marginTop: 3, textAlign: 'right' },
  roomFilters: { gap: 8, paddingBottom: 16, paddingRight: 1 },
  roomChip: { flexDirection: 'row', alignItems: 'center', gap: 6, borderRadius: 18, paddingVertical: 9, paddingHorizontal: 13, backgroundColor: theme.card, borderWidth: 1, borderColor: theme.border, maxWidth: 180 },
  roomChipActive: { backgroundColor: theme.accent, borderColor: theme.accent },
  roomChipText: { color: theme.textSecondary, fontSize: 12, fontWeight: '700', maxWidth: 130 },
  roomChipTextActive: { color: readableOn(theme.accent) },
  roomSection: { marginBottom: 6 },
  roomHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 6, marginBottom: 10, gap: 10 },
  roomHeaderInfo: { flex: 1 },
  roomTitle: { color: theme.textPrimary, fontSize: 16, fontWeight: '800', textAlign: 'right' },
  roomMeta: { color: theme.textMuted, fontSize: 11, marginTop: 2, textAlign: 'right' },
  roomOffBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 8, paddingHorizontal: 12, borderRadius: 16, borderWidth: 1, backgroundColor: theme.card },
  roomOffText: { fontSize: 12, fontWeight: '800' },
  card: { minHeight: cp ? 66 : 86, borderRadius: cp ? 18 : 22, marginBottom: cp ? 8 : 12, padding: cp ? 9 : 14, shadowColor: '#000', shadowOpacity: 0.18, shadowRadius: 8, shadowOffset: { width: 0, height: 3 }, elevation: 3, flexDirection: 'row', alignItems: 'center', backgroundColor: theme.card, borderWidth: 1, borderColor: theme.isLight ? theme.border : 'rgba(214,179,106,0.18)' },
  iconBox: { width: cp ? 42 : 54, height: cp ? 42 : 54, borderRadius: cp ? 14 : 18, alignItems: 'center', justifyContent: 'center', borderWidth: 1.4 },
  info: { flex: 1, marginHorizontal: cp ? 9 : 12 },
  name: { color: theme.textPrimary, fontSize: cp ? 13.5 : 15, fontWeight: '700', textAlign: 'right' },
  board: { color: theme.textMuted, fontSize: cp ? 10 : 11, marginTop: cp ? 2 : 4, textAlign: 'right' },
  empty: { alignItems: 'center', justifyContent: 'center', paddingVertical: 90 },
  emptyTitle: { color: theme.textPrimary, fontSize: 17, fontWeight: '700', marginTop: 14 },
  emptyText: { color: theme.textMuted, fontSize: 12, textAlign: 'center', marginTop: 7, maxWidth: 270 },
  statusRow: { flexDirection: 'row', alignItems: 'center', marginTop: 5, gap: 5 },
  statusDot: { width: 7, height: 7, borderRadius: 4 },
  statusText: { fontSize: 11, fontWeight: '700' },
  sep: { color: theme.textMuted, fontSize: 10 },
  overlay: { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, justifyContent: 'center', alignItems: 'center', zIndex: 50 },
  overlayBg: { position: 'absolute', left: 0, right: 0, top: 0, bottom: 0, backgroundColor: '#00000099' },
  modal: { width: '88%', borderRadius: 28, padding: 22, overflow: 'hidden', backgroundColor: theme.isLight ? 'rgba(255,255,255,0.92)' : `${theme.card}EE`, borderWidth: 1.3, borderColor: `${theme.accent}77`, alignItems: 'center' },
  modalIcon: { width: 76, height: 76, borderRadius: 38, alignItems: 'center', justifyContent: 'center', backgroundColor: `${theme.accent}26`, borderWidth: 1.5, borderColor: `${theme.accent}88`, marginBottom: 12 },
  modalTitle: { color: theme.textPrimary, fontSize: 20, fontWeight: '800' },
  modalBoard: { color: theme.textMuted, fontSize: 12, marginTop: 4, marginBottom: 18 },
  detailRow: { width: '100%', flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 11, borderRadius: 16, paddingHorizontal: 14, marginBottom: 7, backgroundColor: theme.isLight ? theme.cardAlt : 'rgba(255,255,255,0.07)', borderWidth: 1, borderColor: theme.isLight ? theme.border : 'rgba(255,255,255,0.1)' },
  detailLabel: { color: theme.textSecondary, fontSize: 12 },
  detailValue: { fontSize: 12, fontWeight: '800' },
  openBoardBtn: { width: '100%', marginTop: 20, paddingVertical: 14, borderRadius: 26, alignItems: 'center', borderWidth: 1.2, borderColor: 'rgba(255,255,255,0.45)' },
  openBoardText: { color: readableOn(theme.accent), fontSize: 13, fontWeight: '800' },
  closeBtn: { paddingVertical: 12 },
  closeText: { color: theme.textSecondary, fontSize: 12, fontWeight: '700' },
}); };
