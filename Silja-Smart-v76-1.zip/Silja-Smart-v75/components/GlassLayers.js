// طبقات الزجاج المشتركة: تدرج لون خفيف + لمعة علوية، بنفس شكل كارت الملخص في الرئيسية.
// الاستخدام: حط <GlassLayers theme={theme} /> أول عنصر جوه الكارت (والكارت يكون overflow:'hidden')،
// وطبّق glassBox(theme) على ستايل الكارت (خلفية شفافة + حدود مضيئة).
import React from 'react';
import { StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { withAlpha } from '../colorUtils';
import { glassAlpha } from '../glassTokens';

export function glassBox(theme, tint) {
  const t = tint || theme.accent;
  const dark = !theme.isLight;
  return {
    backgroundColor: withAlpha(theme.card, glassAlpha(theme, dark ? 0.5 : 0.7)),
    borderWidth: 1.2,
    borderColor: withAlpha(t, dark ? 0.42 : 0.35),
    overflow: 'hidden',
  };
}

export default function GlassLayers({ theme, tint }) {
  const t = tint || theme.accent;
  const dark = !theme.isLight;
  return (
    <>
      <LinearGradient pointerEvents="none" colors={[withAlpha(t, dark ? 0.2 : 0.16), withAlpha(theme.card, 0.15), withAlpha(t, dark ? 0.06 : 0.05)]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} />
      <LinearGradient pointerEvents="none" colors={[`rgba(255,255,255,${dark ? 0.16 : 0.5})`, 'rgba(255,255,255,0)']} start={{ x: 0, y: 0 }} end={{ x: 0.5, y: 0.6 }} style={StyleSheet.absoluteFill} />
    </>
  );
}
