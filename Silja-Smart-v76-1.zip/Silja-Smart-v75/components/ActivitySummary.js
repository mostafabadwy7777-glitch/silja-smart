import React, { useMemo } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import TouchableOpacity from './AnimatedTouchable';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useTheme } from '../ThemeContext';
import { useActivity, deviceIndex } from '../runtimeTracker';
import { clock12 } from '../numfmt';
import GlassLayers, { glassBox } from './GlassLayers';

// كارت صغير في الرئيسية: كام مفتاح شغال دلوقتي + آخر حركة، وبيفتح شاشة التحركات.
export default function ActivitySummary({ boards = [], onPress }) {
  const { theme } = useTheme();
  const styles = getStyles(theme);
  const act = useActivity();
  const { list, byTopic } = useMemo(() => deviceIndex(boards), [boards]);
  if (!list.length) return null;
  const onCount = list.filter((x) => act.isOn[x.key]).length;
  let last = null;
  for (let i = act.events.length - 1; i >= 0; i -= 1) {
    if (byTopic[act.events[i].topic]) { last = act.events[i]; break; }
  }
  const lastItem = last ? byTopic[last.topic] : null;
  return (
    <TouchableOpacity style={[styles.card, glassBox(theme)]} onPress={onPress} activeOpacity={0.85}>
      <GlassLayers theme={theme} />
      <MaterialCommunityIcons name="chevron-left" size={20} color={theme.textMuted} />
      <View style={{ flex: 1 }}>
        <Text style={styles.title}>التحركات</Text>
        <Text numberOfLines={1} style={styles.sub}>
          {onCount > 0 ? `${onCount} شغال دلوقتي` : 'مفيش حاجة شغالة'}
          {lastItem ? `  •  آخر حركة: ${lastItem.device.name || 'مفتاح'} ${last.on ? 'اتشغّل' : 'اتقفل'} ${clock12(last.ts)}` : ''}
        </Text>
      </View>
      <View style={styles.icon}>
        <MaterialCommunityIcons name="chart-timeline-variant" size={20} color={theme.accentSoft} />
      </View>
    </TouchableOpacity>
  );
}

function getStyles(theme) {
  return StyleSheet.create({
    card: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderRadius: 16, borderWidth: 1, borderColor: theme.border, backgroundColor: theme.card, marginBottom: 14 },
    icon: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', backgroundColor: theme.cardAlt, borderWidth: 1, borderColor: theme.border },
    title: { color: theme.textPrimary, fontSize: 14, fontWeight: '800', textAlign: 'right' },
    sub: { color: theme.textSecondary, fontSize: 11.5, textAlign: 'right', marginTop: 2 },
  });
}
