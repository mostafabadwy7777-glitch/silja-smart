// شريط تحكم (Slider) مشترك: سحب أو لمسة في أي مكان، قيمة من 0 لـ 1 بخطوة 0.01.
// direction: 'ltr' عشان الصفر دايمًا على الشمال حتى لو واجهة التطبيق RTL.
import React, { useRef, useState } from 'react';
import { View, PanResponder } from 'react-native';

export default function OpacitySlider({ value, onChange, onCommit, onDragState, theme }) {
  const [w, setW] = useState(0);
  const wRef = useRef(0);
  const valRef = useRef(value);
  valRef.current = value;
  const cb = useRef({});
  cb.current = { onChange, onCommit, onDragState };
  const startX = useRef(0);
  const setFromX = (x) => {
    if (!wRef.current) return;
    const v = Math.round(Math.max(0, Math.min(1, x / wRef.current)) * 100) / 100;
    valRef.current = v;
    cb.current.onChange && cb.current.onChange(v);
  };
  const pan = useRef(PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: () => true,
    onPanResponderTerminationRequest: () => false,
    onPanResponderGrant: (e) => { startX.current = e.nativeEvent.locationX; cb.current.onDragState && cb.current.onDragState(true); setFromX(startX.current); },
    onPanResponderMove: (e, g) => setFromX(startX.current + g.dx),
    onPanResponderRelease: () => { cb.current.onDragState && cb.current.onDragState(false); cb.current.onCommit && cb.current.onCommit(valRef.current); },
    onPanResponderTerminate: () => { cb.current.onDragState && cb.current.onDragState(false); cb.current.onCommit && cb.current.onCommit(valRef.current); },
  })).current;
  const pos = Math.max(0, Math.min(1, value)) * w;
  return (
    <View
      {...pan.panHandlers}
      onLayout={(e) => { const nw = e.nativeEvent.layout.width; wRef.current = nw; setW(nw); }}
      style={{ direction: 'ltr', height: 44, justifyContent: 'center' }}
    >
      <View pointerEvents="none" style={{ height: 10, borderRadius: 5, backgroundColor: theme.border, overflow: 'hidden' }}>
        <View style={{ width: pos, height: 10, backgroundColor: theme.accent }} />
      </View>
      <View
        pointerEvents="none"
        style={{
          position: 'absolute', left: pos - 15, width: 30, height: 30, borderRadius: 15, backgroundColor: theme.accent, borderWidth: 3, borderColor: theme.card,
          shadowColor: theme.accent, shadowOpacity: 0.8, shadowRadius: 8, shadowOffset: { width: 0, height: 0 }, elevation: 4,
        }}
      />
    </View>
  );
}
