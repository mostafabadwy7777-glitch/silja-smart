import React, { useEffect, useMemo, useRef, useState } from 'react';
import { View, Text, StyleSheet, Modal, ScrollView, Animated, Easing } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import TouchableOpacity from './AnimatedTouchable';
import { useTheme, useMotionActive } from '../ThemeContext';
import { withAlpha } from '../colorUtils';
import { getDeviceIcon } from '../deviceIcons';
import { loadHomeFavorites, saveHomeFavorites } from '../storage';
import { pressFeedback, sentFeedback, errorFeedback } from '../feedback';
import { useLastKnown, formatAge } from '../lastKnown';
import GlassLayers, { glassBox } from './GlassLayers';

const keyOf = (board, device) => `${board.id}|${device.controlTopic}`;

// بلاطة مفضلة بتنوّر لما المفتاح يشتغل: تدريج بلون الجهاز (الإضاءة دافية صفراء، الباقي لون "شغال"
// في الثيم)، إطار ملوّن، وهالة بتنبض حوالين الأيقونة. المطفي بيفضل هادي. النبض بيقف مع "حركة أقل".
function FavTile({ theme, styles, x, on, stale, onPress }) {
  const meta = getDeviceIcon(x.device.icon);
  const color = meta.isLight ? '#FFC857' : theme.on;
  const motion = useMotionActive();
  const glow = useRef(new Animated.Value(0)).current;
  useEffect(() => {
    if (!on || !motion) { glow.stopAnimation(); glow.setValue(on ? 0.5 : 0); return undefined; }
    const loop = Animated.loop(Animated.sequence([
      Animated.timing(glow, { toValue: 1, duration: 1500, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      Animated.timing(glow, { toValue: 0, duration: 1500, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
    ]));
    loop.start();
    return () => loop.stop();
  }, [on, motion, glow]);

  return (
    <TouchableOpacity style={[styles.favTile, glassBox(theme, on ? color : undefined), on && { borderColor: color }]} onPress={onPress}>
      <GlassLayers theme={theme} tint={on ? color : undefined} />
      {on && (
        <LinearGradient
          pointerEvents="none"
          colors={[withAlpha(color, 0.26), withAlpha(color, 0.04)]}
          start={{ x: 0.5, y: 0 }}
          end={{ x: 0.5, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
      )}
      <View style={{ width: 44, height: 44, alignItems: 'center', justifyContent: 'center' }}>
        {on && (
          <Animated.View
            pointerEvents="none"
            style={{
              position: 'absolute', width: 44, height: 44, borderRadius: 22, backgroundColor: color,
              opacity: glow.interpolate({ inputRange: [0, 1], outputRange: [0.14, 0.34] }),
              transform: [{ scale: glow.interpolate({ inputRange: [0, 1], outputRange: [0.9, 1.25] }) }],
            }}
          />
        )}
        <MaterialCommunityIcons name={meta.icon} size={24} color={on ? color : theme.textSecondary} />
      </View>
      <Text numberOfLines={1} style={styles.favName}>{x.device.name}</Text>
      <Text style={[styles.favState, { color: on ? color : theme.textMuted }]}>{on ? 'شغال' : 'مطفي'}{stale ? ' ⚠' : ''}</Text>
    </TouchableOpacity>
  );
}

// لوحتين في الرئيسية: "المفضلة" (تحكم سريع بمفاتيح اخترتها) و"شغال دلوقتي"
// (المفاتيح اللي حالتها ON فعلًا، وعليها زرار إطفاء). كله من حالة MQTT الحقيقية.
export default function HomeSwitchPanels({ boards = [], switchStates = {}, client, connected }) {
  const { theme } = useTheme();
  const styles = useMemo(() => getStyles(theme), [theme]);
  const [favs, setFavs] = useState([]);
  const [picker, setPicker] = useState(false);

  useEffect(() => {
    loadHomeFavorites().then(setFavs).catch(() => {});
  }, []);

  // كل المفاتيح العادية (من غير الري والستائر) مع البورد بتاعها.
  const all = useMemo(
    () => boards
      .filter((b) => b.type !== 'irrigation')
      .flatMap((b) => (b.devices || [])
        .filter((d) => d.controlTopic && d.controlType !== 'updown')
        .map((d) => ({ board: b, device: d, key: keyOf(b, d) }))),
    [boards]
  );
  const byKey = useMemo(() => new Map(all.map((x) => [x.key, x])), [all]);
  const getKnown = useLastKnown();
  const topicOf = (x) => x.device.statusTopic || x.device.controlTopic;
  // الحالة الحية أولًا؛ لو مش متاحة (انقطاع الاتصال) بنعرض آخر حالة معروفة بعلامة "قديمة".
  const liveOf = (x) => switchStates[topicOf(x)];
  const knownOf = (x) => (typeof liveOf(x) === 'boolean' ? undefined : getKnown(topicOf(x)));
  const isOn = (x) => (typeof liveOf(x) === 'boolean' ? liveOf(x) === true : !!knownOf(x)?.on);
  const staleLabel = (x) => { const k = knownOf(x); return k ? `⚠ قديمة · ${formatAge(k.ts)}` : ''; };

  const favItems = favs.map((k) => byKey.get(k)).filter(Boolean);
  const activeItems = all.filter(isOn);

  const send = (x, cmd) => {
    if (!connected || !client) return;
    pressFeedback();
    client.publish(x.device.controlTopic, cmd, { qos: 1 }, (error) => {
      if (error) errorFeedback();
      else sentFeedback();
    });
  };
  const toggleFav = (k) => {
    const next = favs.includes(k) ? favs.filter((f) => f !== k) : [...favs, k];
    setFavs(next);
    saveHomeFavorites(next).catch(() => {});
  };

  if (!all.length) return null;

  return (
    <View>
      {/* ---------- المفضلة ---------- */}
      <View style={styles.headRow}>
        <TouchableOpacity onPress={() => setPicker(true)} style={styles.editBtn}>
          <MaterialCommunityIcons name="star-plus-outline" size={16} color={theme.accentSoft} />
          <Text style={styles.editText}>تعديل</Text>
        </TouchableOpacity>
        <Text style={styles.title}>المفضلة</Text>
      </View>
      {favItems.length === 0 ? (
        <TouchableOpacity style={[styles.emptyFav, glassBox(theme)]} onPress={() => setPicker(true)} activeOpacity={0.8}>
          <GlassLayers theme={theme} />
          <MaterialCommunityIcons name="chevron-left" size={20} color={theme.textMuted} />
          <View style={{ flex: 1 }}>
            <Text style={styles.emptyFavTitle}>ضيف مفاتيحك المفضلة</Text>
            <Text style={styles.emptyFavSub}>تحكم سريع في اللي بتستخدمه كتير من الرئيسية</Text>
          </View>
          <View style={styles.emptyFavIcon}>
            <MaterialCommunityIcons name="star-plus-outline" size={20} color={theme.accentSoft} />
          </View>
        </TouchableOpacity>
      ) : (
        <View style={styles.grid}>
          {favItems.map((x) => (
            <FavTile
              key={x.key}
              theme={theme}
              styles={styles}
              x={x}
              on={isOn(x)}
              stale={!!knownOf(x)}
              onPress={() => send(x, isOn(x) ? 'OFF' : 'ON')}
            />
          ))}
        </View>
      )}

      {/* ---------- شغال دلوقتي ---------- */}
      {activeItems.length > 0 && (
        <View style={{ marginTop: 6 }}>
          <View style={styles.headRow}>
            <Text style={styles.count}>{activeItems.length}</Text>
            <Text style={styles.title}>شغال دلوقتي</Text>
          </View>
          {activeItems.map((x) => (
            <View key={x.key} style={styles.activeRow}>
              <TouchableOpacity onPress={() => send(x, 'OFF')} style={styles.offBtn}>
                <MaterialCommunityIcons name="power" size={16} color={theme.off || '#E5484D'} />
                <Text style={[styles.offText, { color: theme.off || '#E5484D' }]}>إطفاء</Text>
              </TouchableOpacity>
              <View style={{ flex: 1 }}>
                <Text numberOfLines={1} style={styles.activeName}>{x.device.name}</Text>
                <Text numberOfLines={1} style={styles.activeBoard}>{x.board.name}{staleLabel(x) ? `  •  ${staleLabel(x)}` : ''}</Text>
              </View>
              <MaterialCommunityIcons name={getDeviceIcon(x.device.icon).icon} size={22} color={theme.on} />
            </View>
          ))}
        </View>
      )}

      {/* ---------- اختيار المفضلة ---------- */}
      <Modal visible={picker} transparent animationType="fade" onRequestClose={() => setPicker(false)}>
        <View style={styles.backdrop}>
          <View style={styles.sheet}>
            <Text style={styles.sheetTitle}>اختار المفاتيح المفضلة</Text>
            <ScrollView style={{ maxHeight: 420 }}>
              {all.map((x) => {
                const on = favs.includes(x.key);
                return (
                  <TouchableOpacity key={x.key} style={styles.pickRow} onPress={() => toggleFav(x.key)}>
                    <MaterialCommunityIcons name={on ? 'star' : 'star-outline'} size={22} color={on ? theme.accentSoft : theme.textMuted} />
                    <View style={{ flex: 1 }}>
                      <Text numberOfLines={1} style={styles.activeName}>{x.device.name}</Text>
                      <Text numberOfLines={1} style={styles.activeBoard}>{x.board.name}</Text>
                    </View>
                    <MaterialCommunityIcons name={getDeviceIcon(x.device.icon).icon} size={20} color={theme.textSecondary} />
                  </TouchableOpacity>
                );
              })}
            </ScrollView>
            <TouchableOpacity style={styles.doneBtn} onPress={() => setPicker(false)}>
              <Text style={styles.doneText}>تم</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

function getStyles(theme) {
  return StyleSheet.create({
    headRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
    title: { color: theme.textPrimary, fontSize: 16, fontWeight: '800' },
    count: { color: theme.on, fontSize: 14, fontWeight: '800' },
    editBtn: { flexDirection: 'row', alignItems: 'center', gap: 4 },
    editText: { color: theme.accentSoft, fontSize: 13, fontWeight: '700' },
    hint: { color: theme.textSecondary, fontSize: 12.5, textAlign: 'right', marginBottom: 12 },
    emptyFav: { flexDirection: 'row', alignItems: 'center', gap: 12, padding: 12, borderRadius: 16, marginBottom: 12 },
    emptyFavIcon: { width: 38, height: 38, borderRadius: 19, alignItems: 'center', justifyContent: 'center', backgroundColor: theme.cardAlt, borderWidth: 1, borderColor: theme.border },
    emptyFavTitle: { color: theme.textPrimary, fontSize: 13.5, fontWeight: '800', textAlign: 'right' },
    emptyFavSub: { color: theme.textSecondary, fontSize: 11.5, textAlign: 'right', marginTop: 2 },
    grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10, marginBottom: 12 },
    favTile: { width: '31%', borderRadius: 18, borderWidth: 1, paddingVertical: 12, paddingHorizontal: 6, alignItems: 'center' },
    favName: { color: theme.textPrimary, fontSize: 12.5, fontWeight: '700', marginTop: 6, maxWidth: '100%' },
    favState: { fontSize: 11, marginTop: 2 },
    activeRow: { flexDirection: 'row', alignItems: 'center', gap: 10, backgroundColor: theme.card, borderRadius: 16, borderWidth: 1, borderColor: theme.border, padding: 12, marginBottom: 8 },
    activeName: { color: theme.textPrimary, fontSize: 14, fontWeight: '700', textAlign: 'right' },
    activeBoard: { color: theme.textMuted, fontSize: 11.5, textAlign: 'right', marginTop: 1 },
    offBtn: { flexDirection: 'row', alignItems: 'center', gap: 4, paddingVertical: 6, paddingHorizontal: 10, borderRadius: 12, borderWidth: 1, borderColor: theme.border },
    offText: { fontSize: 12, fontWeight: '700' },
    backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.55)', justifyContent: 'center', padding: 20 },
    sheet: { backgroundColor: theme.card, borderRadius: 22, padding: 16, borderWidth: 1, borderColor: theme.border },
    sheetTitle: { color: theme.textPrimary, fontSize: 16, fontWeight: '800', textAlign: 'center', marginBottom: 12 },
    pickRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: theme.border },
    doneBtn: { marginTop: 12, backgroundColor: theme.accent, borderRadius: 14, paddingVertical: 12, alignItems: 'center' },
    doneText: { color: '#17140E', fontWeight: '800', fontSize: 15 },
  });
}
