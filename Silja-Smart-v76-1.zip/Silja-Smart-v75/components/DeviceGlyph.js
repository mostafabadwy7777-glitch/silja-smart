// أيقونة الجهاز بشكل أحلى: لما الجهاز يشتغل بتتحوّل لنسخة معبّية (لمبة منوّرة،
// فانوس مضيء...)، والمراوح بتلف، والإضاءة ليها توهج حقيقي: هالات ضوء متدرجة بتتنفّس
// بهدوء + توهج على الأيقونة نفسها. باقي الأجهزة (مراوح/تكييف...) توهج خفيف.
import React, { useEffect, useRef } from 'react';
import { View, Animated, Easing } from 'react-native';
import { usePaneActive } from '../ThemeContext';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { ON_VARIANTS, SPIN_ICONS, LIGHT_GLYPHS } from '../deviceIcons';
import { withAlpha } from '../colorUtils';

// [قطر الهالة كمضاعف لحجم الأيقونة، الشفافية] من الأوسع للأقرب
const LIGHT_HALOS = [[3.0, 0.05], [2.35, 0.09], [1.8, 0.15], [1.35, 0.24]];
const SOFT_HALOS = [[1.9, 0.06], [1.45, 0.11]];

export default function DeviceGlyph({ icon, size = 34, color, isOn = false, glow = true, moving = null }) {
  const move = useRef(new Animated.Value(0)).current;
  const spin = useRef(new Animated.Value(0)).current;
  const breathe = useRef(new Animated.Value(0)).current;
  const shouldSpin = !!isOn && SPIN_ICONS.includes(icon);
  const isLightIcon = LIGHT_GLYPHS.has(icon);
  const showGlow = !!isOn && !!glow;

  const paneActive = usePaneActive(); // التبويب المخفي بيوقّف الحركة
  useEffect(() => {
    if (!paneActive) return undefined; // التبويب مخفي: بنوقّف الحركة
    if (!shouldSpin) {
      spin.stopAnimation();
      spin.setValue(0);
      return undefined;
    }
    const loop = Animated.loop(
      Animated.timing(spin, { toValue: 1, duration: 1300, easing: Easing.linear, useNativeDriver: true })
    );
    loop.start();
    return () => loop.stop();
  }, [shouldSpin, spin, paneActive]);

  // تنفّس الضوء: الهالات بتكبر وتصغر ببطء (للإضاءة بس)
  useEffect(() => {
    if (!paneActive) return undefined; // التبويب مخفي: بنوقّف الحركة
    if (!showGlow || !isLightIcon) {
      breathe.stopAnimation();
      breathe.setValue(0);
      return undefined;
    }
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(breathe, { toValue: 1, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
        Animated.timing(breathe, { toValue: 0, duration: 1800, easing: Easing.inOut(Easing.sin), useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [showGlow, isLightIcon, breathe, paneActive]);

  // الستارة وهي بتتحرك: الأيقونة بتنزلق في اتجاه الحركة وتتلاشى وترجع (لفوق = UP، لتحت = DOWN).
  useEffect(() => {
    if (!paneActive) return undefined; // التبويب مخفي: بنوقّف الحركة
    if (!moving) { move.stopAnimation(); move.setValue(0); return undefined; }
    const loop = Animated.loop(Animated.timing(move, { toValue: 1, duration: 950, easing: Easing.linear, useNativeDriver: true }));
    move.setValue(0);
    loop.start();
    return () => loop.stop();
  }, [moving, move, paneActive]);
  const moveY = move.interpolate({ inputRange: [0, 1], outputRange: moving === 'up' ? [size * 0.18, -size * 0.18] : [-size * 0.18, size * 0.18] });
  const moveOpacity = move.interpolate({ inputRange: [0, 0.2, 0.8, 1], outputRange: [0.25, 1, 1, 0.25] });

  // لو اسم النسخة المعبّية مش موجود في نسخة المكتبة الحالية نفضل على الأصلية.
  const glyphMap = MaterialCommunityIcons.glyphMap || {};
  const onName = ON_VARIANTS[icon];
  const name = isOn && onName && glyphMap[onName] ? onName : icon;
  const rotate = spin.interpolate({ inputRange: [0, 1], outputRange: ['0deg', '360deg'] });
  const haloScale = breathe.interpolate({ inputRange: [0, 1], outputRange: [0.94, 1.08] });
  const haloOpacity = breathe.interpolate({ inputRange: [0, 1], outputRange: [0.8, 1] });

  const halo = (mult, a, key) => {
    const d = size * mult;
    return (
      <View
        key={key}
        pointerEvents="none"
        style={{
          position: 'absolute',
          width: d,
          height: d,
          borderRadius: d / 2,
          top: -(d - size) / 2,
          left: -(d - size) / 2,
          backgroundColor: withAlpha(color, a),
        }}
      />
    );
  };

  const halos = isLightIcon ? LIGHT_HALOS : SOFT_HALOS;

  return (
    <View style={{ width: size, height: size, alignItems: 'center', justifyContent: 'center' }}>
      {showGlow && (
        <Animated.View
          pointerEvents="none"
          style={{
            position: 'absolute', width: size, height: size,
            opacity: isLightIcon ? haloOpacity : 1,
            transform: isLightIcon ? [{ scale: haloScale }] : undefined,
          }}
        >
          {halos.map(([m, a], i) => halo(m, a, i))}
        </Animated.View>
      )}
      <Animated.View style={shouldSpin ? { transform: [{ rotate }] } : moving ? { opacity: moveOpacity, transform: [{ translateY: moveY }] } : null}>
        <MaterialCommunityIcons
          name={name}
          size={size}
          color={color}
          style={showGlow ? { textShadowColor: withAlpha(color, isLightIcon ? 0.95 : 0.6), textShadowRadius: isLightIcon ? size * 0.5 : size * 0.22, textShadowOffset: { width: 0, height: 0 } } : undefined}
        />
      </Animated.View>
    </View>
  );
}
