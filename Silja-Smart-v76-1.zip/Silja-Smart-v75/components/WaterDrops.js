import React, { useEffect, useRef } from 'react';
import { View, Animated, Easing } from 'react-native';
import { usePaneActive } from '../ThemeContext';
import { MaterialCommunityIcons } from '@expo/vector-icons';

// قطرات ماء بتنزل جوه دايرة الري وهي شغالة (الأنيميشن native).
const DROPS = [
  { x: 0.28, delay: 0, dur: 1500, size: 13 },
  { x: 0.5, delay: 500, dur: 1700, size: 16 },
  { x: 0.72, delay: 1000, dur: 1400, size: 12 },
];

function Drop({ x, delay, dur, size, color, box }) {
  const p = useRef(new Animated.Value(0)).current;
  const paneActive = usePaneActive(); // التبويب المخفي بيوقّف الحركة
  useEffect(() => {
    if (!paneActive) return undefined; // التبويب مخفي: بنوقّف الحركة
    const t = setTimeout(() => {
      Animated.loop(Animated.timing(p, { toValue: 1, duration: dur, easing: Easing.in(Easing.quad), useNativeDriver: true })).start();
    }, delay);
    return () => { clearTimeout(t); p.stopAnimation(); };
  }, [p, delay, dur, paneActive]);
  return (
    <Animated.View
      style={{
        position: 'absolute', left: box * x - size / 2, top: 0,
        opacity: p.interpolate({ inputRange: [0, 0.15, 0.8, 1], outputRange: [0, 0.85, 0.6, 0] }),
        transform: [{ translateY: p.interpolate({ inputRange: [0, 1], outputRange: [-size, box] }) }],
      }}
    >
      <MaterialCommunityIcons name="water" size={size} color={color} />
    </Animated.View>
  );
}

export default function WaterDrops({ size = 128, color = '#4FC3F7', active = true }) {
  if (!active) return null;
  return (
    <View pointerEvents="none" style={{ position: 'absolute', width: size, height: size, borderRadius: size / 2, overflow: 'hidden' }}>
      {DROPS.map((d, i) => <Drop key={i} box={size} color={color} {...d} />)}
    </View>
  );
}
