import React, { useEffect, useRef } from 'react';
import { Animated, Easing } from 'react-native';

// ظهور ناعم: العنصر بيطلع من تحت شوية مع تلاشي (fade) وتكبير خفيف لحد حجمه الطبيعي.
// delay بيخلّي العناصر المتجاورة تظهر ورا بعض (Stagger) بدل ما تظهر مرة واحدة.
// بيستخدم الـ native driver فمفيش أي تأثير على سرعة التطبيق.
// الـ delay بيتقلّص ويتحدّد بسقف (240ms) والمدة قصيرة، عشان التنقل يفضل خفيف حتى مع قوائم طويلة.
const MAX_DELAY = 240;
export default function FadeInView({ children, delay = 0, distance = 18, duration = 300, style }) {
  const eff = Math.min(MAX_DELAY, delay * 0.5);
  const p = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const anim = Animated.timing(p, {
      toValue: 1,
      duration,
      delay: eff,
      easing: Easing.out(Easing.cubic),
      useNativeDriver: true,
    });
    anim.start();
    return () => anim.stop();
  }, [p, eff, duration]);

  return (
    <Animated.View
      style={[
        style,
        {
          opacity: p,
          transform: [
            { translateY: p.interpolate({ inputRange: [0, 1], outputRange: [Math.min(distance, 12), 0] }) },
            { scale: p.interpolate({ inputRange: [0, 1], outputRange: [0.96, 1] }) },
          ],
        },
      ]}
    >
      {children}
    </Animated.View>
  );
}
