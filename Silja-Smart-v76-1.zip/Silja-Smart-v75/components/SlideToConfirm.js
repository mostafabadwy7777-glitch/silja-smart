// زرار "اسحب للتأكيد" الزجاجي الكبير: مقبض بتسحبه ناحية أيقونة الإطفاء في آخر المسار عشان ينفّذ
// (أأمن من ضغطة بالغلط). لو سيبته قبل ما يوصل بيرجع بنعومة. direction: 'ltr' عشان السحب دايمًا من الشمال لليمين.
// الشكل: مسار زجاجي شفاف بلمعة علوية، تعبئة ملوّنة بتتبع المقبض، أسهم متحركة بتلمّح بالاتجاه،
// وأيقونة الإطفاء في الآخر بتنوّر كل ما المقبض يقرّب. فيه اهتزاز خفيف لما توصل لنقطة التأكيد.
import React, { useEffect, useRef, useState } from 'react';
import { View, Text, Animated, PanResponder, Easing, I18nManager } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { withAlpha } from '../colorUtils';
import { pressFeedback, confirmFeedback } from '../feedback';
import { useMotionActive } from '../ThemeContext';

const THUMB = 56;
const PAD = 5;
const TRACK_H = THUMB + PAD * 2;
const THRESHOLD = 0.85;
// التطبيق RTL، وفيه الـ left/right بتتقلبوا فعليًا (وخاصية direction:'ltr' مش مضمونة) — فبنحدّد الجهة
// الفيزيقية بنفس طريقة PremiumSwitch: في RTL الـ end هي الشمال الفعلي والـ start هي اليمين.
const RTL = !!I18nManager.isRTL;
const physLeft = (px) => (RTL ? { end: px } : { start: px });
const physRight = (px) => (RTL ? { start: px } : { end: px });

export default function SlideToConfirm({ label, doneLabel = 'تم', icon = 'power', color = '#E5484D', theme, disabled = false, onConfirm, onDragState }) {
  const motion = useMotionActive();
  const [w, setW] = useState(0);
  const [done, setDone] = useState(false);
  const x = useRef(new Animated.Value(0)).current;
  const grab = useRef(new Animated.Value(0)).current; // 1 أثناء السحب (تكبير خفيف للمقبض)
  const hint = useRef(new Animated.Value(0)).current; // موجة الأسهم
  const maxRef = useRef(0);
  const armed = useRef(false); // عدّى نقطة التأكيد (للاهتزاز مرة واحدة)
  const cb = useRef({});
  cb.current = { onConfirm, onDragState, disabled };
  maxRef.current = Math.max(0, w - THUMB - PAD * 2);

  useEffect(() => {
    if (!motion || disabled || done) { hint.stopAnimation(); hint.setValue(0); return undefined; }
    const loop = Animated.loop(Animated.timing(hint, { toValue: 1, duration: 1500, easing: Easing.linear, useNativeDriver: true }));
    loop.start();
    return () => loop.stop();
  }, [motion, disabled, done, hint]);

  const pan = useRef(PanResponder.create({
    onStartShouldSetPanResponder: () => !cb.current.disabled,
    onMoveShouldSetPanResponder: () => !cb.current.disabled,
    onPanResponderTerminationRequest: () => false,
    onPanResponderGrant: () => {
      x.stopAnimation();
      armed.current = false;
      Animated.spring(grab, { toValue: 1, friction: 6, useNativeDriver: true }).start();
      cb.current.onDragState && cb.current.onDragState(true);
    },
    onPanResponderMove: (_, g) => {
      const max = maxRef.current;
      x.setValue(Math.max(0, Math.min(max, g.dx)));
      const reached = max > 0 && g.dx >= max * THRESHOLD;
      if (reached && !armed.current) { armed.current = true; pressFeedback(); }
      else if (!reached && armed.current) armed.current = false;
    },
    onPanResponderRelease: (_, g) => {
      cb.current.onDragState && cb.current.onDragState(false);
      Animated.spring(grab, { toValue: 0, friction: 7, useNativeDriver: true }).start();
      const max = maxRef.current;
      if (max > 0 && g.dx >= max * THRESHOLD) {
        Animated.timing(x, { toValue: max, duration: 120, easing: Easing.out(Easing.quad), useNativeDriver: true }).start(() => {
          setDone(true);
          confirmFeedback();
          cb.current.onConfirm && cb.current.onConfirm();
          setTimeout(() => { setDone(false); Animated.spring(x, { toValue: 0, friction: 7, useNativeDriver: true }).start(); }, 1100);
        });
      } else {
        Animated.spring(x, { toValue: 0, friction: 7, tension: 140, useNativeDriver: true }).start();
      }
    },
    onPanResponderTerminate: () => {
      cb.current.onDragState && cb.current.onDragState(false);
      Animated.spring(grab, { toValue: 0, useNativeDriver: true }).start();
      Animated.spring(x, { toValue: 0, useNativeDriver: true }).start();
    },
  })).current;

  const max = Math.max(1, w - THUMB - PAD * 2);
  const textOpacity = x.interpolate({ inputRange: [0, max * 0.5], outputRange: [1, 0], extrapolate: 'clamp' });
  // التعبئة نفسها (width) مش بتدعم native driver، فبنحرّك scaleX من الحافة الشمال بدلها.
  const fillScale = x.interpolate({ inputRange: [0, max], outputRange: [(THUMB + PAD * 2) / Math.max(1, w), 1], extrapolate: 'clamp' });
  const fillShift = x.interpolate({ inputRange: [0, max], outputRange: [-(w - (THUMB + PAD * 2)) / 2, 0], extrapolate: 'clamp' });
  const targetGlow = x.interpolate({ inputRange: [0, max * 0.6, max], outputRange: [0.35, 0.6, 1], extrapolate: 'clamp' });
  const targetScale = x.interpolate({ inputRange: [0, max], outputRange: [1, 1.25], extrapolate: 'clamp' });
  const thumbScale = grab.interpolate({ inputRange: [0, 1], outputRange: [1, 1.07] });
  const chevA = (i) => { const a = 0.01 + i * 0.18; return hint.interpolate({ inputRange: [0, a, a + 0.15, a + 0.3, 1], outputRange: [0.25, 0.25, 1, 0.25, 0.25], extrapolate: 'clamp' }); };
  const glass = theme.isLight ? 'rgba(255,255,255,0.55)' : 'rgba(255,255,255,0.07)';

  return (
    <View
      onLayout={(e) => setW(e.nativeEvent.layout.width)}
      style={{
        height: TRACK_H, borderRadius: TRACK_H / 2, overflow: 'hidden', justifyContent: 'center',
        borderWidth: 1.3, borderColor: withAlpha(color, 0.55), backgroundColor: glass, opacity: disabled ? 0.5 : 1,
        shadowColor: color, shadowOpacity: 0.35, shadowRadius: 14, shadowOffset: { width: 0, height: 4 }, elevation: 5,
      }}
    >
      {/* خلفية زجاجية: تدرج لون خفيف + لمعة علوية */}
      <LinearGradient pointerEvents="none" colors={[withAlpha(color, 0.16), withAlpha(color, 0.05)]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
      <LinearGradient pointerEvents="none" colors={['rgba(255,255,255,0.28)', 'rgba(255,255,255,0)']} start={{ x: 0.5, y: 0 }} end={{ x: 0.5, y: 0.6 }} style={{ position: 'absolute', top: 0, left: 0, right: 0, height: TRACK_H * 0.6 }} />

      {/* تعبئة التقدّم */}
      {w > 0 && (
        <Animated.View pointerEvents="none" style={{ position: 'absolute', ...physLeft(0), top: 0, bottom: 0, width: w, transform: [{ translateX: fillShift }, { scaleX: fillScale }] }}>
          <LinearGradient colors={[withAlpha(color, 0.55), withAlpha(color, 0.18)]} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={{ flex: 1 }} />
        </Animated.View>
      )}

      {/* هدف الإطفاء في آخر المسار */}
      <Animated.View pointerEvents="none" style={{ position: 'absolute', ...physRight(PAD + 6), width: THUMB - 12, height: THUMB - 12, borderRadius: (THUMB - 12) / 2, alignItems: 'center', justifyContent: 'center', borderWidth: 1.4, borderColor: withAlpha(color, 0.8), backgroundColor: withAlpha(color, 0.14), opacity: targetGlow, transform: [{ scale: targetScale }] }}>
        <MaterialCommunityIcons name="power" size={22} color={color} />
      </Animated.View>

      {/* النص + أسهم التلميح */}
      <Animated.View pointerEvents="none" style={{ position: 'absolute', ...physLeft(THUMB + PAD * 2), ...physRight(THUMB + PAD), alignItems: 'center', justifyContent: 'center', opacity: done ? 0 : textOpacity }}>
        <Text numberOfLines={1} style={{ color: theme.textPrimary, fontSize: 14, fontWeight: '800' }}>{label}</Text>
        <View style={{ flexDirection: RTL ? 'row-reverse' : 'row', marginTop: 1 }}>
          {[1, 2, 3].map((i) => (
            <Animated.View key={i} style={{ opacity: chevA(i - 1) }}>
              <MaterialCommunityIcons name="chevron-right" size={16} color={color} style={{ marginHorizontal: -3 }} />
            </Animated.View>
          ))}
        </View>
      </Animated.View>
      {done && <Text pointerEvents="none" style={{ position: 'absolute', left: 0, right: 0, textAlign: 'center', color: theme.textPrimary, fontSize: 14, fontWeight: '800' }}>{doneLabel}</Text>}

      {/* المقبض الزجاجي */}
      <Animated.View
        {...pan.panHandlers}
        style={{
          position: 'absolute', ...physLeft(PAD), width: THUMB, height: THUMB, borderRadius: THUMB / 2, alignItems: 'center', justifyContent: 'center', overflow: 'hidden',
          borderWidth: 1.4, borderColor: 'rgba(255,255,255,0.6)', transform: [{ translateX: x }, { scale: thumbScale }],
          shadowColor: color, shadowOpacity: 0.9, shadowRadius: 12, shadowOffset: { width: 0, height: 0 }, elevation: 6,
        }}
      >
        <LinearGradient colors={[withAlpha(color, 1), withAlpha(color, 0.72)]} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
        <LinearGradient pointerEvents="none" colors={['rgba(255,255,255,0.5)', 'rgba(255,255,255,0)']} start={{ x: 0, y: 0 }} end={{ x: 0.6, y: 0.9 }} style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }} />
        <MaterialCommunityIcons name={done ? 'check' : icon} size={26} color="#FFFFFF" />
      </Animated.View>
    </View>
  );
}
