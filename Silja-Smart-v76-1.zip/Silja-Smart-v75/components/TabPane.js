import React, { useEffect, useRef } from 'react';
import { Animated, Easing } from 'react-native';
import { PaneActiveContext } from '../ThemeContext';

// لوح تبويب "حي": بيفضل متركّب في الذاكرة بعد أول زيارة ويتخفّي (display:none) بدل ما يتقفل ويتبني من الأول
// كل مرة تبدّل التبويب — ده اللي بيخلّي التنقل السريع ورا بعض فوري. لما التبويب يتفعّل بيدخل بتلاشي خفيف.
export default function TabPane({ active, children }) {
  const p = useRef(new Animated.Value(active ? 1 : 0)).current;
  useEffect(() => {
    if (!active) return undefined;
    p.setValue(0.55);
    const a = Animated.timing(p, { toValue: 1, duration: 150, easing: Easing.out(Easing.quad), useNativeDriver: true });
    a.start();
    return () => a.stop();
  }, [active, p]);
  return (
    <Animated.View
      pointerEvents={active ? 'auto' : 'none'}
      style={{ flex: 1, display: active ? 'flex' : 'none', opacity: p, transform: [{ translateY: p.interpolate({ inputRange: [0, 1], outputRange: [6, 0] }) }] }}
    >
      <PaneActiveContext.Provider value={!!active}>{children}</PaneActiveContext.Provider>
    </Animated.View>
  );
}
