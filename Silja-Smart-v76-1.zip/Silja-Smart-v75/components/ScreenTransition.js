import React, { useEffect, useRef } from 'react';
import { Animated, Easing, I18nManager } from 'react-native';

// انتقال ناعم بين الشاشات بدل التبديل المفاجئ: الشاشة الجديدة بتدخل بتلاشي (fade) مع إزاحة خفيفة.
//  push = فتح شاشة فوق (بتدخل من ناحية "القدام")، pop = رجوع (من الناحية التانية)،
//  tab  = تبديل تبويب من الشريط السفلي (بتطلع من تحت شوية مع تكبير خفيف).
// الحركة بتتحدد مرة واحدة وقت ما الشاشة تتركّب (key={screen} في App.js بيخلّيها تتركّب من جديد
// عند كل تغيير شاشة)، وبتستخدم الـ native driver فمفيش تأثير على الأداء.
const DISTANCE = 16;

export default function ScreenTransition({ mode = 'tab', style, children }) {
  const p = useRef(new Animated.Value(0)).current;
  const modeRef = useRef(mode).current;

  useEffect(() => {
    const anim = Animated.timing(p, { toValue: 1, duration: 180, easing: Easing.out(Easing.quad), useNativeDriver: true });
    anim.start();
    return () => anim.stop();
  }, [p]);

  const dir = I18nManager.isRTL ? -1 : 1;
  let transform;
  if (modeRef === 'push') transform = [{ translateX: p.interpolate({ inputRange: [0, 1], outputRange: [DISTANCE * dir, 0] }) }];
  else if (modeRef === 'pop') transform = [{ translateX: p.interpolate({ inputRange: [0, 1], outputRange: [-DISTANCE * dir, 0] }) }];
  else transform = [
    { translateY: p.interpolate({ inputRange: [0, 1], outputRange: [8, 0] }) },
  ];

  return (
    <Animated.View style={[{ flex: 1 }, style, { opacity: p.interpolate({ inputRange: [0, 1], outputRange: [0.35, 1] }), transform }]}>
      {children}
    </Animated.View>
  );
}
